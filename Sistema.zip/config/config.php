<?php
// Configurações do Sistema
define('APP_NAME', 'Sistema de Gerenciamento - Construtora Kelles Duarte');
define('APP_VERSION', '1.0.0');
define('BASE_URL', 'https://construtorakellesduarte.com.br/sistema/');
define('BASE_PATH', '/sistema');

// Configurações do Banco de Dados
define('DB_HOST', 'localhost');
define('DB_NAME', 'construtorakelle_sistema');
define('DB_USER', 'construtorakelle_sistema');
define('DB_PASS', 'cpsess2205955420'); // Adicionar senha do banco
define('DB_CHARSET', 'utf8mb4');

// Configurações de Timezone e Localização
date_default_timezone_set('America/Sao_Paulo');
setlocale(LC_ALL, 'pt_BR', 'pt_BR.utf-8', 'portuguese');
setlocale(LC_MONETARY, 'pt_BR');

// Configurações de E-mail
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', ''); // Adicionar email
define('SMTP_PASS', ''); // Adicionar senha
define('SMTP_FROM_NAME', 'Construtora Kelles Duarte');
define('SMTP_FROM_EMAIL', 'noreply@construtorakellesduarte.com.br');

// Configurações de Pagamento
define('PIX_CNPJ', '11.030.523/0001-05');
define('PIX_NOME', 'Construtora Kelles Duarte');
define('BANCO_INTER_API_KEY', ''); // Adicionar API Key do Banco Inter
define('BANCO_INTER_CLIENT_ID', ''); // Adicionar Client ID

// Configurações de WhatsApp
define('WHATSAPP_API_URL', ''); // Adicionar URL da API do WhatsApp
define('WHATSAPP_TOKEN', ''); // Adicionar token

// Configurações de Backup
define('BACKUP_PATH', __DIR__ . '/../backups/');
define('BACKUP_RETENTION_DAYS', 30);

// Configurações de Upload
define('UPLOAD_PATH', __DIR__ . '/../uploads/');
define('MAX_FILE_SIZE', 10485760); // 10MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx', 'xls', 'xlsx']);

// Configurações de Segurança
define('SESSION_LIFETIME', 3600); // 1 hora
define('PASSWORD_MIN_LENGTH', 8);
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCKOUT_TIME', 900); // 15 minutos

// Níveis de Acesso
define('NIVEL_ADMIN', 1);
define('NIVEL_CLIENTE', 2);
define('NIVEL_FUNCIONARIO', 3);
define('NIVEL_FINANCEIRO', 4);
define('NIVEL_ENCARREGADO', 5);

// Configurações de Debug (desativar em produção)
define('DEBUG_MODE', true);
if (DEBUG_MODE) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}
