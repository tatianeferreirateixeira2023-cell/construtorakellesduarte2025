<?php
session_start();
require_once 'config/config.php';
require_once 'app/autoload.php';

// Obtém o caminho base do sistema
$basePath = '/sistema';
$requestUri = $_SERVER['REQUEST_URI'];

// Remove o caminho base da URI para roteamento
if (strpos($requestUri, $basePath) === 0) {
    $requestUri = substr($requestUri, strlen($basePath));
}

// Se estiver vazio, define como raiz
if (empty($requestUri) || $requestUri === '/') {
    $requestUri = '/';
}

// Remove query string se houver
$requestUri = parse_url($requestUri, PHP_URL_PATH);

// Verificar se usuário está logado (exceto para rotas públicas)
$publicRoutes = ['/login', '/logout', '/esqueci-senha', '/reset-senha'];
if (!isset($_SESSION['user_id']) && !in_array($requestUri, $publicRoutes)) {
    header('Location: ' . $basePath . '/login');
    exit;
}

// Inicializar roteador
$router = new Router();

// Definir rotas principais
$router->addRoute('/', 'DashboardController@index');
$router->addRoute('/login', 'AuthController@login');
$router->addRoute('/logout', 'AuthController@logout');
$router->addRoute('/dashboard', 'DashboardController@index');
$router->addRoute('/esqueci-senha', 'AuthController@forgotPassword');
$router->addRoute('/reset-senha', 'AuthController@resetPassword');
$router->addRoute('/perfil', 'UsuarioController@profile');
$router->addRoute('/perfil/alterar-senha', 'UsuarioController@alterarSenha');

// Rotas de módulos - Padronizadas para usar criar/salvar e editar/atualizar
$router->addRoute('/usuarios', 'UsuarioController@index');
$router->addRoute('/usuarios/novo', 'UsuarioController@criar');
$router->addRoute('/usuarios/salvar', 'UsuarioController@salvar');
$router->addRoute('/usuarios/editar/:id', 'UsuarioController@editar');
$router->addRoute('/usuarios/atualizar/:id', 'UsuarioController@atualizar');
$router->addRoute('/usuarios/excluir/:id', 'UsuarioController@excluir');
$router->addRoute('/usuarios/profile', 'UsuarioController@profile');
$router->addRoute('/usuarios/alterar-senha', 'UsuarioController@alterarSenha');

// Imóveis
$router->addRoute('/imoveis', 'ImovelController@index');
$router->addRoute('/imoveis/novo', 'ImovelController@criar');
$router->addRoute('/imoveis/criar', 'ImovelController@criar'); // Alias para compatibilidade
$router->addRoute('/imoveis/salvar', 'ImovelController@salvar');
$router->addRoute('/imoveis/editar/:id', 'ImovelController@editar');
$router->addRoute('/imoveis/atualizar/:id', 'ImovelController@atualizar');
$router->addRoute('/imoveis/excluir/:id', 'ImovelController@excluir');

// Empreendimentos
$router->addRoute('/empreendimentos', 'EmpreendimentoController@index');
$router->addRoute('/empreendimentos/novo', 'EmpreendimentoController@criar');
$router->addRoute('/empreendimentos/criar', 'EmpreendimentoController@criar'); // Alias para compatibilidade
$router->addRoute('/empreendimentos/create', 'EmpreendimentoController@criar'); // Alias para compatibilidade (EN)
$router->addRoute('/empreendimentos/salvar', 'EmpreendimentoController@salvar');
$router->addRoute('/empreendimentos/editar/:id', 'EmpreendimentoController@editar');
$router->addRoute('/empreendimentos/atualizar/:id', 'EmpreendimentoController@atualizar');
$router->addRoute('/empreendimentos/excluir/:id', 'EmpreendimentoController@excluir');

// Faturas
$router->addRoute('/faturas', 'FinanceiroController@faturas');
$router->addRoute('/faturas/nova', 'FinanceiroController@criarFatura');
$router->addRoute('/faturas/criar', 'FinanceiroController@criarFatura'); // Alias
$router->addRoute('/faturas/salvar', 'FinanceiroController@salvarFatura');
$router->addRoute('/faturas/editar/:id', 'FinanceiroController@editarFatura');
$router->addRoute('/faturas/atualizar/:id', 'FinanceiroController@atualizarFatura');
$router->addRoute('/faturas/excluir/:id', 'FinanceiroController@excluirFatura');

// Fornecedores
$router->addRoute('/fornecedores', 'FornecedorController@index');
$router->addRoute('/fornecedores/novo', 'FornecedorController@criar');
$router->addRoute('/fornecedores/criar', 'FornecedorController@criar'); // Alias
$router->addRoute('/fornecedores/salvar', 'FornecedorController@salvar');
$router->addRoute('/fornecedores/editar/:id', 'FornecedorController@editar');
$router->addRoute('/fornecedores/atualizar/:id', 'FornecedorController@atualizar');
$router->addRoute('/fornecedores/excluir/:id', 'FornecedorController@excluir');

// Funcionários
$router->addRoute('/funcionarios', 'FuncionarioController@index');
$router->addRoute('/funcionarios/novo', 'FuncionarioController@criar');
$router->addRoute('/funcionarios/criar', 'FuncionarioController@criar'); // Alias
$router->addRoute('/funcionarios/salvar', 'FuncionarioController@salvar');
$router->addRoute('/funcionarios/editar/:id', 'FuncionarioController@editar');
$router->addRoute('/funcionarios/atualizar/:id', 'FuncionarioController@atualizar');
$router->addRoute('/funcionarios/excluir/:id', 'FuncionarioController@excluir');

// Contas a Pagar
$router->addRoute('/contas-pagar', 'FinanceiroController@contasPagar');
$router->addRoute('/contas-pagar/nova', 'FinanceiroController@criarContaPagar');
$router->addRoute('/contas-pagar/criar', 'FinanceiroController@criarContaPagar'); // Alias
$router->addRoute('/contas-pagar/salvar', 'FinanceiroController@salvarContaPagar');
$router->addRoute('/contas-pagar/editar/:id', 'FinanceiroController@editarContaPagar');
$router->addRoute('/contas-pagar/atualizar/:id', 'FinanceiroController@atualizarContaPagar');
$router->addRoute('/contas-pagar/excluir/:id', 'FinanceiroController@excluirContaPagar');

// EPIs
$router->addRoute('/epis', 'EpiController@index');
$router->addRoute('/epis/nova-entrega', 'EpiController@criarEntrega');
$router->addRoute('/epis/salvar-entrega', 'EpiController@salvarEntrega');

// Ocorrências de Obras
$router->addRoute('/obras/ocorrencias', 'ObraController@ocorrencias');
$router->addRoute('/obras/ocorrencias/criar', 'ObraController@criarOcorrencia');
$router->addRoute('/obras/ocorrencias/salvar', 'ObraController@salvarOcorrencia');
$router->addRoute('/obras/ocorrencias/editar/:id', 'ObraController@editarOcorrencia');
$router->addRoute('/obras/ocorrencias/atualizar/:id', 'ObraController@atualizarOcorrencia');

// Compras e Suprimentos
$router->addRoute('/compras', 'CompraController@index');
$router->addRoute('/compras/nova', 'CompraController@criar');
$router->addRoute('/compras/criar', 'CompraController@criar'); // Alias
$router->addRoute('/compras/salvar', 'CompraController@salvar');
$router->addRoute('/compras/editar/:id', 'CompraController@editar');
$router->addRoute('/compras/atualizar/:id', 'CompraController@atualizar');
$router->addRoute('/compras/excluir/:id', 'CompraController@excluir');
$router->addRoute('/financeiro', 'FinanceiroController@index');
$router->addRoute('/faturas', 'FinanceiroController@faturas');
$router->addRoute('/faturas/nova', 'FinanceiroController@criarFatura');
$router->addRoute('/faturas/editar/:id', 'FinanceiroController@editarFatura');
$router->addRoute('/faturas/excluir/:id', 'FinanceiroController@excluirFatura');
$router->addRoute('/faturas/pagar/:id', 'FinanceiroController@pagarFatura');
$router->addRoute('/contas-pagar', 'FinanceiroController@contasPagar');
$router->addRoute('/contas-pagar/nova', 'FinanceiroController@criarContaPagar');
$router->addRoute('/financeiro/contas-pagar/criar', 'FinanceiroController@criarContaPagar');
$router->addRoute('/contas-pagar/editar/:id', 'FinanceiroController@editarContaPagar');
$router->addRoute('/contas-pagar/excluir/:id', 'FinanceiroController@excluirContaPagar');
$router->addRoute('/contas-pagar/pagar/:id', 'FinanceiroController@pagarContaPagar');
$router->addRoute('/obras', 'ObrasController@index');
$router->addRoute('/obras/nova', 'ObrasController@criar');
$router->addRoute('/obras/editar/:id', 'ObrasController@editar');
$router->addRoute('/obras/excluir/:id', 'ObrasController@excluir');
$router->addRoute('/obras/ver/:id', 'ObrasController@ver');
$router->addRoute('/obras/ocorrencias', 'ObrasController@ocorrencias');
$router->addRoute('/obras/ocorrencias/criar', 'ObrasController@criarOcorrencia');
$router->addRoute('/obras/ocorrencias/editar/:id', 'ObrasController@editarOcorrencia');
$router->addRoute('/obras/ocorrencias/ver/:id', 'ObrasController@verOcorrencia');
$router->addRoute('/obras/ocorrencias/excluir/:id', 'ObrasController@excluirOcorrencia');
$router->addRoute('/obras/compras', 'ObrasController@compras');
$router->addRoute('/obras/compras/solicitar', 'ObrasController@solicitarCompra');
$router->addRoute('/obras/compras/ver/:id', 'ObrasController@verCompra');
$router->addRoute('/obras/compras/aprovar/:id', 'ObrasController@aprovarCompra');
$router->addRoute('/obras/compras/rejeitar/:id', 'ObrasController@rejeitarCompra');
$router->addRoute('/obras/compras/marcar-comprado/:id', 'ObrasController@marcarComprado');
$router->addRoute('/obras/compras/marcar-entregue/:id', 'ObrasController@marcarEntregue');
$router->addRoute('/fornecedores', 'FornecedorController@index');
$router->addRoute('/fornecedores/novo', 'FornecedorController@criar');
$router->addRoute('/fornecedores/salvar', 'FornecedorController@salvar');
$router->addRoute('/fornecedores/editar/:id', 'FornecedorController@editar');
$router->addRoute('/fornecedores/atualizar/:id', 'FornecedorController@atualizar');
$router->addRoute('/fornecedores/excluir/:id', 'FornecedorController@excluir');
$router->addRoute('/funcionarios', 'FuncionarioController@index');
$router->addRoute('/funcionarios/novo', 'FuncionarioController@criar');
$router->addRoute('/funcionarios/salvar', 'FuncionarioController@salvar');
$router->addRoute('/funcionarios/editar/:id', 'FuncionarioController@editar');
$router->addRoute('/funcionarios/atualizar/:id', 'FuncionarioController@atualizar');
$router->addRoute('/funcionarios/excluir/:id', 'FuncionarioController@excluir');
$router->addRoute('/funcionarios/cracha/:id', 'FuncionarioController@cracha');
$router->addRoute('/funcionarios/registrar-falta', 'FuncionarioController@registrarFalta');
$router->addRoute('/funcionarios/excluir-falta/:id', 'FuncionarioController@excluirFalta');
$router->addRoute('/compras', 'ComprasController@index');
$router->addRoute('/epis', 'FuncionarioController@epis');
$router->addRoute('/epis/nova-entrega', 'FuncionarioController@novaEntregaEpi');
$router->addRoute('/epis/registrar-entrega', 'FuncionarioController@registrarEntregaEpi');
$router->addRoute('/epis/devolver/:id', 'FuncionarioController@devolverEpi');
$router->addRoute('/epis/excluir/:id', 'FuncionarioController@excluirEpi');
$router->addRoute('/faltas', 'FuncionarioController@faltas');
$router->addRoute('/ocorrencias', 'ObrasController@ocorrencias');
$router->addRoute('/manutencoes', 'ImovelController@manutencoes');
$router->addRoute('/manutencoes/nova', 'ImovelController@criarManutencao');
$router->addRoute('/manutencoes/editar/:id', 'ImovelController@editarManutencao');
$router->addRoute('/manutencoes/excluir/:id', 'ImovelController@excluirManutencao');
$router->addRoute('/relatorios', 'RelatorioController@index');
$router->addRoute('/relatorios/financeiro', 'RelatorioController@financeiro');
$router->addRoute('/relatorios/obras', 'RelatorioController@obras');
$router->addRoute('/relatorios/imoveis', 'RelatorioController@imoveis');
$router->addRoute('/relatorios/personalizado', 'RelatorioController@personalizado');
$router->addRoute('/relatorios/fornecedores', 'RelatorioController@fornecedores');
$router->addRoute('/relatorios/funcionarios', 'RelatorioController@funcionarios');
$router->addRoute('/relatorios/exportar', 'RelatorioController@exportar');
$router->addRoute('/backup', 'BackupController@index');
$router->addRoute('/backup/criar', 'BackupController@criar');
$router->addRoute('/backup/download/:filename', 'BackupController@download');
$router->addRoute('/backup/deletar/:filename', 'BackupController@deletar');
$router->addRoute('/backup/restaurar/:filename', 'BackupController@restaurar');
$router->addRoute('/logs', 'LogController@index');
$router->addRoute('/logs/limpar', 'LogController@limpar');
$router->addRoute('/logs/exportar', 'LogController@exportar');
$router->addRoute('/notificacoes', 'NotificacaoController@index');
$router->addRoute('/notificacoes/marcar-lida', 'NotificacaoController@marcarLida');
$router->addRoute('/notificacoes/marcar-todas-lidas', 'NotificacaoController@marcarTodasLidas');
$router->addRoute('/notificacoes/excluir/:id', 'NotificacaoController@excluir');
$router->addRoute('/notificacoes/limpar-antigas', 'NotificacaoController@limparAntigas');
$router->addRoute('/notificacoes/obter-nao-lidas', 'NotificacaoController@obterNaoLidas');
$router->addRoute('/notificacoes/criar', 'NotificacaoController@criar');

// Rotas específicas por nível
$router->addRoute('/meus-imoveis', 'ImovelController@meusImoveis');
$router->addRoute('/minhas-faturas', 'FinanceiroController@minhasFaturas');
$router->addRoute('/meu-perfil', 'UsuarioController@profile');

// Processar rota
$router->dispatch($requestUri);

