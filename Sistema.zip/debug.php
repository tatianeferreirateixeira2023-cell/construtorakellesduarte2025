<?php
session_start();
require_once 'config/config.php';

echo "<h1>Debug do Sistema</h1>";
echo "<hr>";

echo "<h2>1. Sessão</h2>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

echo "<h2>2. Constantes</h2>";
echo "BASE_URL: " . BASE_URL . "<br>";
echo "BASE_PATH: " . BASE_PATH . "<br>";

echo "<h2>3. Servidor</h2>";
echo "REQUEST_URI: " . $_SERVER['REQUEST_URI'] . "<br>";
echo "SCRIPT_NAME: " . $_SERVER['SCRIPT_NAME'] . "<br>";
echo "PHP_SELF: " . $_SERVER['PHP_SELF'] . "<br>";
echo "DOCUMENT_ROOT: " . $_SERVER['DOCUMENT_ROOT'] . "<br>";

echo "<h2>4. Teste de Redirecionamento</h2>";
echo "Se você clicar no link abaixo, deve ir para o dashboard:<br>";
echo "<a href='" . BASE_PATH . "/'>Ir para Dashboard (BASE_PATH + /)</a><br>";
echo "<a href='" . BASE_PATH . "/login'>Ir para Login</a><br>";
echo "<a href='" . BASE_PATH . "/logout'>Fazer Logout</a><br>";

echo "<h2>5. Status do Login</h2>";
if (isset($_SESSION['user_id'])) {
    echo "✅ Usuário logado<br>";
    echo "ID: " . $_SESSION['user_id'] . "<br>";
    echo "Nome: " . ($_SESSION['user_name'] ?? 'Não definido') . "<br>";
    echo "Nível: " . ($_SESSION['user_nivel'] ?? 'Não definido') . "<br>";
} else {
    echo "❌ Usuário não logado<br>";
}

echo "<h2>6. Teste de Banco de Dados</h2>";
try {
    require_once 'app/autoload.php';
    $db = Database::getInstance();
    
    // Verifica se existe o usuário admin
    $sql = "SELECT * FROM usuarios WHERE email = 'admin@construtorakellesduarte.com.br'";
    $stmt = $db->query($sql);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($admin) {
        echo "✅ Usuário admin encontrado<br>";
        echo "ID: " . $admin['id'] . "<br>";
        echo "Nome: " . $admin['nome_completo'] . "<br>";
        echo "Nível: " . $admin['nivel_acesso_id'] . "<br>";
        
        // Testa a senha
        $senhaCorreta = password_verify('Admin@2024', $admin['senha']);
        echo "Senha Admin@2024: " . ($senhaCorreta ? '✅ Correta' : '❌ Incorreta') . "<br>";
    } else {
        echo "❌ Usuário admin não encontrado<br>";
    }
} catch (Exception $e) {
    echo "❌ Erro no banco: " . $e->getMessage() . "<br>";
}

echo "<hr>";
echo "<h2>7. Ações</h2>";
echo "<a href='" . BASE_PATH . "/test.php'>Ir para Test.php</a><br>";
echo "<a href='" . BASE_PATH . "/'>Tentar acessar o sistema</a><br>";
