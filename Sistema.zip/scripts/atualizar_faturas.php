<?php
/**
 * Script para atualizar status de faturas vencidas
 * Executar diariamente às 6:00 AM
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../app/core/Database.php';

class AtualizadorFaturas {
    private $db;
    private $totalAtualizadas = 0;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    public function run() {
        echo "[" . date('Y-m-d H:i:s') . "] Iniciando atualização de faturas...\n";
        
        // Atualiza faturas vencidas
        $this->atualizarFaturasVencidas();
        
        // Atualiza status de inadimplentes
        $this->atualizarStatusClientes();
        
        // Gera relatório
        $this->gerarRelatorio();
        
        echo "[" . date('Y-m-d H:i:s') . "] Atualização concluída. Total: {$this->totalAtualizadas} faturas\n";
    }
    
    private function atualizarFaturasVencidas() {
        // Busca faturas em aberto com vencimento passado
        $sql = "UPDATE faturas 
                SET status = 'vencido' 
                WHERE status = 'em_aberto' 
                AND data_vencimento < CURDATE()";
        
        $stmt = $this->db->execute($sql);
        $this->totalAtualizadas = $stmt->rowCount();
        
        echo "- Faturas marcadas como vencidas: {$this->totalAtualizadas}\n";
        
        // Registra no log
        if ($this->totalAtualizadas > 0) {
            $this->registrarLog("Atualizadas {$this->totalAtualizadas} faturas para status vencido");
        }
    }
    
    private function atualizarStatusClientes() {
        // Identifica clientes com 3 ou mais faturas vencidas
        $sql = "SELECT cliente_id, COUNT(*) as total_vencidas, SUM(valor) as total_devido
                FROM faturas
                WHERE status = 'vencido'
                GROUP BY cliente_id
                HAVING total_vencidas >= 3";
        
        $inadimplentes = $this->db->fetchAll($sql);
        
        foreach ($inadimplentes as $cliente) {
            // Aqui você pode adicionar lógica adicional
            // Como marcar o cliente como inadimplente, bloquear novos serviços, etc.
            echo "- Cliente ID {$cliente['cliente_id']}: {$cliente['total_vencidas']} faturas vencidas, ";
            echo "Total devido: R$ " . number_format($cliente['total_devido'], 2, ',', '.') . "\n";
        }
        
        if (count($inadimplentes) > 0) {
            $this->registrarLog("Identificados " . count($inadimplentes) . " clientes inadimplentes");
        }
    }
    
    private function gerarRelatorio() {
        // Estatísticas gerais
        $stats = [];
        
        // Total de faturas por status
        $sql = "SELECT status, COUNT(*) as total, SUM(valor) as valor_total
                FROM faturas
                GROUP BY status";
        
        $stats['por_status'] = $this->db->fetchAll($sql);
        
        // Faturas vencendo hoje
        $sql = "SELECT COUNT(*) as total, SUM(valor) as valor_total
                FROM faturas
                WHERE data_vencimento = CURDATE()
                AND status = 'em_aberto'";
        
        $stats['vencendo_hoje'] = $this->db->fetchOne($sql);
        
        // Faturas vencendo nos próximos 7 dias
        $sql = "SELECT COUNT(*) as total, SUM(valor) as valor_total
                FROM faturas
                WHERE data_vencimento BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)
                AND status = 'em_aberto'";
        
        $stats['proximos_7_dias'] = $this->db->fetchOne($sql);
        
        // Exibe relatório
        echo "\n=== RELATÓRIO DE FATURAS ===\n";
        echo "Data: " . date('d/m/Y H:i:s') . "\n\n";
        
        echo "Por Status:\n";
        foreach ($stats['por_status'] as $status) {
            echo "- {$status['status']}: {$status['total']} faturas - ";
            echo "R$ " . number_format($status['valor_total'], 2, ',', '.') . "\n";
        }
        
        echo "\nVencendo Hoje: {$stats['vencendo_hoje']['total']} faturas - ";
        echo "R$ " . number_format($stats['vencendo_hoje']['valor_total'], 2, ',', '.') . "\n";
        
        echo "Próximos 7 dias: {$stats['proximos_7_dias']['total']} faturas - ";
        echo "R$ " . number_format($stats['proximos_7_dias']['valor_total'], 2, ',', '.') . "\n";
        
        // Salva relatório em arquivo
        $this->salvarRelatorio($stats);
    }
    
    private function salvarRelatorio($stats) {
        $reportPath = __DIR__ . '/../reports/';
        if (!file_exists($reportPath)) {
            mkdir($reportPath, 0777, true);
        }
        
        $filename = $reportPath . 'faturas_' . date('Y-m-d') . '.json';
        file_put_contents($filename, json_encode($stats, JSON_PRETTY_PRINT));
    }
    
    private function registrarLog($mensagem) {
        $this->db->insert('logs_acesso', [
            'usuario_id' => 0, // Sistema
            'ip_address' => '127.0.0.1',
            'user_agent' => 'Sistema Automático',
            'pagina' => 'scripts/atualizar_faturas.php',
            'acao' => 'atualizar_faturas',
            'descricao' => $mensagem
        ]);
    }
}

// Executa o script
$atualizador = new AtualizadorFaturas();
$atualizador->run();
