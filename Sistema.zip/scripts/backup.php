<?php
/**
 * Script de Backup Automático
 * Executa backup do banco de dados e arquivos do sistema
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../app/core/Database.php';

class BackupSystem {
    private $db;
    private $backupPath;
    private $logFile;
    
    public function __construct() {
        $this->db = Database::getInstance();
        $this->backupPath = BACKUP_PATH;
        $this->logFile = __DIR__ . '/../logs/backup.log';
        
        // Cria diretório de backup se não existir
        if (!file_exists($this->backupPath)) {
            mkdir($this->backupPath, 0777, true);
        }
    }
    
    public function run() {
        $this->log("Iniciando processo de backup...");
        
        $tipo = $this->determinarTipoBackup();
        $timestamp = date('Y-m-d_H-i-s');
        
        try {
            switch ($tipo) {
                case 'diario':
                    $this->backupDiario($timestamp);
                    break;
                case 'semanal':
                    $this->backupSemanal($timestamp);
                    break;
                case 'mensal':
                    $this->backupMensal($timestamp);
                    break;
            }
            
            // Limpa backups antigos
            $this->limparBackupsAntigos();
            
            // Registra no banco
            $this->registrarBackup($tipo, 'sucesso', 'Backup realizado com sucesso');
            
            $this->log("Backup $tipo concluído com sucesso!");
            
        } catch (Exception $e) {
            $this->log("ERRO: " . $e->getMessage());
            $this->registrarBackup($tipo, 'erro', $e->getMessage());
        }
    }
    
    private function backupDiario($timestamp) {
        // Backup apenas do banco de dados
        $filename = "backup_diario_{$timestamp}.sql";
        $filepath = $this->backupPath . $filename;
        
        $this->backupDatabase($filepath);
        
        // Compacta o arquivo
        $this->compactarArquivo($filepath);
    }
    
    private function backupSemanal($timestamp) {
        // Backup do banco + arquivos importantes
        $filename = "backup_semanal_{$timestamp}";
        $dbFile = $this->backupPath . $filename . "_db.sql";
        
        // Backup do banco
        $this->backupDatabase($dbFile);
        
        // Cria arquivo ZIP com banco + uploads
        $zipFile = $this->backupPath . $filename . ".zip";
        $zip = new ZipArchive();
        
        if ($zip->open($zipFile, ZipArchive::CREATE) === TRUE) {
            // Adiciona backup do banco
            $zip->addFile($dbFile, basename($dbFile));
            
            // Adiciona pasta de uploads
            $this->addFolderToZip($zip, UPLOAD_PATH, 'uploads');
            
            $zip->close();
            
            // Remove arquivo SQL temporário
            unlink($dbFile);
        }
    }
    
    private function backupMensal($timestamp) {
        // Backup completo do sistema
        $filename = "backup_mensal_{$timestamp}.zip";
        $filepath = $this->backupPath . $filename;
        
        // Primeiro faz backup do banco
        $dbFile = $this->backupPath . "temp_db_{$timestamp}.sql";
        $this->backupDatabase($dbFile);
        
        $zip = new ZipArchive();
        
        if ($zip->open($filepath, ZipArchive::CREATE) === TRUE) {
            // Adiciona backup do banco
            $zip->addFile($dbFile, "database/backup.sql");
            
            // Adiciona todas as pastas importantes
            $this->addFolderToZip($zip, __DIR__ . '/../app', 'app');
            $this->addFolderToZip($zip, __DIR__ . '/../views', 'views');
            $this->addFolderToZip($zip, __DIR__ . '/../config', 'config');
            $this->addFolderToZip($zip, UPLOAD_PATH, 'uploads');
            
            $zip->close();
            
            // Remove arquivo SQL temporário
            unlink($dbFile);
        }
    }
    
    private function backupDatabase($filepath) {
        $host = DB_HOST;
        $dbname = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASS;
        
        // Comando mysqldump
        $command = "mysqldump --host=$host --user=$user --password=$pass " .
                   "--single-transaction --routines --triggers --events " .
                   "$dbname > $filepath 2>&1";
        
        exec($command, $output, $return);
        
        if ($return !== 0) {
            throw new Exception("Erro ao executar mysqldump: " . implode("\n", $output));
        }
        
        return true;
    }
    
    private function addFolderToZip($zip, $folder, $zipPath) {
        if (!file_exists($folder)) {
            return;
        }
        
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($folder, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        
        foreach ($iterator as $file) {
            if (!$file->isDir()) {
                $filePath = $file->getRealPath();
                $relativePath = $zipPath . '/' . str_replace($folder . '/', '', $filePath);
                $zip->addFile($filePath, $relativePath);
            }
        }
    }
    
    private function compactarArquivo($filepath) {
        $zipFile = $filepath . '.zip';
        $zip = new ZipArchive();
        
        if ($zip->open($zipFile, ZipArchive::CREATE) === TRUE) {
            $zip->addFile($filepath, basename($filepath));
            $zip->close();
            
            // Remove arquivo original
            unlink($filepath);
            
            return $zipFile;
        }
        
        return false;
    }
    
    private function determinarTipoBackup() {
        $diaSemana = date('w'); // 0 = Domingo, 6 = Sábado
        $diaMes = date('j');
        
        // Mensal: dia 1 de cada mês
        if ($diaMes == 1) {
            return 'mensal';
        }
        
        // Semanal: todos os domingos
        if ($diaSemana == 0) {
            return 'semanal';
        }
        
        // Diário: todos os outros dias
        return 'diario';
    }
    
    private function limparBackupsAntigos() {
        $files = glob($this->backupPath . "*.{sql,zip}", GLOB_BRACE);
        $now = time();
        $diasRetencao = BACKUP_RETENTION_DAYS * 86400; // Converte dias para segundos
        
        foreach ($files as $file) {
            if (is_file($file)) {
                if ($now - filemtime($file) >= $diasRetencao) {
                    unlink($file);
                    $this->log("Backup antigo removido: " . basename($file));
                }
            }
        }
    }
    
    private function registrarBackup($tipo, $status, $mensagem) {
        $data = [
            'tipo' => $tipo,
            'arquivo' => $this->getUltimoBackup(),
            'tamanho' => $this->getTamanhoUltimoBackup(),
            'status' => $status,
            'mensagem' => $mensagem
        ];
        
        $this->db->insert('backups', $data);
    }
    
    private function getUltimoBackup() {
        $files = glob($this->backupPath . "*.{sql,zip}", GLOB_BRACE);
        if (empty($files)) {
            return null;
        }
        
        usort($files, function($a, $b) {
            return filemtime($b) - filemtime($a);
        });
        
        return basename($files[0]);
    }
    
    private function getTamanhoUltimoBackup() {
        $arquivo = $this->getUltimoBackup();
        if ($arquivo) {
            $filepath = $this->backupPath . $arquivo;
            if (file_exists($filepath)) {
                return filesize($filepath);
            }
        }
        return 0;
    }
    
    private function log($message) {
        $timestamp = date('Y-m-d H:i:s');
        $logMessage = "[$timestamp] $message" . PHP_EOL;
        
        // Cria diretório de logs se não existir
        $logDir = dirname($this->logFile);
        if (!file_exists($logDir)) {
            mkdir($logDir, 0777, true);
        }
        
        file_put_contents($this->logFile, $logMessage, FILE_APPEND);
        
        // Também imprime na tela se executado via CLI
        if (php_sapi_name() === 'cli') {
            echo $logMessage;
        }
    }
}

// Executa o backup
$backup = new BackupSystem();
$backup->run();
