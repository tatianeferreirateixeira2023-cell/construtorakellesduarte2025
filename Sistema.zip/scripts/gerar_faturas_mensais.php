<?php
/**
 * Script para gerar faturas mensais automaticamente
 * Executar no dia 1 de cada mês às 6:00 AM
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../app/core/Database.php';
require_once __DIR__ . '/../app/services/NotificationService.php';

class GeradorFaturasMensais {
    private $db;
    private $notifier;
    private $totalGeradas = 0;
    private $mesReferencia;
    
    public function __construct() {
        $this->db = Database::getInstance();
        $this->notifier = new NotificationService();
        $this->mesReferencia = date('Y-m');
    }
    
    public function run() {
        echo "[" . date('Y-m-d H:i:s') . "] Iniciando geração de faturas mensais...\n";
        echo "Mês de referência: " . $this->mesReferencia . "\n\n";
        
        // Gera faturas para imóveis vendidos com parcelas ativas
        $this->gerarFaturasImoveis();
        
        // Gera faturas de serviços recorrentes (se houver)
        $this->gerarFaturasServicos();
        
        // Envia notificações
        $this->enviarNotificacoes();
        
        // Gera relatório
        $this->gerarRelatorio();
        
        echo "\n[" . date('Y-m-d H:i:s') . "] Geração concluída. Total: {$this->totalGeradas} faturas\n";
    }
    
    private function gerarFaturasImoveis() {
        echo "=== GERANDO FATURAS DE IMÓVEIS ===\n";
        
        // Busca imóveis vendidos com financiamento ativo
        $sql = "SELECT i.*, u.id as cliente_id, u.nome_completo, u.email, u.telefone
                FROM imoveis i
                JOIN usuarios u ON i.cliente_id = u.id
                WHERE i.status = 'vendido'
                AND i.quantidade_parcelas > 0
                AND i.valor_parcela > 0";
        
        $imoveis = $this->db->fetchAll($sql);
        
        foreach ($imoveis as $imovel) {
            // Verifica se já existe fatura para este mês
            $existeFatura = $this->verificarFaturaExistente($imovel['id'], $this->mesReferencia);
            
            if (!$existeFatura) {
                $faturaId = $this->gerarFatura($imovel);
                
                if ($faturaId) {
                    echo "- Fatura gerada para {$imovel['nome_completo']} - Imóvel #{$imovel['id']}\n";
                    $this->totalGeradas++;
                    
                    // Envia notificação de nova fatura
                    $this->notifier->notificarNovaFatura($faturaId);
                }
            } else {
                echo "- Fatura já existe para {$imovel['nome_completo']} - Imóvel #{$imovel['id']}\n";
            }
        }
        
        if (count($imoveis) == 0) {
            echo "Nenhum imóvel com parcelas ativas encontrado.\n";
        }
        
        echo "\n";
    }
    
    private function gerarFaturasServicos() {
        echo "=== GERANDO FATURAS DE SERVIÇOS ===\n";
        
        // Aqui você pode adicionar lógica para gerar faturas de:
        // - Taxas de manutenção
        // - Condomínio
        // - Outros serviços recorrentes
        
        // Exemplo: Taxa de manutenção mensal
        $sql = "SELECT DISTINCT c.id as cliente_id, c.nome_completo, c.email, c.telefone
                FROM usuarios c
                JOIN imoveis i ON i.cliente_id = c.id
                WHERE c.nivel_acesso_id = " . NIVEL_CLIENTE . "
                AND i.status = 'vendido'
                AND EXISTS (
                    SELECT 1 FROM empreendimentos e
                    WHERE e.id = i.empreendimento_id
                    AND e.status = 'concluido'
                )";
        
        $clientes = $this->db->fetchAll($sql);
        
        // Por enquanto, apenas mostra que poderia gerar
        if (count($clientes) > 0) {
            echo "- " . count($clientes) . " clientes identificados para possíveis taxas de serviço\n";
        } else {
            echo "- Nenhum serviço recorrente configurado\n";
        }
        
        echo "\n";
    }
    
    private function gerarFatura($imovel) {
        // Calcula número da parcela
        $sql = "SELECT COUNT(*) as total_parcelas 
                FROM faturas 
                WHERE imovel_id = :imovel_id";
        
        $result = $this->db->fetchOne($sql, ['imovel_id' => $imovel['id']]);
        $numeroParcela = ($result['total_parcelas'] ?? 0) + 1;
        
        // Se já atingiu o número máximo de parcelas, não gera
        if ($numeroParcela > $imovel['quantidade_parcelas']) {
            return false;
        }
        
        // Gera número único da fatura
        $numeroFatura = sprintf('%s-%04d-%03d', 
            date('Ym'),
            $imovel['id'],
            $numeroParcela
        );
        
        // Calcula data de vencimento (dia 10 do mês)
        $dataVencimento = date('Y-m-10');
        
        // Dados da fatura
        $faturaData = [
            'imovel_id' => $imovel['id'],
            'cliente_id' => $imovel['cliente_id'],
            'numero_fatura' => $numeroFatura,
            'valor' => $imovel['valor_parcela'],
            'data_vencimento' => $dataVencimento,
            'status' => 'em_aberto',
            'observacoes' => "Parcela {$numeroParcela}/{$imovel['quantidade_parcelas']}"
        ];
        
        // Insere fatura
        $faturaId = $this->db->insert('faturas', $faturaData);
        
        if ($faturaId) {
            // Registra log
            $this->registrarLog("Fatura gerada automaticamente: #{$numeroFatura}");
            
            // Gera código PIX
            $this->gerarCodigoPix($faturaId, $imovel['valor_parcela']);
        }
        
        return $faturaId;
    }
    
    private function verificarFaturaExistente($imovelId, $mesReferencia) {
        $sql = "SELECT COUNT(*) as total 
                FROM faturas 
                WHERE imovel_id = :imovel_id 
                AND DATE_FORMAT(created_at, '%Y-%m') = :mes";
        
        $result = $this->db->fetchOne($sql, [
            'imovel_id' => $imovelId,
            'mes' => $mesReferencia
        ]);
        
        return $result['total'] > 0;
    }
    
    private function gerarCodigoPix($faturaId, $valor) {
        // Gera código PIX simplificado
        $valor = number_format($valor, 2, '', '');
        $txid = 'FAT' . str_pad($faturaId, 10, '0', STR_PAD_LEFT);
        
        $pixCode = "00020126360014BR.GOV.BCB.PIX0114" . str_replace(['.', '/', '-'], '', PIX_CNPJ);
        $pixCode .= "5204000053039865402" . $valor;
        $pixCode .= "5802BR5925CONSTRUTORA KELLES DUARTE6007ITABIRA";
        $pixCode .= "62070503" . $txid;
        
        // Atualiza fatura com código PIX
        $this->db->update('faturas', ['pix_codigo' => $pixCode], 'id = :id', ['id' => $faturaId]);
        
        return $pixCode;
    }
    
    private function enviarNotificacoes() {
        echo "=== ENVIANDO NOTIFICAÇÕES ===\n";
        
        // Busca todas as faturas geradas hoje
        $sql = "SELECT f.*, u.nome_completo, u.email, u.telefone
                FROM faturas f
                JOIN usuarios u ON f.cliente_id = u.id
                WHERE DATE(f.created_at) = CURDATE()";
        
        $faturas = $this->db->fetchAll($sql);
        
        foreach ($faturas as $fatura) {
            echo "- Notificando {$fatura['nome_completo']} sobre fatura #{$fatura['numero_fatura']}\n";
            
            // E-mail
            $subject = "Nova Fatura Disponível - Construtora Kelles Duarte";
            $body = $this->gerarCorpoEmail($fatura);
            $this->notifier->sendEmail($fatura['email'], $subject, $body);
            
            // WhatsApp
            $whatsappMsg = $this->gerarMensagemWhatsApp($fatura);
            $this->notifier->sendWhatsApp($fatura['telefone'], $whatsappMsg);
            
            // Registra envio
            $this->db->insert('lembretes_faturas', [
                'fatura_id' => $fatura['id'],
                'tipo' => 'lancamento',
                'enviado_whatsapp' => 1,
                'enviado_email' => 1,
                'data_envio' => date('Y-m-d H:i:s')
            ]);
        }
        
        echo "Total de notificações enviadas: " . count($faturas) . "\n\n";
    }
    
    private function gerarCorpoEmail($fatura) {
        $body = "Prezado(a) {$fatura['nome_completo']},\n\n";
        $body .= "Sua fatura mensal já está disponível para pagamento.\n\n";
        $body .= "=== DETALHES DA FATURA ===\n";
        $body .= "Número: {$fatura['numero_fatura']}\n";
        $body .= "Valor: R$ " . number_format($fatura['valor'], 2, ',', '.') . "\n";
        $body .= "Vencimento: " . date('d/m/Y', strtotime($fatura['data_vencimento'])) . "\n\n";
        $body .= "=== FORMAS DE PAGAMENTO ===\n";
        $body .= "PIX: Use o CNPJ " . PIX_CNPJ . "\n";
        $body .= "Boleto: Acesse o sistema para gerar\n\n";
        $body .= "Para sua comodidade, efetue o pagamento até a data de vencimento ";
        $body .= "e evite multas e juros.\n\n";
        $body .= "Em caso de dúvidas, entre em contato conosco.\n\n";
        $body .= "Atenciosamente,\n";
        $body .= "Construtora Kelles Duarte\n";
        $body .= "www.construtorakellesduarte.com.br";
        
        return $body;
    }
    
    private function gerarMensagemWhatsApp($fatura) {
        $msg = "🏠 *Construtora Kelles Duarte*\n\n";
        $msg .= "Olá, {$fatura['nome_completo']}!\n\n";
        $msg .= "📄 *Nova Fatura Disponível*\n\n";
        $msg .= "Número: *{$fatura['numero_fatura']}*\n";
        $msg .= "Valor: *R$ " . number_format($fatura['valor'], 2, ',', '.') . "*\n";
        $msg .= "Vencimento: *" . date('d/m/Y', strtotime($fatura['data_vencimento'])) . "*\n\n";
        $msg .= "💳 *Formas de Pagamento:*\n";
        $msg .= "• PIX CNPJ: " . PIX_CNPJ . "\n";
        $msg .= "• Boleto no sistema\n\n";
        $msg .= "📱 Acesse o sistema para mais detalhes.\n\n";
        $msg .= "_Evite multas, pague em dia!_ ✅";
        
        return $msg;
    }
    
    private function gerarRelatorio() {
        echo "=== RELATÓRIO DE GERAÇÃO ===\n";
        
        // Estatísticas
        $stats = [
            'data_geracao' => date('Y-m-d H:i:s'),
            'mes_referencia' => $this->mesReferencia,
            'total_geradas' => $this->totalGeradas,
            'valor_total' => 0,
            'faturas' => []
        ];
        
        // Busca detalhes das faturas geradas
        $sql = "SELECT f.*, u.nome_completo, i.id as imovel_ref
                FROM faturas f
                JOIN usuarios u ON f.cliente_id = u.id
                JOIN imoveis i ON f.imovel_id = i.id
                WHERE DATE(f.created_at) = CURDATE()";
        
        $faturas = $this->db->fetchAll($sql);
        
        foreach ($faturas as $fatura) {
            $stats['valor_total'] += $fatura['valor'];
            $stats['faturas'][] = [
                'numero' => $fatura['numero_fatura'],
                'cliente' => $fatura['nome_completo'],
                'valor' => $fatura['valor'],
                'vencimento' => $fatura['data_vencimento']
            ];
        }
        
        echo "Total de faturas geradas: {$stats['total_geradas']}\n";
        echo "Valor total: R$ " . number_format($stats['valor_total'], 2, ',', '.') . "\n";
        
        // Salva relatório
        $this->salvarRelatorio($stats);
    }
    
    private function salvarRelatorio($stats) {
        $reportPath = __DIR__ . '/../reports/faturas/';
        if (!file_exists($reportPath)) {
            mkdir($reportPath, 0777, true);
        }
        
        $filename = $reportPath . 'geracao_' . date('Y-m-d') . '.json';
        file_put_contents($filename, json_encode($stats, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        
        echo "Relatório salvo em: $filename\n";
    }
    
    private function registrarLog($mensagem) {
        $this->db->insert('logs_acesso', [
            'usuario_id' => 0, // Sistema
            'ip_address' => '127.0.0.1',
            'user_agent' => 'Sistema Automático',
            'pagina' => 'scripts/gerar_faturas_mensais.php',
            'acao' => 'gerar_faturas',
            'descricao' => $mensagem
        ]);
    }
}

// Executa o script
$gerador = new GeradorFaturasMensais();
$gerador->run();
