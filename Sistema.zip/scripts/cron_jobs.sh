#!/bin/bash
# Script de tarefas agendadas - Construtora Kelles Duarte
# Adicione este arquivo ao crontab com: crontab cron_jobs.sh

# Caminho base do sistema
SISTEMA_PATH="/var/www/sistema"
PHP_BIN="/usr/bin/php"

# ====================================
# TAREFAS DIÁRIAS
# ====================================

# Backup diário do banco de dados - 2:00 AM
0 2 * * * $PHP_BIN $SISTEMA_PATH/scripts/backup.php >> $SISTEMA_PATH/logs/backup.log 2>&1

# Atualizar status de faturas vencidas - 6:00 AM
0 6 * * * $PHP_BIN $SISTEMA_PATH/scripts/atualizar_faturas.php >> $SISTEMA_PATH/logs/faturas.log 2>&1

# Enviar lembretes de vencimento - 8:00 AM
0 8 * * * $PHP_BIN $SISTEMA_PATH/scripts/enviar_lembretes.php >> $SISTEMA_PATH/logs/lembretes.log 2>&1

# Verificar aniversários e enviar felicitações - 9:00 AM
0 9 * * * $PHP_BIN $SISTEMA_PATH/scripts/aniversarios.php >> $SISTEMA_PATH/logs/aniversarios.log 2>&1

# ====================================
# TAREFAS SEMANAIS
# ====================================

# Backup semanal completo - Domingo 3:00 AM
0 3 * * 0 $PHP_BIN $SISTEMA_PATH/scripts/backup.php --tipo=semanal >> $SISTEMA_PATH/logs/backup.log 2>&1

# Limpeza de logs antigos - Domingo 4:00 AM
0 4 * * 0 $PHP_BIN $SISTEMA_PATH/scripts/limpar_logs.php >> $SISTEMA_PATH/logs/limpeza.log 2>&1

# Relatório semanal para administração - Segunda 7:00 AM
0 7 * * 1 $PHP_BIN $SISTEMA_PATH/scripts/relatorio_semanal.php >> $SISTEMA_PATH/logs/relatorios.log 2>&1

# ====================================
# TAREFAS MENSAIS
# ====================================

# Backup mensal completo - Dia 1 de cada mês 3:00 AM
0 3 1 * * $PHP_BIN $SISTEMA_PATH/scripts/backup.php --tipo=mensal >> $SISTEMA_PATH/logs/backup.log 2>&1

# Gerar faturas mensais - Dia 1 de cada mês 6:00 AM
0 6 1 * * $PHP_BIN $SISTEMA_PATH/scripts/gerar_faturas_mensais.php >> $SISTEMA_PATH/logs/faturas.log 2>&1

# Relatório financeiro mensal - Dia 1 de cada mês 8:00 AM
0 8 1 * * $PHP_BIN $SISTEMA_PATH/scripts/relatorio_financeiro.php >> $SISTEMA_PATH/logs/relatorios.log 2>&1

# Verificação de integridade do sistema - Dia 15 de cada mês 2:00 AM
0 2 15 * * $PHP_BIN $SISTEMA_PATH/scripts/verificar_integridade.php >> $SISTEMA_PATH/logs/integridade.log 2>&1

# ====================================
# TAREFAS A CADA 5 MINUTOS
# ====================================

# Processar fila de e-mails
*/5 * * * * $PHP_BIN $SISTEMA_PATH/scripts/processar_emails.php >> $SISTEMA_PATH/logs/emails.log 2>&1

# Processar fila de WhatsApp
*/5 * * * * $PHP_BIN $SISTEMA_PATH/scripts/processar_whatsapp.php >> $SISTEMA_PATH/logs/whatsapp.log 2>&1

# ====================================
# MONITORAMENTO
# ====================================

# Verificar status do sistema a cada 10 minutos
*/10 * * * * $PHP_BIN $SISTEMA_PATH/scripts/monitor_sistema.php >> $SISTEMA_PATH/logs/monitor.log 2>&1

# ====================================
# NOTAS DE INSTALAÇÃO
# ====================================
# 1. Edite o crontab do usuário www-data ou apache:
#    sudo crontab -u www-data -e
#
# 2. Adicione as linhas deste arquivo
#
# 3. Verifique se os scripts têm permissão de execução:
#    chmod +x /var/www/sistema/scripts/*.php
#
# 4. Certifique-se de que os diretórios de log existem:
#    mkdir -p /var/www/sistema/logs
#    chown www-data:www-data /var/www/sistema/logs
