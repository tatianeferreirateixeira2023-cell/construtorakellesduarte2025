<?php
/**
 * Script para enviar lembretes de vencimento
 * Executar diariamente às 8:00 AM
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../app/core/Database.php';
require_once __DIR__ . '/../app/services/NotificationService.php';

class EnviadorLembretes {
    private $db;
    private $notifier;
    private $totalEnviados = 0;
    
    public function __construct() {
        $this->db = Database::getInstance();
        $this->notifier = new NotificationService();
    }
    
    public function run() {
        echo "[" . date('Y-m-d H:i:s') . "] Iniciando envio de lembretes...\n\n";
        
        // Lembretes de faturas
        $this->enviarLembretesFaturas();
        
        // Lembretes de férias
        $this->enviarLembretesFerias();
        
        // Lembretes de documentos
        $this->enviarLembretesDocumentos();
        
        echo "\n[" . date('Y-m-d H:i:s') . "] Envio concluído. Total: {$this->totalEnviados} lembretes\n";
    }
    
    private function enviarLembretesFaturas() {
        echo "=== LEMBRETES DE FATURAS ===\n";
        
        // Faturas vencendo amanhã
        $sql = "SELECT f.*, u.nome_completo, u.email, u.telefone
                FROM faturas f
                JOIN usuarios u ON f.cliente_id = u.id
                WHERE f.data_vencimento = DATE_ADD(CURDATE(), INTERVAL 1 DAY)
                AND f.status = 'em_aberto'
                AND NOT EXISTS (
                    SELECT 1 FROM lembretes_faturas lf
                    WHERE lf.fatura_id = f.id
                    AND lf.tipo = 'pre_vencimento'
                    AND DATE(lf.data_envio) = CURDATE()
                )";
        
        $faturas = $this->db->fetchAll($sql);
        
        foreach ($faturas as $fatura) {
            echo "- Enviando lembrete para {$fatura['nome_completo']} - Fatura #{$fatura['id']}\n";
            
            if ($this->notifier->notificarVencimentoFatura($fatura['id'])) {
                $this->totalEnviados++;
            }
        }
        
        // Faturas vencendo hoje
        $sql = "SELECT f.*, u.nome_completo, u.email, u.telefone
                FROM faturas f
                JOIN usuarios u ON f.cliente_id = u.id
                WHERE f.data_vencimento = CURDATE()
                AND f.status = 'em_aberto'
                AND NOT EXISTS (
                    SELECT 1 FROM lembretes_faturas lf
                    WHERE lf.fatura_id = f.id
                    AND lf.tipo = 'vencimento'
                    AND DATE(lf.data_envio) = CURDATE()
                )";
        
        $faturas = $this->db->fetchAll($sql);
        
        foreach ($faturas as $fatura) {
            echo "- VENCIMENTO HOJE: {$fatura['nome_completo']} - Fatura #{$fatura['id']}\n";
            
            if ($this->notifier->notificarVencimentoFatura($fatura['id'])) {
                $this->totalEnviados++;
            }
        }
        
        // Faturas vencidas há 1 dia
        $sql = "SELECT f.*, u.nome_completo, u.email, u.telefone
                FROM faturas f
                JOIN usuarios u ON f.cliente_id = u.id
                WHERE f.data_vencimento = DATE_SUB(CURDATE(), INTERVAL 1 DAY)
                AND f.status = 'vencido'
                AND NOT EXISTS (
                    SELECT 1 FROM lembretes_faturas lf
                    WHERE lf.fatura_id = f.id
                    AND lf.tipo = 'pos_vencimento'
                    AND DATE(lf.data_envio) = CURDATE()
                )";
        
        $faturas = $this->db->fetchAll($sql);
        
        foreach ($faturas as $fatura) {
            echo "- FATURA VENCIDA: {$fatura['nome_completo']} - Fatura #{$fatura['id']}\n";
            
            if ($this->notifier->notificarVencimentoFatura($fatura['id'])) {
                $this->totalEnviados++;
            }
        }
        
        echo "Total de lembretes de faturas: {$this->totalEnviados}\n\n";
    }
    
    private function enviarLembretesFerias() {
        echo "=== LEMBRETES DE FÉRIAS ===\n";
        
        // Funcionários com direito a férias (1 ano de empresa)
        $sql = "SELECT f.*, 
                DATEDIFF(CURDATE(), f.data_admissao) as dias_empresa,
                DATEDIFF(CURDATE(), IFNULL(f.ultimas_ferias, f.data_admissao)) as dias_desde_ferias
                FROM funcionarios f
                WHERE f.status = 'ativo'
                AND DATEDIFF(CURDATE(), f.data_admissao) >= 365
                AND (f.ultimas_ferias IS NULL OR DATEDIFF(CURDATE(), f.ultimas_ferias) >= 330)";
        
        $funcionarios = $this->db->fetchAll($sql);
        
        foreach ($funcionarios as $func) {
            echo "- Funcionário {$func['nome']} tem direito a férias ";
            echo "(Dias desde últimas férias: {$func['dias_desde_ferias']})\n";
            
            // Notifica RH
            $this->notificarRHFerias($func);
            $this->totalEnviados++;
        }
        
        if (count($funcionarios) == 0) {
            echo "Nenhum funcionário com férias pendentes.\n";
        }
        
        echo "\n";
    }
    
    private function enviarLembretesDocumentos() {
        echo "=== LEMBRETES DE DOCUMENTOS ===\n";
        
        // Documentos vencendo (CNH, certidões, etc.)
        // Este é um exemplo - você pode expandir conforme necessidade
        
        // EPIs vencidos
        $sql = "SELECT e.*, f.nome as funcionario_nome, f.email, f.telefone
                FROM epis e
                JOIN funcionarios f ON e.funcionario_id = f.id
                WHERE e.data_devolucao IS NULL
                AND DATEDIFF(CURDATE(), e.data_entrega) > 180"; // EPIs com mais de 6 meses
        
        $epis = $this->db->fetchAll($sql);
        
        foreach ($epis as $epi) {
            echo "- EPI vencido: {$epi['descricao']} - Funcionário: {$epi['funcionario_nome']}\n";
            
            // Notifica encarregado
            $this->notificarEPIVencido($epi);
            $this->totalEnviados++;
        }
        
        if (count($epis) == 0) {
            echo "Nenhum documento/EPI vencido.\n";
        }
    }
    
    private function notificarRHFerias($funcionario) {
        // Busca usuários do RH/Admin
        $sql = "SELECT * FROM usuarios 
                WHERE nivel_acesso_id IN (" . NIVEL_ADMIN . ", " . NIVEL_FINANCEIRO . ") 
                AND ativo = 1";
        
        $responsaveis = $this->db->fetchAll($sql);
        
        foreach ($responsaveis as $resp) {
            $subject = "Lembrete de Férias - {$funcionario['nome']}";
            $body = "O funcionário {$funcionario['nome']} tem direito a férias.\n\n";
            $body .= "Data de admissão: " . date('d/m/Y', strtotime($funcionario['data_admissao'])) . "\n";
            
            if ($funcionario['ultimas_ferias']) {
                $body .= "Últimas férias: " . date('d/m/Y', strtotime($funcionario['ultimas_ferias'])) . "\n";
            } else {
                $body .= "O funcionário ainda não tirou férias.\n";
            }
            
            $body .= "\nPor favor, agende as férias o quanto antes.";
            
            $this->notifier->sendEmail($resp['email'], $subject, $body);
        }
        
        // Registra lembrete
        $this->db->insert('lembretes', [
            'usuario_id' => 0,
            'tipo' => 'ferias',
            'titulo' => "Férias pendentes - {$funcionario['nome']}",
            'descricao' => "Funcionário com direito a férias",
            'data_lembrete' => date('Y-m-d'),
            'enviado' => 1
        ]);
    }
    
    private function notificarEPIVencido($epi) {
        // Busca encarregados
        $sql = "SELECT * FROM usuarios WHERE nivel_acesso_id = " . NIVEL_ENCARREGADO . " AND ativo = 1";
        $encarregados = $this->db->fetchAll($sql);
        
        foreach ($encarregados as $enc) {
            $subject = "EPI Vencido - {$epi['funcionario_nome']}";
            $body = "O EPI abaixo precisa ser substituído:\n\n";
            $body .= "Funcionário: {$epi['funcionario_nome']}\n";
            $body .= "EPI: {$epi['descricao']}\n";
            $body .= "Data de entrega: " . date('d/m/Y', strtotime($epi['data_entrega'])) . "\n";
            $body .= "Dias em uso: " . (int)((time() - strtotime($epi['data_entrega'])) / 86400) . "\n\n";
            $body .= "Por favor, providencie a substituição.";
            
            $this->notifier->sendEmail($enc['email'], $subject, $body);
        }
    }
}

// Executa o script
$enviador = new EnviadorLembretes();
$enviador->run();
