<!-- Content Header -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Dashboard</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?= BASE_PATH ?>/">Início</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </div>
        </div>
    </div>
</section>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        
        <?php if ($user['nivel_acesso_id'] == NIVEL_ADMIN): ?>
        <!-- Admin Dashboard -->
        <div class="row">
            <div class="col-lg-3 col-6">
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3><?= $total_imoveis ?? 0 ?></h3>
                        <p>Total de Imóveis</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-home"></i>
                    </div>
                    <a href="/imoveis" class="small-box-footer">Ver mais <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-success">
                    <div class="inner">
                        <h3><?= $this->formatMoney($receita_mes ?? 0) ?></h3>
                        <p>Receita do Mês</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-dollar-sign"></i>
                    </div>
                    <a href="/faturas" class="small-box-footer">Ver mais <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-warning">
                    <div class="inner">
                        <h3><?= $total_clientes ?? 0 ?></h3>
                        <p>Clientes Cadastrados</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <a href="/usuarios?nivel=2" class="small-box-footer">Ver mais <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-danger">
                    <div class="inner">
                        <h3><?= $faturas_vencidas ?? 0 ?></h3>
                        <p>Faturas Vencidas</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <a href="/faturas?status=vencido" class="small-box-footer">Ver mais <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-8">
                <!-- Gráfico de Vendas -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-chart-line mr-1"></i>
                            Vendas dos Últimos 6 Meses
                        </h3>
                    </div>
                    <div class="card-body">
                        <canvas id="salesChart" style="height: 300px;"></canvas>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <!-- Resumo Financeiro -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-calculator mr-1"></i>
                            Resumo Financeiro
                        </h3>
                    </div>
                    <div class="card-body">
                        <div class="info-box mb-3 bg-success">
                            <span class="info-box-icon"><i class="fas fa-plus"></i></span>
                            <div class="info-box-content">
                                <span class="info-box-text">Receitas</span>
                                <span class="info-box-number"><?= $this->formatMoney($receita_mes ?? 0) ?></span>
                            </div>
                        </div>
                        
                        <div class="info-box mb-3 bg-danger">
                            <span class="info-box-icon"><i class="fas fa-minus"></i></span>
                            <div class="info-box-content">
                                <span class="info-box-text">Despesas</span>
                                <span class="info-box-number"><?= $this->formatMoney($despesa_mes ?? 0) ?></span>
                            </div>
                        </div>
                        
                        <div class="info-box mb-3 bg-info">
                            <span class="info-box-icon"><i class="fas fa-balance-scale"></i></span>
                            <div class="info-box-content">
                                <span class="info-box-text">Saldo</span>
                                <span class="info-box-number"><?= $this->formatMoney(($receita_mes ?? 0) - ($despesa_mes ?? 0)) ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6">
                <!-- Últimas Atividades -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-history mr-1"></i>
                            Últimas Atividades
                        </h3>
                    </div>
                    <div class="card-body p-0">
                        <ul class="products-list product-list-in-card pl-2 pr-2">
                            <?php foreach ($ultimas_atividades ?? [] as $atividade): ?>
                            <li class="item">
                                <div class="product-info ml-0">
                                    <a href="#" class="product-title"><?= $atividade['acao'] ?>
                                        <span class="badge badge-info float-right"><?= $this->formatDateTime($atividade['created_at']) ?></span>
                                    </a>
                                    <span class="product-description">
                                        <?= $atividade['nome_completo'] ?> - <?= $atividade['descricao'] ?>
                                    </span>
                                </div>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <div class="card-footer text-center">
                        <a href="<?= BASE_URL ?>logs.php" class="uppercase">Ver Todos os Logs</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <!-- Empreendimentos -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-building mr-1"></i>
                            Empreendimentos em Andamento
                        </h3>
                    </div>
                    <div class="card-body">
                        <div class="progress-group">
                            <span class="progress-text">Total de Empreendimentos</span>
                            <span class="float-right"><b><?= $empreendimentos_andamento ?? 0 ?></b>/<?= $total_empreendimentos ?? 0 ?></span>
                            <div class="progress progress-sm">
                                <div class="progress-bar bg-primary" style="width: <?= $total_empreendimentos > 0 ? ($empreendimentos_andamento / $total_empreendimentos * 100) : 0 ?>%"></div>
                            </div>
                        </div>
                        
                        <div class="progress-group">
                            <span class="progress-text">Imóveis Vendidos</span>
                            <span class="float-right"><b><?= $imoveis_vendidos ?? 0 ?></b>/<?= $total_imoveis ?? 0 ?></span>
                            <div class="progress progress-sm">
                                <div class="progress-bar bg-success" style="width: <?= $total_imoveis > 0 ? ($imoveis_vendidos / $total_imoveis * 100) : 0 ?>%"></div>
                            </div>
                        </div>
                        
                        <div class="progress-group">
                            <span class="progress-text">Imóveis Disponíveis</span>
                            <span class="float-right"><b><?= $imoveis_disponiveis ?? 0 ?></b>/<?= $total_imoveis ?? 0 ?></span>
                            <div class="progress progress-sm">
                                <div class="progress-bar bg-warning" style="width: <?= $total_imoveis > 0 ? ($imoveis_disponiveis / $total_imoveis * 100) : 0 ?>%"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <?php elseif ($user['nivel_acesso_id'] == NIVEL_CLIENTE): ?>
        <!-- Cliente Dashboard -->
        <div class="row">
            <div class="col-lg-3 col-6">
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3><?= count($meus_imoveis ?? []) ?></h3>
                        <p>Meus Imóveis</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-home"></i>
                    </div>
                    <a href="/meus-imoveis" class="small-box-footer">Ver mais <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-warning">
                    <div class="inner">
                        <h3><?= count($faturas_pendentes ?? []) ?></h3>
                        <p>Faturas Pendentes</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-file-invoice"></i>
                    </div>
                    <a href="/minhas-faturas" class="small-box-footer">Ver mais <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-success">
                    <div class="inner">
                        <h3><?= $this->formatMoney($total_pago ?? 0) ?></h3>
                        <p>Total Pago</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <a href="/minhas-faturas?status=pago" class="small-box-footer">Ver mais <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-danger">
                    <div class="inner">
                        <h3><?= $this->formatMoney($total_a_pagar ?? 0) ?></h3>
                        <p>Total a Pagar</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-exclamation-circle"></i>
                    </div>
                    <a href="/minhas-faturas?status=em_aberto" class="small-box-footer">Ver mais <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-8">
                <!-- Próximas Parcelas -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-calendar-alt mr-1"></i>
                            Próximas Parcelas
                        </h3>
                    </div>
                    <div class="card-body p-0">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Vencimento</th>
                                    <th>Imóvel</th>
                                    <th>Valor</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($proximas_parcelas ?? [] as $parcela): ?>
                                <tr>
                                    <td><?= $this->formatDate($parcela['data_vencimento']) ?></td>
                                    <td>Imóvel #<?= $parcela['imovel_id'] ?></td>
                                    <td><?= $this->formatMoney($parcela['valor']) ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-primary" onclick="gerarBoleto(<?= $parcela['id'] ?>)">
                                            <i class="fas fa-barcode"></i> Boleto
                                        </button>
                                        <button class="btn btn-sm btn-success" onclick="gerarPixQRCode(<?= $parcela['id'] ?>)">
                                            <i class="fas fa-qrcode"></i> PIX
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <!-- Meus Imóveis -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-home mr-1"></i>
                            Meus Imóveis
                        </h3>
                    </div>
                    <div class="card-body">
                        <?php foreach ($meus_imoveis ?? [] as $imovel): ?>
                        <div class="info-box">
                            <span class="info-box-icon bg-info"><i class="fas fa-home"></i></span>
                            <div class="info-box-content">
                                <span class="info-box-text">Imóvel #<?= $imovel['id'] ?></span>
                                <span class="info-box-number"><?= $this->formatMoney($imovel['valor']) ?></span>
                                <div class="progress">
                                    <div class="progress-bar bg-info" style="width: 70%"></div>
                                </div>
                                <span class="progress-description">
                                    <?= $imovel['quartos'] ?> quartos, <?= $imovel['metragem'] ?>m²
                                </span>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <?php elseif ($user['nivel_acesso_id'] == NIVEL_FINANCEIRO): ?>
        <!-- Financeiro Dashboard -->
        <div class="row">
            <div class="col-lg-3 col-6">
                <div class="small-box bg-success">
                    <div class="inner">
                        <h3><?= $this->formatMoney($receitas_mes ?? 0) ?></h3>
                        <p>Receitas do Mês</p>
                        <small><?= $qtd_receitas ?? 0 ?> transações</small>
                    </div>
                    <div class="icon">
                        <i class="fas fa-arrow-up"></i>
                    </div>
                    <a href="/faturas" class="small-box-footer">Ver mais <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-danger">
                    <div class="inner">
                        <h3><?= $this->formatMoney($despesas_mes ?? 0) ?></h3>
                        <p>Despesas do Mês</p>
                        <small><?= $qtd_despesas ?? 0 ?> transações</small>
                    </div>
                    <div class="icon">
                        <i class="fas fa-arrow-down"></i>
                    </div>
                    <a href="/contas-pagar" class="small-box-footer">Ver mais <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3><?= $this->formatMoney($saldo_mes ?? 0) ?></h3>
                        <p>Saldo do Mês</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-balance-scale"></i>
                    </div>
                    <a href="/relatorios/financeiro" class="small-box-footer">Ver mais <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-warning">
                    <div class="inner">
                        <h3><?= $qtd_receber ?? 0 ?></h3>
                        <p>Contas a Receber</p>
                        <small><?= $this->formatMoney($total_receber ?? 0) ?></small>
                    </div>
                    <div class="icon">
                        <i class="fas fa-hand-holding-usd"></i>
                    </div>
                    <a href="/faturas?status=em_aberto" class="small-box-footer">Ver mais <i class="fas fa-arrow-circle-right"></i></a>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-12">
                <!-- Fluxo de Caixa -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-chart-line mr-1"></i>
                            Fluxo de Caixa - Próximos 30 dias
                        </h3>
                    </div>
                    <div class="card-body">
                        <canvas id="fluxoCaixaChart" style="height: 300px;"></canvas>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if (!empty($aniversarios)): ?>
        <!-- Aniversários do Dia -->
        <div class="row">
            <div class="col-md-12">
                <div class="callout callout-info">
                    <h5><i class="fas fa-birthday-cake"></i> Aniversários de Hoje!</h5>
                    <ul>
                        <?php foreach ($aniversarios as $aniversariante): ?>
                        <li><?= $aniversariante['nome_completo'] ?> - <?= $aniversariante['telefone'] ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
    </div>
</section>

<script>
// Gráfico de Vendas (Admin)
<?php if (isset($grafico_vendas)): ?>
var salesData = <?= json_encode($grafico_vendas) ?>;
var ctx = document.getElementById('salesChart').getContext('2d');
var salesChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: salesData.map(item => item.mes),
        datasets: [{
            label: 'Vendas',
            data: salesData.map(item => item.vendas),
            borderColor: 'rgb(75, 192, 192)',
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            tension: 0.1
        }, {
            label: 'Valor Total',
            data: salesData.map(item => item.total),
            borderColor: 'rgb(255, 99, 132)',
            backgroundColor: 'rgba(255, 99, 132, 0.2)',
            tension: 0.1,
            yAxisID: 'y1'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true,
                position: 'left'
            },
            y1: {
                beginAtZero: true,
                position: 'right',
                grid: {
                    drawOnChartArea: false
                }
            }
        }
    }
});
<?php endif; ?>

// Gráfico de Fluxo de Caixa (Financeiro)
<?php if (isset($fluxo_caixa)): ?>
var fluxoData = <?= json_encode($fluxo_caixa) ?>;
var ctx2 = document.getElementById('fluxoCaixaChart').getContext('2d');
var fluxoChart = new Chart(ctx2, {
    type: 'bar',
    data: {
        labels: fluxoData.map(item => new Date(item.data).toLocaleDateString('pt-BR')),
        datasets: [{
            label: 'Receitas',
            data: fluxoData.map(item => item.receita),
            backgroundColor: 'rgba(75, 192, 192, 0.8)'
        }, {
            label: 'Despesas',
            data: fluxoData.map(item => item.despesa),
            backgroundColor: 'rgba(255, 99, 132, 0.8)'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});
<?php endif; ?>
</script>
