<?php require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <h1 class="h3 mb-3">Logs do Sistema</h1>
        </div>
    </div>

    <?php if (isset($flash)): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show" role="alert">
            <?= $flash['message'] ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <!-- Filtros -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Filtros</h6>
        </div>
        <div class="card-body">
            <form method="GET" action="<?= BASE_URL ?>logs.php">
                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="usuario">Usuário</label>
                            <select name="usuario" id="usuario" class="form-control">
                                <option value="">Todos</option>
                                <?php foreach ($usuarios as $usuario): ?>
                                    <option value="<?= $usuario['id'] ?>" 
                                            <?= (isset($filters['usuario']) && $filters['usuario'] == $usuario['id']) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($usuario['nome_completo']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="acao">Ação</label>
                            <input type="text" name="acao" id="acao" class="form-control" 
                                   placeholder="Ex: login, logout, criar" 
                                   value="<?= htmlspecialchars($filters['acao'] ?? '') ?>">
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="data_inicio">Data Início</label>
                            <input type="date" name="data_inicio" id="data_inicio" class="form-control" 
                                   value="<?= $filters['data_inicio'] ?? '' ?>">
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="data_fim">Data Fim</label>
                            <input type="date" name="data_fim" id="data_fim" class="form-control" 
                                   value="<?= $filters['data_fim'] ?? '' ?>">
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label>&nbsp;</label>
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-search"></i> Filtrar
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Tabela de Logs -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">
                Registros de Atividade (<?= number_format($pagination['total_records']) ?> registros)
            </h6>
            <div>
                <a href="<?= BASE_URL ?>logs.php?action=exportar&<?= http_build_query($filters) ?>" class="btn btn-sm btn-success">
                    <i class="fas fa-file-csv"></i> Exportar CSV
                </a>
                <button type="button" class="btn btn-sm btn-danger" onclick="limparLogs()">
                    <i class="fas fa-trash"></i> Limpar Logs Antigos
                </button>
            </div>
        </div>
        <div class="card-body">
            <?php if (!empty($logs)): ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-sm">
                        <thead>
                            <tr>
                                <th width="150">Data/Hora</th>
                                <th>Usuário</th>
                                <th>IP</th>
                                <th>Página</th>
                                <th>Ação</th>
                                <th>Descrição</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($logs as $log): ?>
                                <tr>
                                    <td class="small"><?= date('d/m/Y H:i:s', strtotime($log['created_at'])) ?></td>
                                    <td><?= htmlspecialchars($log['usuario_nome'] ?? 'Sistema') ?></td>
                                    <td class="small"><?= htmlspecialchars($log['ip_address']) ?></td>
                                    <td class="small"><?= htmlspecialchars($log['pagina']) ?></td>
                                    <td>
                                        <?php
                                        $acaoClass = 'badge-secondary';
                                        if (strpos($log['acao'], 'login') !== false) $acaoClass = 'badge-info';
                                        if (strpos($log['acao'], 'criar') !== false || strpos($log['acao'], 'criado') !== false) $acaoClass = 'badge-success';
                                        if (strpos($log['acao'], 'editar') !== false || strpos($log['acao'], 'atualizar') !== false) $acaoClass = 'badge-warning';
                                        if (strpos($log['acao'], 'deletar') !== false || strpos($log['acao'], 'excluir') !== false) $acaoClass = 'badge-danger';
                                        ?>
                                        <span class="badge <?= $acaoClass ?>">
                                            <?= htmlspecialchars($log['acao']) ?>
                                        </span>
                                    </td>
                                    <td class="small"><?= htmlspecialchars($log['descricao']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Paginação -->
                <?php if ($pagination['total'] > 1): ?>
                    <nav aria-label="Navegação de páginas">
                        <ul class="pagination justify-content-center">
                            <li class="page-item <?= $pagination['current'] == 1 ? 'disabled' : '' ?>">
                                <a class="page-link" href="?page=<?= $pagination['current'] - 1 ?>&<?= http_build_query($filters) ?>">
                                    Anterior
                                </a>
                            </li>
                            
                            <?php for ($i = max(1, $pagination['current'] - 2); $i <= min($pagination['total'], $pagination['current'] + 2); $i++): ?>
                                <li class="page-item <?= $i == $pagination['current'] ? 'active' : '' ?>">
                                    <a class="page-link" href="?page=<?= $i ?>&<?= http_build_query($filters) ?>">
                                        <?= $i ?>
                                    </a>
                                </li>
                            <?php endfor; ?>
                            
                            <li class="page-item <?= $pagination['current'] == $pagination['total'] ? 'disabled' : '' ?>">
                                <a class="page-link" href="?page=<?= $pagination['current'] + 1 ?>&<?= http_build_query($filters) ?>">
                                    Próxima
                                </a>
                            </li>
                        </ul>
                    </nav>
                <?php endif; ?>
            <?php else: ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> Nenhum log encontrado com os filtros aplicados.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Modal para limpar logs -->
<div class="modal fade" id="modalLimparLogs" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Limpar Logs Antigos</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="POST" action="<?= BASE_URL ?>logs.php?action=limpar">
                <div class="modal-body">
                    <p>Esta ação removerá permanentemente os logs antigos do sistema.</p>
                    <div class="form-group">
                        <label for="dias">Remover logs com mais de:</label>
                        <select name="dias" id="dias" class="form-control" required>
                            <option value="7">7 dias</option>
                            <option value="15">15 dias</option>
                            <option value="30" selected>30 dias</option>
                            <option value="60">60 dias</option>
                            <option value="90">90 dias</option>
                            <option value="180">180 dias</option>
                            <option value="365">1 ano</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-danger">
                        <i class="fas fa-trash"></i> Limpar Logs
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function limparLogs() {
    $('#modalLimparLogs').modal('show');
}
</script>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
