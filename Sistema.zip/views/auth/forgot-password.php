<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Esqueci Minha Senha - Construtora Kelles Duarte</title>
    
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    
    <style>
        .login-page {
            background: linear-gradient(135deg, #E85D2C 0%, #D64520 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-logo {
            font-size: 35px;
            text-align: center;
            margin-bottom: 25px;
            font-weight: 300;
        }
        .login-logo a {
            color: #fff !important;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        .login-box {
            width: 400px;
        }
        @media (max-width: 576px) {
            .login-box {
                width: 90%;
            }
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            border: none;
        }
        .btn-primary {
            background: #E85D2C;
            border-color: #E85D2C;
            font-weight: 600;
            letter-spacing: 0.5px;
        }
        .btn-primary:hover {
            background: #D64520;
            border-color: #D64520;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(232, 93, 44, 0.3);
        }
        .form-control:focus {
            border-color: #E85D2C;
            box-shadow: 0 0 0 0.2rem rgba(232, 93, 44, 0.25);
        }
        a {
            color: #E85D2C;
        }
        a:hover {
            color: #D64520;
        }
    </style>
</head>
<body class="hold-transition login-page">
<div class="login-box">
    <div class="login-logo">
        <a href="<?= BASE_PATH ?>/"><b>Construtora</b> Kelles Duarte</a>
    </div>
    
    <div class="card">
        <div class="card-body login-card-body">
            <p class="login-box-msg">Recupere sua senha</p>

            <?php if (isset($flash) && $flash): ?>
            <div class="alert alert-<?= $flash['type'] ?> alert-dismissible">
                <?= $flash['message'] ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php endif; ?>

            <form action="<?= BASE_PATH ?>/esqueci-senha" method="post" class="needs-validation" novalidate>
                <p class="text-muted">
                    Digite seu e-mail cadastrado e enviaremos instruções para redefinir sua senha.
                </p>
                
                <div class="input-group mb-3">
                    <input type="email" 
                           class="form-control" 
                           placeholder="E-mail cadastrado" 
                           name="email" 
                           required 
                           autofocus>
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-envelope"></span>
                        </div>
                    </div>
                    <div class="invalid-feedback">
                        Por favor, informe um e-mail válido.
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary btn-block">
                            <i class="fas fa-paper-plane"></i> Enviar Instruções
                        </button>
                    </div>
                </div>
            </form>

            <p class="mt-3 mb-1">
                <a href="<?= BASE_PATH ?>/login">
                    <i class="fas fa-arrow-left"></i> Voltar ao Login
                </a>
            </p>
        </div>
    </div>
    
    <div class="text-center mt-3">
        <small class="text-white">
            &copy; <?= date('Y') ?> Construtora Kelles Duarte<br>
            CNPJ: 11.030.523/0001-05
        </small>
    </div>
</div>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Bootstrap 4 -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>

<script>
(function() {
    'use strict';
    window.addEventListener('load', function() {
        var forms = document.getElementsByClassName('needs-validation');
        var validation = Array.prototype.filter.call(forms, function(form) {
            form.addEventListener('submit', function(event) {
                if (form.checkValidity() === false) {
                    event.preventDefault();
                    event.stopPropagation();
                }
                form.classList.add('was-validated');
            }, false);
        });
    }, false);
})();
</script>

</body>
</html>
