<!-- Content Header -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>
                    <i class="fas fa-file-invoice-dollar"></i> Faturas
                    <small>Gerenciamento de faturas</small>
                </h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?= url() ?>">Início</a></li>
                    <li class="breadcrumb-item"><a href="<?= url('financeiro') ?>">Financeiro</a></li>
                    <li class="breadcrumb-item active">Faturas</li>
                </ol>
            </div>
        </div>
    </div>
</section>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        
        <!-- Estatísticas -->
        <div class="row">
            <div class="col-lg-3 col-6">
                <div class="small-box bg-success">
                    <div class="inner">
                        <h3>R$ <?= number_format($estatisticas['total_recebido'] ?? 0, 2, ',', '.') ?></h3>
                        <p>Total Recebido</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-warning">
                    <div class="inner">
                        <h3>R$ <?= number_format($estatisticas['total_aberto'] ?? 0, 2, ',', '.') ?></h3>
                        <p>Em Aberto</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-clock"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-danger">
                    <div class="inner">
                        <h3>R$ <?= number_format($estatisticas['total_vencido'] ?? 0, 2, ',', '.') ?></h3>
                        <p>Vencidas</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3><?= $estatisticas['total_faturas'] ?? 0 ?></h3>
                        <p>Total de Faturas</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-file-invoice"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Filtros -->
        <div class="card card-outline card-primary collapsed-card">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-filter"></i> Filtros
                </h3>
                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                        <i class="fas fa-plus"></i>
                    </button>
                </div>
            </div>
            <div class="card-body">
                <form method="get" action="<?= url('faturas') ?>">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Cliente</label>
                                <select name="cliente" class="form-control select2">
                                    <option value="">Todos</option>
                                    <?php foreach ($clientes ?? [] as $cliente): ?>
                                    <option value="<?= $cliente['id'] ?>" 
                                            <?= ($filters['cliente'] ?? '') == $cliente['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($cliente['nome_completo']) ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>Status</label>
                                <select name="status" class="form-control">
                                    <option value="">Todos</option>
                                    <option value="em_aberto" <?= ($filters['status'] ?? '') == 'em_aberto' ? 'selected' : '' ?>>Em Aberto</option>
                                    <option value="pago" <?= ($filters['status'] ?? '') == 'pago' ? 'selected' : '' ?>>Pago</option>
                                    <option value="vencido" <?= ($filters['status'] ?? '') == 'vencido' ? 'selected' : '' ?>>Vencido</option>
                                    <option value="cancelado" <?= ($filters['status'] ?? '') == 'cancelado' ? 'selected' : '' ?>>Cancelado</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>Vencimento De</label>
                                <input type="date" name="data_inicio" class="form-control" 
                                       value="<?= $filters['data_inicio'] ?? '' ?>">
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>Vencimento Até</label>
                                <input type="date" name="data_fim" class="form-control" 
                                       value="<?= $filters['data_fim'] ?? '' ?>">
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>Número</label>
                                <input type="text" name="numero" class="form-control" 
                                       placeholder="Nº da fatura"
                                       value="<?= htmlspecialchars($filters['numero'] ?? '') ?>">
                            </div>
                        </div>
                        <div class="col-md-1">
                            <div class="form-group">
                                <label>&nbsp;</label>
                                <div>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-search"></i>
                                    </button>
                                    <a href="<?= url('faturas') ?>" class="btn btn-default">
                                        <i class="fas fa-times"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Lista de Faturas -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    Lista de Faturas
                    <span class="badge badge-primary"><?= $pagination['total_records'] ?? 0 ?> registros</span>
                </h3>
                <div class="card-tools">
                    <a href="<?= url('faturas/nova') ?>" class="btn btn-primary btn-sm">
                        <i class="fas fa-plus"></i> Nova Fatura
                    </a>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th width="100">Número</th>
                                <th>Cliente</th>
                                <th>Descrição</th>
                                <th width="120">Vencimento</th>
                                <th width="120">Valor</th>
                                <th width="100">Status</th>
                                <th width="180">Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($faturas)): ?>
                            <tr>
                                <td colspan="7" class="text-center py-4">
                                    <i class="fas fa-file-invoice fa-3x text-muted mb-3"></i>
                                    <p class="text-muted">Nenhuma fatura encontrada</p>
                                </td>
                            </tr>
                            <?php else: ?>
                                <?php foreach ($faturas as $fatura): ?>
                                <tr class="<?= $fatura['status'] == 'vencido' ? 'table-danger' : '' ?>">
                                    <td>
                                        <strong>#<?= str_pad($fatura['numero'] ?? $fatura['id'], 6, '0', STR_PAD_LEFT) ?></strong>
                                    </td>
                                    <td>
                                        <strong><?= htmlspecialchars($fatura['cliente_nome']) ?></strong>
                                        <?php if ($fatura['cpf']): ?>
                                        <br>
                                        <small class="text-muted">
                                            CPF: <?= htmlspecialchars($fatura['cpf']) ?>
                                        </small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?= htmlspecialchars($fatura['descricao'] ?? 'Mensalidade') ?>
                                        <?php if ($fatura['referencia']): ?>
                                        <br>
                                        <small class="text-muted">
                                            Ref: <?= htmlspecialchars($fatura['referencia']) ?>
                                        </small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php 
                                        $vencimento = new DateTime($fatura['data_vencimento']);
                                        $hoje = new DateTime();
                                        $diff = $hoje->diff($vencimento);
                                        $diasAtraso = $vencimento < $hoje ? $diff->days : 0;
                                        ?>
                                        <?= $vencimento->format('d/m/Y') ?>
                                        <?php if ($diasAtraso > 0 && $fatura['status'] != 'pago'): ?>
                                        <br>
                                        <small class="text-danger">
                                            <i class="fas fa-exclamation-triangle"></i> 
                                            <?= $diasAtraso ?> dias de atraso
                                        </small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <strong>R$ <?= number_format($fatura['valor'], 2, ',', '.') ?></strong>
                                        <?php if ($fatura['multa'] > 0): ?>
                                        <br>
                                        <small class="text-danger">
                                            + Multa: R$ <?= number_format($fatura['multa'], 2, ',', '.') ?>
                                        </small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php
                                        $statusClass = [
                                            'em_aberto' => 'badge-warning',
                                            'pago' => 'badge-success',
                                            'vencido' => 'badge-danger',
                                            'cancelado' => 'badge-secondary'
                                        ];
                                        $statusText = [
                                            'em_aberto' => 'Em Aberto',
                                            'pago' => 'Pago',
                                            'vencido' => 'Vencido',
                                            'cancelado' => 'Cancelado'
                                        ];
                                        ?>
                                        <span class="badge <?= $statusClass[$fatura['status']] ?? 'badge-secondary' ?>">
                                            <?= $statusText[$fatura['status']] ?? 'N/D' ?>
                                        </span>
                                        <?php if ($fatura['data_pagamento']): ?>
                                        <br>
                                        <small class="text-muted">
                                            <?= date('d/m/Y', strtotime($fatura['data_pagamento'])) ?>
                                        </small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="<?= url('faturas/visualizar/' . $fatura['id']) ?>" 
                                               class="btn btn-info" title="Visualizar">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            
                                            <?php if ($fatura['status'] != 'pago' && $fatura['status'] != 'cancelado'): ?>
                                            <a href="<?= url('faturas/boleto/' . $fatura['id']) ?>" 
                                               class="btn btn-secondary" title="Gerar Boleto" target="_blank">
                                                <i class="fas fa-barcode"></i>
                                            </a>
                                            <a href="<?= url('faturas/pix/' . $fatura['id']) ?>" 
                                               class="btn btn-success" title="Gerar PIX">
                                                <i class="fas fa-qrcode"></i>
                                            </a>
                                            <button type="button" class="btn btn-primary" 
                                                    onclick="registrarPagamento(<?= $fatura['id'] ?>)" 
                                                    title="Registrar Pagamento">
                                                <i class="fas fa-check"></i>
                                            </button>
                                            <?php endif; ?>
                                            
                                            <?php if ($fatura['status'] == 'pago'): ?>
                                            <a href="<?= url('faturas/recibo/' . $fatura['id']) ?>" 
                                               class="btn btn-success" title="Gerar Recibo" target="_blank">
                                                <i class="fas fa-receipt"></i>
                                            </a>
                                            <?php endif; ?>
                                            
                                            <a href="<?= url('faturas/editar/' . $fatura['id']) ?>" 
                                               class="btn btn-warning" title="Editar">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <?php if (($pagination['total'] ?? 0) > 1): ?>
            <div class="card-footer">
                <nav aria-label="Paginação">
                    <ul class="pagination pagination-sm m-0 float-right">
                        <?php if ($pagination['current'] > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?= $pagination['current'] - 1 ?>&<?= http_build_query(array_diff_key($filters ?? [], ['page' => ''])) ?>">
                                &laquo;
                            </a>
                        </li>
                        <?php endif; ?>
                        
                        <?php for ($i = 1; $i <= $pagination['total']; $i++): ?>
                            <?php if ($i == 1 || $i == $pagination['total'] || ($i >= $pagination['current'] - 2 && $i <= $pagination['current'] + 2)): ?>
                            <li class="page-item <?= $i == $pagination['current'] ? 'active' : '' ?>">
                                <a class="page-link" href="?page=<?= $i ?>&<?= http_build_query(array_diff_key($filters ?? [], ['page' => ''])) ?>">
                                    <?= $i ?>
                                </a>
                            </li>
                            <?php elseif ($i == $pagination['current'] - 3 || $i == $pagination['current'] + 3): ?>
                            <li class="page-item disabled"><span class="page-link">...</span></li>
                            <?php endif; ?>
                        <?php endfor; ?>
                        
                        <?php if ($pagination['current'] < $pagination['total']): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?= $pagination['current'] + 1 ?>&<?= http_build_query(array_diff_key($filters ?? [], ['page' => ''])) ?>">
                                &raquo;
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<script>
function registrarPagamento(id) {
    Swal.fire({
        title: 'Registrar Pagamento',
        html: `
            <div class="form-group text-left">
                <label>Data do Pagamento</label>
                <input type="date" id="data_pagamento" class="form-control" value="${new Date().toISOString().split('T')[0]}">
            </div>
            <div class="form-group text-left">
                <label>Forma de Pagamento</label>
                <select id="forma_pagamento" class="form-control">
                    <option value="dinheiro">Dinheiro</option>
                    <option value="pix">PIX</option>
                    <option value="boleto">Boleto</option>
                    <option value="cartao_credito">Cartão de Crédito</option>
                    <option value="cartao_debito">Cartão de Débito</option>
                    <option value="transferencia">Transferência</option>
                </select>
            </div>
            <div class="form-group text-left">
                <label>Observações</label>
                <textarea id="observacoes" class="form-control" rows="3"></textarea>
            </div>
        `,
        showCancelButton: true,
        confirmButtonColor: '#28a745',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Registrar',
        cancelButtonText: 'Cancelar',
        preConfirm: () => {
            return {
                data_pagamento: document.getElementById('data_pagamento').value,
                forma_pagamento: document.getElementById('forma_pagamento').value,
                observacoes: document.getElementById('observacoes').value
            }
        }
    }).then((result) => {
        if (result.isConfirmed) {
            // Aqui você faria a chamada AJAX para registrar o pagamento
            window.location.href = '<?= url('faturas/pagar/') ?>' + id + 
                '?data=' + result.value.data_pagamento + 
                '&forma=' + result.value.forma_pagamento +
                '&obs=' + encodeURIComponent(result.value.observacoes);
        }
    });
}
</script>
