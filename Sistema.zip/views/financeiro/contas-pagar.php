<!-- Content Header -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>
                    <i class="fas fa-money-check-alt"></i> Contas a Pagar
                    <small>Gerenciamento de despesas</small>
                </h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?= url() ?>">Início</a></li>
                    <li class="breadcrumb-item"><a href="<?= url('financeiro') ?>">Financeiro</a></li>
                    <li class="breadcrumb-item active">Contas a Pagar</li>
                </ol>
            </div>
        </div>
    </div>
</section>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        
        <!-- Estatísticas -->
        <div class="row">
            <div class="col-lg-3 col-6">
                <div class="small-box bg-success">
                    <div class="inner">
                        <h3>R$ <?= number_format($estatisticas['total_pago'] ?? 0, 2, ',', '.') ?></h3>
                        <p>Total Pago</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-warning">
                    <div class="inner">
                        <h3>R$ <?= number_format($estatisticas['total_pendente'] ?? 0, 2, ',', '.') ?></h3>
                        <p>Pendente</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-clock"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-danger">
                    <div class="inner">
                        <h3>R$ <?= number_format($estatisticas['total_vencido'] ?? 0, 2, ',', '.') ?></h3>
                        <p>Vencidas</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3><?= $estatisticas['total_contas'] ?? 0 ?></h3>
                        <p>Total de Contas</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-file-invoice"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Filtros -->
        <div class="card card-outline card-primary collapsed-card">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-filter"></i> Filtros
                </h3>
                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                        <i class="fas fa-plus"></i>
                    </button>
                </div>
            </div>
            <div class="card-body">
                <form method="get" action="<?= url('contas-pagar') ?>">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Fornecedor</label>
                                <select name="fornecedor" class="form-control select2">
                                    <option value="">Todos</option>
                                    <?php foreach ($fornecedores ?? [] as $fornecedor): ?>
                                    <option value="<?= $fornecedor['id'] ?>" 
                                            <?= ($filters['fornecedor'] ?? '') == $fornecedor['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($fornecedor['nome']) ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>Categoria</label>
                                <select name="categoria" class="form-control">
                                    <option value="">Todas</option>
                                    <option value="fornecedores" <?= ($filters['categoria'] ?? '') == 'fornecedores' ? 'selected' : '' ?>>Fornecedores</option>
                                    <option value="folha_pagamento" <?= ($filters['categoria'] ?? '') == 'folha_pagamento' ? 'selected' : '' ?>>Folha de Pagamento</option>
                                    <option value="impostos" <?= ($filters['categoria'] ?? '') == 'impostos' ? 'selected' : '' ?>>Impostos</option>
                                    <option value="aluguel" <?= ($filters['categoria'] ?? '') == 'aluguel' ? 'selected' : '' ?>>Aluguel</option>
                                    <option value="servicos" <?= ($filters['categoria'] ?? '') == 'servicos' ? 'selected' : '' ?>>Serviços</option>
                                    <option value="manutencao" <?= ($filters['categoria'] ?? '') == 'manutencao' ? 'selected' : '' ?>>Manutenção</option>
                                    <option value="outros" <?= ($filters['categoria'] ?? '') == 'outros' ? 'selected' : '' ?>>Outros</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>Status</label>
                                <select name="status" class="form-control">
                                    <option value="">Todos</option>
                                    <option value="pendente" <?= ($filters['status'] ?? '') == 'pendente' ? 'selected' : '' ?>>Pendente</option>
                                    <option value="pago" <?= ($filters['status'] ?? '') == 'pago' ? 'selected' : '' ?>>Pago</option>
                                    <option value="vencido" <?= ($filters['status'] ?? '') == 'vencido' ? 'selected' : '' ?>>Vencido</option>
                                    <option value="cancelado" <?= ($filters['status'] ?? '') == 'cancelado' ? 'selected' : '' ?>>Cancelado</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>Vencimento De</label>
                                <input type="date" name="data_inicio" class="form-control" 
                                       value="<?= $filters['data_inicio'] ?? '' ?>">
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>Vencimento Até</label>
                                <input type="date" name="data_fim" class="form-control" 
                                       value="<?= $filters['data_fim'] ?? '' ?>">
                            </div>
                        </div>
                        <div class="col-md-1">
                            <div class="form-group">
                                <label>&nbsp;</label>
                                <div>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-search"></i>
                                    </button>
                                    <a href="<?= url('contas-pagar') ?>" class="btn btn-default">
                                        <i class="fas fa-times"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Lista de Contas a Pagar -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    Lista de Contas a Pagar
                    <span class="badge badge-primary"><?= $pagination['total_records'] ?? 0 ?> registros</span>
                </h3>
                <div class="card-tools">
                    <a href="<?= url('contas-pagar/nova') ?>" class="btn btn-primary btn-sm">
                        <i class="fas fa-plus"></i> Nova Conta
                    </a>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th width="80">Código</th>
                                <th>Fornecedor/Descrição</th>
                                <th width="120">Categoria</th>
                                <th width="120">Vencimento</th>
                                <th width="120">Valor</th>
                                <th width="100">Status</th>
                                <th width="180">Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($contas)): ?>
                            <tr>
                                <td colspan="7" class="text-center py-4">
                                    <i class="fas fa-money-check-alt fa-3x text-muted mb-3"></i>
                                    <p class="text-muted">Nenhuma conta encontrada</p>
                                </td>
                            </tr>
                            <?php else: ?>
                                <?php foreach ($contas as $conta): ?>
                                <tr class="<?= $conta['status'] == 'vencido' ? 'table-danger' : '' ?>">
                                    <td>
                                        <strong>#<?= str_pad($conta['id'], 6, '0', STR_PAD_LEFT) ?></strong>
                                    </td>
                                    <td>
                                        <?php if ($conta['fornecedor_nome']): ?>
                                            <strong><?= htmlspecialchars($conta['fornecedor_nome']) ?></strong>
                                        <?php else: ?>
                                            <strong><?= htmlspecialchars($conta['descricao'] ?? 'Despesa') ?></strong>
                                        <?php endif; ?>
                                        <?php if ($conta['descricao'] && $conta['fornecedor_nome']): ?>
                                        <br>
                                        <small class="text-muted">
                                            <?= htmlspecialchars($conta['descricao']) ?>
                                        </small>
                                        <?php endif; ?>
                                        <?php if ($conta['numero_documento']): ?>
                                        <br>
                                        <small class="text-muted">
                                            Doc: <?= htmlspecialchars($conta['numero_documento']) ?>
                                        </small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php
                                        $categoriaLabels = [
                                            'fornecedores' => 'Fornecedores',
                                            'folha_pagamento' => 'Folha',
                                            'impostos' => 'Impostos',
                                            'aluguel' => 'Aluguel',
                                            'servicos' => 'Serviços',
                                            'manutencao' => 'Manutenção',
                                            'outros' => 'Outros'
                                        ];
                                        $categoriaClass = [
                                            'fornecedores' => 'badge-primary',
                                            'folha_pagamento' => 'badge-info',
                                            'impostos' => 'badge-warning',
                                            'aluguel' => 'badge-secondary',
                                            'servicos' => 'badge-dark',
                                            'manutencao' => 'badge-danger',
                                            'outros' => 'badge-light'
                                        ];
                                        ?>
                                        <span class="badge <?= $categoriaClass[$conta['categoria']] ?? 'badge-secondary' ?>">
                                            <?= $categoriaLabels[$conta['categoria']] ?? 'N/D' ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php 
                                        $vencimento = new DateTime($conta['data_vencimento']);
                                        $hoje = new DateTime();
                                        $diff = $hoje->diff($vencimento);
                                        $diasAtraso = $vencimento < $hoje ? $diff->days : 0;
                                        ?>
                                        <?= $vencimento->format('d/m/Y') ?>
                                        <?php if ($diasAtraso > 0 && $conta['status'] != 'pago'): ?>
                                        <br>
                                        <small class="text-danger">
                                            <i class="fas fa-exclamation-triangle"></i> 
                                            <?= $diasAtraso ?> dias de atraso
                                        </small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <strong>R$ <?= number_format($conta['valor'], 2, ',', '.') ?></strong>
                                        <?php if ($conta['juros'] > 0): ?>
                                        <br>
                                        <small class="text-danger">
                                            + Juros: R$ <?= number_format($conta['juros'], 2, ',', '.') ?>
                                        </small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php
                                        $statusClass = [
                                            'pendente' => 'badge-warning',
                                            'pago' => 'badge-success',
                                            'vencido' => 'badge-danger',
                                            'cancelado' => 'badge-secondary'
                                        ];
                                        $statusText = [
                                            'pendente' => 'Pendente',
                                            'pago' => 'Pago',
                                            'vencido' => 'Vencido',
                                            'cancelado' => 'Cancelado'
                                        ];
                                        ?>
                                        <span class="badge <?= $statusClass[$conta['status']] ?? 'badge-secondary' ?>">
                                            <?= $statusText[$conta['status']] ?? 'N/D' ?>
                                        </span>
                                        <?php if ($conta['data_pagamento']): ?>
                                        <br>
                                        <small class="text-muted">
                                            <?= date('d/m/Y', strtotime($conta['data_pagamento'])) ?>
                                        </small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="<?= url('contas-pagar/visualizar/' . $conta['id']) ?>" 
                                               class="btn btn-info" title="Visualizar">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            
                                            <?php if ($conta['status'] != 'pago' && $conta['status'] != 'cancelado'): ?>
                                            <button type="button" class="btn btn-success" 
                                                    onclick="registrarPagamento(<?= $conta['id'] ?>)" 
                                                    title="Pagar">
                                                <i class="fas fa-check"></i>
                                            </button>
                                            <?php endif; ?>
                                            
                                            <?php if ($conta['status'] == 'pago'): ?>
                                            <a href="<?= url('contas-pagar/comprovante/' . $conta['id']) ?>" 
                                               class="btn btn-secondary" title="Comprovante" target="_blank">
                                                <i class="fas fa-file-pdf"></i>
                                            </a>
                                            <?php endif; ?>
                                            
                                            <a href="<?= url('contas-pagar/editar/' . $conta['id']) ?>" 
                                               class="btn btn-warning" title="Editar">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            
                                            <?php if ($conta['status'] != 'pago'): ?>
                                            <button type="button" class="btn btn-danger" 
                                                    onclick="cancelarConta(<?= $conta['id'] ?>)" 
                                                    title="Cancelar">
                                                <i class="fas fa-times"></i>
                                            </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <?php if (($pagination['total'] ?? 0) > 1): ?>
            <div class="card-footer">
                <nav aria-label="Paginação">
                    <ul class="pagination pagination-sm m-0 float-right">
                        <?php if ($pagination['current'] > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?= $pagination['current'] - 1 ?>&<?= http_build_query(array_diff_key($filters ?? [], ['page' => ''])) ?>">
                                &laquo;
                            </a>
                        </li>
                        <?php endif; ?>
                        
                        <?php for ($i = 1; $i <= $pagination['total']; $i++): ?>
                            <?php if ($i == 1 || $i == $pagination['total'] || ($i >= $pagination['current'] - 2 && $i <= $pagination['current'] + 2)): ?>
                            <li class="page-item <?= $i == $pagination['current'] ? 'active' : '' ?>">
                                <a class="page-link" href="?page=<?= $i ?>&<?= http_build_query(array_diff_key($filters ?? [], ['page' => ''])) ?>">
                                    <?= $i ?>
                                </a>
                            </li>
                            <?php elseif ($i == $pagination['current'] - 3 || $i == $pagination['current'] + 3): ?>
                            <li class="page-item disabled"><span class="page-link">...</span></li>
                            <?php endif; ?>
                        <?php endfor; ?>
                        
                        <?php if ($pagination['current'] < $pagination['total']): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?= $pagination['current'] + 1 ?>&<?= http_build_query(array_diff_key($filters ?? [], ['page' => ''])) ?>">
                                &raquo;
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<script>
function registrarPagamento(id) {
    Swal.fire({
        title: 'Registrar Pagamento',
        html: `
            <div class="form-group text-left">
                <label>Data do Pagamento</label>
                <input type="date" id="data_pagamento" class="form-control" value="${new Date().toISOString().split('T')[0]}">
            </div>
            <div class="form-group text-left">
                <label>Forma de Pagamento</label>
                <select id="forma_pagamento" class="form-control">
                    <option value="dinheiro">Dinheiro</option>
                    <option value="pix">PIX</option>
                    <option value="boleto">Boleto</option>
                    <option value="transferencia">Transferência</option>
                    <option value="cheque">Cheque</option>
                    <option value="cartao">Cartão</option>
                </select>
            </div>
            <div class="form-group text-left">
                <label>Observações</label>
                <textarea id="observacoes" class="form-control" rows="3"></textarea>
            </div>
        `,
        showCancelButton: true,
        confirmButtonColor: '#28a745',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Registrar',
        cancelButtonText: 'Cancelar',
        preConfirm: () => {
            return {
                data_pagamento: document.getElementById('data_pagamento').value,
                forma_pagamento: document.getElementById('forma_pagamento').value,
                observacoes: document.getElementById('observacoes').value
            }
        }
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = '<?= url('contas-pagar/pagar/') ?>' + id + 
                '?data=' + result.value.data_pagamento + 
                '&forma=' + result.value.forma_pagamento +
                '&obs=' + encodeURIComponent(result.value.observacoes);
        }
    });
}

function cancelarConta(id) {
    Swal.fire({
        title: 'Cancelar Conta',
        text: 'Tem certeza que deseja cancelar esta conta?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Sim, cancelar!',
        cancelButtonText: 'Não'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = '<?= url('contas-pagar/cancelar/') ?>' + id;
        }
    });
}
</script>
