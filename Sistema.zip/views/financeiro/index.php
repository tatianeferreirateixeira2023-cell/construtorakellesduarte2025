<?php include __DIR__ . '/../layouts/header.php'; ?>

<!-- Content Header -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>
                    <i class="fas fa-chart-line"></i> Financeiro
                    <small>Visão geral financeira</small>
                </h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?= url() ?>">Início</a></li>
                    <li class="breadcrumb-item active">Financeiro</li>
                </ol>
            </div>
        </div>
    </div>
</section>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        
        <!-- Resumo do Mês -->
        <div class="row">
            <div class="col-lg-3 col-6">
                <div class="small-box bg-success">
                    <div class="inner">
                        <h3>R$ <?= number_format($receitas_mes ?? 0, 2, ',', '.') ?></h3>
                        <p>Receitas do Mês</p>
                        <small><?= $qtd_receitas ?? 0 ?> lançamentos</small>
                    </div>
                    <div class="icon">
                        <i class="fas fa-arrow-up"></i>
                    </div>
                    <a href="<?= url('faturas') ?>" class="small-box-footer">
                        Ver detalhes <i class="fas fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-danger">
                    <div class="inner">
                        <h3>R$ <?= number_format($despesas_mes ?? 0, 2, ',', '.') ?></h3>
                        <p>Despesas do Mês</p>
                        <small><?= $qtd_despesas ?? 0 ?> lançamentos</small>
                    </div>
                    <div class="icon">
                        <i class="fas fa-arrow-down"></i>
                    </div>
                    <a href="<?= url('contas-pagar') ?>" class="small-box-footer">
                        Ver detalhes <i class="fas fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box <?= ($saldo_mes ?? 0) >= 0 ? 'bg-info' : 'bg-warning' ?>">
                    <div class="inner">
                        <h3>R$ <?= number_format($saldo_mes ?? 0, 2, ',', '.') ?></h3>
                        <p>Saldo do Mês</p>
                        <small><?= ($saldo_mes ?? 0) >= 0 ? 'Positivo' : 'Negativo' ?></small>
                    </div>
                    <div class="icon">
                        <i class="fas fa-balance-scale"></i>
                    </div>
                    <a href="<?= url('financeiro/relatorio') ?>" class="small-box-footer">
                        Ver relatório <i class="fas fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-warning">
                    <div class="inner">
                        <h3>R$ <?= number_format($total_receber ?? 0, 2, ',', '.') ?></h3>
                        <p>A Receber</p>
                        <small><?= $qtd_receber ?? 0 ?> faturas</small>
                    </div>
                    <div class="icon">
                        <i class="fas fa-hand-holding-usd"></i>
                    </div>
                    <a href="<?= url('faturas?status=em_aberto') ?>" class="small-box-footer">
                        Ver pendências <i class="fas fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Faturas Vencendo Hoje -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header border-0">
                        <h3 class="card-title">
                            <i class="fas fa-exclamation-triangle text-warning"></i> 
                            Faturas Vencendo Hoje
                        </h3>
                        <div class="card-tools">
                            <a href="<?= url('faturas?vencimento=hoje') ?>" class="btn btn-sm btn-primary">
                                Ver todas
                            </a>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <?php if (empty($vencendo_hoje)): ?>
                        <div class="p-4 text-center text-muted">
                            <i class="fas fa-check-circle fa-3x mb-3"></i>
                            <p>Nenhuma fatura vencendo hoje</p>
                        </div>
                        <?php else: ?>
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Cliente</th>
                                    <th>Valor</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($vencendo_hoje as $fatura): ?>
                                <tr>
                                    <td>
                                        <strong><?= htmlspecialchars($fatura['cliente_nome']) ?></strong>
                                        <br>
                                        <small class="text-muted">
                                            Fatura #<?= str_pad($fatura['id'], 6, '0', STR_PAD_LEFT) ?>
                                        </small>
                                    </td>
                                    <td>
                                        <strong>R$ <?= number_format($fatura['valor'], 2, ',', '.') ?></strong>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="<?= url('faturas/visualizar/' . $fatura['id']) ?>" 
                                               class="btn btn-info" title="Ver">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <button type="button" class="btn btn-success" 
                                                    onclick="registrarPagamento(<?= $fatura['id'] ?>)" 
                                                    title="Receber">
                                                <i class="fas fa-check"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Gráfico de Receitas x Despesas -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header border-0">
                        <h3 class="card-title">
                            <i class="fas fa-chart-bar"></i> 
                            Receitas x Despesas (Últimos 6 meses)
                        </h3>
                    </div>
                    <div class="card-body">
                        <canvas id="graficoFinanceiro" style="height: 250px;"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Ações Rápidas -->
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-bolt"></i> Ações Rápidas
                        </h3>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3">
                                <a href="<?= url('faturas/nova') ?>" class="btn btn-success btn-block">
                                    <i class="fas fa-plus-circle"></i> Nova Fatura
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="<?= url('contas-pagar/nova') ?>" class="btn btn-danger btn-block">
                                    <i class="fas fa-minus-circle"></i> Nova Despesa
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="<?= url('financeiro/fluxo-caixa') ?>" class="btn btn-info btn-block">
                                    <i class="fas fa-chart-line"></i> Fluxo de Caixa
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="<?= url('financeiro/relatorio') ?>" class="btn btn-primary btn-block">
                                    <i class="fas fa-file-pdf"></i> Relatório Mensal
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Resumo por Categoria -->
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-tags"></i> Receitas por Categoria
                        </h3>
                    </div>
                    <div class="card-body">
                        <canvas id="graficoReceitasCategoria" style="height: 200px;"></canvas>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-tags"></i> Despesas por Categoria
                        </h3>
                    </div>
                    <div class="card-body">
                        <canvas id="graficoDespesasCategoria" style="height: 200px;"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
// Gráfico de Receitas x Despesas
var ctx = document.getElementById('graficoFinanceiro').getContext('2d');
var graficoFinanceiro = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'],
        datasets: [{
            label: 'Receitas',
            data: [12000, 15000, 18000, 14000, 16000, 20000],
            backgroundColor: 'rgba(40, 167, 69, 0.8)',
            borderColor: 'rgba(40, 167, 69, 1)',
            borderWidth: 1
        }, {
            label: 'Despesas',
            data: [8000, 9000, 11000, 10000, 12000, 13000],
            backgroundColor: 'rgba(220, 53, 69, 0.8)',
            borderColor: 'rgba(220, 53, 69, 1)',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return 'R$ ' + value.toLocaleString('pt-BR');
                    }
                }
            }
        }
    }
});

// Gráfico de Receitas por Categoria
var ctx2 = document.getElementById('graficoReceitasCategoria').getContext('2d');
var graficoReceitasCategoria = new Chart(ctx2, {
    type: 'doughnut',
    data: {
        labels: ['Vendas', 'Aluguel', 'Serviços', 'Outros'],
        datasets: [{
            data: [45, 30, 20, 5],
            backgroundColor: [
                '#28a745',
                '#17a2b8',
                '#ffc107',
                '#6c757d'
            ]
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false
    }
});

// Gráfico de Despesas por Categoria
var ctx3 = document.getElementById('graficoDespesasCategoria').getContext('2d');
var graficoDespesasCategoria = new Chart(ctx3, {
    type: 'doughnut',
    data: {
        labels: ['Fornecedores', 'Folha', 'Impostos', 'Manutenção', 'Outros'],
        datasets: [{
            data: [35, 25, 20, 15, 5],
            backgroundColor: [
                '#dc3545',
                '#E85D2C',
                '#ffc107',
                '#6f42c1',
                '#6c757d'
            ]
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false
    }
});

// Função para registrar pagamento
function registrarPagamento(id) {
    Swal.fire({
        title: 'Registrar Pagamento',
        text: 'Confirma o recebimento desta fatura?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#28a745',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Sim, registrar!',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = '<?= url('faturas/pagar/') ?>' + id;
        }
    });
}
</script>

<?php include __DIR__ . '/../layouts/footer.php'; ?>
