<?php require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-file-invoice-dollar"></i> Nova Conta a Pagar
                    </h3>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?= BASE_URL ?>contas-pagar/nova">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="descricao">Descrição <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="descricao" name="descricao" required
                                           placeholder="Descrição da conta">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="valor">Valor <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">R$</span>
                                        </div>
                                        <input type="text" class="form-control money" id="valor" name="valor" required
                                               placeholder="0,00">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="data_vencimento">Data de Vencimento <span class="text-danger">*</span></label>
                                    <input type="date" class="form-control" id="data_vencimento" name="data_vencimento" required>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="fornecedor_id">Fornecedor</label>
                                    <select class="form-control select2" id="fornecedor_id" name="fornecedor_id">
                                        <option value="">Selecione...</option>
                                        <?php foreach ($fornecedores as $fornecedor): ?>
                                            <option value="<?= $fornecedor['id'] ?>">
                                                <?= htmlspecialchars($fornecedor['razao_social']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="empreendimento_id">Empreendimento</label>
                                    <select class="form-control select2" id="empreendimento_id" name="empreendimento_id">
                                        <option value="">Selecione...</option>
                                        <?php foreach ($empreendimentos as $empreendimento): ?>
                                            <option value="<?= $empreendimento['id'] ?>">
                                                <?= htmlspecialchars($empreendimento['nome']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="categoria">Categoria <span class="text-danger">*</span></label>
                                    <select class="form-control" id="categoria" name="categoria" required>
                                        <option value="">Selecione...</option>
                                        <option value="material">Material de Construção</option>
                                        <option value="mao_obra">Mão de Obra</option>
                                        <option value="servico">Serviço</option>
                                        <option value="aluguel">Aluguel</option>
                                        <option value="energia">Energia</option>
                                        <option value="agua">Água</option>
                                        <option value="telefone">Telefone/Internet</option>
                                        <option value="combustivel">Combustível</option>
                                        <option value="manutencao">Manutenção</option>
                                        <option value="impostos">Impostos/Taxas</option>
                                        <option value="outros">Outros</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="forma_pagamento">Forma de Pagamento</label>
                                    <select class="form-control" id="forma_pagamento" name="forma_pagamento">
                                        <option value="boleto">Boleto</option>
                                        <option value="pix">PIX</option>
                                        <option value="transferencia">Transferência</option>
                                        <option value="dinheiro">Dinheiro</option>
                                        <option value="cartao">Cartão</option>
                                        <option value="cheque">Cheque</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="numero_documento">Número do Documento</label>
                                    <input type="text" class="form-control" id="numero_documento" name="numero_documento"
                                           placeholder="NF, Boleto, etc">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="centro_custo">Centro de Custo</label>
                                    <input type="text" class="form-control" id="centro_custo" name="centro_custo"
                                           placeholder="Ex: Obra 01">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="cidade">Cidade</label>
                                    <input type="text" class="form-control" id="cidade" name="cidade"
                                           placeholder="Cidade">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="observacoes">Observações</label>
                                    <textarea class="form-control" id="observacoes" name="observacoes" rows="3"
                                              placeholder="Observações adicionais"></textarea>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Salvar Conta
                                </button>
                                <a href="/sistema/contas-pagar" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> Cancelar
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Máscara para valor monetário
    $('.money').mask('#.##0,00', {reverse: true});
    
    // Select2 para dropdowns
    $('.select2').select2({
        theme: 'bootstrap4',
        placeholder: 'Selecione...',
        allowClear: true
    });
});
</script>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
