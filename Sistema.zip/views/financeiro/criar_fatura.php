<?php require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-file-invoice"></i> Nova Fatura
                    </h3>
                </div>
                <div class="card-body">
                    <?php if (isset($flash)): ?>
                        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show" role="alert">
                            <?= $flash['message'] ?>
                            <button type="button" class="close" data-dismiss="alert">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="/sistema/faturas/nova">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="imovel_id">Imóvel <span class="text-danger">*</span></label>
                                    <select class="form-control select2" id="imovel_id" name="imovel_id" required>
                                        <option value="">Selecione o imóvel...</option>
                                        <?php foreach ($imoveis as $imovel): ?>
                                            <option value="<?= $imovel['id'] ?>">
                                                <?= htmlspecialchars($imovel['codigo']) ?> - 
                                                <?= htmlspecialchars($imovel['endereco']) ?>
                                                <?php if ($imovel['empreendimento']): ?>
                                                    (<?= htmlspecialchars($imovel['empreendimento']) ?>)
                                                <?php endif; ?>
                                                <?php if ($imovel['cliente']): ?>
                                                    - Cliente: <?= htmlspecialchars($imovel['cliente']) ?>
                                                <?php endif; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="tipo">Tipo de Fatura <span class="text-danger">*</span></label>
                                    <select class="form-control" id="tipo" name="tipo" required>
                                        <option value="mensalidade">Mensalidade</option>
                                        <option value="entrada">Entrada</option>
                                        <option value="parcela">Parcela</option>
                                        <option value="taxa">Taxa</option>
                                        <option value="multa">Multa</option>
                                        <option value="outros">Outros</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="data_vencimento">Data de Vencimento <span class="text-danger">*</span></label>
                                    <input type="date" class="form-control" id="data_vencimento" name="data_vencimento" 
                                           required min="<?= date('Y-m-d') ?>">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label for="descricao">Descrição <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="descricao" name="descricao" 
                                           required placeholder="Ex: Mensalidade referente ao mês de Janeiro/2024">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="valor">Valor <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">R$</span>
                                        </div>
                                        <input type="text" class="form-control money" id="valor" name="valor" 
                                               required placeholder="0,00">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="observacoes">Observações</label>
                                    <textarea class="form-control" id="observacoes" name="observacoes" rows="3"
                                              placeholder="Observações adicionais (opcional)"></textarea>
                                </div>
                            </div>
                        </div>

                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> 
                            Após criar a fatura, o cliente receberá uma notificação e poderá realizar o pagamento através do sistema.
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Criar Fatura
                                </button>
                                <a href="/sistema/faturas" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> Cancelar
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Máscara para valor monetário
    $('.money').mask('#.##0,00', {reverse: true});
    
    // Select2 para dropdown de imóveis
    $('.select2').select2({
        theme: 'bootstrap4',
        placeholder: 'Selecione o imóvel...',
        allowClear: true,
        width: '100%'
    });
    
    // Preenche descrição automaticamente baseado no tipo
    $('#tipo').change(function() {
        var tipo = $(this).val();
        var mes = new Date().toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
        var descricoes = {
            'mensalidade': 'Mensalidade referente a ' + mes,
            'entrada': 'Entrada do imóvel',
            'parcela': 'Parcela do financiamento',
            'taxa': 'Taxa administrativa',
            'multa': 'Multa por atraso',
            'outros': 'Cobrança'
        };
        
        if (descricoes[tipo]) {
            $('#descricao').val(descricoes[tipo]);
        }
    });
});
</script>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
