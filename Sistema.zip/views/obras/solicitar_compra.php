<?php require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-shopping-cart"></i> Solicitar Compra
                    </h3>
                </div>
                <div class="card-body">
                    <?php if (isset($flash)): ?>
                        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show" role="alert">
                            <?= $flash['message'] ?>
                            <button type="button" class="close" data-dismiss="alert">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="/sistema/obras/compras/solicitar">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="empreendimento_id">Empreendimento <span class="text-danger">*</span></label>
                                    <select class="form-control select2" id="empreendimento_id" name="empreendimento_id" required>
                                        <option value="">Selecione o empreendimento...</option>
                                        <?php foreach ($empreendimentos as $empreendimento): ?>
                                            <option value="<?= $empreendimento['id'] ?>">
                                                <?= htmlspecialchars($empreendimento['nome']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="fornecedor_id">Fornecedor Sugerido</label>
                                    <select class="form-control select2" id="fornecedor_id" name="fornecedor_id">
                                        <option value="">Selecione (opcional)...</option>
                                        <?php foreach ($fornecedores as $fornecedor): ?>
                                            <option value="<?= $fornecedor['id'] ?>">
                                                <?= htmlspecialchars($fornecedor['razao_social']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="prazo_entrega">Prazo de Entrega</label>
                                    <input type="date" class="form-control" id="prazo_entrega" name="prazo_entrega"
                                           min="<?= date('Y-m-d') ?>">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="descricao">Descrição da Compra <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="descricao" name="descricao" required
                                           placeholder="Ex: Materiais para construção do Bloco A">
                                </div>
                            </div>
                        </div>

                        <!-- Itens da Compra -->
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Itens da Compra</h5>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="tabela-itens">
                                        <thead>
                                            <tr>
                                                <th width="40%">Descrição do Item</th>
                                                <th width="15%">Quantidade</th>
                                                <th width="10%">Unidade</th>
                                                <th width="15%">Valor Unit.</th>
                                                <th width="15%">Valor Total</th>
                                                <th width="5%">Ação</th>
                                            </tr>
                                        </thead>
                                        <tbody id="itens-container">
                                            <tr class="item-row">
                                                <td>
                                                    <input type="text" class="form-control" name="item_descricao[]" 
                                                           placeholder="Ex: Cimento CP-II 50kg">
                                                </td>
                                                <td>
                                                    <input type="number" class="form-control quantidade" name="item_quantidade[]" 
                                                           step="0.01" min="0" value="1">
                                                </td>
                                                <td>
                                                    <select class="form-control" name="item_unidade[]">
                                                        <option value="UN">UN</option>
                                                        <option value="PC">PC</option>
                                                        <option value="CX">CX</option>
                                                        <option value="M">M</option>
                                                        <option value="M2">M²</option>
                                                        <option value="M3">M³</option>
                                                        <option value="KG">KG</option>
                                                        <option value="L">L</option>
                                                        <option value="SC">SC</option>
                                                    </select>
                                                </td>
                                                <td>
                                                    <input type="text" class="form-control money valor-unitario" 
                                                           name="item_valor[]" placeholder="0,00">
                                                </td>
                                                <td>
                                                    <input type="text" class="form-control money valor-total" 
                                                           name="item_total[]" placeholder="0,00" readonly>
                                                </td>
                                                <td>
                                                    <button type="button" class="btn btn-sm btn-danger remover-item" disabled>
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td colspan="4" class="text-right"><strong>Total Geral:</strong></td>
                                                <td>
                                                    <input type="text" class="form-control money" id="valor_total" 
                                                           name="valor_total" readonly value="0,00">
                                                </td>
                                                <td>
                                                    <button type="button" class="btn btn-sm btn-success" id="adicionar-item">
                                                        <i class="fas fa-plus"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <div class="row mt-3">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="observacoes">Observações</label>
                                    <textarea class="form-control" id="observacoes" name="observacoes" rows="3"
                                              placeholder="Informações adicionais sobre a compra"></textarea>
                                </div>
                            </div>
                        </div>

                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle"></i> 
                            Esta solicitação será enviada para aprovação do setor financeiro antes de ser processada.
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-paper-plane"></i> Enviar Solicitação
                                </button>
                                <a href="/sistema/obras/compras" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> Cancelar
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Select2 para dropdowns
    $('.select2').select2({
        theme: 'bootstrap4',
        placeholder: 'Selecione...',
        allowClear: true,
        width: '100%'
    });
    
    // Máscara monetária
    $('.money').mask('#.##0,00', {reverse: true});
    
    // Template para nova linha de item
    var itemTemplate = `
        <tr class="item-row">
            <td>
                <input type="text" class="form-control" name="item_descricao[]" placeholder="Descrição do item">
            </td>
            <td>
                <input type="number" class="form-control quantidade" name="item_quantidade[]" 
                       step="0.01" min="0" value="1">
            </td>
            <td>
                <select class="form-control" name="item_unidade[]">
                    <option value="UN">UN</option>
                    <option value="PC">PC</option>
                    <option value="CX">CX</option>
                    <option value="M">M</option>
                    <option value="M2">M²</option>
                    <option value="M3">M³</option>
                    <option value="KG">KG</option>
                    <option value="L">L</option>
                    <option value="SC">SC</option>
                </select>
            </td>
            <td>
                <input type="text" class="form-control money valor-unitario" name="item_valor[]" placeholder="0,00">
            </td>
            <td>
                <input type="text" class="form-control money valor-total" name="item_total[]" placeholder="0,00" readonly>
            </td>
            <td>
                <button type="button" class="btn btn-sm btn-danger remover-item">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
    `;
    
    // Adicionar novo item
    $('#adicionar-item').click(function() {
        $('#itens-container').append(itemTemplate);
        
        // Reaplica máscara nos novos campos
        $('.money').mask('#.##0,00', {reverse: true});
        
        // Habilita botão remover da primeira linha se houver mais de uma
        if ($('.item-row').length > 1) {
            $('.remover-item').first().prop('disabled', false);
        }
    });
    
    // Remover item
    $(document).on('click', '.remover-item', function() {
        $(this).closest('tr').remove();
        calcularTotal();
        
        // Desabilita botão remover se só houver uma linha
        if ($('.item-row').length === 1) {
            $('.remover-item').prop('disabled', true);
        }
    });
    
    // Calcular valor total do item
    $(document).on('keyup change', '.quantidade, .valor-unitario', function() {
        var row = $(this).closest('tr');
        var quantidade = parseFloat(row.find('.quantidade').val()) || 0;
        var valorUnitario = parseFloat(row.find('.valor-unitario').val().replace(/\./g, '').replace(',', '.')) || 0;
        var total = quantidade * valorUnitario;
        
        row.find('.valor-total').val(total.toFixed(2).replace('.', ','));
        calcularTotal();
    });
    
    // Calcular total geral
    function calcularTotal() {
        var total = 0;
        $('.valor-total').each(function() {
            var valor = parseFloat($(this).val().replace(/\./g, '').replace(',', '.')) || 0;
            total += valor;
        });
        
        $('#valor_total').val(total.toFixed(2).replace('.', ','));
    }
});
</script>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
