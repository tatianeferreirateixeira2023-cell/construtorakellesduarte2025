<?php require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-exclamation-triangle"></i> Nova Ocorrência/Manutenção
                    </h3>
                </div>
                <div class="card-body">
                    <?php if (isset($flash)): ?>
                        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show" role="alert">
                            <?= $flash['message'] ?>
                            <button type="button" class="close" data-dismiss="alert">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="/sistema/obras/ocorrencias/criar" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="empreendimento_id">Empreendimento <span class="text-danger">*</span></label>
                                    <select class="form-control select2" id="empreendimento_id" name="empreendimento_id" required>
                                        <option value="">Selecione o empreendimento...</option>
                                        <?php foreach ($empreendimentos as $empreendimento): ?>
                                            <option value="<?= $empreendimento['id'] ?>" 
                                                    <?= (isset($old['empreendimento_id']) && $old['empreendimento_id'] == $empreendimento['id']) ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($empreendimento['nome']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <?php if (isset($errors['empreendimento_id'])): ?>
                                        <small class="text-danger"><?= $errors['empreendimento_id'][0] ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="prioridade">Prioridade <span class="text-danger">*</span></label>
                                    <select class="form-control" id="prioridade" name="prioridade" required>
                                        <option value="">Selecione...</option>
                                        <option value="baixa" <?= (isset($old['prioridade']) && $old['prioridade'] == 'baixa') ? 'selected' : '' ?>>
                                            Baixa
                                        </option>
                                        <option value="media" <?= (isset($old['prioridade']) && $old['prioridade'] == 'media') ? 'selected' : '' ?>>
                                            Média
                                        </option>
                                        <option value="alta" <?= (isset($old['prioridade']) && $old['prioridade'] == 'alta') ? 'selected' : '' ?>>
                                            Alta
                                        </option>
                                        <option value="urgente" <?= (isset($old['prioridade']) && $old['prioridade'] == 'urgente') ? 'selected' : '' ?>>
                                            Urgente
                                        </option>
                                    </select>
                                    <?php if (isset($errors['prioridade'])): ?>
                                        <small class="text-danger"><?= $errors['prioridade'][0] ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="encarregado_id">Encarregado Responsável</label>
                                    <select class="form-control select2" id="encarregado_id" name="encarregado_id">
                                        <option value="">Selecione...</option>
                                        <?php foreach ($encarregados as $encarregado): ?>
                                            <option value="<?= $encarregado['id'] ?>"
                                                    <?= (isset($old['encarregado_id']) && $old['encarregado_id'] == $encarregado['id']) ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($encarregado['nome_completo']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="descricao">Descrição da Ocorrência <span class="text-danger">*</span></label>
                                    <textarea class="form-control" id="descricao" name="descricao" rows="5" required
                                              placeholder="Descreva detalhadamente a ocorrência ou problema encontrado"><?= isset($old['descricao']) ? htmlspecialchars($old['descricao']) : '' ?></textarea>
                                    <?php if (isset($errors['descricao'])): ?>
                                        <small class="text-danger"><?= $errors['descricao'][0] ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="local">Local/Área Específica</label>
                                    <input type="text" class="form-control" id="local" name="local" 
                                           placeholder="Ex: Bloco A, Apartamento 201"
                                           value="<?= isset($old['local']) ? htmlspecialchars($old['local']) : '' ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="arquivos">Anexar Fotos/Documentos</label>
                                    <input type="file" class="form-control-file" id="arquivos" name="arquivos[]" 
                                           multiple accept="image/*,.pdf,.doc,.docx">
                                    <small class="form-text text-muted">
                                        Você pode selecionar múltiplos arquivos. Formatos aceitos: imagens, PDF, Word
                                    </small>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="observacoes">Observações Adicionais</label>
                                    <textarea class="form-control" id="observacoes" name="observacoes" rows="3"
                                              placeholder="Informações complementares (opcional)"><?= isset($old['observacoes']) ? htmlspecialchars($old['observacoes']) : '' ?></textarea>
                                </div>
                            </div>
                        </div>

                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> 
                            Após o registro, o encarregado responsável será notificado e poderá acompanhar a resolução da ocorrência.
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Registrar Ocorrência
                                </button>
                                <a href="/sistema/obras/ocorrencias" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> Cancelar
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Select2 para dropdowns
    $('.select2').select2({
        theme: 'bootstrap4',
        placeholder: 'Selecione...',
        allowClear: true,
        width: '100%'
    });
    
    // Destaca campo de prioridade baseado na seleção
    $('#prioridade').change(function() {
        var prioridade = $(this).val();
        $(this).removeClass('bg-danger bg-warning bg-info bg-success');
        
        switch(prioridade) {
            case 'urgente':
                $(this).addClass('bg-danger text-white');
                break;
            case 'alta':
                $(this).addClass('bg-warning');
                break;
            case 'media':
                $(this).addClass('bg-info text-white');
                break;
            case 'baixa':
                $(this).addClass('bg-success text-white');
                break;
        }
    });
});
</script>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
