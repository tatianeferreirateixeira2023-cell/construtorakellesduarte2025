<?php
$pageTitle = 'Ocorrências de Manutenção';
$currentPage = 'obras';
?>

<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12 d-flex justify-content-between align-items-center">
            <h1 class="h3 mb-0">Ocorrências de Manutenção</h1>
            <a href="<?= BASE_URL ?>obras/ocorrencias/criar" class="btn btn-primary">
                <i class="fas fa-plus"></i> Nova Ocorrência
            </a>
        </div>
    </div>

    <?php if (isset($flash)): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show" role="alert">
            <?= $flash['message'] ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <!-- Filtros -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Filtros</h6>
        </div>
        <div class="card-body">
            <form method="GET" action="<?= BASE_URL ?>obras/ocorrencias">
                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="empreendimento">Empreendimento</label>
                            <select name="empreendimento" id="empreendimento" class="form-control">
                                <option value="">Todos</option>
                                <?php foreach ($empreendimentos as $emp): ?>
                                    <option value="<?= $emp['id'] ?>" 
                                            <?= (isset($filters['empreendimento']) && $filters['empreendimento'] == $emp['id']) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($emp['nome']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select name="status" id="status" class="form-control">
                                <option value="">Todos</option>
                                <option value="aberta" <?= (isset($filters['status']) && $filters['status'] == 'aberta') ? 'selected' : '' ?>>Aberta</option>
                                <option value="em_andamento" <?= (isset($filters['status']) && $filters['status'] == 'em_andamento') ? 'selected' : '' ?>>Em Andamento</option>
                                <option value="concluida" <?= (isset($filters['status']) && $filters['status'] == 'concluida') ? 'selected' : '' ?>>Concluída</option>
                                <option value="cancelada" <?= (isset($filters['status']) && $filters['status'] == 'cancelada') ? 'selected' : '' ?>>Cancelada</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="prioridade">Prioridade</label>
                            <select name="prioridade" id="prioridade" class="form-control">
                                <option value="">Todas</option>
                                <option value="baixa" <?= (isset($filters['prioridade']) && $filters['prioridade'] == 'baixa') ? 'selected' : '' ?>>Baixa</option>
                                <option value="media" <?= (isset($filters['prioridade']) && $filters['prioridade'] == 'media') ? 'selected' : '' ?>>Média</option>
                                <option value="alta" <?= (isset($filters['prioridade']) && $filters['prioridade'] == 'alta') ? 'selected' : '' ?>>Alta</option>
                                <option value="urgente" <?= (isset($filters['prioridade']) && $filters['prioridade'] == 'urgente') ? 'selected' : '' ?>>Urgente</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>&nbsp;</label>
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-search"></i> Filtrar
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Tabela de Ocorrências -->
    <div class="card shadow">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">
                Lista de Ocorrências (<?= number_format($pagination['total_records']) ?> registros)
            </h6>
        </div>
        <div class="card-body">
            <?php if (!empty($ocorrencias)): ?>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th width="80">ID</th>
                                <th>Empreendimento</th>
                                <th>Descrição</th>
                                <th>Encarregado</th>
                                <th width="100">Prioridade</th>
                                <th width="120">Status</th>
                                <th width="100">Duração</th>
                                <th width="150">Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($ocorrencias as $ocorrencia): ?>
                                <tr>
                                    <td class="text-center">#<?= $ocorrencia['id'] ?></td>
                                    <td>
                                        <strong><?= htmlspecialchars($ocorrencia['empreendimento_nome']) ?></strong><br>
                                        <small class="text-muted"><?= htmlspecialchars($ocorrencia['cidade']) ?></small>
                                    </td>
                                    <td><?= htmlspecialchars(substr($ocorrencia['descricao'], 0, 100)) ?>...</td>
                                    <td><?= htmlspecialchars($ocorrencia['encarregado_nome']) ?></td>
                                    <td class="text-center">
                                        <?php
                                        $prioridadeClass = [
                                            'baixa' => 'badge-secondary',
                                            'media' => 'badge-info',
                                            'alta' => 'badge-warning',
                                            'urgente' => 'badge-danger'
                                        ][$ocorrencia['prioridade']] ?? 'badge-secondary';
                                        ?>
                                        <span class="badge <?= $prioridadeClass ?>">
                                            <?= ucfirst($ocorrencia['prioridade']) ?>
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <?php
                                        $statusClass = [
                                            'aberta' => 'badge-danger',
                                            'em_andamento' => 'badge-warning',
                                            'concluida' => 'badge-success',
                                            'cancelada' => 'badge-secondary'
                                        ][$ocorrencia['status']] ?? 'badge-secondary';
                                        ?>
                                        <span class="badge <?= $statusClass ?>">
                                            <?= ucfirst(str_replace('_', ' ', $ocorrencia['status'])) ?>
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <?= $ocorrencia['dias_duracao'] ?? 0 ?> dias
                                    </td>
                                    <td class="text-center">
                                        <div class="btn-group" role="group">
                                            <a href="<?= BASE_URL ?>obras/ocorrencias/ver/<?= $ocorrencia['id'] ?>" 
                                               class="btn btn-sm btn-info" title="Visualizar">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="<?= BASE_URL ?>obras/ocorrencias/editar/<?= $ocorrencia['id'] ?>" 
                                               class="btn btn-sm btn-warning" title="Editar">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Paginação -->
                <?php if ($pagination['total'] > 1): ?>
                    <nav aria-label="Navegação de páginas">
                        <ul class="pagination justify-content-center">
                            <li class="page-item <?= $pagination['current'] == 1 ? 'disabled' : '' ?>">
                                <a class="page-link" href="?page=<?= $pagination['current'] - 1 ?>&<?= http_build_query($filters) ?>">
                                    Anterior
                                </a>
                            </li>
                            
                            <?php for ($i = max(1, $pagination['current'] - 2); $i <= min($pagination['total'], $pagination['current'] + 2); $i++): ?>
                                <li class="page-item <?= $i == $pagination['current'] ? 'active' : '' ?>">
                                    <a class="page-link" href="?page=<?= $i ?>&<?= http_build_query($filters) ?>">
                                        <?= $i ?>
                                    </a>
                                </li>
                            <?php endfor; ?>
                            
                            <li class="page-item <?= $pagination['current'] == $pagination['total'] ? 'disabled' : '' ?>">
                                <a class="page-link" href="?page=<?= $pagination['current'] + 1 ?>&<?= http_build_query($filters) ?>">
                                    Próxima
                                </a>
                            </li>
                        </ul>
                    </nav>
                <?php endif; ?>
            <?php else: ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> Nenhuma ocorrência encontrada.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
