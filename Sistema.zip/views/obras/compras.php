<?php
$pageTitle = 'Gestão de Compras';
$currentPage = 'obras';
?>

<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12 d-flex justify-content-between align-items-center">
            <h1 class="h3 mb-0">Gestão de Compras</h1>
            <a href="<?= BASE_URL ?>obras/compras/solicitar" class="btn btn-primary">
                <i class="fas fa-plus"></i> Solicitar Compra
            </a>
        </div>
    </div>

    <?php if (isset($flash)): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show" role="alert">
            <?= $flash['message'] ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <!-- Filtros -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Filtros</h6>
        </div>
        <div class="card-body">
            <form method="GET" action="<?= BASE_URL ?>obras/compras">
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="empreendimento">Empreendimento</label>
                            <select name="empreendimento" id="empreendimento" class="form-control">
                                <option value="">Todos</option>
                                <?php foreach ($empreendimentos as $emp): ?>
                                    <option value="<?= $emp['id'] ?>" 
                                            <?= (isset($filters['empreendimento']) && $filters['empreendimento'] == $emp['id']) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($emp['nome']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select name="status" id="status" class="form-control">
                                <option value="">Todos</option>
                                <option value="solicitado" <?= (isset($filters['status']) && $filters['status'] == 'solicitado') ? 'selected' : '' ?>>Solicitado</option>
                                <option value="aprovado" <?= (isset($filters['status']) && $filters['status'] == 'aprovado') ? 'selected' : '' ?>>Aprovado</option>
                                <option value="comprado" <?= (isset($filters['status']) && $filters['status'] == 'comprado') ? 'selected' : '' ?>>Comprado</option>
                                <option value="entregue" <?= (isset($filters['status']) && $filters['status'] == 'entregue') ? 'selected' : '' ?>>Entregue</option>
                                <option value="cancelado" <?= (isset($filters['status']) && $filters['status'] == 'cancelado') ? 'selected' : '' ?>>Cancelado</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>&nbsp;</label>
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-search"></i> Filtrar
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Tabela de Compras -->
    <div class="card shadow">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">
                Lista de Compras (<?= number_format($pagination['total_records']) ?> registros)
            </h6>
        </div>
        <div class="card-body">
            <?php if (!empty($compras)): ?>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th width="80">ID</th>
                                <th>Empreendimento</th>
                                <th>Descrição</th>
                                <th>Fornecedor</th>
                                <th>Solicitante</th>
                                <th width="120">Valor Total</th>
                                <th width="100">Status</th>
                                <th width="180">Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($compras as $compra): ?>
                                <tr>
                                    <td class="text-center">#<?= $compra['id'] ?></td>
                                    <td><?= htmlspecialchars($compra['empreendimento_nome']) ?></td>
                                    <td><?= htmlspecialchars(substr($compra['descricao'], 0, 80)) ?>...</td>
                                    <td><?= htmlspecialchars($compra['fornecedor_nome'] ?? 'Não definido') ?></td>
                                    <td><?= htmlspecialchars($compra['solicitante_nome']) ?></td>
                                    <td class="text-right">
                                        R$ <?= number_format($compra['valor_total'], 2, ',', '.') ?>
                                    </td>
                                    <td class="text-center">
                                        <?php
                                        $statusClass = [
                                            'solicitado' => 'badge-warning',
                                            'aprovado' => 'badge-info',
                                            'comprado' => 'badge-primary',
                                            'entregue' => 'badge-success',
                                            'cancelado' => 'badge-danger'
                                        ][$compra['status']] ?? 'badge-secondary';
                                        ?>
                                        <span class="badge <?= $statusClass ?>">
                                            <?= ucfirst($compra['status']) ?>
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <div class="btn-group" role="group">
                                            <a href="<?= BASE_URL ?>obras/compras/ver/<?= $compra['id'] ?>" 
                                               class="btn btn-sm btn-info" title="Visualizar">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            
                                            <?php if ($compra['status'] == 'solicitado'): ?>
                                                <a href="<?= BASE_URL ?>obras/compras/aprovar/<?= $compra['id'] ?>" 
                                                   class="btn btn-sm btn-success" title="Aprovar"
                                                   onclick="return confirm('Aprovar esta compra?')">
                                                    <i class="fas fa-check"></i>
                                                </a>
                                                <a href="<?= BASE_URL ?>obras/compras/rejeitar/<?= $compra['id'] ?>" 
                                                   class="btn btn-sm btn-danger" title="Rejeitar"
                                                   onclick="return confirm('Rejeitar esta compra?')">
                                                    <i class="fas fa-times"></i>
                                                </a>
                                            <?php endif; ?>
                                            
                                            <?php if ($compra['status'] == 'aprovado'): ?>
                                                <a href="<?= BASE_URL ?>obras/compras/marcar-comprado/<?= $compra['id'] ?>" 
                                                   class="btn btn-sm btn-primary" title="Marcar como Comprado"
                                                   onclick="return confirm('Marcar como comprado?')">
                                                    <i class="fas fa-shopping-cart"></i>
                                                </a>
                                            <?php endif; ?>
                                            
                                            <?php if ($compra['status'] == 'comprado'): ?>
                                                <a href="<?= BASE_URL ?>obras/compras/marcar-entregue/<?= $compra['id'] ?>" 
                                                   class="btn btn-sm btn-success" title="Confirmar Entrega"
                                                   onclick="return confirm('Confirmar recebimento?')">
                                                    <i class="fas fa-truck"></i>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Paginação -->
                <?php if ($pagination['total'] > 1): ?>
                    <nav aria-label="Navegação de páginas">
                        <ul class="pagination justify-content-center">
                            <li class="page-item <?= $pagination['current'] == 1 ? 'disabled' : '' ?>">
                                <a class="page-link" href="?page=<?= $pagination['current'] - 1 ?>&<?= http_build_query($filters) ?>">
                                    Anterior
                                </a>
                            </li>
                            
                            <?php for ($i = max(1, $pagination['current'] - 2); $i <= min($pagination['total'], $pagination['current'] + 2); $i++): ?>
                                <li class="page-item <?= $i == $pagination['current'] ? 'active' : '' ?>">
                                    <a class="page-link" href="?page=<?= $i ?>&<?= http_build_query($filters) ?>">
                                        <?= $i ?>
                                    </a>
                                </li>
                            <?php endfor; ?>
                            
                            <li class="page-item <?= $pagination['current'] == $pagination['total'] ? 'disabled' : '' ?>">
                                <a class="page-link" href="?page=<?= $pagination['current'] + 1 ?>&<?= http_build_query($filters) ?>">
                                    Próxima
                                </a>
                            </li>
                        </ul>
                    </nav>
                <?php endif; ?>
            <?php else: ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> Nenhuma compra encontrada.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
