<?php
$pageTitle = 'Dashboard de Obras';
$currentPage = 'obras';
?>

<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <h1 class="h3 mb-3">Dashboard de Obras</h1>
        </div>
    </div>

    <!-- Cards de Estatísticas -->
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Empreendimentos Ativos
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?= $total_empreendimentos ?? 0 ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-building fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Ocorrências Abertas
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?= $total_ocorrencias ?? 0 ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-exclamation-triangle fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                Compras Pendentes
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?= $total_compras ?? 0 ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-shopping-cart fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Ocorrências Recentes -->
    <div class="row mb-4">
        <div class="col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">Ocorrências Recentes</h6>
                    <a href="<?= BASE_URL ?>obras/ocorrencias" class="btn btn-sm btn-primary">
                        Ver Todas
                    </a>
                </div>
                <div class="card-body">
                    <?php if (!empty($ocorrencias_recentes)): ?>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Empreendimento</th>
                                        <th>Descrição</th>
                                        <th>Prioridade</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($ocorrencias_recentes as $ocorrencia): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($ocorrencia['empreendimento_nome']) ?></td>
                                            <td><?= htmlspecialchars(substr($ocorrencia['descricao'], 0, 50)) ?>...</td>
                                            <td>
                                                <?php
                                                $prioridadeClass = [
                                                    'baixa' => 'badge-secondary',
                                                    'media' => 'badge-info',
                                                    'alta' => 'badge-warning',
                                                    'urgente' => 'badge-danger'
                                                ][$ocorrencia['prioridade']] ?? 'badge-secondary';
                                                ?>
                                                <span class="badge <?= $prioridadeClass ?>">
                                                    <?= ucfirst($ocorrencia['prioridade']) ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php
                                                $statusClass = [
                                                    'aberta' => 'badge-danger',
                                                    'em_andamento' => 'badge-warning',
                                                    'concluida' => 'badge-success',
                                                    'cancelada' => 'badge-secondary'
                                                ][$ocorrencia['status']] ?? 'badge-secondary';
                                                ?>
                                                <span class="badge <?= $statusClass ?>">
                                                    <?= ucfirst(str_replace('_', ' ', $ocorrencia['status'])) ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">Nenhuma ocorrência recente.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Compras Pendentes -->
        <div class="col-lg-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">Compras Pendentes</h6>
                    <a href="<?= BASE_URL ?>obras/compras" class="btn btn-sm btn-primary">
                        Ver Todas
                    </a>
                </div>
                <div class="card-body">
                    <?php if (!empty($compras_pendentes)): ?>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Empreendimento</th>
                                        <th>Descrição</th>
                                        <th>Valor</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($compras_pendentes as $compra): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($compra['empreendimento_nome']) ?></td>
                                            <td><?= htmlspecialchars(substr($compra['descricao'], 0, 50)) ?>...</td>
                                            <td>R$ <?= number_format($compra['valor_total'], 2, ',', '.') ?></td>
                                            <td>
                                                <?php
                                                $statusClass = [
                                                    'solicitado' => 'badge-warning',
                                                    'aprovado' => 'badge-info',
                                                    'comprado' => 'badge-primary',
                                                    'entregue' => 'badge-success',
                                                    'cancelado' => 'badge-danger'
                                                ][$compra['status']] ?? 'badge-secondary';
                                                ?>
                                                <span class="badge <?= $statusClass ?>">
                                                    <?= ucfirst($compra['status']) ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">Nenhuma compra pendente.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Menu de Ações Rápidas -->
    <div class="row">
        <div class="col-12">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Ações Rápidas</h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <a href="<?= BASE_URL ?>obras/ocorrencias/criar" class="btn btn-primary btn-block">
                                <i class="fas fa-plus"></i> Nova Ocorrência
                            </a>
                        </div>
                        <div class="col-md-3 mb-3">
                            <a href="<?= BASE_URL ?>obras/compras/solicitar" class="btn btn-info btn-block">
                                <i class="fas fa-shopping-cart"></i> Solicitar Compra
                            </a>
                        </div>
                        <div class="col-md-3 mb-3">
                            <a href="<?= BASE_URL ?>obras/ocorrencias" class="btn btn-warning btn-block">
                                <i class="fas fa-list"></i> Gerenciar Ocorrências
                            </a>
                        </div>
                        <div class="col-md-3 mb-3">
                            <a href="<?= BASE_URL ?>obras/compras" class="btn btn-success btn-block">
                                <i class="fas fa-clipboard-list"></i> Gerenciar Compras
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
