<!-- Content Header -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>
                    <i class="fas fa-user-<?= isset($usuario) ? 'edit' : 'plus' ?>"></i> 
                    <?= isset($usuario) ? 'Editar' : 'Novo' ?> Usuário
                </h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?= BASE_PATH ?>/">Início</a></li>
                    <li class="breadcrumb-item"><a href="<?= BASE_PATH ?>/usuarios">Usuários</a></li>
                    <li class="breadcrumb-item active"><?= isset($usuario) ? 'Editar' : 'Novo' ?></li>
                </ol>
            </div>
        </div>
    </div>
</section>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <form method="post" action="<?= BASE_PATH ?>/usuarios/<?= isset($usuario) ? 'atualizar/' . $usuario['id'] : 'salvar' ?>" 
              class="needs-validation" novalidate>
            
            <div class="row">
                <!-- Dados Pessoais -->
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-user"></i> Dados Pessoais
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Nome Completo <span class="text-danger">*</span></label>
                                        <input type="text" name="nome_completo" class="form-control" 
                                               value="<?= htmlspecialchars($usuario['nome_completo'] ?? '') ?>" 
                                               required>
                                        <div class="invalid-feedback">
                                            Por favor, informe o nome completo.
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>E-mail <span class="text-danger">*</span></label>
                                        <input type="email" name="email" class="form-control" 
                                               value="<?= htmlspecialchars($usuario['email'] ?? '') ?>" 
                                               required>
                                        <div class="invalid-feedback">
                                            Por favor, informe um e-mail válido.
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>CPF <span class="text-danger">*</span></label>
                                        <input type="text" name="cpf" class="form-control cpf-mask" 
                                               value="<?= htmlspecialchars($usuario['cpf'] ?? '') ?>" 
                                               required>
                                        <div class="invalid-feedback">
                                            Por favor, informe um CPF válido.
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Identidade</label>
                                        <input type="text" name="identidade" class="form-control" 
                                               value="<?= htmlspecialchars($usuario['identidade'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Data de Nascimento</label>
                                        <input type="date" name="data_nascimento" class="form-control" 
                                               value="<?= $usuario['data_nascimento'] ?? '' ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Telefone</label>
                                        <input type="text" name="telefone" class="form-control phone-mask" 
                                               value="<?= htmlspecialchars($usuario['telefone'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Profissão</label>
                                        <input type="text" name="profissao" class="form-control" 
                                               value="<?= htmlspecialchars($usuario['profissao'] ?? '') ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Endereço -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-map-marker-alt"></i> Endereço
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>CEP</label>
                                        <input type="text" name="cep" class="form-control cep-mask" 
                                               value="<?= htmlspecialchars($usuario['cep'] ?? '') ?>"
                                               onblur="buscarCEP(this.value)">
                                    </div>
                                </div>
                                
                                <div class="col-md-7">
                                    <div class="form-group">
                                        <label>Endereço</label>
                                        <input type="text" name="endereco" id="endereco" class="form-control" 
                                               value="<?= htmlspecialchars($usuario['endereco'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Número</label>
                                        <input type="text" name="numero" class="form-control" 
                                               value="<?= htmlspecialchars($usuario['numero'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Complemento</label>
                                        <input type="text" name="complemento" class="form-control" 
                                               value="<?= htmlspecialchars($usuario['complemento'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Bairro</label>
                                        <input type="text" name="bairro" id="bairro" class="form-control" 
                                               value="<?= htmlspecialchars($usuario['bairro'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Cidade</label>
                                        <input type="text" name="cidade" id="cidade" class="form-control" 
                                               value="<?= htmlspecialchars($usuario['cidade'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-1">
                                    <div class="form-group">
                                        <label>UF</label>
                                        <input type="text" name="uf" id="uf" class="form-control" 
                                               maxlength="2" style="text-transform: uppercase"
                                               value="<?= htmlspecialchars($usuario['uf'] ?? '') ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Configurações -->
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-cog"></i> Configurações
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <label>Nível de Acesso <span class="text-danger">*</span></label>
                                <select name="nivel_acesso_id" class="form-control" required>
                                    <option value="">Selecione...</option>
                                    <?php foreach ($niveis as $nivel): ?>
                                    <option value="<?= $nivel['id'] ?>" 
                                            <?= ($usuario['nivel_acesso_id'] ?? '') == $nivel['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($nivel['nome']) ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="invalid-feedback">
                                    Por favor, selecione um nível de acesso.
                                </div>
                            </div>
                            
                            <?php if (!isset($usuario)): ?>
                            <div class="form-group">
                                <label>Senha <span class="text-danger">*</span></label>
                                <input type="password" name="senha" class="form-control" 
                                       minlength="8" required>
                                <small class="form-text text-muted">
                                    Mínimo de 8 caracteres
                                </small>
                                <div class="invalid-feedback">
                                    A senha deve ter no mínimo 8 caracteres.
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label>Confirmar Senha <span class="text-danger">*</span></label>
                                <input type="password" name="confirma_senha" class="form-control" 
                                       minlength="8" required>
                                <div class="invalid-feedback">
                                    Por favor, confirme a senha.
                                </div>
                            </div>
                            <?php else: ?>
                            <div class="form-group">
                                <label>Nova Senha</label>
                                <input type="password" name="senha" class="form-control" minlength="8">
                                <small class="form-text text-muted">
                                    Deixe em branco para manter a senha atual
                                </small>
                            </div>
                            
                            <div class="form-group">
                                <label>Confirmar Nova Senha</label>
                                <input type="password" name="confirma_senha" class="form-control" minlength="8">
                            </div>
                            <?php endif; ?>
                            
                            <div class="form-group">
                                <label>Status</label>
                                <div class="custom-control custom-switch">
                                    <input type="checkbox" class="custom-control-input" id="ativo" 
                                           name="ativo" value="1" 
                                           <?= ($usuario['ativo'] ?? 1) ? 'checked' : '' ?>>
                                    <label class="custom-control-label" for="ativo">
                                        Usuário Ativo
                                    </label>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label>Observações</label>
                                <textarea name="observacoes" class="form-control" rows="4"><?= htmlspecialchars($usuario['observacoes'] ?? '') ?></textarea>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-save"></i> Salvar
                            </button>
                            <a href="<?= BASE_PATH ?>/usuarios" class="btn btn-default btn-block">
                                <i class="fas fa-arrow-left"></i> Voltar
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</section>

<script>
function buscarCEP(cep) {
    cep = cep.replace(/\D/g, '');
    
    if (cep.length === 8) {
        fetch(`https://viacep.com.br/ws/${cep}/json/`)
            .then(response => response.json())
            .then(data => {
                if (!data.erro) {
                    document.getElementById('endereco').value = data.logradouro;
                    document.getElementById('bairro').value = data.bairro;
                    document.getElementById('cidade').value = data.localidade;
                    document.getElementById('uf').value = data.uf;
                }
            })
            .catch(error => console.error('Erro ao buscar CEP:', error));
    }
}

// Validação de senha
document.querySelector('form').addEventListener('submit', function(e) {
    const senha = document.querySelector('input[name="senha"]').value;
    const confirmaSenha = document.querySelector('input[name="confirma_senha"]').value;
    
    if (senha && senha !== confirmaSenha) {
        e.preventDefault();
        Swal.fire({
            icon: 'error',
            title: 'Erro',
            text: 'As senhas não coincidem!'
        });
    }
});
</script>
