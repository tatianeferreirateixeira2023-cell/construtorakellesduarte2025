<!-- Content Header -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>
                    <i class="fas fa-users"></i> Usuários
                    <small>Gerenciamento de usuários do sistema</small>
                </h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?= BASE_PATH ?>/">Início</a></li>
                    <li class="breadcrumb-item active">Usuários</li>
                </ol>
            </div>
        </div>
    </div>
</section>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        
        <!-- Filtros -->
        <div class="card card-outline card-primary collapsed-card">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-filter"></i> Filtros
                </h3>
                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                        <i class="fas fa-plus"></i>
                    </button>
                </div>
            </div>
            <div class="card-body">
                <form method="get" action="<?= BASE_PATH ?>/usuarios">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Buscar</label>
                                <input type="text" name="search" class="form-control" 
                                       placeholder="Nome, e-mail ou CPF" 
                                       value="<?= htmlspecialchars($filters['search'] ?? '') ?>">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Nível de Acesso</label>
                                <select name="nivel" class="form-control">
                                    <option value="">Todos</option>
                                    <?php foreach ($niveis as $nivel): ?>
                                    <option value="<?= $nivel['id'] ?>" 
                                            <?= ($filters['nivel'] ?? '') == $nivel['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($nivel['nome']) ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Status</label>
                                <select name="status" class="form-control">
                                    <option value="">Todos</option>
                                    <option value="1" <?= ($filters['status'] ?? '') === '1' ? 'selected' : '' ?>>Ativo</option>
                                    <option value="0" <?= ($filters['status'] ?? '') === '0' ? 'selected' : '' ?>>Inativo</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>&nbsp;</label>
                                <div>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-search"></i> Filtrar
                                    </button>
                                    <a href="<?= BASE_PATH ?>/usuarios" class="btn btn-default">
                                        <i class="fas fa-times"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Lista de Usuários -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    Lista de Usuários 
                    <span class="badge badge-primary"><?= $pagination['total_records'] ?> registros</span>
                </h3>
                <div class="card-tools">
                    <a href="<?= BASE_PATH ?>/usuarios/novo" class="btn btn-primary btn-sm">
                        <i class="fas fa-plus"></i> Novo Usuário
                    </a>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th width="50">ID</th>
                                <th>Nome</th>
                                <th>E-mail</th>
                                <th>CPF</th>
                                <th>Nível</th>
                                <th width="100">Status</th>
                                <th width="150">Último Acesso</th>
                                <th width="120">Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($usuarios)): ?>
                            <tr>
                                <td colspan="8" class="text-center py-4">
                                    <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                                    <p class="text-muted">Nenhum usuário encontrado</p>
                                </td>
                            </tr>
                            <?php else: ?>
                                <?php foreach ($usuarios as $usuario): ?>
                                <tr>
                                    <td><?= $usuario['id'] ?></td>
                                    <td>
                                        <strong><?= htmlspecialchars($usuario['nome_completo']) ?></strong>
                                        <?php if ($usuario['telefone']): ?>
                                        <br>
                                        <small class="text-muted">
                                            <i class="fas fa-phone"></i> <?= htmlspecialchars($usuario['telefone']) ?>
                                        </small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="mailto:<?= htmlspecialchars($usuario['email']) ?>">
                                            <?= htmlspecialchars($usuario['email']) ?>
                                        </a>
                                    </td>
                                    <td>
                                        <span class="cpf-mask"><?= htmlspecialchars($usuario['cpf'] ?? '-') ?></span>
                                    </td>
                                    <td>
                                        <span class="badge badge-info">
                                            <?= htmlspecialchars($usuario['nivel_nome']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($usuario['ativo']): ?>
                                            <span class="badge badge-success">Ativo</span>
                                        <?php else: ?>
                                            <span class="badge badge-danger">Inativo</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($usuario['ultimo_acesso']): ?>
                                            <small><?= date('d/m/Y H:i', strtotime($usuario['ultimo_acesso'])) ?></small>
                                        <?php else: ?>
                                            <small class="text-muted">Nunca acessou</small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?= BASE_PATH ?>/usuarios/visualizar/<?= $usuario['id'] ?>" 
                                               class="btn btn-sm btn-info" title="Visualizar">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="<?= BASE_PATH ?>/usuarios/editar/<?= $usuario['id'] ?>" 
                                               class="btn btn-sm btn-warning" title="Editar">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <?php if ($usuario['id'] != $_SESSION['user_id']): ?>
                                            <button type="button" class="btn btn-sm btn-danger" 
                                                    onclick="confirmarExclusao(<?= $usuario['id'] ?>)" 
                                                    title="Excluir">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <?php if ($pagination['total'] > 1): ?>
            <div class="card-footer">
                <nav aria-label="Paginação">
                    <ul class="pagination pagination-sm m-0 float-right">
                        <?php if ($pagination['current'] > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?= $pagination['current'] - 1 ?><?= http_build_query(array_diff_key($filters, ['page' => ''])) ?>">
                                &laquo;
                            </a>
                        </li>
                        <?php endif; ?>
                        
                        <?php for ($i = 1; $i <= $pagination['total']; $i++): ?>
                            <?php if ($i == 1 || $i == $pagination['total'] || ($i >= $pagination['current'] - 2 && $i <= $pagination['current'] + 2)): ?>
                            <li class="page-item <?= $i == $pagination['current'] ? 'active' : '' ?>">
                                <a class="page-link" href="?page=<?= $i ?><?= http_build_query(array_diff_key($filters, ['page' => ''])) ?>">
                                    <?= $i ?>
                                </a>
                            </li>
                            <?php elseif ($i == $pagination['current'] - 3 || $i == $pagination['current'] + 3): ?>
                            <li class="page-item disabled"><span class="page-link">...</span></li>
                            <?php endif; ?>
                        <?php endfor; ?>
                        
                        <?php if ($pagination['current'] < $pagination['total']): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?= $pagination['current'] + 1 ?><?= http_build_query(array_diff_key($filters, ['page' => ''])) ?>">
                                &raquo;
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<script>
function confirmarExclusao(id) {
    Swal.fire({
        title: 'Confirmar Exclusão',
        text: 'Tem certeza que deseja excluir este usuário?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Sim, excluir!',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = '<?= BASE_PATH ?>/usuarios/excluir/' + id;
        }
    });
}
</script>
