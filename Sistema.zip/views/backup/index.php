<?php
$pageTitle = 'Gerenciamento de Backup';
$currentPage = 'backup';
?>

<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <h1 class="h3 mb-3">Gerenciamento de Backup</h1>
        </div>
    </div>

    <?php if (isset($flash)): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show" role="alert">
            <?= $flash['message'] ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <!-- Botão para criar novo backup -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card shadow">
                <div class="card-body">
                    <h5 class="card-title">Criar Novo Backup</h5>
                    <p class="card-text text-muted">
                        Crie um backup completo do banco de dados do sistema. Este processo pode levar alguns minutos.
                    </p>
                    <form method="POST" action="<?= BASE_PATH ?>/backup/criar" onsubmit="return confirm('Deseja criar um novo backup do sistema?')">
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-database"></i> Criar Backup Agora
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Lista de backups existentes -->
    <div class="row">
        <div class="col-12">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Backups Disponíveis</h6>
                </div>
                <div class="card-body">
                    <?php if (!empty($backups)): ?>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Nome do Arquivo</th>
                                        <th>Data/Hora</th>
                                        <th>Tamanho</th>
                                        <th width="200">Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($backups as $backup): ?>
                                        <tr>
                                            <td>
                                                <i class="fas fa-file-archive text-primary"></i>
                                                <?= htmlspecialchars($backup['nome']) ?>
                                            </td>
                                            <td><?= date('d/m/Y H:i:s', $backup['data']) ?></td>
                                            <td><?= number_format($backup['tamanho'] / 1024 / 1024, 2) ?> MB</td>
                                            <td>
                                                <div class="btn-group" role="group">
                                                    <a href="<?= BASE_PATH ?>/backup/download/<?= urlencode($backup['nome']) ?>" 
                                                       class="btn btn-sm btn-info" title="Download">
                                                        <i class="fas fa-download"></i>
                                                    </a>
                                                    <button type="button" class="btn btn-sm btn-warning" 
                                                            onclick="restaurarBackup('<?= htmlspecialchars($backup['nome']) ?>')"
                                                            title="Restaurar">
                                                        <i class="fas fa-undo"></i>
                                                    </button>
                                                    <button type="button" class="btn btn-sm btn-danger" 
                                                            onclick="deletarBackup('<?= htmlspecialchars($backup['nome']) ?>')"
                                                            title="Deletar">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> Nenhum backup encontrado. Crie o primeiro backup do sistema.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Informações importantes -->
    <div class="row mt-4">
        <div class="col-12">
            <div class="card shadow border-left-warning">
                <div class="card-body">
                    <h5 class="card-title text-warning">
                        <i class="fas fa-exclamation-triangle"></i> Informações Importantes
                    </h5>
                    <ul class="mb-0">
                        <li>Realize backups regularmente para garantir a segurança dos dados.</li>
                        <li>Armazene cópias dos backups em local seguro, preferencialmente fora do servidor.</li>
                        <li>Antes de restaurar um backup, certifique-se de que é a versão correta.</li>
                        <li>A restauração de backup substituirá todos os dados atuais do sistema.</li>
                        <li>Após restaurar um backup, você será desconectado e deverá fazer login novamente.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Forms ocultos para ações -->
<form id="formRestore" method="POST" style="display: none;">
    <input type="hidden" name="filename" id="restoreFilename">
</form>

<form id="formDelete" method="POST" style="display: none;">
    <input type="hidden" name="filename" id="deleteFilename">
</form>

<script>
function restaurarBackup(filename) {
    if (confirm('ATENÇÃO: Esta ação substituirá todos os dados atuais do sistema!\n\nTem certeza que deseja restaurar o backup "' + filename + '"?\n\nVocê será desconectado após a restauração.')) {
        document.getElementById('restoreFilename').value = filename;
        document.getElementById('formRestore').action = '<?= BASE_PATH ?>/backup/restaurar/' + encodeURIComponent(filename);
        document.getElementById('formRestore').submit();
    }
}

function deletarBackup(filename) {
    if (confirm('Tem certeza que deseja deletar o backup "' + filename + '"?\n\nEsta ação não pode ser desfeita.')) {
        document.getElementById('deleteFilename').value = filename;
        document.getElementById('formDelete').action = '<?= BASE_PATH ?>/backup/deletar/' + encodeURIComponent(filename);
        document.getElementById('formDelete').submit();
    }
}
</script>
