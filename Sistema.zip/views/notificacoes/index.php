<?php require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h3 class="card-title">
                        <i class="fas fa-bell"></i> Notificações
                        <?php if ($naoLidas > 0): ?>
                            <span class="badge badge-danger"><?= $naoLidas ?> não lidas</span>
                        <?php endif; ?>
                    </h3>
                    <div class="card-tools">
                        <?php if ($this->user['nivel_acesso_id'] == NIVEL_ADMIN): ?>
                            <a href="/sistema/notificacoes/criar" class="btn btn-sm btn-primary">
                                <i class="fas fa-plus"></i> Nova Notificação
                            </a>
                        <?php endif; ?>
                        <?php if ($naoLidas > 0): ?>
                            <a href="/sistema/notificacoes/marcar-todas-lidas" class="btn btn-sm btn-success" 
                               onclick="return confirm('Marcar todas as notificações como lidas?')">
                                <i class="fas fa-check-double"></i> Marcar todas como lidas
                            </a>
                        <?php endif; ?>
                        <?php if (!empty($notificacoes)): ?>
                            <a href="/sistema/notificacoes/limpar-antigas" class="btn btn-sm btn-warning"
                               onclick="return confirm('Remover notificações antigas já lidas?')">
                                <i class="fas fa-broom"></i> Limpar antigas
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body">
                    <?php if (isset($flash)): ?>
                        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show" role="alert">
                            <?= $flash['message'] ?>
                            <button type="button" class="close" data-dismiss="alert">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($notificacoes)): ?>
                        <div class="list-group">
                            <?php foreach ($notificacoes as $notificacao): ?>
                                <div class="list-group-item <?= !$notificacao['lida'] ? 'list-group-item-light' : '' ?>" 
                                     id="notificacao-<?= $notificacao['id'] ?>">
                                    <div class="d-flex w-100 justify-content-between">
                                        <div class="d-flex align-items-start">
                                            <div class="mr-3">
                                                <i class="fas <?= $notificacao['icone'] ?> fa-2x <?= $notificacao['cor'] ?>"></i>
                                            </div>
                                            <div>
                                                <h5 class="mb-1 <?= !$notificacao['lida'] ? 'font-weight-bold' : '' ?>">
                                                    <?= htmlspecialchars($notificacao['titulo']) ?>
                                                    <?php if (!$notificacao['lida']): ?>
                                                        <span class="badge badge-primary">Nova</span>
                                                    <?php endif; ?>
                                                </h5>
                                                <p class="mb-1"><?= nl2br(htmlspecialchars($notificacao['mensagem'])) ?></p>
                                                <small class="text-muted">
                                                    <i class="fas fa-clock"></i> 
                                                    <?= date('d/m/Y H:i', strtotime($notificacao['created_at'])) ?>
                                                    <?php if ($notificacao['lida'] && $notificacao['data_leitura']): ?>
                                                        | Lida em <?= date('d/m/Y H:i', strtotime($notificacao['data_leitura'])) ?>
                                                    <?php endif; ?>
                                                </small>
                                            </div>
                                        </div>
                                        <div class="btn-group-vertical btn-group-sm">
                                            <?php if (!$notificacao['lida']): ?>
                                                <button type="button" class="btn btn-success" 
                                                        onclick="marcarComoLida(<?= $notificacao['id'] ?>)">
                                                    <i class="fas fa-check"></i> Marcar como lida
                                                </button>
                                            <?php endif; ?>
                                            <?php if (!empty($notificacao['link'])): ?>
                                                <a href="<?= $notificacao['link'] ?>" class="btn btn-info">
                                                    <i class="fas fa-external-link-alt"></i> Ver detalhes
                                                </a>
                                            <?php endif; ?>
                                            <a href="/sistema/notificacoes/excluir/<?= $notificacao['id'] ?>" 
                                               class="btn btn-danger"
                                               onclick="return confirm('Excluir esta notificação?')">
                                                <i class="fas fa-trash"></i> Excluir
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <!-- Paginação -->
                        <?php if ($pagination['total'] > 1): ?>
                            <nav aria-label="Navegação de páginas" class="mt-4">
                                <ul class="pagination justify-content-center">
                                    <li class="page-item <?= $pagination['current'] == 1 ? 'disabled' : '' ?>">
                                        <a class="page-link" href="?page=<?= $pagination['current'] - 1 ?>">
                                            Anterior
                                        </a>
                                    </li>
                                    
                                    <?php for ($i = max(1, $pagination['current'] - 2); $i <= min($pagination['total'], $pagination['current'] + 2); $i++): ?>
                                        <li class="page-item <?= $i == $pagination['current'] ? 'active' : '' ?>">
                                            <a class="page-link" href="?page=<?= $i ?>">
                                                <?= $i ?>
                                            </a>
                                        </li>
                                    <?php endfor; ?>
                                    
                                    <li class="page-item <?= $pagination['current'] == $pagination['total'] ? 'disabled' : '' ?>">
                                        <a class="page-link" href="?page=<?= $pagination['current'] + 1 ?>">
                                            Próxima
                                        </a>
                                    </li>
                                </ul>
                            </nav>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-bell-slash fa-4x text-muted mb-3"></i>
                            <h4>Nenhuma notificação</h4>
                            <p class="text-muted">Você não possui notificações no momento.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function marcarComoLida(id) {
    $.ajax({
        url: '/sistema/notificacoes/marcar-lida',
        method: 'POST',
        data: { id: id },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                // Remove a classe de não lida e o botão
                $('#notificacao-' + id).removeClass('list-group-item-light');
                $('#notificacao-' + id + ' .font-weight-bold').removeClass('font-weight-bold');
                $('#notificacao-' + id + ' .badge-primary').remove();
                $('#notificacao-' + id + ' .btn-success').remove();
                
                // Atualiza o contador no header se existir
                var badge = $('.card-header .badge-danger');
                if (badge.length) {
                    var count = parseInt(badge.text()) - 1;
                    if (count > 0) {
                        badge.text(count + ' não lidas');
                    } else {
                        badge.remove();
                    }
                }
                
                // Atualiza o contador no menu se existir
                updateNotificationCount();
            } else {
                alert('Erro ao marcar notificação como lida: ' + response.message);
            }
        },
        error: function() {
            alert('Erro ao processar solicitação');
        }
    });
}

function updateNotificationCount() {
    // Atualiza o contador de notificações no menu principal
    $.ajax({
        url: '/sistema/notificacoes/obter-nao-lidas',
        method: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                var badge = $('#notification-count');
                if (response.count > 0) {
                    if (badge.length) {
                        badge.text(response.count);
                    } else {
                        $('.fa-bell').parent().append('<span id="notification-count" class="badge badge-danger">' + response.count + '</span>');
                    }
                } else {
                    badge.remove();
                }
            }
        }
    });
}

// Atualiza o contador a cada 30 segundos
setInterval(updateNotificationCount, 30000);
</script>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
