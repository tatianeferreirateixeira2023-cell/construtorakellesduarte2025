<?php require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-8 offset-md-2">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-bell"></i> Criar Nova Notificação
                    </h3>
                </div>
                <div class="card-body">
                    <?php if (isset($flash)): ?>
                        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show" role="alert">
                            <?= $flash['message'] ?>
                            <button type="button" class="close" data-dismiss="alert">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="/sistema/notificacoes/criar">
                        <div class="form-group">
                            <label for="titulo">Título <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="titulo" name="titulo" required 
                                   placeholder="Título da notificação">
                        </div>

                        <div class="form-group">
                            <label for="mensagem">Mensagem <span class="text-danger">*</span></label>
                            <textarea class="form-control" id="mensagem" name="mensagem" rows="4" required
                                      placeholder="Conteúdo da notificação"></textarea>
                        </div>

                        <div class="form-group">
                            <label for="tipo">Tipo de Notificação</label>
                            <select class="form-control" id="tipo" name="tipo">
                                <option value="sistema">Sistema</option>
                                <option value="alerta">Alerta</option>
                                <option value="fatura">Fatura</option>
                                <option value="manutencao">Manutenção</option>
                                <option value="obra">Obra</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="destinatarios">Destinatários</label>
                            <select class="form-control" id="destinatarios" name="destinatarios" onchange="toggleNivelAcesso()">
                                <option value="todos">Todos os usuários ativos</option>
                                <option value="nivel">Por nível de acesso</option>
                            </select>
                        </div>

                        <div class="form-group" id="nivel-group" style="display: none;">
                            <label for="nivel_acesso">Nível de Acesso</label>
                            <select class="form-control" id="nivel_acesso" name="nivel_acesso">
                                <?php foreach ($niveis as $nivel): ?>
                                    <option value="<?= $nivel['id'] ?>"><?= htmlspecialchars($nivel['nome']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> 
                            A notificação será enviada imediatamente para todos os destinatários selecionados.
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-paper-plane"></i> Enviar Notificação
                            </button>
                            <a href="/sistema/notificacoes" class="btn btn-secondary">
                                <i class="fas fa-times"></i> Cancelar
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function toggleNivelAcesso() {
    var destinatarios = document.getElementById('destinatarios').value;
    var nivelGroup = document.getElementById('nivel-group');
    
    if (destinatarios === 'nivel') {
        nivelGroup.style.display = 'block';
    } else {
        nivelGroup.style.display = 'none';
    }
}
</script>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
