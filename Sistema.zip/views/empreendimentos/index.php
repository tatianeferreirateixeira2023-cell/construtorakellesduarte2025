<!-- Content Header -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>
                    <i class="fas fa-building"></i> Empreendimentos
                    <small>Gerenciamento de empreendimentos</small>
                </h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?= url() ?>">Início</a></li>
                    <li class="breadcrumb-item active">Empreendimentos</li>
                </ol>
            </div>
        </div>
    </div>
</section>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        
        <!-- Estatísticas -->
        <div class="row">
            <div class="col-lg-3 col-6">
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3><?= $estatisticas['total'] ?? 0 ?></h3>
                        <p>Total de Empreendimentos</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-building"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-success">
                    <div class="inner">
                        <h3><?= $estatisticas['em_construcao'] ?? 0 ?></h3>
                        <p>Em Construção</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-hammer"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-warning">
                    <div class="inner">
                        <h3><?= $estatisticas['concluidos'] ?? 0 ?></h3>
                        <p>Concluídos</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-danger">
                    <div class="inner">
                        <h3><?= $estatisticas['paralisados'] ?? 0 ?></h3>
                        <p>Paralisados</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-pause-circle"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Filtros -->
        <div class="card card-outline card-primary collapsed-card">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-filter"></i> Filtros
                </h3>
                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                        <i class="fas fa-plus"></i>
                    </button>
                </div>
            </div>
            <div class="card-body">
                <form method="get" action="<?= url('empreendimentos') ?>">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Buscar</label>
                                <input type="text" name="search" class="form-control" 
                                       placeholder="Nome ou descrição" 
                                       value="<?= htmlspecialchars($filters['search'] ?? '') ?>">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Status</label>
                                <select name="status" class="form-control">
                                    <option value="">Todos</option>
                                    <option value="planejamento" <?= ($filters['status'] ?? '') == 'planejamento' ? 'selected' : '' ?>>Planejamento</option>
                                    <option value="em_construcao" <?= ($filters['status'] ?? '') == 'em_construcao' ? 'selected' : '' ?>>Em Construção</option>
                                    <option value="concluido" <?= ($filters['status'] ?? '') == 'concluido' ? 'selected' : '' ?>>Concluído</option>
                                    <option value="paralisado" <?= ($filters['status'] ?? '') == 'paralisado' ? 'selected' : '' ?>>Paralisado</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Tipo</label>
                                <select name="tipo" class="form-control">
                                    <option value="">Todos</option>
                                    <option value="residencial" <?= ($filters['tipo'] ?? '') == 'residencial' ? 'selected' : '' ?>>Residencial</option>
                                    <option value="comercial" <?= ($filters['tipo'] ?? '') == 'comercial' ? 'selected' : '' ?>>Comercial</option>
                                    <option value="misto" <?= ($filters['tipo'] ?? '') == 'misto' ? 'selected' : '' ?>>Misto</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>&nbsp;</label>
                                <div>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-search"></i> Filtrar
                                    </button>
                                    <a href="<?= url('empreendimentos') ?>" class="btn btn-default">
                                        <i class="fas fa-times"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Lista de Empreendimentos -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    Lista de Empreendimentos
                    <span class="badge badge-primary"><?= $pagination['total_records'] ?? 0 ?> registros</span>
                </h3>
                <div class="card-tools">
                    <a href="<?= url('empreendimentos/novo') ?>" class="btn btn-primary btn-sm">
                        <i class="fas fa-plus"></i> Novo Empreendimento
                    </a>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th width="50">ID</th>
                                <th>Nome</th>
                                <th>Tipo</th>
                                <th>Localização</th>
                                <th width="120">Status</th>
                                <th width="100">Progresso</th>
                                <th width="150">Valor Total</th>
                                <th width="150">Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($empreendimentos)): ?>
                            <tr>
                                <td colspan="8" class="text-center py-4">
                                    <i class="fas fa-building fa-3x text-muted mb-3"></i>
                                    <p class="text-muted">Nenhum empreendimento encontrado</p>
                                </td>
                            </tr>
                            <?php else: ?>
                                <?php foreach ($empreendimentos as $emp): ?>
                                <tr>
                                    <td><?= $emp['id'] ?></td>
                                    <td>
                                        <strong><?= htmlspecialchars($emp['nome']) ?></strong>
                                        <?php if ($emp['descricao']): ?>
                                        <br>
                                        <small class="text-muted">
                                            <?= htmlspecialchars(substr($emp['descricao'], 0, 50)) ?>...
                                        </small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge badge-secondary">
                                            <?= ucfirst($emp['tipo'] ?? 'N/D') ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($emp['endereco']): ?>
                                            <i class="fas fa-map-marker-alt"></i> 
                                            <?= htmlspecialchars($emp['endereco']) ?>
                                            <?php if ($emp['cidade']): ?>
                                                <br>
                                                <small><?= htmlspecialchars($emp['cidade']) ?>/<?= htmlspecialchars($emp['uf']) ?></small>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php
                                        $statusClass = [
                                            'planejamento' => 'badge-info',
                                            'em_construcao' => 'badge-warning',
                                            'concluido' => 'badge-success',
                                            'paralisado' => 'badge-danger'
                                        ];
                                        $statusText = [
                                            'planejamento' => 'Planejamento',
                                            'em_construcao' => 'Em Construção',
                                            'concluido' => 'Concluído',
                                            'paralisado' => 'Paralisado'
                                        ];
                                        ?>
                                        <span class="badge <?= $statusClass[$emp['status']] ?? 'badge-secondary' ?>">
                                            <?= $statusText[$emp['status']] ?? 'N/D' ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php 
                                        $progresso = $emp['progresso_percentual'] ?? 0;
                                        $progressClass = 'bg-info';
                                        if ($progresso >= 75) $progressClass = 'bg-success';
                                        elseif ($progresso >= 50) $progressClass = 'bg-warning';
                                        elseif ($progresso >= 25) $progressClass = 'bg-danger';
                                        ?>
                                        <div class="progress progress-sm">
                                            <div class="progress-bar <?= $progressClass ?>" 
                                                 style="width: <?= $progresso ?>%">
                                            </div>
                                        </div>
                                        <small><?= $progresso ?>%</small>
                                    </td>
                                    <td>
                                        <?php if ($emp['valor_total']): ?>
                                            <strong>R$ <?= number_format($emp['valor_total'], 2, ',', '.') ?></strong>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?= url('empreendimentos/visualizar/' . $emp['id']) ?>" 
                                               class="btn btn-sm btn-info" title="Visualizar">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="<?= url('empreendimentos/editar/' . $emp['id']) ?>" 
                                               class="btn btn-sm btn-warning" title="Editar">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="<?= url('empreendimentos/documentos/' . $emp['id']) ?>" 
                                               class="btn btn-sm btn-secondary" title="Documentos">
                                                <i class="fas fa-file-alt"></i>
                                            </a>
                                            <button type="button" class="btn btn-sm btn-danger" 
                                                    onclick="confirmarExclusao(<?= $emp['id'] ?>)" 
                                                    title="Excluir">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <?php if (($pagination['total'] ?? 0) > 1): ?>
            <div class="card-footer">
                <nav aria-label="Paginação">
                    <ul class="pagination pagination-sm m-0 float-right">
                        <?php if ($pagination['current'] > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?= $pagination['current'] - 1 ?>&<?= http_build_query(array_diff_key($filters ?? [], ['page' => ''])) ?>">
                                &laquo;
                            </a>
                        </li>
                        <?php endif; ?>
                        
                        <?php for ($i = 1; $i <= $pagination['total']; $i++): ?>
                            <?php if ($i == 1 || $i == $pagination['total'] || ($i >= $pagination['current'] - 2 && $i <= $pagination['current'] + 2)): ?>
                            <li class="page-item <?= $i == $pagination['current'] ? 'active' : '' ?>">
                                <a class="page-link" href="?page=<?= $i ?>&<?= http_build_query(array_diff_key($filters ?? [], ['page' => ''])) ?>">
                                    <?= $i ?>
                                </a>
                            </li>
                            <?php elseif ($i == $pagination['current'] - 3 || $i == $pagination['current'] + 3): ?>
                            <li class="page-item disabled"><span class="page-link">...</span></li>
                            <?php endif; ?>
                        <?php endfor; ?>
                        
                        <?php if ($pagination['current'] < $pagination['total']): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?= $pagination['current'] + 1 ?>&<?= http_build_query(array_diff_key($filters ?? [], ['page' => ''])) ?>">
                                &raquo;
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<script>
function confirmarExclusao(id) {
    Swal.fire({
        title: 'Confirmar Exclusão',
        text: 'Tem certeza que deseja excluir este empreendimento?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Sim, excluir!',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = '<?= url('empreendimentos/excluir/') ?>' + id;
        }
    });
}
</script>
