<?php include_once __DIR__ . '/../layouts/header.php'; ?>

<!-- Content Header -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1><i class="fas fa-plus-circle"></i> Novo Empreendimento</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?= url() ?>">Início</a></li>
                    <li class="breadcrumb-item"><a href="<?= url('empreendimentos') ?>">Empreendimentos</a></li>
                    <li class="breadcrumb-item active">Novo</li>
                </ol>
            </div>
        </div>
    </div>
</section>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <h5><i class="icon fas fa-ban"></i> Erro!</h5>
                <ul>
                    <?php foreach ($errors as $field => $error): ?>
                        <li><?= is_array($error) ? implode('<br>', $error) : $error ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="post" action="<?= url('empreendimentos/salvar') ?>" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
            
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"><i class="fas fa-info-circle"></i> Informações Básicas</h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="nome">Nome do Empreendimento <span class="text-danger">*</span></label>
                                <input type="text" class="form-control <?= isset($errors['nome']) ? 'is-invalid' : '' ?>" 
                                       id="nome" name="nome" value="<?= $old['nome'] ?? '' ?>" required>
                                <?php if (isset($errors['nome'])): ?>
                                    <div class="invalid-feedback">
                                        <?= $errors['nome'] ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="cidade">Cidade <span class="text-danger">*</span></label>
                                <input type="text" class="form-control <?= isset($errors['cidade']) ? 'is-invalid' : '' ?>" 
                                       id="cidade" name="cidade" value="<?= $old['cidade'] ?? '' ?>" required>
                                <?php if (isset($errors['cidade'])): ?>
                                    <div class="invalid-feedback">
                                        <?= $errors['cidade'] ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="status">Status <span class="text-danger">*</span></label>
                                <select class="form-control <?= isset($errors['status']) ? 'is-invalid' : '' ?>" 
                                        id="status" name="status" required>
                                    <option value="">Selecione...</option>
                                    <option value="planejamento" <?= ($old['status'] ?? '') == 'planejamento' ? 'selected' : '' ?>>Planejamento</option>
                                    <option value="em_construcao" <?= ($old['status'] ?? '') == 'em_construcao' ? 'selected' : '' ?>>Em Construção</option>
                                    <option value="concluido" <?= ($old['status'] ?? '') == 'concluido' ? 'selected' : '' ?>>Concluído</option>
                                    <option value="paralisado" <?= ($old['status'] ?? '') == 'paralisado' ? 'selected' : '' ?>>Paralisado</option>
                                </select>
                                <?php if (isset($errors['status'])): ?>
                                    <div class="invalid-feedback">
                                        <?= $errors['status'] ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="endereco">Endereço <span class="text-danger">*</span></label>
                                <input type="text" class="form-control <?= isset($errors['endereco']) ? 'is-invalid' : '' ?>" 
                                       id="endereco" name="endereco" value="<?= $old['endereco'] ?? '' ?>" required>
                                <?php if (isset($errors['endereco'])): ?>
                                    <div class="invalid-feedback">
                                        <?= $errors['endereco'] ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"><i class="fas fa-user-tie"></i> Responsáveis Técnicos</h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="engenheiro_nome">Engenheiro Responsável <span class="text-danger">*</span></label>
                                <input type="text" class="form-control <?= isset($errors['engenheiro_nome']) ? 'is-invalid' : '' ?>" 
                                       id="engenheiro_nome" name="engenheiro_nome" value="<?= $old['engenheiro_nome'] ?? '' ?>" required>
                                <?php if (isset($errors['engenheiro_nome'])): ?>
                                    <div class="invalid-feedback">
                                        <?= $errors['engenheiro_nome'] ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="engenheiro_art">ART <span class="text-danger">*</span></label>
                                <input type="text" class="form-control <?= isset($errors['engenheiro_art']) ? 'is-invalid' : '' ?>" 
                                       id="engenheiro_art" name="engenheiro_art" value="<?= $old['engenheiro_art'] ?? '' ?>" required>
                                <?php if (isset($errors['engenheiro_art'])): ?>
                                    <div class="invalid-feedback">
                                        <?= $errors['engenheiro_art'] ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="arquiteto_nome">Arquiteto Responsável <span class="text-danger">*</span></label>
                                <input type="text" class="form-control <?= isset($errors['arquiteto_nome']) ? 'is-invalid' : '' ?>" 
                                       id="arquiteto_nome" name="arquiteto_nome" value="<?= $old['arquiteto_nome'] ?? '' ?>" required>
                                <?php if (isset($errors['arquiteto_nome'])): ?>
                                    <div class="invalid-feedback">
                                        <?= $errors['arquiteto_nome'] ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="arquiteto_cau">CAU <span class="text-danger">*</span></label>
                                <input type="text" class="form-control <?= isset($errors['arquiteto_cau']) ? 'is-invalid' : '' ?>" 
                                       id="arquiteto_cau" name="arquiteto_cau" value="<?= $old['arquiteto_cau'] ?? '' ?>" required>
                                <?php if (isset($errors['arquiteto_cau'])): ?>
                                    <div class="invalid-feedback">
                                        <?= $errors['arquiteto_cau'] ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Salvar
                            </button>
                            <a href="<?= url('empreendimentos') ?>" class="btn btn-default">
                                <i class="fas fa-arrow-left"></i> Voltar
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</section>

<?php include_once __DIR__ . '/../layouts/footer.php'; ?>
