<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>404 - Página não encontrada</title>
    
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .error-page {
            max-width: 600px;
            text-align: center;
            color: white;
        }
        .error-page h2 {
            font-size: 120px;
            font-weight: 700;
            margin: 0;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        .error-page .error-content {
            margin-top: 20px;
        }
        .error-page .error-content h3 {
            font-size: 24px;
            margin-bottom: 20px;
        }
        .btn-light {
            padding: 10px 30px;
            font-size: 18px;
            border-radius: 25px;
            margin: 5px;
        }
    </style>
</head>
<body>
    <div class="error-page">
        <h2 class="headline">404</h2>
        <div class="error-content">
            <h3><i class="fas fa-exclamation-triangle"></i> Oops! Página não encontrada.</h3>
            <p>
                Não conseguimos encontrar a página que você está procurando.
                Ela pode ter sido removida, renomeada ou está temporariamente indisponível.
            </p>
            <div class="mt-4">
                <a href="/" class="btn btn-light">
                    <i class="fas fa-home"></i> Voltar ao Início
                </a>
                <a href="javascript:history.back()" class="btn btn-light">
                    <i class="fas fa-arrow-left"></i> Voltar
                </a>
            </div>
        </div>
    </div>
</body>
</html>
