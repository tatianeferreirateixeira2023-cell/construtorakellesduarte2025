<!-- Content Header -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>
                    <i class="fas fa-home"></i> 
                    <?= isset($imovel) ? 'Editar' : 'Novo' ?> Imóvel
                </h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?= url() ?>">Início</a></li>
                    <li class="breadcrumb-item"><a href="<?= url('imoveis') ?>">Imóveis</a></li>
                    <li class="breadcrumb-item active"><?= isset($imovel) ? 'Editar' : 'Novo' ?></li>
                </ol>
            </div>
        </div>
    </div>
</section>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <form method="post" action="<?= url('imoveis/' . (isset($imovel) ? 'atualizar/' . $imovel['id'] : 'salvar')) ?>" 
              enctype="multipart/form-data" class="needs-validation" novalidate>
            
            <div class="row">
                <!-- Informações Principais -->
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-info-circle"></i> Informações do Imóvel
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Código <span class="text-danger">*</span></label>
                                        <input type="text" name="codigo" class="form-control" 
                                               value="<?= htmlspecialchars($imovel['codigo'] ?? 'IMV-' . date('YmdHis')) ?>" 
                                               required readonly>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Empreendimento</label>
                                        <select name="empreendimento_id" class="form-control">
                                            <option value="">Selecione...</option>
                                            <?php foreach ($empreendimentos ?? [] as $emp): ?>
                                            <option value="<?= $emp['id'] ?>" 
                                                    <?= ($imovel['empreendimento_id'] ?? '') == $emp['id'] ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($emp['nome']) ?>
                                            </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Tipo <span class="text-danger">*</span></label>
                                        <select name="tipo" class="form-control" required>
                                            <option value="">Selecione...</option>
                                            <option value="casa" <?= ($imovel['tipo'] ?? '') == 'casa' ? 'selected' : '' ?>>Casa</option>
                                            <option value="apartamento" <?= ($imovel['tipo'] ?? '') == 'apartamento' ? 'selected' : '' ?>>Apartamento</option>
                                            <option value="terreno" <?= ($imovel['tipo'] ?? '') == 'terreno' ? 'selected' : '' ?>>Terreno</option>
                                            <option value="sala_comercial" <?= ($imovel['tipo'] ?? '') == 'sala_comercial' ? 'selected' : '' ?>>Sala Comercial</option>
                                            <option value="galpao" <?= ($imovel['tipo'] ?? '') == 'galpao' ? 'selected' : '' ?>>Galpão</option>
                                        </select>
                                        <div class="invalid-feedback">
                                            Por favor, selecione o tipo.
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Descrição</label>
                                        <textarea name="descricao" class="form-control" rows="4"><?= htmlspecialchars($imovel['descricao'] ?? '') ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Localização -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-map-marker-alt"></i> Localização
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>CEP</label>
                                        <input type="text" name="cep" class="form-control cep-mask" 
                                               value="<?= htmlspecialchars($imovel['cep'] ?? '') ?>"
                                               onblur="buscarCEP(this.value)">
                                    </div>
                                </div>
                                
                                <div class="col-md-7">
                                    <div class="form-group">
                                        <label>Endereço</label>
                                        <input type="text" name="endereco" id="endereco" class="form-control" 
                                               value="<?= htmlspecialchars($imovel['endereco'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Número</label>
                                        <input type="text" name="numero" class="form-control" 
                                               value="<?= htmlspecialchars($imovel['numero'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Complemento</label>
                                        <input type="text" name="complemento" class="form-control" 
                                               value="<?= htmlspecialchars($imovel['complemento'] ?? '') ?>"
                                               placeholder="Apto, Bloco, etc">
                                    </div>
                                </div>
                                
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Bairro</label>
                                        <input type="text" name="bairro" id="bairro" class="form-control" 
                                               value="<?= htmlspecialchars($imovel['bairro'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Cidade</label>
                                        <input type="text" name="cidade" id="cidade" class="form-control" 
                                               value="<?= htmlspecialchars($imovel['cidade'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>UF</label>
                                        <input type="text" name="uf" id="uf" class="form-control" 
                                               maxlength="2" style="text-transform: uppercase"
                                               value="<?= htmlspecialchars($imovel['uf'] ?? '') ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Características -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-list-ul"></i> Características
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Quartos</label>
                                        <input type="number" name="quartos" class="form-control" 
                                               min="0" value="<?= $imovel['quartos'] ?? '' ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Suítes</label>
                                        <input type="number" name="suites" class="form-control" 
                                               min="0" value="<?= $imovel['suites'] ?? '' ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Banheiros</label>
                                        <input type="number" name="banheiros" class="form-control" 
                                               min="0" value="<?= $imovel['banheiros'] ?? '' ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Vagas Garagem</label>
                                        <input type="number" name="vagas_garagem" class="form-control" 
                                               min="0" value="<?= $imovel['vagas_garagem'] ?? '' ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Área Total (m²)</label>
                                        <input type="number" name="area_total" class="form-control" 
                                               step="0.01" value="<?= $imovel['area_total'] ?? '' ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Área Construída (m²)</label>
                                        <input type="number" name="area_construida" class="form-control" 
                                               step="0.01" value="<?= $imovel['area_construida'] ?? '' ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Andar</label>
                                        <input type="number" name="andar" class="form-control" 
                                               value="<?= $imovel['andar'] ?? '' ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Posição Solar</label>
                                        <select name="posicao_solar" class="form-control">
                                            <option value="">Selecione...</option>
                                            <option value="norte" <?= ($imovel['posicao_solar'] ?? '') == 'norte' ? 'selected' : '' ?>>Norte</option>
                                            <option value="sul" <?= ($imovel['posicao_solar'] ?? '') == 'sul' ? 'selected' : '' ?>>Sul</option>
                                            <option value="leste" <?= ($imovel['posicao_solar'] ?? '') == 'leste' ? 'selected' : '' ?>>Leste</option>
                                            <option value="oeste" <?= ($imovel['posicao_solar'] ?? '') == 'oeste' ? 'selected' : '' ?>>Oeste</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label>Características Adicionais</label>
                                <div class="row">
                                    <?php 
                                    $caracteristicas = [
                                        'piscina' => 'Piscina',
                                        'churrasqueira' => 'Churrasqueira',
                                        'ar_condicionado' => 'Ar Condicionado',
                                        'armarios_embutidos' => 'Armários Embutidos',
                                        'area_servico' => 'Área de Serviço',
                                        'dependencia_empregada' => 'Dependência de Empregada',
                                        'elevador' => 'Elevador',
                                        'portaria_24h' => 'Portaria 24h',
                                        'academia' => 'Academia',
                                        'playground' => 'Playground',
                                        'salao_festas' => 'Salão de Festas',
                                        'quadra_esportes' => 'Quadra de Esportes'
                                    ];
                                    
                                    $imovel_caracteristicas = explode(',', $imovel['caracteristicas'] ?? '');
                                    
                                    foreach ($caracteristicas as $key => $label):
                                    ?>
                                    <div class="col-md-3">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" 
                                                   id="carac_<?= $key ?>" name="caracteristicas[]" 
                                                   value="<?= $key ?>"
                                                   <?= in_array($key, $imovel_caracteristicas) ? 'checked' : '' ?>>
                                            <label class="custom-control-label" for="carac_<?= $key ?>">
                                                <?= $label ?>
                                            </label>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Sidebar -->
                <div class="col-md-4">
                    <!-- Valores e Status -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-dollar-sign"></i> Valores e Status
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <label>Status <span class="text-danger">*</span></label>
                                <select name="status" class="form-control" required>
                                    <option value="disponivel" <?= ($imovel['status'] ?? 'disponivel') == 'disponivel' ? 'selected' : '' ?>>Disponível</option>
                                    <option value="reservado" <?= ($imovel['status'] ?? '') == 'reservado' ? 'selected' : '' ?>>Reservado</option>
                                    <option value="vendido" <?= ($imovel['status'] ?? '') == 'vendido' ? 'selected' : '' ?>>Vendido</option>
                                    <option value="indisponivel" <?= ($imovel['status'] ?? '') == 'indisponivel' ? 'selected' : '' ?>>Indisponível</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label>Valor de Venda</label>
                                <input type="text" name="valor" class="form-control money-input" 
                                       placeholder="R$ 0,00"
                                       value="<?= $imovel['valor'] ?? '' ?>">
                            </div>
                            
                            <div class="form-group">
                                <label>Valor de Aluguel</label>
                                <input type="text" name="valor_aluguel" class="form-control money-input" 
                                       placeholder="R$ 0,00"
                                       value="<?= $imovel['valor_aluguel'] ?? '' ?>">
                            </div>
                            
                            <div class="form-group">
                                <label>Valor do Condomínio</label>
                                <input type="text" name="valor_condominio" class="form-control money-input" 
                                       placeholder="R$ 0,00"
                                       value="<?= $imovel['valor_condominio'] ?? '' ?>">
                            </div>
                            
                            <div class="form-group">
                                <label>Valor do IPTU</label>
                                <input type="text" name="valor_iptu" class="form-control money-input" 
                                       placeholder="R$ 0,00"
                                       value="<?= $imovel['valor_iptu'] ?? '' ?>">
                            </div>
                        </div>
                    </div>
                    
                    <!-- Imagens -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-images"></i> Imagens
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <label>Imagem Principal</label>
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" name="imagem_principal" 
                                           accept="image/*">
                                    <label class="custom-file-label">Escolher imagem</label>
                                </div>
                                <?php if (!empty($imovel['imagem_principal'])): ?>
                                    <img src="<?= upload_url($imovel['imagem_principal']) ?>" 
                                         class="img-thumbnail mt-2" style="max-height: 150px;">
                                <?php endif; ?>
                            </div>
                            
                            <div class="form-group">
                                <label>Galeria de Imagens</label>
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" name="galeria[]" 
                                           accept="image/*" multiple>
                                    <label class="custom-file-label">Escolher imagens</label>
                                </div>
                                <small class="form-text text-muted">
                                    Você pode selecionar múltiplas imagens
                                </small>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-save"></i> Salvar
                            </button>
                            <a href="<?= url('imoveis') ?>" class="btn btn-default btn-block">
                                <i class="fas fa-arrow-left"></i> Voltar
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</section>

<script>
// Busca CEP
function buscarCEP(cep) {
    cep = cep.replace(/\D/g, '');
    
    if (cep.length === 8) {
        fetch(`https://viacep.com.br/ws/${cep}/json/`)
            .then(response => response.json())
            .then(data => {
                if (!data.erro) {
                    document.getElementById('endereco').value = data.logradouro;
                    document.getElementById('bairro').value = data.bairro;
                    document.getElementById('cidade').value = data.localidade;
                    document.getElementById('uf').value = data.uf;
                }
            })
            .catch(error => console.error('Erro ao buscar CEP:', error));
    }
}

// Preview de arquivo selecionado
$('.custom-file-input').on('change', function() {
    const fileName = $(this).val().split('\\').pop();
    $(this).siblings('.custom-file-label').addClass('selected').html(fileName);
});
</script>
