<!-- Content Header -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>
                    <i class="fas fa-home"></i> Imóveis
                    <small>Gerenciamento de imóveis</small>
                </h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?= url() ?>">Início</a></li>
                    <li class="breadcrumb-item active">Imóveis</li>
                </ol>
            </div>
        </div>
    </div>
</section>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        
        <!-- Estatísticas -->
        <div class="row">
            <div class="col-lg-3 col-6">
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3><?= $estatisticas['total'] ?? 0 ?></h3>
                        <p>Total de Imóveis</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-home"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-success">
                    <div class="inner">
                        <h3><?= $estatisticas['disponiveis'] ?? 0 ?></h3>
                        <p>Disponíveis</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-warning">
                    <div class="inner">
                        <h3><?= $estatisticas['reservados'] ?? 0 ?></h3>
                        <p>Reservados</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-clock"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-danger">
                    <div class="inner">
                        <h3><?= $estatisticas['vendidos'] ?? 0 ?></h3>
                        <p>Vendidos</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-handshake"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Filtros -->
        <div class="card card-outline card-primary collapsed-card">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-filter"></i> Filtros
                </h3>
                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                        <i class="fas fa-plus"></i>
                    </button>
                </div>
            </div>
            <div class="card-body">
                <form method="get" action="<?= url('imoveis') ?>">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Buscar</label>
                                <input type="text" name="search" class="form-control" 
                                       placeholder="Código, endereço..." 
                                       value="<?= htmlspecialchars($filters['search'] ?? '') ?>">
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>Empreendimento</label>
                                <select name="empreendimento_id" class="form-control">
                                    <option value="">Todos</option>
                                    <?php foreach ($empreendimentos ?? [] as $emp): ?>
                                    <option value="<?= $emp['id'] ?>" 
                                            <?= ($filters['empreendimento_id'] ?? '') == $emp['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($emp['nome']) ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>Tipo</label>
                                <select name="tipo" class="form-control">
                                    <option value="">Todos</option>
                                    <option value="casa" <?= ($filters['tipo'] ?? '') == 'casa' ? 'selected' : '' ?>>Casa</option>
                                    <option value="apartamento" <?= ($filters['tipo'] ?? '') == 'apartamento' ? 'selected' : '' ?>>Apartamento</option>
                                    <option value="terreno" <?= ($filters['tipo'] ?? '') == 'terreno' ? 'selected' : '' ?>>Terreno</option>
                                    <option value="sala_comercial" <?= ($filters['tipo'] ?? '') == 'sala_comercial' ? 'selected' : '' ?>>Sala Comercial</option>
                                    <option value="galpao" <?= ($filters['tipo'] ?? '') == 'galpao' ? 'selected' : '' ?>>Galpão</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>Status</label>
                                <select name="status" class="form-control">
                                    <option value="">Todos</option>
                                    <option value="disponivel" <?= ($filters['status'] ?? '') == 'disponivel' ? 'selected' : '' ?>>Disponível</option>
                                    <option value="reservado" <?= ($filters['status'] ?? '') == 'reservado' ? 'selected' : '' ?>>Reservado</option>
                                    <option value="vendido" <?= ($filters['status'] ?? '') == 'vendido' ? 'selected' : '' ?>>Vendido</option>
                                    <option value="indisponivel" <?= ($filters['status'] ?? '') == 'indisponivel' ? 'selected' : '' ?>>Indisponível</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>Valor até</label>
                                <input type="text" name="valor_max" class="form-control money-input" 
                                       placeholder="R$ 0,00"
                                       value="<?= htmlspecialchars($filters['valor_max'] ?? '') ?>">
                            </div>
                        </div>
                        <div class="col-md-1">
                            <div class="form-group">
                                <label>&nbsp;</label>
                                <div>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-search"></i>
                                    </button>
                                    <a href="<?= url('imoveis') ?>" class="btn btn-default">
                                        <i class="fas fa-times"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Lista de Imóveis -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    Lista de Imóveis
                    <span class="badge badge-primary"><?= $pagination['total_records'] ?? 0 ?> registros</span>
                </h3>
                <div class="card-tools">
                    <a href="<?= url('imoveis/novo') ?>" class="btn btn-primary btn-sm">
                        <i class="fas fa-plus"></i> Novo Imóvel
                    </a>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <?php if (empty($imoveis)): ?>
                    <div class="col-12 text-center py-5">
                        <i class="fas fa-home fa-4x text-muted mb-3"></i>
                        <p class="text-muted">Nenhum imóvel encontrado</p>
                    </div>
                    <?php else: ?>
                        <?php foreach ($imoveis as $imovel): ?>
                        <div class="col-lg-4 col-md-6 mb-4">
                            <div class="card h-100">
                                <?php if ($imovel['imagem_principal']): ?>
                                <img src="<?= upload_url($imovel['imagem_principal']) ?>" 
                                     class="card-img-top" alt="<?= htmlspecialchars($imovel['codigo']) ?>"
                                     style="height: 200px; object-fit: cover;">
                                <?php else: ?>
                                <div class="card-img-top bg-secondary d-flex align-items-center justify-content-center" 
                                     style="height: 200px;">
                                    <i class="fas fa-home fa-3x text-white"></i>
                                </div>
                                <?php endif; ?>
                                
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <h5 class="card-title mb-0">
                                            <strong><?= htmlspecialchars($imovel['codigo']) ?></strong>
                                        </h5>
                                        <?php
                                        $statusClass = [
                                            'disponivel' => 'badge-success',
                                            'reservado' => 'badge-warning',
                                            'vendido' => 'badge-danger',
                                            'indisponivel' => 'badge-secondary'
                                        ];
                                        $statusText = [
                                            'disponivel' => 'Disponível',
                                            'reservado' => 'Reservado',
                                            'vendido' => 'Vendido',
                                            'indisponivel' => 'Indisponível'
                                        ];
                                        ?>
                                        <span class="badge <?= $statusClass[$imovel['status']] ?? 'badge-secondary' ?>">
                                            <?= $statusText[$imovel['status']] ?? 'N/D' ?>
                                        </span>
                                    </div>
                                    
                                    <?php if ($imovel['empreendimento_nome']): ?>
                                    <p class="text-muted small mb-2">
                                        <i class="fas fa-building"></i> <?= htmlspecialchars($imovel['empreendimento_nome']) ?>
                                    </p>
                                    <?php endif; ?>
                                    
                                    <p class="card-text">
                                        <i class="fas fa-map-marker-alt text-primary"></i> 
                                        <?= htmlspecialchars($imovel['endereco'] ?? 'Endereço não informado') ?>
                                        <?php if ($imovel['cidade']): ?>
                                            <br>
                                            <small class="text-muted"><?= htmlspecialchars($imovel['cidade']) ?>/<?= htmlspecialchars($imovel['uf']) ?></small>
                                        <?php endif; ?>
                                    </p>
                                    
                                    <div class="row text-center mb-3">
                                        <?php if ($imovel['quartos']): ?>
                                        <div class="col">
                                            <i class="fas fa-bed text-muted"></i><br>
                                            <small><?= $imovel['quartos'] ?> quartos</small>
                                        </div>
                                        <?php endif; ?>
                                        <?php if ($imovel['banheiros']): ?>
                                        <div class="col">
                                            <i class="fas fa-bath text-muted"></i><br>
                                            <small><?= $imovel['banheiros'] ?> banheiros</small>
                                        </div>
                                        <?php endif; ?>
                                        <?php if ($imovel['vagas_garagem']): ?>
                                        <div class="col">
                                            <i class="fas fa-car text-muted"></i><br>
                                            <small><?= $imovel['vagas_garagem'] ?> vagas</small>
                                        </div>
                                        <?php endif; ?>
                                        <?php if ($imovel['area_total']): ?>
                                        <div class="col">
                                            <i class="fas fa-ruler-combined text-muted"></i><br>
                                            <small><?= number_format($imovel['area_total'], 0) ?> m²</small>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <?php if ($imovel['valor']): ?>
                                    <h4 class="text-primary text-center mb-3">
                                        <strong>R$ <?= number_format($imovel['valor'], 2, ',', '.') ?></strong>
                                    </h4>
                                    <?php endif; ?>
                                    
                                    <div class="btn-group btn-group-sm w-100">
                                        <a href="<?= url('imoveis/visualizar/' . $imovel['id']) ?>" 
                                           class="btn btn-info">
                                            <i class="fas fa-eye"></i> Ver
                                        </a>
                                        <a href="<?= url('imoveis/editar/' . $imovel['id']) ?>" 
                                           class="btn btn-warning">
                                            <i class="fas fa-edit"></i> Editar
                                        </a>
                                        <?php if ($imovel['status'] == 'disponivel'): ?>
                                        <a href="<?= url('imoveis/reservar/' . $imovel['id']) ?>" 
                                           class="btn btn-success">
                                            <i class="fas fa-handshake"></i> Reservar
                                        </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <?php if (($pagination['total'] ?? 0) > 1): ?>
            <div class="card-footer">
                <nav aria-label="Paginação">
                    <ul class="pagination pagination-sm m-0 float-right">
                        <?php if ($pagination['current'] > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?= $pagination['current'] - 1 ?>&<?= http_build_query(array_diff_key($filters ?? [], ['page' => ''])) ?>">
                                &laquo;
                            </a>
                        </li>
                        <?php endif; ?>
                        
                        <?php for ($i = 1; $i <= $pagination['total']; $i++): ?>
                            <?php if ($i == 1 || $i == $pagination['total'] || ($i >= $pagination['current'] - 2 && $i <= $pagination['current'] + 2)): ?>
                            <li class="page-item <?= $i == $pagination['current'] ? 'active' : '' ?>">
                                <a class="page-link" href="?page=<?= $i ?>&<?= http_build_query(array_diff_key($filters ?? [], ['page' => ''])) ?>">
                                    <?= $i ?>
                                </a>
                            </li>
                            <?php elseif ($i == $pagination['current'] - 3 || $i == $pagination['current'] + 3): ?>
                            <li class="page-item disabled"><span class="page-link">...</span></li>
                            <?php endif; ?>
                        <?php endfor; ?>
                        
                        <?php if ($pagination['current'] < $pagination['total']): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?= $pagination['current'] + 1 ?>&<?= http_build_query(array_diff_key($filters ?? [], ['page' => ''])) ?>">
                                &raquo;
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>
