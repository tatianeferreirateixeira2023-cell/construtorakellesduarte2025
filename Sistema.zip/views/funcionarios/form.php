<!-- Content Header -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>
                    <i class="fas fa-user-plus"></i> 
                    <?= isset($funcionario) ? 'Editar' : 'Novo' ?> Funcionário
                </h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?= url() ?>">Início</a></li>
                    <li class="breadcrumb-item"><a href="<?= url('funcionarios') ?>">Funcionários</a></li>
                    <li class="breadcrumb-item active"><?= isset($funcionario) ? 'Editar' : 'Novo' ?></li>
                </ol>
            </div>
        </div>
    </div>
</section>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <form method="post" action="<?= url('funcionarios/' . (isset($funcionario) ? 'atualizar/' . $funcionario['id'] : 'salvar')) ?>" 
              enctype="multipart/form-data" class="needs-validation" novalidate>
            
            <div class="row">
                <!-- Dados Pessoais -->
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-user"></i> Dados Pessoais
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label>Nome Completo <span class="text-danger">*</span></label>
                                        <input type="text" name="nome" class="form-control" 
                                               value="<?= htmlspecialchars($funcionario['nome'] ?? '') ?>" 
                                               required>
                                        <div class="invalid-feedback">
                                            Por favor, informe o nome completo.
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Data de Nascimento</label>
                                        <input type="date" name="data_nascimento" class="form-control" 
                                               value="<?= $funcionario['data_nascimento'] ?? '' ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>CPF <span class="text-danger">*</span></label>
                                        <input type="text" name="cpf" class="form-control cpf-mask" 
                                               value="<?= htmlspecialchars($funcionario['cpf'] ?? '') ?>" 
                                               required>
                                        <div class="invalid-feedback">
                                            Por favor, informe um CPF válido.
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>RG</label>
                                        <input type="text" name="rg" class="form-control" 
                                               value="<?= htmlspecialchars($funcionario['rg'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>PIS/PASEP</label>
                                        <input type="text" name="pis" class="form-control" 
                                               value="<?= htmlspecialchars($funcionario['pis'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>CTPS - Número</label>
                                        <input type="text" name="ctps_numero" class="form-control" 
                                               value="<?= htmlspecialchars($funcionario['ctps_numero'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>CTPS - Série</label>
                                        <input type="text" name="ctps_serie" class="form-control" 
                                               value="<?= htmlspecialchars($funcionario['ctps_serie'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Estado Civil</label>
                                        <select name="estado_civil" class="form-control">
                                            <option value="">Selecione...</option>
                                            <option value="solteiro" <?= ($funcionario['estado_civil'] ?? '') == 'solteiro' ? 'selected' : '' ?>>Solteiro(a)</option>
                                            <option value="casado" <?= ($funcionario['estado_civil'] ?? '') == 'casado' ? 'selected' : '' ?>>Casado(a)</option>
                                            <option value="divorciado" <?= ($funcionario['estado_civil'] ?? '') == 'divorciado' ? 'selected' : '' ?>>Divorciado(a)</option>
                                            <option value="viuvo" <?= ($funcionario['estado_civil'] ?? '') == 'viuvo' ? 'selected' : '' ?>>Viúvo(a)</option>
                                            <option value="uniao_estavel" <?= ($funcionario['estado_civil'] ?? '') == 'uniao_estavel' ? 'selected' : '' ?>>União Estável</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>E-mail</label>
                                        <input type="email" name="email" class="form-control" 
                                               value="<?= htmlspecialchars($funcionario['email'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Telefone</label>
                                        <input type="text" name="telefone" class="form-control phone-mask" 
                                               value="<?= htmlspecialchars($funcionario['telefone'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Telefone Emergência</label>
                                        <input type="text" name="telefone_emergencia" class="form-control phone-mask" 
                                               value="<?= htmlspecialchars($funcionario['telefone_emergencia'] ?? '') ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Endereço -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-map-marker-alt"></i> Endereço
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>CEP</label>
                                        <input type="text" name="cep" class="form-control cep-mask" 
                                               value="<?= htmlspecialchars($funcionario['cep'] ?? '') ?>"
                                               onblur="buscarCEP(this.value)">
                                    </div>
                                </div>
                                
                                <div class="col-md-7">
                                    <div class="form-group">
                                        <label>Endereço</label>
                                        <input type="text" name="endereco" id="endereco" class="form-control" 
                                               value="<?= htmlspecialchars($funcionario['endereco'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Número</label>
                                        <input type="text" name="numero" class="form-control" 
                                               value="<?= htmlspecialchars($funcionario['numero'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Complemento</label>
                                        <input type="text" name="complemento" class="form-control" 
                                               value="<?= htmlspecialchars($funcionario['complemento'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Bairro</label>
                                        <input type="text" name="bairro" id="bairro" class="form-control" 
                                               value="<?= htmlspecialchars($funcionario['bairro'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Cidade</label>
                                        <input type="text" name="cidade" id="cidade" class="form-control" 
                                               value="<?= htmlspecialchars($funcionario['cidade'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-1">
                                    <div class="form-group">
                                        <label>UF</label>
                                        <input type="text" name="uf" id="uf" class="form-control" 
                                               maxlength="2" style="text-transform: uppercase"
                                               value="<?= htmlspecialchars($funcionario['uf'] ?? '') ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Dados Profissionais -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-briefcase"></i> Dados Profissionais
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Cargo <span class="text-danger">*</span></label>
                                        <select name="cargo" class="form-control" required>
                                            <option value="">Selecione...</option>
                                            <option value="pedreiro" <?= ($funcionario['cargo'] ?? '') == 'pedreiro' ? 'selected' : '' ?>>Pedreiro</option>
                                            <option value="servente" <?= ($funcionario['cargo'] ?? '') == 'servente' ? 'selected' : '' ?>>Servente</option>
                                            <option value="mestre_obras" <?= ($funcionario['cargo'] ?? '') == 'mestre_obras' ? 'selected' : '' ?>>Mestre de Obras</option>
                                            <option value="encarregado" <?= ($funcionario['cargo'] ?? '') == 'encarregado' ? 'selected' : '' ?>>Encarregado</option>
                                            <option value="eletricista" <?= ($funcionario['cargo'] ?? '') == 'eletricista' ? 'selected' : '' ?>>Eletricista</option>
                                            <option value="encanador" <?= ($funcionario['cargo'] ?? '') == 'encanador' ? 'selected' : '' ?>>Encanador</option>
                                            <option value="pintor" <?= ($funcionario['cargo'] ?? '') == 'pintor' ? 'selected' : '' ?>>Pintor</option>
                                            <option value="carpinteiro" <?= ($funcionario['cargo'] ?? '') == 'carpinteiro' ? 'selected' : '' ?>>Carpinteiro</option>
                                            <option value="administrativo" <?= ($funcionario['cargo'] ?? '') == 'administrativo' ? 'selected' : '' ?>>Administrativo</option>
                                            <option value="outros" <?= ($funcionario['cargo'] ?? '') == 'outros' ? 'selected' : '' ?>>Outros</option>
                                        </select>
                                        <div class="invalid-feedback">
                                            Por favor, selecione um cargo.
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Função Específica</label>
                                        <input type="text" name="funcao" class="form-control" 
                                               value="<?= htmlspecialchars($funcionario['funcao'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Obra Atual</label>
                                        <select name="obra_id" class="form-control">
                                            <option value="">Nenhuma</option>
                                            <?php foreach ($obras ?? [] as $obra): ?>
                                            <option value="<?= $obra['id'] ?>" 
                                                    <?= ($funcionario['obra_id'] ?? '') == $obra['id'] ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($obra['nome']) ?>
                                            </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Data de Admissão</label>
                                        <input type="date" name="data_admissao" class="form-control" 
                                               value="<?= $funcionario['data_admissao'] ?? '' ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Tipo de Contrato</label>
                                        <select name="tipo_contrato" class="form-control">
                                            <option value="clt" <?= ($funcionario['tipo_contrato'] ?? 'clt') == 'clt' ? 'selected' : '' ?>>CLT</option>
                                            <option value="pj" <?= ($funcionario['tipo_contrato'] ?? '') == 'pj' ? 'selected' : '' ?>>PJ</option>
                                            <option value="temporario" <?= ($funcionario['tipo_contrato'] ?? '') == 'temporario' ? 'selected' : '' ?>>Temporário</option>
                                            <option value="terceirizado" <?= ($funcionario['tipo_contrato'] ?? '') == 'terceirizado' ? 'selected' : '' ?>>Terceirizado</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Salário</label>
                                        <input type="text" name="salario" class="form-control money-input" 
                                               value="<?= $funcionario['salario'] ?? '' ?>"
                                               placeholder="R$ 0,00">
                                    </div>
                                </div>
                                
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Vale Transporte</label>
                                        <input type="text" name="vale_transporte" class="form-control money-input" 
                                               value="<?= $funcionario['vale_transporte'] ?? '' ?>"
                                               placeholder="R$ 0,00">
                                    </div>
                                </div>
                                
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Observações</label>
                                        <textarea name="observacoes" class="form-control" rows="3"><?= htmlspecialchars($funcionario['observacoes'] ?? '') ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Sidebar -->
                <div class="col-md-4">
                    <!-- Foto e Status -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-camera"></i> Foto e Status
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <label>Foto do Funcionário</label>
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" name="foto" 
                                           accept="image/*">
                                    <label class="custom-file-label">Escolher foto</label>
                                </div>
                                <?php if (!empty($funcionario['foto'])): ?>
                                    <img src="<?= upload_url($funcionario['foto']) ?>" 
                                         class="img-thumbnail mt-2" style="max-height: 200px;">
                                <?php endif; ?>
                            </div>
                            
                            <div class="form-group">
                                <label>Status</label>
                                <select name="status" class="form-control">
                                    <option value="ativo" <?= ($funcionario['status'] ?? 'ativo') == 'ativo' ? 'selected' : '' ?>>Ativo</option>
                                    <option value="ferias" <?= ($funcionario['status'] ?? '') == 'ferias' ? 'selected' : '' ?>>Férias</option>
                                    <option value="afastado" <?= ($funcionario['status'] ?? '') == 'afastado' ? 'selected' : '' ?>>Afastado</option>
                                    <option value="demitido" <?= ($funcionario['status'] ?? '') == 'demitido' ? 'selected' : '' ?>>Demitido</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label>Data de Demissão</label>
                                <input type="date" name="data_demissao" class="form-control" 
                                       value="<?= $funcionario['data_demissao'] ?? '' ?>">
                                <small class="form-text text-muted">
                                    Preencher apenas se o status for "Demitido"
                                </small>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Dados Bancários -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-university"></i> Dados Bancários
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <label>Banco</label>
                                <input type="text" name="banco" class="form-control" 
                                       value="<?= htmlspecialchars($funcionario['banco'] ?? '') ?>">
                            </div>
                            
                            <div class="form-group">
                                <label>Agência</label>
                                <input type="text" name="agencia" class="form-control" 
                                       value="<?= htmlspecialchars($funcionario['agencia'] ?? '') ?>">
                            </div>
                            
                            <div class="form-group">
                                <label>Conta</label>
                                <input type="text" name="conta" class="form-control" 
                                       value="<?= htmlspecialchars($funcionario['conta'] ?? '') ?>">
                            </div>
                            
                            <div class="form-group">
                                <label>PIX</label>
                                <input type="text" name="pix" class="form-control" 
                                       value="<?= htmlspecialchars($funcionario['pix'] ?? '') ?>"
                                       placeholder="CPF, E-mail ou Telefone">
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-save"></i> Salvar
                            </button>
                            <a href="<?= url('funcionarios') ?>" class="btn btn-default btn-block">
                                <i class="fas fa-arrow-left"></i> Voltar
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</section>

<script>
// Busca CEP
function buscarCEP(cep) {
    cep = cep.replace(/\D/g, '');
    
    if (cep.length === 8) {
        fetch(`https://viacep.com.br/ws/${cep}/json/`)
            .then(response => response.json())
            .then(data => {
                if (!data.erro) {
                    document.getElementById('endereco').value = data.logradouro;
                    document.getElementById('bairro').value = data.bairro;
                    document.getElementById('cidade').value = data.localidade;
                    document.getElementById('uf').value = data.uf;
                }
            })
            .catch(error => console.error('Erro ao buscar CEP:', error));
    }
}

// Preview de imagem
$('.custom-file-input').on('change', function() {
    const fileName = $(this).val().split('\\').pop();
    $(this).siblings('.custom-file-label').addClass('selected').html(fileName);
});
</script>
