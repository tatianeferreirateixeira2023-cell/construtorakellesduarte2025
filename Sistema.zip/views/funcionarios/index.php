<!-- Content Header -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>
                    <i class="fas fa-id-card"></i> Funcionários
                    <small>Gerenciamento de funcionários</small>
                </h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?= url() ?>">Início</a></li>
                    <li class="breadcrumb-item active">Funcionários</li>
                </ol>
            </div>
        </div>
    </div>
</section>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        
        <!-- Estatísticas -->
        <div class="row">
            <div class="col-lg-3 col-6">
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3><?= $estatisticas['total'] ?? 0 ?></h3>
                        <p>Total de Funcionários</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-success">
                    <div class="inner">
                        <h3><?= $estatisticas['ativos'] ?? 0 ?></h3>
                        <p>Ativos</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-user-check"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-warning">
                    <div class="inner">
                        <h3><?= $estatisticas['ferias'] ?? 0 ?></h3>
                        <p>Em Férias</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-umbrella-beach"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-danger">
                    <div class="inner">
                        <h3><?= $estatisticas['afastados'] ?? 0 ?></h3>
                        <p>Afastados</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-user-times"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Filtros -->
        <div class="card card-outline card-primary collapsed-card">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-filter"></i> Filtros
                </h3>
                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                        <i class="fas fa-plus"></i>
                    </button>
                </div>
            </div>
            <div class="card-body">
                <form method="get" action="<?= url('funcionarios') ?>">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Buscar</label>
                                <input type="text" name="search" class="form-control" 
                                       placeholder="Nome, CPF, função..." 
                                       value="<?= htmlspecialchars($filters['search'] ?? '') ?>">
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>Cargo</label>
                                <select name="cargo" class="form-control">
                                    <option value="">Todos</option>
                                    <option value="pedreiro" <?= ($filters['cargo'] ?? '') == 'pedreiro' ? 'selected' : '' ?>>Pedreiro</option>
                                    <option value="servente" <?= ($filters['cargo'] ?? '') == 'servente' ? 'selected' : '' ?>>Servente</option>
                                    <option value="mestre_obras" <?= ($filters['cargo'] ?? '') == 'mestre_obras' ? 'selected' : '' ?>>Mestre de Obras</option>
                                    <option value="encarregado" <?= ($filters['cargo'] ?? '') == 'encarregado' ? 'selected' : '' ?>>Encarregado</option>
                                    <option value="eletricista" <?= ($filters['cargo'] ?? '') == 'eletricista' ? 'selected' : '' ?>>Eletricista</option>
                                    <option value="encanador" <?= ($filters['cargo'] ?? '') == 'encanador' ? 'selected' : '' ?>>Encanador</option>
                                    <option value="pintor" <?= ($filters['cargo'] ?? '') == 'pintor' ? 'selected' : '' ?>>Pintor</option>
                                    <option value="carpinteiro" <?= ($filters['cargo'] ?? '') == 'carpinteiro' ? 'selected' : '' ?>>Carpinteiro</option>
                                    <option value="administrativo" <?= ($filters['cargo'] ?? '') == 'administrativo' ? 'selected' : '' ?>>Administrativo</option>
                                    <option value="outros" <?= ($filters['cargo'] ?? '') == 'outros' ? 'selected' : '' ?>>Outros</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>Status</label>
                                <select name="status" class="form-control">
                                    <option value="">Todos</option>
                                    <option value="ativo" <?= ($filters['status'] ?? '') == 'ativo' ? 'selected' : '' ?>>Ativo</option>
                                    <option value="ferias" <?= ($filters['status'] ?? '') == 'ferias' ? 'selected' : '' ?>>Férias</option>
                                    <option value="afastado" <?= ($filters['status'] ?? '') == 'afastado' ? 'selected' : '' ?>>Afastado</option>
                                    <option value="demitido" <?= ($filters['status'] ?? '') == 'demitido' ? 'selected' : '' ?>>Demitido</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>Obra</label>
                                <select name="obra_id" class="form-control">
                                    <option value="">Todas</option>
                                    <?php foreach ($obras ?? [] as $obra): ?>
                                    <option value="<?= $obra['id'] ?>" 
                                            <?= ($filters['obra_id'] ?? '') == $obra['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($obra['nome']) ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>Tipo</label>
                                <select name="tipo_contrato" class="form-control">
                                    <option value="">Todos</option>
                                    <option value="clt" <?= ($filters['tipo_contrato'] ?? '') == 'clt' ? 'selected' : '' ?>>CLT</option>
                                    <option value="pj" <?= ($filters['tipo_contrato'] ?? '') == 'pj' ? 'selected' : '' ?>>PJ</option>
                                    <option value="temporario" <?= ($filters['tipo_contrato'] ?? '') == 'temporario' ? 'selected' : '' ?>>Temporário</option>
                                    <option value="terceirizado" <?= ($filters['tipo_contrato'] ?? '') == 'terceirizado' ? 'selected' : '' ?>>Terceirizado</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-1">
                            <div class="form-group">
                                <label>&nbsp;</label>
                                <div>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-search"></i>
                                    </button>
                                    <a href="<?= url('funcionarios') ?>" class="btn btn-default">
                                        <i class="fas fa-times"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Lista de Funcionários -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    Lista de Funcionários
                    <span class="badge badge-primary"><?= $pagination['total_records'] ?? 0 ?> registros</span>
                </h3>
                <div class="card-tools">
                    <div class="btn-group">
                        <a href="<?= url('funcionarios/novo') ?>" class="btn btn-primary btn-sm">
                            <i class="fas fa-plus"></i> Novo Funcionário
                        </a>
                        <a href="<?= url('epis') ?>" class="btn btn-warning btn-sm">
                            <i class="fas fa-hard-hat"></i> EPIs
                        </a>
                        <a href="<?= url('faltas') ?>" class="btn btn-danger btn-sm">
                            <i class="fas fa-calendar-times"></i> Faltas
                        </a>
                    </div>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th width="50">Foto</th>
                                <th>Nome</th>
                                <th>Cargo/Função</th>
                                <th>Contato</th>
                                <th>Obra Atual</th>
                                <th width="100">Salário</th>
                                <th width="100">Status</th>
                                <th width="180">Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($funcionarios)): ?>
                            <tr>
                                <td colspan="8" class="text-center py-4">
                                    <i class="fas fa-users fa-3x text-muted mb-3"></i>
                                    <p class="text-muted">Nenhum funcionário encontrado</p>
                                </td>
                            </tr>
                            <?php else: ?>
                                <?php foreach ($funcionarios as $func): ?>
                                <tr>
                                    <td>
                                        <?php if ($func['foto']): ?>
                                            <img src="<?= upload_url($func['foto']) ?>" 
                                                 class="img-circle" 
                                                 style="width: 40px; height: 40px; object-fit: cover;">
                                        <?php else: ?>
                                            <div class="img-circle bg-secondary d-flex align-items-center justify-content-center" 
                                                 style="width: 40px; height: 40px;">
                                                <i class="fas fa-user text-white"></i>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <strong><?= htmlspecialchars($func['nome']) ?></strong>
                                        <br>
                                        <small class="text-muted">
                                            CPF: <?= htmlspecialchars($func['cpf']) ?>
                                            <?php if ($func['pis']): ?>
                                                | PIS: <?= htmlspecialchars($func['pis']) ?>
                                            <?php endif; ?>
                                        </small>
                                    </td>
                                    <td>
                                        <?php
                                        $cargoLabels = [
                                            'pedreiro' => 'Pedreiro',
                                            'servente' => 'Servente',
                                            'mestre_obras' => 'Mestre de Obras',
                                            'encarregado' => 'Encarregado',
                                            'eletricista' => 'Eletricista',
                                            'encanador' => 'Encanador',
                                            'pintor' => 'Pintor',
                                            'carpinteiro' => 'Carpinteiro',
                                            'administrativo' => 'Administrativo',
                                            'outros' => 'Outros'
                                        ];
                                        ?>
                                        <span class="badge badge-info">
                                            <?= $cargoLabels[$func['cargo']] ?? $func['cargo'] ?>
                                        </span>
                                        <?php if ($func['funcao']): ?>
                                            <br>
                                            <small><?= htmlspecialchars($func['funcao']) ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($func['telefone']): ?>
                                            <i class="fas fa-phone"></i> <?= htmlspecialchars($func['telefone']) ?>
                                        <?php endif; ?>
                                        <?php if ($func['email']): ?>
                                            <br>
                                            <a href="mailto:<?= htmlspecialchars($func['email']) ?>">
                                                <i class="fas fa-envelope"></i> <?= htmlspecialchars($func['email']) ?>
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($func['obra_nome']): ?>
                                            <span class="badge badge-secondary">
                                                <?= htmlspecialchars($func['obra_nome']) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($func['salario']): ?>
                                            <strong>R$ <?= number_format($func['salario'], 2, ',', '.') ?></strong>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php
                                        $statusClass = [
                                            'ativo' => 'badge-success',
                                            'ferias' => 'badge-warning',
                                            'afastado' => 'badge-danger',
                                            'demitido' => 'badge-secondary'
                                        ];
                                        $statusText = [
                                            'ativo' => 'Ativo',
                                            'ferias' => 'Férias',
                                            'afastado' => 'Afastado',
                                            'demitido' => 'Demitido'
                                        ];
                                        ?>
                                        <span class="badge <?= $statusClass[$func['status']] ?? 'badge-secondary' ?>">
                                            <?= $statusText[$func['status']] ?? 'N/D' ?>
                                        </span>
                                        <?php if ($func['data_admissao']): ?>
                                            <br>
                                            <small class="text-muted">
                                                <?= date('d/m/Y', strtotime($func['data_admissao'])) ?>
                                            </small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="<?= url('funcionarios/visualizar/' . $func['id']) ?>" 
                                               class="btn btn-info" title="Visualizar">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="<?= url('funcionarios/editar/' . $func['id']) ?>" 
                                               class="btn btn-warning" title="Editar">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="<?= url('funcionarios/epis/' . $func['id']) ?>" 
                                               class="btn btn-secondary" title="EPIs">
                                                <i class="fas fa-hard-hat"></i>
                                            </a>
                                            <a href="<?= url('funcionarios/faltas/' . $func['id']) ?>" 
                                               class="btn btn-danger" title="Faltas">
                                                <i class="fas fa-calendar-times"></i>
                                            </a>
                                            <button type="button" class="btn btn-primary" 
                                                    onclick="gerarCracha(<?= $func['id'] ?>)" 
                                                    title="Gerar Crachá">
                                                <i class="fas fa-id-badge"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <?php if (($pagination['total'] ?? 0) > 1): ?>
            <div class="card-footer">
                <nav aria-label="Paginação">
                    <ul class="pagination pagination-sm m-0 float-right">
                        <?php if ($pagination['current'] > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?= $pagination['current'] - 1 ?>&<?= http_build_query(array_diff_key($filters ?? [], ['page' => ''])) ?>">
                                &laquo;
                            </a>
                        </li>
                        <?php endif; ?>
                        
                        <?php for ($i = 1; $i <= $pagination['total']; $i++): ?>
                            <?php if ($i == 1 || $i == $pagination['total'] || ($i >= $pagination['current'] - 2 && $i <= $pagination['current'] + 2)): ?>
                            <li class="page-item <?= $i == $pagination['current'] ? 'active' : '' ?>">
                                <a class="page-link" href="?page=<?= $i ?>&<?= http_build_query(array_diff_key($filters ?? [], ['page' => ''])) ?>">
                                    <?= $i ?>
                                </a>
                            </li>
                            <?php elseif ($i == $pagination['current'] - 3 || $i == $pagination['current'] + 3): ?>
                            <li class="page-item disabled"><span class="page-link">...</span></li>
                            <?php endif; ?>
                        <?php endfor; ?>
                        
                        <?php if ($pagination['current'] < $pagination['total']): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?= $pagination['current'] + 1 ?>&<?= http_build_query(array_diff_key($filters ?? [], ['page' => ''])) ?>">
                                &raquo;
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<script>
function gerarCracha(id) {
    window.open('<?= url('funcionarios/cracha/') ?>' + id, '_blank');
}
</script>
