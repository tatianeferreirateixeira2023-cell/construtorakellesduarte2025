<?php
$pageTitle = 'Gestão de Faltas';
$currentPage = 'funcionarios';
?>

<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12 d-flex justify-content-between align-items-center">
            <h1 class="h3 mb-0">Gestão de Faltas</h1>
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalRegistrarFalta">
                <i class="fas fa-plus"></i> Registrar Falta
            </button>
        </div>
    </div>

    <?php if (isset($flash)): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show" role="alert">
            <?= $flash['message'] ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <!-- Cards de Estatísticas -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Total de Faltas (Mês)
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?= $estatisticas['total_mes'] ?? 0 ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-calendar-times fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Faltas Justificadas
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?= $estatisticas['total_justificadas'] ?? 0 ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Faltas Injustificadas
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?= $estatisticas['total_injustificadas'] ?? 0 ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-exclamation-triangle fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                Funcionários Faltosos
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?= $estatisticas['funcionarios_faltosos'] ?? 0 ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-users fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filtros -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Filtros</h6>
        </div>
        <div class="card-body">
            <form method="GET" action="<?= BASE_URL ?>/faltas">
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="funcionario">Funcionário</label>
                            <select name="funcionario" id="funcionario" class="form-control">
                                <option value="">Todos</option>
                                <?php foreach ($funcionarios as $func): ?>
                                    <option value="<?= $func['id'] ?>" 
                                            <?= (isset($filters['funcionario']) && $filters['funcionario'] == $func['id']) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($func['nome']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="mes">Mês/Ano</label>
                            <input type="month" name="mes" id="mes" class="form-control" 
                                   value="<?= $filters['mes'] ?? date('Y-m') ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>&nbsp;</label>
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-search"></i> Filtrar
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Tabela de Faltas -->
    <div class="card shadow">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">
                Registro de Faltas (<?= number_format($pagination['total_records']) ?> registros)
            </h6>
        </div>
        <div class="card-body">
            <?php if (!empty($faltas)): ?>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th width="100">Data</th>
                                <th>Funcionário</th>
                                <th>CPF</th>
                                <th>Tipo</th>
                                <th>Horas/Atraso</th>
                                <th>Motivo</th>
                                <th width="100">Justificada</th>
                                <th width="120">Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($faltas as $falta): ?>
                                <tr>
                                    <td><?= date('d/m/Y', strtotime($falta['data'])) ?></td>
                                    <td><?= htmlspecialchars($falta['funcionario_nome']) ?></td>
                                    <td><?= htmlspecialchars($falta['funcionario_cpf']) ?></td>
                                    <td>
                                        <?php if ($falta['tipo'] == 'falta'): ?>
                                            <span class="badge badge-danger">Falta</span>
                                        <?php elseif ($falta['tipo'] == 'atraso'): ?>
                                            <span class="badge badge-warning">Atraso</span>
                                        <?php else: ?>
                                            <span class="badge badge-info">Saída Antecipada</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($falta['horas_atraso']): ?>
                                            <?= $falta['horas_atraso'] ?> horas
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td><?= htmlspecialchars($falta['motivo'] ?? '-') ?></td>
                                    <td class="text-center">
                                        <?php if ($falta['justificada']): ?>
                                            <span class="badge badge-success">Sim</span>
                                        <?php else: ?>
                                            <span class="badge badge-danger">Não</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <div class="btn-group" role="group">
                                            <button type="button" class="btn btn-sm btn-info" 
                                                    onclick="editarFalta(<?= $falta['id'] ?>)" title="Editar">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-danger" 
                                                    onclick="excluirFalta(<?= $falta['id'] ?>)" title="Excluir">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Paginação -->
                <?php if ($pagination['total'] > 1): ?>
                    <nav aria-label="Navegação de páginas">
                        <ul class="pagination justify-content-center">
                            <li class="page-item <?= $pagination['current'] == 1 ? 'disabled' : '' ?>">
                                <a class="page-link" href="?page=<?= $pagination['current'] - 1 ?>&<?= http_build_query($filters) ?>">
                                    Anterior
                                </a>
                            </li>
                            
                            <?php for ($i = max(1, $pagination['current'] - 2); $i <= min($pagination['total'], $pagination['current'] + 2); $i++): ?>
                                <li class="page-item <?= $i == $pagination['current'] ? 'active' : '' ?>">
                                    <a class="page-link" href="?page=<?= $i ?>&<?= http_build_query($filters) ?>">
                                        <?= $i ?>
                                    </a>
                                </li>
                            <?php endfor; ?>
                            
                            <li class="page-item <?= $pagination['current'] == $pagination['total'] ? 'disabled' : '' ?>">
                                <a class="page-link" href="?page=<?= $pagination['current'] + 1 ?>&<?= http_build_query($filters) ?>">
                                    Próxima
                                </a>
                            </li>
                        </ul>
                    </nav>
                <?php endif; ?>
            <?php else: ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> Nenhuma falta registrada para o período selecionado.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Modal Registrar Falta -->
<div class="modal fade" id="modalRegistrarFalta" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Registrar Falta</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="POST" action="<?= BASE_URL ?>/funcionarios/registrar-falta">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="funcionario_id">Funcionário *</label>
                        <select name="funcionario_id" id="funcionario_id" class="form-control" required>
                            <option value="">Selecione...</option>
                            <?php foreach ($funcionarios as $func): ?>
                                <option value="<?= $func['id'] ?>">
                                    <?= htmlspecialchars($func['nome']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="data">Data *</label>
                        <input type="date" name="data" id="data" class="form-control" 
                               max="<?= date('Y-m-d') ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="tipo">Tipo *</label>
                        <select name="tipo" id="tipo" class="form-control" required onchange="toggleHorasAtraso()">
                            <option value="">Selecione...</option>
                            <option value="falta">Falta</option>
                            <option value="atraso">Atraso</option>
                            <option value="saida_antecipada">Saída Antecipada</option>
                        </select>
                    </div>
                    
                    <div class="form-group" id="divHorasAtraso" style="display: none;">
                        <label for="horas_atraso">Horas de Atraso</label>
                        <input type="number" name="horas_atraso" id="horas_atraso" 
                               class="form-control" min="0" step="0.5">
                    </div>
                    
                    <div class="form-group">
                        <label for="motivo">Motivo</label>
                        <textarea name="motivo" id="motivo" class="form-control" rows="3"></textarea>
                    </div>
                    
                    <div class="form-group">
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="justificada" name="justificada" value="1">
                            <label class="custom-control-label" for="justificada">
                                Falta Justificada
                            </label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Registrar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function toggleHorasAtraso() {
    var tipo = document.getElementById('tipo').value;
    var divHoras = document.getElementById('divHorasAtraso');
    
    if (tipo === 'atraso' || tipo === 'saida_antecipada') {
        divHoras.style.display = 'block';
    } else {
        divHoras.style.display = 'none';
        document.getElementById('horas_atraso').value = '';
    }
}

function editarFalta(id) {
    // Implementar edição de falta
    alert('Funcionalidade de edição em desenvolvimento');
}

function excluirFalta(id) {
    if (confirm('Tem certeza que deseja excluir esta falta?')) {
        // Implementar exclusão
        window.location.href = '<?= BASE_URL ?>/funcionarios/excluir-falta/' + id;
    }
}
</script>
