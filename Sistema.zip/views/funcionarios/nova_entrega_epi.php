<?php require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-hard-hat"></i> Nova Entrega de EPI
                    </h3>
                </div>
                <div class="card-body">
                    <?php if (isset($flash)): ?>
                        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show" role="alert">
                            <?= $flash['message'] ?>
                            <button type="button" class="close" data-dismiss="alert">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="/sistema/epis/nova-entrega">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="funcionario_id">Funcionário <span class="text-danger">*</span></label>
                                    <select class="form-control select2" id="funcionario_id" name="funcionario_id" required>
                                        <option value="">Selecione o funcionário...</option>
                                        <?php foreach ($funcionarios as $funcionario): ?>
                                            <option value="<?= $funcionario['id'] ?>">
                                                <?= htmlspecialchars($funcionario['nome']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="data_entrega">Data de Entrega <span class="text-danger">*</span></label>
                                    <input type="date" class="form-control" id="data_entrega" name="data_entrega" 
                                           value="<?= date('Y-m-d') ?>" required>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="quantidade">Quantidade <span class="text-danger">*</span></label>
                                    <input type="number" class="form-control" id="quantidade" name="quantidade" 
                                           value="1" min="1" required>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="descricao">Descrição do EPI <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="descricao" name="descricao" 
                                           required placeholder="Ex: Capacete de segurança branco">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="codigo">Código/CA</label>
                                    <input type="text" class="form-control" id="codigo" name="codigo" 
                                           placeholder="Certificado de Aprovação">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="validade_meses">Validade (meses)</label>
                                    <input type="number" class="form-control" id="validade_meses" name="validade_meses" 
                                           min="1" placeholder="Ex: 12">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="marca">Marca</label>
                                    <input type="text" class="form-control" id="marca" name="marca" 
                                           placeholder="Marca do EPI">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="tamanho">Tamanho</label>
                                    <select class="form-control" id="tamanho" name="tamanho">
                                        <option value="">Selecione...</option>
                                        <option value="PP">PP</option>
                                        <option value="P">P</option>
                                        <option value="M">M</option>
                                        <option value="G">G</option>
                                        <option value="GG">GG</option>
                                        <option value="XG">XG</option>
                                        <option value="Único">Único</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="numero_nota">Número da Nota Fiscal</label>
                                    <input type="text" class="form-control" id="numero_nota" name="numero_nota" 
                                           placeholder="NF de compra">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="observacoes">Observações</label>
                                    <textarea class="form-control" id="observacoes" name="observacoes" rows="3"
                                              placeholder="Observações adicionais"></textarea>
                                </div>
                            </div>
                        </div>

                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> 
                            O funcionário deverá assinar o termo de recebimento do EPI. 
                            Mantenha o controle físico dos termos assinados.
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Registrar Entrega
                                </button>
                                <a href="/sistema/epis" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> Cancelar
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Select2 para dropdown de funcionários
    $('.select2').select2({
        theme: 'bootstrap4',
        placeholder: 'Selecione o funcionário...',
        allowClear: true,
        width: '100%'
    });
});
</script>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
