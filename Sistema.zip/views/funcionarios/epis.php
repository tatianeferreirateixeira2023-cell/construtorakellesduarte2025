<!-- Content Header -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>
                    <i class="fas fa-hard-hat"></i> EPIs
                    <small>Equipamentos de Proteção Individual</small>
                </h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?= url() ?>">Início</a></li>
                    <li class="breadcrumb-item"><a href="<?= url('funcionarios') ?>">Funcionários</a></li>
                    <li class="breadcrumb-item active">EPIs</li>
                </ol>
            </div>
        </div>
    </div>
</section>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        
        <!-- Estatísticas -->
        <div class="row">
            <div class="col-lg-3 col-6">
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3><?= $estatisticas['total_entregue'] ?? 0 ?></h3>
                        <p>EPIs Entregues</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-hard-hat"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-success">
                    <div class="inner">
                        <h3><?= $estatisticas['total_devolvido'] ?? 0 ?></h3>
                        <p>EPIs Devolvidos</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-undo"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-warning">
                    <div class="inner">
                        <h3><?= $estatisticas['vencendo_mes'] ?? 0 ?></h3>
                        <p>Vencendo este Mês</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-primary">
                    <div class="inner">
                        <h3><?= $estatisticas['total_funcionarios'] ?? 0 ?></h3>
                        <p>Funcionários Ativos</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Filtros -->
        <div class="card card-outline card-primary collapsed-card">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-filter"></i> Filtros
                </h3>
                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                        <i class="fas fa-plus"></i>
                    </button>
                </div>
            </div>
            <div class="card-body">
                <form method="get" action="<?= url('epis') ?>">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Funcionário</label>
                                <select name="funcionario" class="form-control select2">
                                    <option value="">Todos</option>
                                    <?php foreach ($funcionarios ?? [] as $func): ?>
                                    <option value="<?= $func['id'] ?>" 
                                            <?= ($filters['funcionario'] ?? '') == $func['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($func['nome']) ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Status</label>
                                <select name="status" class="form-control">
                                    <option value="">Todos</option>
                                    <option value="entregue" <?= ($filters['status'] ?? '') == 'entregue' ? 'selected' : '' ?>>Entregue</option>
                                    <option value="devolvido" <?= ($filters['status'] ?? '') == 'devolvido' ? 'selected' : '' ?>>Devolvido</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>Data Entrega De</label>
                                <input type="date" name="data_inicio" class="form-control" 
                                       value="<?= $filters['data_inicio'] ?? '' ?>">
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>Data Entrega Até</label>
                                <input type="date" name="data_fim" class="form-control" 
                                       value="<?= $filters['data_fim'] ?? '' ?>">
                            </div>
                        </div>
                        <div class="col-md-1">
                            <div class="form-group">
                                <label>&nbsp;</label>
                                <div>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-search"></i>
                                    </button>
                                    <a href="<?= url('epis') ?>" class="btn btn-default">
                                        <i class="fas fa-times"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Lista de EPIs -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    Controle de EPIs
                    <span class="badge badge-primary"><?= $pagination['total_records'] ?? 0 ?> registros</span>
                </h3>
                <div class="card-tools">
                    <button type="button" class="btn btn-primary btn-sm" onclick="novaEntrega()">
                        <i class="fas fa-plus"></i> Nova Entrega
                    </button>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th width="50">ID</th>
                                <th>Funcionário</th>
                                <th>EPI</th>
                                <th width="120">Data Entrega</th>
                                <th width="120">Validade</th>
                                <th width="120">Devolução</th>
                                <th width="100">Status</th>
                                <th width="150">Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($epis)): ?>
                            <tr>
                                <td colspan="8" class="text-center py-4">
                                    <i class="fas fa-hard-hat fa-3x text-muted mb-3"></i>
                                    <p class="text-muted">Nenhum registro de EPI encontrado</p>
                                </td>
                            </tr>
                            <?php else: ?>
                                <?php foreach ($epis as $epi): ?>
                                <tr>
                                    <td><?= $epi['id'] ?></td>
                                    <td>
                                        <strong><?= htmlspecialchars($epi['funcionario_nome']) ?></strong>
                                        <br>
                                        <small class="text-muted">
                                            CPF: <?= htmlspecialchars($epi['funcionario_cpf']) ?>
                                        </small>
                                    </td>
                                    <td>
                                        <strong><?= htmlspecialchars($epi['tipo_epi_nome'] ?? $epi['descricao']) ?></strong>
                                        <?php if ($epi['ca_numero']): ?>
                                        <br>
                                        <small class="text-muted">
                                            CA: <?= htmlspecialchars($epi['ca_numero']) ?>
                                        </small>
                                        <?php endif; ?>
                                        <?php if ($epi['tamanho']): ?>
                                        <br>
                                        <small class="text-muted">
                                            Tamanho: <?= htmlspecialchars($epi['tamanho']) ?>
                                        </small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?= date('d/m/Y', strtotime($epi['data_entrega'])) ?>
                                    </td>
                                    <td>
                                        <?php 
                                        if ($epi['validade_meses']) {
                                            $validade = date('d/m/Y', strtotime("+{$epi['validade_meses']} months", strtotime($epi['data_entrega'])));
                                            $vencido = strtotime($validade) < time();
                                            ?>
                                            <span class="<?= $vencido ? 'text-danger' : '' ?>">
                                                <?= $validade ?>
                                                <?php if ($vencido): ?>
                                                <br>
                                                <small><i class="fas fa-exclamation-triangle"></i> Vencido</small>
                                                <?php endif; ?>
                                            </span>
                                        <?php } else { ?>
                                            <span class="text-muted">-</span>
                                        <?php } ?>
                                    </td>
                                    <td>
                                        <?php if ($epi['data_devolucao']): ?>
                                            <?= date('d/m/Y', strtotime($epi['data_devolucao'])) ?>
                                            <?php if ($epi['motivo_devolucao']): ?>
                                            <br>
                                            <small class="text-muted">
                                                <?= htmlspecialchars($epi['motivo_devolucao']) ?>
                                            </small>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($epi['data_devolucao']): ?>
                                            <span class="badge badge-secondary">Devolvido</span>
                                        <?php else: ?>
                                            <?php
                                            $vencido = false;
                                            if ($epi['validade_meses']) {
                                                $validade = date('Y-m-d', strtotime("+{$epi['validade_meses']} months", strtotime($epi['data_entrega'])));
                                                $vencido = strtotime($validade) < time();
                                            }
                                            ?>
                                            <?php if ($vencido): ?>
                                                <span class="badge badge-danger">Vencido</span>
                                            <?php else: ?>
                                                <span class="badge badge-success">Em Uso</span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <?php if (!$epi['data_devolucao']): ?>
                                            <button type="button" class="btn btn-warning" 
                                                    onclick="registrarDevolucao(<?= $epi['id'] ?>)" 
                                                    title="Registrar Devolução">
                                                <i class="fas fa-undo"></i>
                                            </button>
                                            <button type="button" class="btn btn-info" 
                                                    onclick="renovarEPI(<?= $epi['id'] ?>)" 
                                                    title="Renovar">
                                                <i class="fas fa-sync"></i>
                                            </button>
                                            <?php endif; ?>
                                            <button type="button" class="btn btn-primary" 
                                                    onclick="imprimirTermoEntrega(<?= $epi['id'] ?>)" 
                                                    title="Termo de Entrega">
                                                <i class="fas fa-print"></i>
                                            </button>
                                            <button type="button" class="btn btn-danger" 
                                                    onclick="excluirRegistro(<?= $epi['id'] ?>)" 
                                                    title="Excluir">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <?php if (($pagination['total'] ?? 0) > 1): ?>
            <div class="card-footer">
                <nav aria-label="Paginação">
                    <ul class="pagination pagination-sm m-0 float-right">
                        <?php if ($pagination['current'] > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?= $pagination['current'] - 1 ?>&<?= http_build_query(array_diff_key($filters ?? [], ['page' => ''])) ?>">
                                &laquo;
                            </a>
                        </li>
                        <?php endif; ?>
                        
                        <?php for ($i = 1; $i <= $pagination['total']; $i++): ?>
                            <?php if ($i == 1 || $i == $pagination['total'] || ($i >= $pagination['current'] - 2 && $i <= $pagination['current'] + 2)): ?>
                            <li class="page-item <?= $i == $pagination['current'] ? 'active' : '' ?>">
                                <a class="page-link" href="?page=<?= $i ?>&<?= http_build_query(array_diff_key($filters ?? [], ['page' => ''])) ?>">
                                    <?= $i ?>
                                </a>
                            </li>
                            <?php elseif ($i == $pagination['current'] - 3 || $i == $pagination['current'] + 3): ?>
                            <li class="page-item disabled"><span class="page-link">...</span></li>
                            <?php endif; ?>
                        <?php endfor; ?>
                        
                        <?php if ($pagination['current'] < $pagination['total']): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?= $pagination['current'] + 1 ?>&<?= http_build_query(array_diff_key($filters ?? [], ['page' => ''])) ?>">
                                &raquo;
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<script>
function novaEntrega() {
    window.location.href = '<?= url('epis/nova-entrega') ?>';
}

function registrarDevolucao(id) {
    Swal.fire({
        title: 'Registrar Devolução',
        html: `
            <div class="form-group text-left">
                <label>Data da Devolução</label>
                <input type="date" id="data_devolucao" class="form-control" value="${new Date().toISOString().split('T')[0]}">
            </div>
            <div class="form-group text-left">
                <label>Motivo</label>
                <select id="motivo" class="form-control">
                    <option value="Troca">Troca</option>
                    <option value="Desgaste">Desgaste</option>
                    <option value="Perda">Perda</option>
                    <option value="Demissão">Demissão</option>
                    <option value="Outro">Outro</option>
                </select>
            </div>
            <div class="form-group text-left">
                <label>Observações</label>
                <textarea id="observacoes" class="form-control" rows="3"></textarea>
            </div>
        `,
        showCancelButton: true,
        confirmButtonColor: '#28a745',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Registrar',
        cancelButtonText: 'Cancelar',
        preConfirm: () => {
            return {
                data_devolucao: document.getElementById('data_devolucao').value,
                motivo: document.getElementById('motivo').value,
                observacoes: document.getElementById('observacoes').value
            }
        }
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = '<?= url('epis/devolver/') ?>' + id + 
                '?data=' + result.value.data_devolucao + 
                '&motivo=' + result.value.motivo +
                '&obs=' + encodeURIComponent(result.value.observacoes);
        }
    });
}

function renovarEPI(id) {
    Swal.fire({
        title: 'Renovar EPI',
        text: 'Deseja renovar este EPI? Será criado um novo registro de entrega.',
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#28a745',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Sim, renovar!',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = '<?= url('epis/renovar/') ?>' + id;
        }
    });
}

function imprimirTermoEntrega(id) {
    window.open('<?= url('epis/termo-entrega/') ?>' + id, '_blank');
}

function excluirRegistro(id) {
    Swal.fire({
        title: 'Confirmar Exclusão',
        text: 'Tem certeza que deseja excluir este registro?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Sim, excluir!',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = '<?= url('epis/excluir/') ?>' + id;
        }
    });
}
</script>
