<!-- Content Header -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>
                    <i class="fas fa-truck"></i> Fornecedores
                    <small>Gerenciamento de fornecedores</small>
                </h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?= url() ?>">Início</a></li>
                    <li class="breadcrumb-item active">Fornecedores</li>
                </ol>
            </div>
        </div>
    </div>
</section>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        
        <!-- Estatísticas -->
        <div class="row">
            <div class="col-lg-3 col-6">
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3><?= $estatisticas['total'] ?? 0 ?></h3>
                        <p>Total de Fornecedores</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-truck"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-success">
                    <div class="inner">
                        <h3><?= $estatisticas['ativos'] ?? 0 ?></h3>
                        <p>Ativos</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-warning">
                    <div class="inner">
                        <h3>R$ <?= number_format($estatisticas['total_compras_mes'] ?? 0, 2, ',', '.') ?></h3>
                        <p>Compras do Mês</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-6">
                <div class="small-box bg-danger">
                    <div class="inner">
                        <h3>R$ <?= number_format($estatisticas['total_pendente'] ?? 0, 2, ',', '.') ?></h3>
                        <p>Pagamentos Pendentes</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Filtros -->
        <div class="card card-outline card-primary collapsed-card">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-filter"></i> Filtros
                </h3>
                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                        <i class="fas fa-plus"></i>
                    </button>
                </div>
            </div>
            <div class="card-body">
                <form method="get" action="<?= url('fornecedores') ?>">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Buscar</label>
                                <input type="text" name="search" class="form-control" 
                                       placeholder="Nome, CNPJ, telefone..." 
                                       value="<?= htmlspecialchars($filters['search'] ?? '') ?>">
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>Categoria</label>
                                <select name="categoria" class="form-control">
                                    <option value="">Todas</option>
                                    <option value="material_construcao" <?= ($filters['categoria'] ?? '') == 'material_construcao' ? 'selected' : '' ?>>Material de Construção</option>
                                    <option value="servicos" <?= ($filters['categoria'] ?? '') == 'servicos' ? 'selected' : '' ?>>Serviços</option>
                                    <option value="equipamentos" <?= ($filters['categoria'] ?? '') == 'equipamentos' ? 'selected' : '' ?>>Equipamentos</option>
                                    <option value="mao_obra" <?= ($filters['categoria'] ?? '') == 'mao_obra' ? 'selected' : '' ?>>Mão de Obra</option>
                                    <option value="outros" <?= ($filters['categoria'] ?? '') == 'outros' ? 'selected' : '' ?>>Outros</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>Status</label>
                                <select name="status" class="form-control">
                                    <option value="">Todos</option>
                                    <option value="1" <?= ($filters['status'] ?? '') === '1' ? 'selected' : '' ?>>Ativo</option>
                                    <option value="0" <?= ($filters['status'] ?? '') === '0' ? 'selected' : '' ?>>Inativo</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>Cidade</label>
                                <input type="text" name="cidade" class="form-control" 
                                       placeholder="Cidade"
                                       value="<?= htmlspecialchars($filters['cidade'] ?? '') ?>">
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label>UF</label>
                                <input type="text" name="uf" class="form-control" 
                                       placeholder="UF" maxlength="2"
                                       value="<?= htmlspecialchars($filters['uf'] ?? '') ?>">
                            </div>
                        </div>
                        <div class="col-md-1">
                            <div class="form-group">
                                <label>&nbsp;</label>
                                <div>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-search"></i>
                                    </button>
                                    <a href="<?= url('fornecedores') ?>" class="btn btn-default">
                                        <i class="fas fa-times"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Lista de Fornecedores -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    Lista de Fornecedores
                    <span class="badge badge-primary"><?= $pagination['total_records'] ?? 0 ?> registros</span>
                </h3>
                <div class="card-tools">
                    <a href="<?= url('fornecedores/novo') ?>" class="btn btn-primary btn-sm">
                        <i class="fas fa-plus"></i> Novo Fornecedor
                    </a>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th width="50">ID</th>
                                <th>Fornecedor</th>
                                <th>Contato</th>
                                <th>Categoria</th>
                                <th>Localização</th>
                                <th width="100">Status</th>
                                <th width="150">Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($fornecedores)): ?>
                            <tr>
                                <td colspan="7" class="text-center py-4">
                                    <i class="fas fa-truck fa-3x text-muted mb-3"></i>
                                    <p class="text-muted">Nenhum fornecedor encontrado</p>
                                </td>
                            </tr>
                            <?php else: ?>
                                <?php foreach ($fornecedores as $fornecedor): ?>
                                <tr>
                                    <td><?= $fornecedor['id'] ?></td>
                                    <td>
                                        <strong><?= htmlspecialchars($fornecedor['nome']) ?></strong>
                                        <?php if ($fornecedor['nome_fantasia']): ?>
                                        <br>
                                        <small class="text-muted">
                                            <?= htmlspecialchars($fornecedor['nome_fantasia']) ?>
                                        </small>
                                        <?php endif; ?>
                                        <?php if ($fornecedor['cnpj']): ?>
                                        <br>
                                        <small class="text-muted">
                                            CNPJ: <?= htmlspecialchars($fornecedor['cnpj']) ?>
                                        </small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($fornecedor['email']): ?>
                                            <a href="mailto:<?= htmlspecialchars($fornecedor['email']) ?>">
                                                <i class="fas fa-envelope"></i> <?= htmlspecialchars($fornecedor['email']) ?>
                                            </a>
                                        <?php endif; ?>
                                        <?php if ($fornecedor['telefone']): ?>
                                            <br>
                                            <i class="fas fa-phone"></i> <?= htmlspecialchars($fornecedor['telefone']) ?>
                                        <?php endif; ?>
                                        <?php if ($fornecedor['contato_nome']): ?>
                                            <br>
                                            <small class="text-muted">
                                                <i class="fas fa-user"></i> <?= htmlspecialchars($fornecedor['contato_nome']) ?>
                                            </small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php
                                        $categoriaLabels = [
                                            'material_construcao' => 'Material de Construção',
                                            'servicos' => 'Serviços',
                                            'equipamentos' => 'Equipamentos',
                                            'mao_obra' => 'Mão de Obra',
                                            'outros' => 'Outros'
                                        ];
                                        $categoriaClass = [
                                            'material_construcao' => 'badge-primary',
                                            'servicos' => 'badge-info',
                                            'equipamentos' => 'badge-warning',
                                            'mao_obra' => 'badge-success',
                                            'outros' => 'badge-secondary'
                                        ];
                                        ?>
                                        <span class="badge <?= $categoriaClass[$fornecedor['categoria']] ?? 'badge-secondary' ?>">
                                            <?= $categoriaLabels[$fornecedor['categoria']] ?? 'N/D' ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($fornecedor['endereco']): ?>
                                            <i class="fas fa-map-marker-alt"></i> 
                                            <?= htmlspecialchars($fornecedor['endereco']) ?>
                                            <?php if ($fornecedor['numero']): ?>
                                                , <?= htmlspecialchars($fornecedor['numero']) ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <?php if ($fornecedor['cidade']): ?>
                                            <br>
                                            <small class="text-muted">
                                                <?= htmlspecialchars($fornecedor['cidade']) ?>/<?= htmlspecialchars($fornecedor['uf']) ?>
                                            </small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($fornecedor['ativo']): ?>
                                            <span class="badge badge-success">Ativo</span>
                                        <?php else: ?>
                                            <span class="badge badge-danger">Inativo</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="<?= url('fornecedores/visualizar/' . $fornecedor['id']) ?>" 
                                               class="btn btn-info" title="Visualizar">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="<?= url('fornecedores/editar/' . $fornecedor['id']) ?>" 
                                               class="btn btn-warning" title="Editar">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="<?= url('fornecedores/historico/' . $fornecedor['id']) ?>" 
                                               class="btn btn-secondary" title="Histórico de Compras">
                                                <i class="fas fa-history"></i>
                                            </a>
                                            <button type="button" class="btn btn-danger" 
                                                    onclick="confirmarExclusao(<?= $fornecedor['id'] ?>)" 
                                                    title="Excluir">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <?php if (($pagination['total'] ?? 0) > 1): ?>
            <div class="card-footer">
                <nav aria-label="Paginação">
                    <ul class="pagination pagination-sm m-0 float-right">
                        <?php if ($pagination['current'] > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?= $pagination['current'] - 1 ?>&<?= http_build_query(array_diff_key($filters ?? [], ['page' => ''])) ?>">
                                &laquo;
                            </a>
                        </li>
                        <?php endif; ?>
                        
                        <?php for ($i = 1; $i <= $pagination['total']; $i++): ?>
                            <?php if ($i == 1 || $i == $pagination['total'] || ($i >= $pagination['current'] - 2 && $i <= $pagination['current'] + 2)): ?>
                            <li class="page-item <?= $i == $pagination['current'] ? 'active' : '' ?>">
                                <a class="page-link" href="?page=<?= $i ?>&<?= http_build_query(array_diff_key($filters ?? [], ['page' => ''])) ?>">
                                    <?= $i ?>
                                </a>
                            </li>
                            <?php elseif ($i == $pagination['current'] - 3 || $i == $pagination['current'] + 3): ?>
                            <li class="page-item disabled"><span class="page-link">...</span></li>
                            <?php endif; ?>
                        <?php endfor; ?>
                        
                        <?php if ($pagination['current'] < $pagination['total']): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?= $pagination['current'] + 1 ?>&<?= http_build_query(array_diff_key($filters ?? [], ['page' => ''])) ?>">
                                &raquo;
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<script>
function confirmarExclusao(id) {
    Swal.fire({
        title: 'Confirmar Exclusão',
        text: 'Tem certeza que deseja excluir este fornecedor?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Sim, excluir!',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = '<?= url('fornecedores/excluir/') ?>' + id;
        }
    });
}
</script>
