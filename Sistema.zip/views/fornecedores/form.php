<!-- Content Header -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>
                    <i class="fas fa-truck"></i> 
                    <?= isset($fornecedor) ? 'Editar' : 'Novo' ?> Fornecedor
                </h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?= url() ?>">Início</a></li>
                    <li class="breadcrumb-item"><a href="<?= url('fornecedores') ?>">Fornecedores</a></li>
                    <li class="breadcrumb-item active"><?= isset($fornecedor) ? 'Editar' : 'Novo' ?></li>
                </ol>
            </div>
        </div>
    </div>
</section>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <form method="post" action="<?= url('fornecedores/' . (isset($fornecedor) ? 'atualizar/' . $fornecedor['id'] : 'salvar')) ?>" 
              class="needs-validation" novalidate>
            
            <div class="row">
                <!-- Dados Principais -->
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-info-circle"></i> Dados do Fornecedor
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Razão Social <span class="text-danger">*</span></label>
                                        <input type="text" name="nome" class="form-control" 
                                               value="<?= htmlspecialchars($fornecedor['nome'] ?? '') ?>" 
                                               required>
                                        <div class="invalid-feedback">
                                            Por favor, informe a razão social.
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Nome Fantasia</label>
                                        <input type="text" name="nome_fantasia" class="form-control" 
                                               value="<?= htmlspecialchars($fornecedor['nome_fantasia'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>CNPJ <span class="text-danger">*</span></label>
                                        <input type="text" name="cnpj" class="form-control cnpj-mask" 
                                               value="<?= htmlspecialchars($fornecedor['cnpj'] ?? '') ?>" 
                                               required>
                                        <div class="invalid-feedback">
                                            Por favor, informe um CNPJ válido.
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Inscrição Estadual</label>
                                        <input type="text" name="inscricao_estadual" class="form-control" 
                                               value="<?= htmlspecialchars($fornecedor['inscricao_estadual'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Inscrição Municipal</label>
                                        <input type="text" name="inscricao_municipal" class="form-control" 
                                               value="<?= htmlspecialchars($fornecedor['inscricao_municipal'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Descrição/Observações</label>
                                        <textarea name="descricao" class="form-control" rows="3"><?= htmlspecialchars($fornecedor['descricao'] ?? '') ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Endereço -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-map-marker-alt"></i> Endereço
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>CEP</label>
                                        <input type="text" name="cep" class="form-control cep-mask" 
                                               value="<?= htmlspecialchars($fornecedor['cep'] ?? '') ?>"
                                               onblur="buscarCEP(this.value)">
                                    </div>
                                </div>
                                
                                <div class="col-md-7">
                                    <div class="form-group">
                                        <label>Endereço</label>
                                        <input type="text" name="endereco" id="endereco" class="form-control" 
                                               value="<?= htmlspecialchars($fornecedor['endereco'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Número</label>
                                        <input type="text" name="numero" class="form-control" 
                                               value="<?= htmlspecialchars($fornecedor['numero'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Complemento</label>
                                        <input type="text" name="complemento" class="form-control" 
                                               value="<?= htmlspecialchars($fornecedor['complemento'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Bairro</label>
                                        <input type="text" name="bairro" id="bairro" class="form-control" 
                                               value="<?= htmlspecialchars($fornecedor['bairro'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Cidade</label>
                                        <input type="text" name="cidade" id="cidade" class="form-control" 
                                               value="<?= htmlspecialchars($fornecedor['cidade'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-1">
                                    <div class="form-group">
                                        <label>UF</label>
                                        <input type="text" name="uf" id="uf" class="form-control" 
                                               maxlength="2" style="text-transform: uppercase"
                                               value="<?= htmlspecialchars($fornecedor['uf'] ?? '') ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Contato -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-address-book"></i> Informações de Contato
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>E-mail Principal</label>
                                        <input type="email" name="email" class="form-control" 
                                               value="<?= htmlspecialchars($fornecedor['email'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Telefone</label>
                                        <input type="text" name="telefone" class="form-control phone-mask" 
                                               value="<?= htmlspecialchars($fornecedor['telefone'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>WhatsApp</label>
                                        <input type="text" name="whatsapp" class="form-control phone-mask" 
                                               value="<?= htmlspecialchars($fornecedor['whatsapp'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-12">
                                    <h5>Pessoa de Contato</h5>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Nome do Contato</label>
                                        <input type="text" name="contato_nome" class="form-control" 
                                               value="<?= htmlspecialchars($fornecedor['contato_nome'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Cargo</label>
                                        <input type="text" name="contato_cargo" class="form-control" 
                                               value="<?= htmlspecialchars($fornecedor['contato_cargo'] ?? '') ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Telefone do Contato</label>
                                        <input type="text" name="contato_telefone" class="form-control phone-mask" 
                                               value="<?= htmlspecialchars($fornecedor['contato_telefone'] ?? '') ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Sidebar -->
                <div class="col-md-4">
                    <!-- Configurações -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-cog"></i> Configurações
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <label>Categoria <span class="text-danger">*</span></label>
                                <select name="categoria" class="form-control" required>
                                    <option value="">Selecione...</option>
                                    <option value="material_construcao" <?= ($fornecedor['categoria'] ?? '') == 'material_construcao' ? 'selected' : '' ?>>Material de Construção</option>
                                    <option value="servicos" <?= ($fornecedor['categoria'] ?? '') == 'servicos' ? 'selected' : '' ?>>Serviços</option>
                                    <option value="equipamentos" <?= ($fornecedor['categoria'] ?? '') == 'equipamentos' ? 'selected' : '' ?>>Equipamentos</option>
                                    <option value="mao_obra" <?= ($fornecedor['categoria'] ?? '') == 'mao_obra' ? 'selected' : '' ?>>Mão de Obra</option>
                                    <option value="outros" <?= ($fornecedor['categoria'] ?? '') == 'outros' ? 'selected' : '' ?>>Outros</option>
                                </select>
                                <div class="invalid-feedback">
                                    Por favor, selecione uma categoria.
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label>Status</label>
                                <div class="custom-control custom-switch">
                                    <input type="checkbox" class="custom-control-input" id="ativo" 
                                           name="ativo" value="1" 
                                           <?= ($fornecedor['ativo'] ?? 1) ? 'checked' : '' ?>>
                                    <label class="custom-control-label" for="ativo">
                                        Fornecedor Ativo
                                    </label>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label>Avaliação</label>
                                <select name="avaliacao" class="form-control">
                                    <option value="">Não avaliado</option>
                                    <option value="5" <?= ($fornecedor['avaliacao'] ?? '') == '5' ? 'selected' : '' ?>>⭐⭐⭐⭐⭐ Excelente</option>
                                    <option value="4" <?= ($fornecedor['avaliacao'] ?? '') == '4' ? 'selected' : '' ?>>⭐⭐⭐⭐ Muito Bom</option>
                                    <option value="3" <?= ($fornecedor['avaliacao'] ?? '') == '3' ? 'selected' : '' ?>>⭐⭐⭐ Bom</option>
                                    <option value="2" <?= ($fornecedor['avaliacao'] ?? '') == '2' ? 'selected' : '' ?>>⭐⭐ Regular</option>
                                    <option value="1" <?= ($fornecedor['avaliacao'] ?? '') == '1' ? 'selected' : '' ?>>⭐ Ruim</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Dados Bancários -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-university"></i> Dados Bancários
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <label>Banco</label>
                                <input type="text" name="banco" class="form-control" 
                                       value="<?= htmlspecialchars($fornecedor['banco'] ?? '') ?>">
                            </div>
                            
                            <div class="form-group">
                                <label>Agência</label>
                                <input type="text" name="agencia" class="form-control" 
                                       value="<?= htmlspecialchars($fornecedor['agencia'] ?? '') ?>">
                            </div>
                            
                            <div class="form-group">
                                <label>Conta</label>
                                <input type="text" name="conta" class="form-control" 
                                       value="<?= htmlspecialchars($fornecedor['conta'] ?? '') ?>">
                            </div>
                            
                            <div class="form-group">
                                <label>PIX</label>
                                <input type="text" name="pix" class="form-control" 
                                       value="<?= htmlspecialchars($fornecedor['pix'] ?? '') ?>"
                                       placeholder="CPF, CNPJ, E-mail ou Telefone">
                            </div>
                        </div>
                    </div>
                    
                    <!-- Condições Comerciais -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-handshake"></i> Condições Comerciais
                            </h3>
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <label>Prazo de Pagamento (dias)</label>
                                <input type="number" name="prazo_pagamento" class="form-control" 
                                       value="<?= $fornecedor['prazo_pagamento'] ?? 30 ?>"
                                       min="0">
                            </div>
                            
                            <div class="form-group">
                                <label>Limite de Crédito</label>
                                <input type="text" name="limite_credito" class="form-control money-input" 
                                       value="<?= $fornecedor['limite_credito'] ?? '' ?>"
                                       placeholder="R$ 0,00">
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-save"></i> Salvar
                            </button>
                            <a href="<?= url('fornecedores') ?>" class="btn btn-default btn-block">
                                <i class="fas fa-arrow-left"></i> Voltar
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</section>

<script>
// Busca CEP
function buscarCEP(cep) {
    cep = cep.replace(/\D/g, '');
    
    if (cep.length === 8) {
        fetch(`https://viacep.com.br/ws/${cep}/json/`)
            .then(response => response.json())
            .then(data => {
                if (!data.erro) {
                    document.getElementById('endereco').value = data.logradouro;
                    document.getElementById('bairro').value = data.bairro;
                    document.getElementById('cidade').value = data.localidade;
                    document.getElementById('uf').value = data.uf;
                }
            })
            .catch(error => console.error('Erro ao buscar CEP:', error));
    }
}

// Validação de CNPJ
document.querySelector('input[name="cnpj"]').addEventListener('blur', function() {
    const cnpj = this.value.replace(/\D/g, '');
    if (cnpj.length === 14) {
        // Aqui você pode adicionar validação de CNPJ
        // e buscar dados da Receita Federal se tiver integração
    }
});
</script>
