<?php require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-truck"></i> Relatório de Fornecedores
                    </h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" onclick="window.print()">
                            <i class="fas fa-print"></i> Imprimir
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <!-- Filtros de Período -->
                    <form method="GET" action="/sistema/relatorios/fornecedores" class="mb-4">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Data Início</label>
                                    <input type="date" name="data_inicio" class="form-control" value="<?= $data_inicio ?>">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Data Fim</label>
                                    <input type="date" name="data_fim" class="form-control" value="<?= $data_fim ?>">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>&nbsp;</label>
                                    <button type="submit" class="btn btn-primary btn-block">
                                        <i class="fas fa-search"></i> Filtrar
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>

                    <!-- Estatísticas Gerais -->
                    <div class="row">
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-info">
                                <div class="inner">
                                    <h3><?= $estatisticas['total_fornecedores'] ?? 0 ?></h3>
                                    <p>Total de Fornecedores</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-truck"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-success">
                                <div class="inner">
                                    <h3><?= $estatisticas['fornecedores_ativos'] ?? 0 ?></h3>
                                    <p>Fornecedores Ativos</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-warning">
                                <div class="inner">
                                    <h3><?= $estatisticas['total_compras'] ?? 0 ?></h3>
                                    <p>Total de Compras</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-shopping-cart"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-danger">
                                <div class="inner">
                                    <h3>R$ <?= number_format($estatisticas['valor_total_compras'] ?? 0, 2, ',', '.') ?></h3>
                                    <p>Valor Total</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-dollar-sign"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Top Fornecedores -->
                    <div class="row mt-4">
                        <div class="col-md-8">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Top 10 Fornecedores por Volume de Compras</h4>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Fornecedor</th>
                                                    <th>CNPJ</th>
                                                    <th>Qtd Compras</th>
                                                    <th>Valor Total</th>
                                                    <th>Valor Médio</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                $posicao = 1;
                                                foreach ($top_fornecedores as $fornecedor): 
                                                ?>
                                                <tr>
                                                    <td><?= $posicao++ ?></td>
                                                    <td><?= htmlspecialchars($fornecedor['nome']) ?></td>
                                                    <td><?= htmlspecialchars($fornecedor['cnpj']) ?></td>
                                                    <td><?= $fornecedor['total_compras'] ?></td>
                                                    <td>R$ <?= number_format($fornecedor['valor_total'] ?? 0, 2, ',', '.') ?></td>
                                                    <td>R$ <?= number_format($fornecedor['valor_medio'] ?? 0, 2, ',', '.') ?></td>
                                                </tr>
                                                <?php endforeach; ?>
                                                <?php if (empty($top_fornecedores)): ?>
                                                <tr>
                                                    <td colspan="6" class="text-center">Nenhum fornecedor encontrado no período</td>
                                                </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Compras por Categoria -->
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Por Categoria</h4>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Categoria</th>
                                                    <th>Fornec.</th>
                                                    <th>Compras</th>
                                                    <th>Valor</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($categorias as $cat): ?>
                                                <tr>
                                                    <td><?= htmlspecialchars($cat['categoria'] ?? 'Sem categoria') ?></td>
                                                    <td><?= $cat['total_fornecedores'] ?></td>
                                                    <td><?= $cat['total_compras'] ?></td>
                                                    <td>R$ <?= number_format($cat['valor_total'] ?? 0, 2, ',', '.') ?></td>
                                                </tr>
                                                <?php endforeach; ?>
                                                <?php if (empty($categorias)): ?>
                                                <tr>
                                                    <td colspan="4" class="text-center">Sem dados</td>
                                                </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Gráfico de Evolução (placeholder) -->
                    <div class="row mt-4">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Evolução de Compras no Período</h4>
                                </div>
                                <div class="card-body">
                                    <canvas id="graficoCompras" height="80"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Gráfico placeholder - pode ser implementado com dados reais
var ctx = document.getElementById('graficoCompras').getContext('2d');
var chart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'],
        datasets: [{
            label: 'Valor de Compras',
            data: [12000, 19000, 15000, 25000, 22000, 30000],
            borderColor: 'rgb(75, 192, 192)',
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            tension: 0.1
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return 'R$ ' + value.toLocaleString('pt-BR');
                    }
                }
            }
        }
    }
});
</script>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
