<?php require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-users"></i> Relatório de Funcionários
                    </h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" onclick="window.print()">
                            <i class="fas fa-print"></i> Imprimir
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <!-- Filtros de Período -->
                    <form method="GET" action="/sistema/relatorios/funcionarios" class="mb-4">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Mês</label>
                                    <select name="mes" class="form-control">
                                        <?php for($m = 1; $m <= 12; $m++): ?>
                                            <option value="<?= str_pad($m, 2, '0', STR_PAD_LEFT) ?>" <?= $mes == str_pad($m, 2, '0', STR_PAD_LEFT) ? 'selected' : '' ?>>
                                                <?= strftime('%B', mktime(0, 0, 0, $m, 1)) ?>
                                            </option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Ano</label>
                                    <select name="ano" class="form-control">
                                        <?php for($a = date('Y') - 2; $a <= date('Y'); $a++): ?>
                                            <option value="<?= $a ?>" <?= $ano == $a ? 'selected' : '' ?>><?= $a ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>&nbsp;</label>
                                    <button type="submit" class="btn btn-primary btn-block">
                                        <i class="fas fa-search"></i> Filtrar
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>

                    <!-- Estatísticas Gerais -->
                    <div class="row">
                        <div class="col-lg-2 col-6">
                            <div class="small-box bg-info">
                                <div class="inner">
                                    <h3><?= $estatisticas['total_funcionarios'] ?? 0 ?></h3>
                                    <p>Total</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-users"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-6">
                            <div class="small-box bg-success">
                                <div class="inner">
                                    <h3><?= $estatisticas['ativos'] ?? 0 ?></h3>
                                    <p>Ativos</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-user-check"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-6">
                            <div class="small-box bg-warning">
                                <div class="inner">
                                    <h3><?= $estatisticas['inativos'] ?? 0 ?></h3>
                                    <p>Inativos</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-user-times"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-primary">
                                <div class="inner">
                                    <h3>R$ <?= number_format($estatisticas['salario_medio'] ?? 0, 2, ',', '.') ?></h3>
                                    <p>Salário Médio</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-chart-line"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-danger">
                                <div class="inner">
                                    <h3>R$ <?= number_format($estatisticas['folha_pagamento'] ?? 0, 2, ',', '.') ?></h3>
                                    <p>Folha de Pagamento</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-money-bill-wave"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-4">
                        <!-- Funcionários por Cargo -->
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Funcionários por Cargo</h4>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped">
                                            <thead>
                                                <tr>
                                                    <th>Cargo</th>
                                                    <th>Quantidade</th>
                                                    <th>Salário Médio</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($funcionarios_cargo as $cargo): ?>
                                                <tr>
                                                    <td><?= htmlspecialchars($cargo['cargo']) ?></td>
                                                    <td><?= $cargo['total'] ?></td>
                                                    <td>R$ <?= number_format($cargo['salario_medio'] ?? 0, 2, ',', '.') ?></td>
                                                </tr>
                                                <?php endforeach; ?>
                                                <?php if (empty($funcionarios_cargo)): ?>
                                                <tr>
                                                    <td colspan="3" class="text-center">Nenhum funcionário encontrado</td>
                                                </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Funcionários por Empreendimento -->
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Funcionários por Empreendimento</h4>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped">
                                            <thead>
                                                <tr>
                                                    <th>Empreendimento</th>
                                                    <th>Total de Funcionários</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($funcionarios_empreendimento as $emp): ?>
                                                <tr>
                                                    <td><?= htmlspecialchars($emp['empreendimento']) ?></td>
                                                    <td><?= $emp['total_funcionarios'] ?></td>
                                                </tr>
                                                <?php endforeach; ?>
                                                <?php if (empty($funcionarios_empreendimento)): ?>
                                                <tr>
                                                    <td colspan="2" class="text-center">Nenhum dado encontrado</td>
                                                </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Relatório de Faltas -->
                    <div class="row mt-4">
                        <div class="col-md-8">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Faltas no Período (<?= date('d/m/Y', strtotime($data_inicio)) ?> a <?= date('d/m/Y', strtotime($data_fim)) ?>)</h4>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped">
                                            <thead>
                                                <tr>
                                                    <th>Funcionário</th>
                                                    <th>Total de Faltas</th>
                                                    <th>Justificadas</th>
                                                    <th>Injustificadas</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($faltas as $falta): ?>
                                                <tr>
                                                    <td><?= htmlspecialchars($falta['nome']) ?></td>
                                                    <td>
                                                        <span class="badge badge-<?= $falta['total_faltas'] > 3 ? 'danger' : 'warning' ?>">
                                                            <?= $falta['total_faltas'] ?>
                                                        </span>
                                                    </td>
                                                    <td><?= $falta['faltas_justificadas'] ?></td>
                                                    <td>
                                                        <span class="text-danger"><?= $falta['faltas_injustificadas'] ?></span>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                                <?php if (empty($faltas)): ?>
                                                <tr>
                                                    <td colspan="4" class="text-center">Nenhuma falta registrada no período</td>
                                                </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- EPIs -->
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">EPIs no Período</h4>
                                </div>
                                <div class="card-body">
                                    <div class="info-box bg-info">
                                        <span class="info-box-icon"><i class="fas fa-hard-hat"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Total de Entregas</span>
                                            <span class="info-box-number"><?= $epis['total_entregas'] ?? 0 ?></span>
                                        </div>
                                    </div>
                                    <div class="info-box bg-success">
                                        <span class="info-box-icon"><i class="fas fa-user-shield"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Funcionários Atendidos</span>
                                            <span class="info-box-number"><?= $epis['funcionarios_atendidos'] ?? 0 ?></span>
                                        </div>
                                    </div>
                                    <div class="info-box bg-warning">
                                        <span class="info-box-icon"><i class="fas fa-vest"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">EPIs em Uso</span>
                                            <span class="info-box-number"><?= $epis['epis_em_uso'] ?? 0 ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Gráfico de Distribuição -->
                    <div class="row mt-4">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Distribuição de Funcionários</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <canvas id="graficoCargos" height="200"></canvas>
                                        </div>
                                        <div class="col-md-6">
                                            <canvas id="graficoStatus" height="200"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Gráfico de Cargos
var ctxCargos = document.getElementById('graficoCargos').getContext('2d');
var chartCargos = new Chart(ctxCargos, {
    type: 'doughnut',
    data: {
        labels: [<?php foreach($funcionarios_cargo as $c) echo "'" . addslashes($c['cargo']) . "',"; ?>],
        datasets: [{
            data: [<?php foreach($funcionarios_cargo as $c) echo $c['total'] . ","; ?>],
            backgroundColor: [
                'rgba(255, 99, 132, 0.8)',
                'rgba(54, 162, 235, 0.8)',
                'rgba(255, 206, 86, 0.8)',
                'rgba(75, 192, 192, 0.8)',
                'rgba(153, 102, 255, 0.8)'
            ]
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            title: {
                display: true,
                text: 'Distribuição por Cargo'
            }
        }
    }
});

// Gráfico de Status
var ctxStatus = document.getElementById('graficoStatus').getContext('2d');
var chartStatus = new Chart(ctxStatus, {
    type: 'pie',
    data: {
        labels: ['Ativos', 'Inativos'],
        datasets: [{
            data: [<?= $estatisticas['ativos'] ?? 0 ?>, <?= $estatisticas['inativos'] ?? 0 ?>],
            backgroundColor: [
                'rgba(75, 192, 192, 0.8)',
                'rgba(255, 99, 132, 0.8)'
            ]
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            title: {
                display: true,
                text: 'Status dos Funcionários'
            }
        }
    }
});
</script>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
