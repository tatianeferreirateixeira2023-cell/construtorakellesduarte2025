<?php require_once __DIR__ . '/../layouts/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-chart-line"></i> Relatório Personalizado
                    </h3>
                </div>
                <div class="card-body">
                    <!-- Filtros -->
                    <form method="GET" action="/sistema/relatorios/personalizado" class="mb-4">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Tipo de Relatório</label>
                                    <select name="tipo" class="form-control">
                                        <option value="geral" <?= ($filtros['tipo_relatorio'] ?? '') == 'geral' ? 'selected' : '' ?>>Geral</option>
                                        <option value="financeiro_detalhado" <?= ($filtros['tipo_relatorio'] ?? '') == 'financeiro_detalhado' ? 'selected' : '' ?>>Financeiro Detalhado</option>
                                        <option value="obras_detalhado" <?= ($filtros['tipo_relatorio'] ?? '') == 'obras_detalhado' ? 'selected' : '' ?>>Obras Detalhado</option>
                                        <option value="imoveis_detalhado" <?= ($filtros['tipo_relatorio'] ?? '') == 'imoveis_detalhado' ? 'selected' : '' ?>>Imóveis Detalhado</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Data Início</label>
                                    <input type="date" name="data_inicio" class="form-control" value="<?= $filtros['data_inicio'] ?? date('Y-m-01') ?>">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Data Fim</label>
                                    <input type="date" name="data_fim" class="form-control" value="<?= $filtros['data_fim'] ?? date('Y-m-t') ?>">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>&nbsp;</label>
                                    <button type="submit" class="btn btn-primary btn-block">
                                        <i class="fas fa-search"></i> Gerar Relatório
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>

                    <!-- Resultados -->
                    <?php if (!empty($dados)): ?>
                        <?php if ($filtros['tipo_relatorio'] == 'geral'): ?>
                            <!-- Relatório Geral -->
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="info-box">
                                        <span class="info-box-icon bg-success"><i class="fas fa-dollar-sign"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Resumo Financeiro</span>
                                            <span class="info-box-number">
                                                Receitas: R$ <?= number_format($dados['financeiro']['receitas'] ?? 0, 2, ',', '.') ?><br>
                                                Despesas: R$ <?= number_format($dados['financeiro']['despesas'] ?? 0, 2, ',', '.') ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="info-box">
                                        <span class="info-box-icon bg-info"><i class="fas fa-building"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Resumo Obras</span>
                                            <span class="info-box-number">
                                                Empreendimentos: <?= $dados['obras']['empreendimentos_ativos'] ?? 0 ?><br>
                                                Ocorrências: <?= $dados['obras']['total_ocorrencias'] ?? 0 ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="info-box">
                                        <span class="info-box-icon bg-warning"><i class="fas fa-home"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Resumo Imóveis</span>
                                            <span class="info-box-number">
                                                Total: <?= $dados['imoveis']['total'] ?? 0 ?><br>
                                                Disponíveis: <?= $dados['imoveis']['disponiveis'] ?? 0 ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="info-box">
                                        <span class="info-box-icon bg-primary"><i class="fas fa-users"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Resumo Funcionários</span>
                                            <span class="info-box-number">
                                                Total: <?= $dados['funcionarios']['total'] ?? 0 ?><br>
                                                Folha: R$ <?= number_format($dados['funcionarios']['folha_pagamento'] ?? 0, 2, ',', '.') ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            <!-- Relatórios Detalhados -->
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped">
                                    <?php if ($filtros['tipo_relatorio'] == 'financeiro_detalhado'): ?>
                                        <thead>
                                            <tr>
                                                <th>Tipo</th>
                                                <th>Descrição</th>
                                                <th>Data</th>
                                                <th>Valor</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($dados as $item): ?>
                                                <tr>
                                                    <td>
                                                        <span class="badge badge-<?= $item['tipo'] == 'Receitas' ? 'success' : 'danger' ?>">
                                                            <?= $item['tipo'] ?>
                                                        </span>
                                                    </td>
                                                    <td><?= htmlspecialchars($item['descricao']) ?></td>
                                                    <td><?= date('d/m/Y', strtotime($item['data'])) ?></td>
                                                    <td>R$ <?= number_format($item['valor'], 2, ',', '.') ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    <?php elseif ($filtros['tipo_relatorio'] == 'obras_detalhado'): ?>
                                        <thead>
                                            <tr>
                                                <th>Empreendimento</th>
                                                <th>Ocorrências</th>
                                                <th>Compras</th>
                                                <th>Valor Compras</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($dados as $item): ?>
                                                <tr>
                                                    <td><?= htmlspecialchars($item['empreendimento']) ?></td>
                                                    <td><?= $item['total_ocorrencias'] ?></td>
                                                    <td><?= $item['total_compras'] ?></td>
                                                    <td>R$ <?= number_format($item['valor_compras'] ?? 0, 2, ',', '.') ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    <?php elseif ($filtros['tipo_relatorio'] == 'imoveis_detalhado'): ?>
                                        <thead>
                                            <tr>
                                                <th>Código</th>
                                                <th>Endereço</th>
                                                <th>Status</th>
                                                <th>Manutenções</th>
                                                <th>Valor Manutenções</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($dados as $item): ?>
                                                <tr>
                                                    <td><?= htmlspecialchars($item['codigo']) ?></td>
                                                    <td><?= htmlspecialchars($item['endereco']) ?></td>
                                                    <td>
                                                        <span class="badge badge-<?= $item['status'] == 'disponivel' ? 'success' : ($item['status'] == 'alugado' ? 'info' : 'warning') ?>">
                                                            <?= ucfirst($item['status']) ?>
                                                        </span>
                                                    </td>
                                                    <td><?= $item['total_manutencoes'] ?? 0 ?></td>
                                                    <td>R$ <?= number_format($item['valor_manutencoes'] ?? 0, 2, ',', '.') ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    <?php endif; ?>
                                </table>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> Selecione os filtros e clique em "Gerar Relatório" para visualizar os dados.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
