<?php
$pageTitle = 'Relatório de Imóveis';
$currentPage = 'relatorios';
?>

<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <h1 class="h3 mb-3">
                <i class="fas fa-building"></i> Relatório de Imóveis
            </h1>
        </div>
    </div>

    <?php if (isset($flash)): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show" role="alert">
            <?= $flash['message'] ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <!-- Filtros -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Filtros do Relatório</h6>
        </div>
        <div class="card-body">
            <form method="GET" action="<?= BASE_PATH ?>/relatorios/imoveis">
                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="empreendimento">Empreendimento</label>
                            <select name="empreendimento" id="empreendimento" class="form-control">
                                <option value="">Todos</option>
                                <?php foreach ($empreendimentos ?? [] as $emp): ?>
                                    <option value="<?= $emp['id'] ?>" 
                                            <?= (isset($_GET['empreendimento']) && $_GET['empreendimento'] == $emp['id']) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($emp['nome']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="tipo">Tipo</label>
                            <select name="tipo" id="tipo" class="form-control">
                                <option value="">Todos</option>
                                <option value="casa" <?= (isset($_GET['tipo']) && $_GET['tipo'] == 'casa') ? 'selected' : '' ?>>Casa</option>
                                <option value="apartamento" <?= (isset($_GET['tipo']) && $_GET['tipo'] == 'apartamento') ? 'selected' : '' ?>>Apartamento</option>
                                <option value="terreno" <?= (isset($_GET['tipo']) && $_GET['tipo'] == 'terreno') ? 'selected' : '' ?>>Terreno</option>
                                <option value="comercial" <?= (isset($_GET['tipo']) && $_GET['tipo'] == 'comercial') ? 'selected' : '' ?>>Comercial</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select name="status" id="status" class="form-control">
                                <option value="">Todos</option>
                                <option value="disponivel" <?= (isset($_GET['status']) && $_GET['status'] == 'disponivel') ? 'selected' : '' ?>>Disponível</option>
                                <option value="vendido" <?= (isset($_GET['status']) && $_GET['status'] == 'vendido') ? 'selected' : '' ?>>Vendido</option>
                                <option value="alugado" <?= (isset($_GET['status']) && $_GET['status'] == 'alugado') ? 'selected' : '' ?>>Alugado</option>
                                <option value="reservado" <?= (isset($_GET['status']) && $_GET['status'] == 'reservado') ? 'selected' : '' ?>>Reservado</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>&nbsp;</label>
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-filter"></i> Filtrar
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Cards de Resumo -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Total de Imóveis
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?= number_format($estatisticas['total_imoveis'] ?? 0) ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-home fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Disponíveis
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?= number_format($estatisticas['disponiveis'] ?? 0) ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                Vendidos
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?= number_format($estatisticas['vendidos'] ?? 0) ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Valor Total
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                R$ <?= number_format($estatisticas['valor_total'] ?? 0, 2, ',', '.') ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-chart-line fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Gráficos -->
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Distribuição por Tipo</h6>
                </div>
                <div class="card-body">
                    <canvas id="chartTipo" height="150"></canvas>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Status dos Imóveis</h6>
                </div>
                <div class="card-body">
                    <canvas id="chartStatus" height="150"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Tabela Detalhada -->
    <div class="card shadow">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">Listagem Detalhada</h6>
            <div>
                <button onclick="exportarPDF()" class="btn btn-sm btn-danger">
                    <i class="fas fa-file-pdf"></i> PDF
                </button>
                <button onclick="exportarExcel()" class="btn btn-sm btn-success">
                    <i class="fas fa-file-excel"></i> Excel
                </button>
                <button onclick="window.print()" class="btn btn-sm btn-secondary">
                    <i class="fas fa-print"></i> Imprimir
                </button>
            </div>
        </div>
        <div class="card-body">
            <?php if (!empty($imoveis)): ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover" id="dataTable">
                        <thead>
                            <tr>
                                <th>Código</th>
                                <th>Empreendimento</th>
                                <th>Tipo</th>
                                <th>Endereço</th>
                                <th>Área (m²)</th>
                                <th>Quartos</th>
                                <th>Status</th>
                                <th>Valor</th>
                                <th>Cliente</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($imoveis as $imovel): ?>
                                <tr>
                                    <td><?= htmlspecialchars($imovel['codigo']) ?></td>
                                    <td><?= htmlspecialchars($imovel['empreendimento_nome'] ?? '-') ?></td>
                                    <td>
                                        <?php
                                        $tipos = [
                                            'casa' => '<span class="badge badge-primary">Casa</span>',
                                            'apartamento' => '<span class="badge badge-info">Apartamento</span>',
                                            'terreno' => '<span class="badge badge-warning">Terreno</span>',
                                            'comercial' => '<span class="badge badge-secondary">Comercial</span>'
                                        ];
                                        echo $tipos[$imovel['tipo']] ?? $imovel['tipo'];
                                        ?>
                                    </td>
                                    <td><?= htmlspecialchars($imovel['endereco']) ?></td>
                                    <td><?= number_format($imovel['area_total'] ?? 0, 2, ',', '.') ?></td>
                                    <td><?= $imovel['quartos'] ?? '-' ?></td>
                                    <td>
                                        <?php
                                        $status = [
                                            'disponivel' => '<span class="badge badge-success">Disponível</span>',
                                            'vendido' => '<span class="badge badge-info">Vendido</span>',
                                            'alugado' => '<span class="badge badge-warning">Alugado</span>',
                                            'reservado' => '<span class="badge badge-secondary">Reservado</span>'
                                        ];
                                        echo $status[$imovel['status']] ?? $imovel['status'];
                                        ?>
                                    </td>
                                    <td>R$ <?= number_format($imovel['valor_venda'] ?? 0, 2, ',', '.') ?></td>
                                    <td><?= htmlspecialchars($imovel['cliente_nome'] ?? '-') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr class="font-weight-bold">
                                <td colspan="7" class="text-right">Total:</td>
                                <td colspan="2">R$ <?= number_format($estatisticas['valor_total'] ?? 0, 2, ',', '.') ?></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> Nenhum imóvel encontrado com os filtros aplicados.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
// Dados para os gráficos
var dadosTipo = <?= json_encode($grafico_tipo ?? []) ?>;
var dadosStatus = <?= json_encode($grafico_status ?? []) ?>;

// Gráfico de Tipos
if (document.getElementById('chartTipo')) {
    var ctx = document.getElementById('chartTipo').getContext('2d');
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: Object.keys(dadosTipo),
            datasets: [{
                data: Object.values(dadosTipo),
                backgroundColor: [
                    '#4e73df',
                    '#1cc88a',
                    '#36b9cc',
                    '#f6c23e'
                ]
            }]
        },
        options: {
            maintainAspectRatio: false,
            legend: {
                display: true,
                position: 'bottom'
            }
        }
    });
}

// Gráfico de Status
if (document.getElementById('chartStatus')) {
    var ctx = document.getElementById('chartStatus').getContext('2d');
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: Object.keys(dadosStatus),
            datasets: [{
                data: Object.values(dadosStatus),
                backgroundColor: [
                    '#1cc88a',
                    '#36b9cc',
                    '#f6c23e',
                    '#858796'
                ]
            }]
        },
        options: {
            maintainAspectRatio: false,
            legend: {
                display: true,
                position: 'bottom'
            }
        }
    });
}

// DataTable
$(document).ready(function() {
    $('#dataTable').DataTable({
        language: {
            url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/pt-BR.json'
        },
        pageLength: 25,
        order: [[0, 'desc']]
    });
});

function exportarPDF() {
    window.location.href = '<?= BASE_PATH ?>/relatorios/imoveis/exportar?formato=pdf&' + $('form').serialize();
}

function exportarExcel() {
    window.location.href = '<?= BASE_PATH ?>/relatorios/imoveis/exportar?formato=excel&' + $('form').serialize();
}
</script>
