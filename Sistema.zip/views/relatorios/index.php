<?php
require_once __DIR__ . '/../layouts/header.php';
$pageTitle = 'Relatórios';
$currentPage = 'relatorios';
?>

<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <h1 class="h3 mb-3">Central de Relatórios</h1>
        </div>
    </div>

    <?php if (isset($flash)): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show" role="alert">
            <?= $flash['message'] ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="row">
        <!-- Relatório Financeiro -->
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card shadow h-100">
                <div class="card-body">
                    <div class="text-center mb-3">
                        <i class="fas fa-dollar-sign fa-3x text-success"></i>
                    </div>
                    <h5 class="card-title text-center">Relatório Financeiro</h5>
                    <p class="card-text text-muted">
                        Visualize receitas, despesas, lucros e análises financeiras detalhadas.
                    </p>
                    <div class="text-center">
                        <a href="<?= BASE_PATH ?>/relatorios/financeiro" class="btn btn-success">
                            <i class="fas fa-chart-line"></i> Acessar
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Relatório de Obras -->
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card shadow h-100">
                <div class="card-body">
                    <div class="text-center mb-3">
                        <i class="fas fa-hard-hat fa-3x text-warning"></i>
                    </div>
                    <h5 class="card-title text-center">Relatório de Obras</h5>
                    <p class="card-text text-muted">
                        Acompanhe o progresso das obras, ocorrências e compras realizadas.
                    </p>
                    <div class="text-center">
                        <a href="<?= BASE_PATH ?>/relatorios/obras" class="btn btn-warning">
                            <i class="fas fa-chart-bar"></i> Acessar
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Relatório de Imóveis -->
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card shadow h-100">
                <div class="card-body">
                    <div class="text-center mb-3">
                        <i class="fas fa-building fa-3x text-info"></i>
                    </div>
                    <h5 class="card-title text-center">Relatório de Imóveis</h5>
                    <p class="card-text text-muted">
                        Análise completa do portfólio de imóveis, ocupação e valores.
                    </p>
                    <div class="text-center">
                        <a href="<?= BASE_PATH ?>/relatorios/imoveis" class="btn btn-info">
                            <i class="fas fa-chart-pie"></i> Acessar
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Relatório de Funcionários -->
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card shadow h-100">
                <div class="card-body">
                    <div class="text-center mb-3">
                        <i class="fas fa-users fa-3x text-primary"></i>
                    </div>
                    <h5 class="card-title text-center">Relatório de Funcionários</h5>
                    <p class="card-text text-muted">
                        Informações sobre funcionários, faltas, EPIs e produtividade.
                    </p>
                    <div class="text-center">
                        <a href="<?= BASE_PATH ?>/relatorios/funcionarios" class="btn btn-primary">
                            <i class="fas fa-chart-area"></i> Acessar
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Relatório de Fornecedores -->
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card shadow h-100">
                <div class="card-body">
                    <div class="text-center mb-3">
                        <i class="fas fa-truck fa-3x text-secondary"></i>
                    </div>
                    <h5 class="card-title text-center">Relatório de Fornecedores</h5>
                    <p class="card-text text-muted">
                        Análise de fornecedores, compras realizadas e avaliações.
                    </p>
                    <div class="text-center">
                        <a href="<?= BASE_PATH ?>/relatorios/fornecedores" class="btn btn-secondary">
                            <i class="fas fa-chart-scatter"></i> Acessar
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Relatório Personalizado -->
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card shadow h-100">
                <div class="card-body">
                    <div class="text-center mb-3">
                        <i class="fas fa-cog fa-3x text-dark"></i>
                    </div>
                    <h5 class="card-title text-center">Relatório Personalizado</h5>
                    <p class="card-text text-muted">
                        Crie relatórios personalizados com os dados que você precisa.
                    </p>
                    <div class="text-center">
                        <a href="<?= BASE_PATH ?>/relatorios/personalizado" class="btn btn-dark">
                            <i class="fas fa-tools"></i> Criar
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Ações Rápidas -->
    <div class="row mt-4">
        <div class="col-12">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Ações Rápidas</h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4">
                            <button class="btn btn-outline-primary btn-block" onclick="window.print()">
                                <i class="fas fa-print"></i> Imprimir Página
                            </button>
                        </div>
                        <div class="col-md-4">
                            <a href="<?= BASE_PATH ?>/relatorios/exportar?tipo=pdf" class="btn btn-outline-danger btn-block">
                                <i class="fas fa-file-pdf"></i> Exportar PDF
                            </a>
                        </div>
                        <div class="col-md-4">
                            <a href="<?= BASE_PATH ?>/relatorios/exportar?tipo=excel" class="btn btn-outline-success btn-block">
                                <i class="fas fa-file-excel"></i> Exportar Excel
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
