<?php
$pageTitle = 'Relatório Financeiro';
$currentPage = 'relatorios';
?>

<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <h1 class="h3 mb-3">
                <i class="fas fa-dollar-sign"></i> Relatório Financeiro
            </h1>
        </div>
    </div>

    <?php if (isset($flash)): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show" role="alert">
            <?= $flash['message'] ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <!-- Filtros -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Período do Relatório</h6>
        </div>
        <div class="card-body">
            <form method="GET" action="<?= BASE_PATH ?>/relatorios/financeiro">
                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="data_inicio">Data Inicial</label>
                            <input type="date" name="data_inicio" id="data_inicio" class="form-control" 
                                   value="<?= $_GET['data_inicio'] ?? date('Y-m-01') ?>">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="data_fim">Data Final</label>
                            <input type="date" name="data_fim" id="data_fim" class="form-control" 
                                   value="<?= $_GET['data_fim'] ?? date('Y-m-t') ?>">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="tipo">Tipo</label>
                            <select name="tipo" id="tipo" class="form-control">
                                <option value="">Todos</option>
                                <option value="receita" <?= (isset($_GET['tipo']) && $_GET['tipo'] == 'receita') ? 'selected' : '' ?>>Receitas</option>
                                <option value="despesa" <?= (isset($_GET['tipo']) && $_GET['tipo'] == 'despesa') ? 'selected' : '' ?>>Despesas</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>&nbsp;</label>
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-filter"></i> Filtrar
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Cards de Resumo -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Total de Receitas
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                R$ <?= number_format($resumo['total_receitas'] ?? 0, 2, ',', '.') ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-arrow-up fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card border-left-danger shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                Total de Despesas
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                R$ <?= number_format($resumo['total_despesas'] ?? 0, 2, ',', '.') ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-arrow-down fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                Saldo do Período
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?php 
                                $saldo = ($resumo['total_receitas'] ?? 0) - ($resumo['total_despesas'] ?? 0);
                                $cor = $saldo >= 0 ? 'text-success' : 'text-danger';
                                ?>
                                <span class="<?= $cor ?>">
                                    R$ <?= number_format($saldo, 2, ',', '.') ?>
                                </span>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-balance-scale fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Contas Pendentes
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                R$ <?= number_format($resumo['contas_pendentes'] ?? 0, 2, ',', '.') ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-clock fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Gráficos -->
    <div class="row mb-4">
        <div class="col-md-8">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Evolução Mensal</h6>
                </div>
                <div class="card-body">
                    <canvas id="chartEvolucao" height="100"></canvas>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Distribuição por Categoria</h6>
                </div>
                <div class="card-body">
                    <canvas id="chartCategorias" height="200"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Tabelas -->
    <div class="row">
        <div class="col-md-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-success">Principais Receitas</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Descrição</th>
                                    <th>Valor</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($receitas ?? [] as $receita): ?>
                                    <tr>
                                        <td><?= date('d/m/Y', strtotime($receita['data'])) ?></td>
                                        <td><?= htmlspecialchars($receita['descricao']) ?></td>
                                        <td>R$ <?= number_format($receita['valor'], 2, ',', '.') ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-danger">Principais Despesas</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Descrição</th>
                                    <th>Valor</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($despesas ?? [] as $despesa): ?>
                                    <tr>
                                        <td><?= date('d/m/Y', strtotime($despesa['data'])) ?></td>
                                        <td><?= htmlspecialchars($despesa['descricao']) ?></td>
                                        <td>R$ <?= number_format($despesa['valor'], 2, ',', '.') ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Ações -->
    <div class="card shadow">
        <div class="card-body text-center">
            <button onclick="exportarPDF()" class="btn btn-danger">
                <i class="fas fa-file-pdf"></i> Exportar PDF
            </button>
            <button onclick="exportarExcel()" class="btn btn-success">
                <i class="fas fa-file-excel"></i> Exportar Excel
            </button>
            <button onclick="window.print()" class="btn btn-secondary">
                <i class="fas fa-print"></i> Imprimir
            </button>
        </div>
    </div>
</div>

<script>
// Dados para os gráficos
var dadosEvolucao = <?= json_encode($grafico_evolucao ?? []) ?>;
var dadosCategorias = <?= json_encode($grafico_categorias ?? []) ?>;

// Gráfico de Evolução
if (document.getElementById('chartEvolucao')) {
    var ctx = document.getElementById('chartEvolucao').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: dadosEvolucao.labels || [],
            datasets: [{
                label: 'Receitas',
                data: dadosEvolucao.receitas || [],
                borderColor: '#1cc88a',
                backgroundColor: 'rgba(28, 200, 138, 0.1)',
                tension: 0.3
            }, {
                label: 'Despesas',
                data: dadosEvolucao.despesas || [],
                borderColor: '#e74a3b',
                backgroundColor: 'rgba(231, 74, 59, 0.1)',
                tension: 0.3
            }]
        },
        options: {
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return 'R$ ' + value.toLocaleString('pt-BR');
                        }
                    }
                }
            }
        }
    });
}

// Gráfico de Categorias
if (document.getElementById('chartCategorias')) {
    var ctx = document.getElementById('chartCategorias').getContext('2d');
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: Object.keys(dadosCategorias),
            datasets: [{
                data: Object.values(dadosCategorias),
                backgroundColor: [
                    '#4e73df',
                    '#1cc88a',
                    '#36b9cc',
                    '#f6c23e',
                    '#e74a3b'
                ]
            }]
        },
        options: {
            maintainAspectRatio: false,
            legend: {
                display: true,
                position: 'bottom'
            }
        }
    });
}

function exportarPDF() {
    window.location.href = '<?= BASE_PATH ?>/relatorios/financeiro/exportar?formato=pdf&' + $('form').serialize();
}

function exportarExcel() {
    window.location.href = '<?= BASE_PATH ?>/relatorios/financeiro/exportar?formato=excel&' + $('form').serialize();
}
</script>
