<?php
$pageTitle = 'Relatório de Obras';
$currentPage = 'relatorios';
?>

<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <h1 class="h3 mb-3">
                <i class="fas fa-hard-hat"></i> Relatório de Obras
            </h1>
        </div>
    </div>

    <?php if (isset($flash)): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show" role="alert">
            <?= $flash['message'] ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <!-- Filtros -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Filtros do Relatório</h6>
        </div>
        <div class="card-body">
            <form method="GET" action="<?= BASE_PATH ?>/relatorios/obras">
                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="empreendimento">Empreendimento</label>
                            <select name="empreendimento" id="empreendimento" class="form-control">
                                <option value="">Todos</option>
                                <?php foreach ($empreendimentos ?? [] as $emp): ?>
                                    <option value="<?= $emp['id'] ?>" 
                                            <?= (isset($_GET['empreendimento']) && $_GET['empreendimento'] == $emp['id']) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($emp['nome']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select name="status" id="status" class="form-control">
                                <option value="">Todos</option>
                                <option value="planejamento" <?= (isset($_GET['status']) && $_GET['status'] == 'planejamento') ? 'selected' : '' ?>>Planejamento</option>
                                <option value="em_andamento" <?= (isset($_GET['status']) && $_GET['status'] == 'em_andamento') ? 'selected' : '' ?>>Em Andamento</option>
                                <option value="pausada" <?= (isset($_GET['status']) && $_GET['status'] == 'pausada') ? 'selected' : '' ?>>Pausada</option>
                                <option value="concluida" <?= (isset($_GET['status']) && $_GET['status'] == 'concluida') ? 'selected' : '' ?>>Concluída</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="periodo">Período</label>
                            <select name="periodo" id="periodo" class="form-control">
                                <option value="30" <?= (isset($_GET['periodo']) && $_GET['periodo'] == '30') ? 'selected' : '' ?>>Últimos 30 dias</option>
                                <option value="60" <?= (isset($_GET['periodo']) && $_GET['periodo'] == '60') ? 'selected' : '' ?>>Últimos 60 dias</option>
                                <option value="90" <?= (isset($_GET['periodo']) && $_GET['periodo'] == '90') ? 'selected' : '' ?>>Últimos 90 dias</option>
                                <option value="180" <?= (isset($_GET['periodo']) && $_GET['periodo'] == '180') ? 'selected' : '' ?>>Últimos 6 meses</option>
                                <option value="365" <?= (isset($_GET['periodo']) && $_GET['periodo'] == '365') ? 'selected' : '' ?>>Último ano</option>
                                <option value="all" <?= (isset($_GET['periodo']) && $_GET['periodo'] == 'all') ? 'selected' : '' ?>>Todo período</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>&nbsp;</label>
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-filter"></i> Filtrar
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Cards de Resumo -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Total de Obras
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?= number_format($estatisticas['total_obras'] ?? 0) ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-hammer fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Em Andamento
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?= number_format($estatisticas['em_andamento'] ?? 0) ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-spinner fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Ocorrências
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?= number_format($estatisticas['total_ocorrencias'] ?? 0) ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-exclamation-triangle fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                Investimento Total
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                R$ <?= number_format($estatisticas['investimento_total'] ?? 0, 2, ',', '.') ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Gráficos -->
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Progresso das Obras</h6>
                </div>
                <div class="card-body">
                    <canvas id="chartProgresso" height="150"></canvas>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Gastos por Categoria</h6>
                </div>
                <div class="card-body">
                    <canvas id="chartGastos" height="150"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Tabela de Obras -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">Detalhamento das Obras</h6>
            <div>
                <button onclick="exportarPDF()" class="btn btn-sm btn-danger">
                    <i class="fas fa-file-pdf"></i> PDF
                </button>
                <button onclick="exportarExcel()" class="btn btn-sm btn-success">
                    <i class="fas fa-file-excel"></i> Excel
                </button>
            </div>
        </div>
        <div class="card-body">
            <?php if (!empty($obras)): ?>
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable">
                        <thead>
                            <tr>
                                <th>Código</th>
                                <th>Empreendimento</th>
                                <th>Descrição</th>
                                <th>Status</th>
                                <th>Progresso</th>
                                <th>Início</th>
                                <th>Previsão</th>
                                <th>Orçamento</th>
                                <th>Gasto</th>
                                <th>Responsável</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($obras as $obra): ?>
                                <tr>
                                    <td><?= htmlspecialchars($obra['codigo']) ?></td>
                                    <td><?= htmlspecialchars($obra['empreendimento_nome'] ?? '-') ?></td>
                                    <td><?= htmlspecialchars($obra['descricao']) ?></td>
                                    <td>
                                        <?php
                                        $status = [
                                            'planejamento' => '<span class="badge badge-secondary">Planejamento</span>',
                                            'em_andamento' => '<span class="badge badge-primary">Em Andamento</span>',
                                            'pausada' => '<span class="badge badge-warning">Pausada</span>',
                                            'concluida' => '<span class="badge badge-success">Concluída</span>'
                                        ];
                                        echo $status[$obra['status']] ?? $obra['status'];
                                        ?>
                                    </td>
                                    <td>
                                        <div class="progress">
                                            <div class="progress-bar" role="progressbar" 
                                                 style="width: <?= $obra['progresso'] ?? 0 ?>%"
                                                 aria-valuenow="<?= $obra['progresso'] ?? 0 ?>" 
                                                 aria-valuemin="0" aria-valuemax="100">
                                                <?= $obra['progresso'] ?? 0 ?>%
                                            </div>
                                        </div>
                                    </td>
                                    <td><?= date('d/m/Y', strtotime($obra['data_inicio'])) ?></td>
                                    <td><?= date('d/m/Y', strtotime($obra['data_previsao'])) ?></td>
                                    <td>R$ <?= number_format($obra['orcamento'] ?? 0, 2, ',', '.') ?></td>
                                    <td>R$ <?= number_format($obra['gasto_total'] ?? 0, 2, ',', '.') ?></td>
                                    <td><?= htmlspecialchars($obra['responsavel_nome'] ?? '-') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> Nenhuma obra encontrada com os filtros aplicados.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Ocorrências Recentes -->
    <div class="card shadow">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-warning">Ocorrências Recentes</h6>
        </div>
        <div class="card-body">
            <?php if (!empty($ocorrencias)): ?>
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>Data</th>
                                <th>Obra</th>
                                <th>Tipo</th>
                                <th>Descrição</th>
                                <th>Prioridade</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($ocorrencias as $ocorrencia): ?>
                                <tr>
                                    <td><?= date('d/m/Y', strtotime($ocorrencia['data'])) ?></td>
                                    <td><?= htmlspecialchars($ocorrencia['obra_nome']) ?></td>
                                    <td>
                                        <?php
                                        $tipos = [
                                            'acidente' => '<span class="badge badge-danger">Acidente</span>',
                                            'atraso' => '<span class="badge badge-warning">Atraso</span>',
                                            'qualidade' => '<span class="badge badge-info">Qualidade</span>',
                                            'outro' => '<span class="badge badge-secondary">Outro</span>'
                                        ];
                                        echo $tipos[$ocorrencia['tipo']] ?? $ocorrencia['tipo'];
                                        ?>
                                    </td>
                                    <td><?= htmlspecialchars(substr($ocorrencia['descricao'], 0, 50)) ?>...</td>
                                    <td>
                                        <?php
                                        $prioridades = [
                                            'alta' => '<span class="badge badge-danger">Alta</span>',
                                            'media' => '<span class="badge badge-warning">Média</span>',
                                            'baixa' => '<span class="badge badge-success">Baixa</span>'
                                        ];
                                        echo $prioridades[$ocorrencia['prioridade']] ?? $ocorrencia['prioridade'];
                                        ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted">Nenhuma ocorrência registrada no período.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
// Dados para os gráficos
var dadosProgresso = <?= json_encode($grafico_progresso ?? []) ?>;
var dadosGastos = <?= json_encode($grafico_gastos ?? []) ?>;

// Gráfico de Progresso
if (document.getElementById('chartProgresso')) {
    var ctx = document.getElementById('chartProgresso').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: dadosProgresso.labels || [],
            datasets: [{
                label: 'Progresso (%)',
                data: dadosProgresso.valores || [],
                backgroundColor: '#4e73df'
            }]
        },
        options: {
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100
                }
            }
        }
    });
}

// Gráfico de Gastos
if (document.getElementById('chartGastos')) {
    var ctx = document.getElementById('chartGastos').getContext('2d');
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: Object.keys(dadosGastos),
            datasets: [{
                data: Object.values(dadosGastos),
                backgroundColor: [
                    '#e74a3b',
                    '#f6c23e',
                    '#4e73df',
                    '#1cc88a',
                    '#36b9cc'
                ]
            }]
        },
        options: {
            maintainAspectRatio: false,
            legend: {
                display: true,
                position: 'bottom'
            }
        }
    });
}

// DataTable
$(document).ready(function() {
    $('#dataTable').DataTable({
        language: {
            url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/pt-BR.json'
        },
        pageLength: 10,
        order: [[5, 'desc']]
    });
});

function exportarPDF() {
    window.location.href = '<?= BASE_PATH ?>/relatorios/obras/exportar?formato=pdf&' + $('form').serialize();
}

function exportarExcel() {
    window.location.href = '<?= BASE_PATH ?>/relatorios/obras/exportar?formato=excel&' + $('form').serialize();
}
</script>
