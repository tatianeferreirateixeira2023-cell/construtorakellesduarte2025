<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= APP_NAME ?></title>
    
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap4.min.css">
    <!-- SweetAlert2 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?= css_url('custom.css') ?>">
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?= img_url('favicon.ico') ?>">
    <style>
        .brazilian-currency::before { content: "R$ "; }
        .cpf-mask { text-transform: uppercase; }
        .cnpj-mask { text-transform: uppercase; }
        .phone-mask { text-transform: uppercase; }
        .date-br { text-transform: uppercase; }
        .navbar-dark .navbar-nav .nav-link { color: rgba(255,255,255,.8); }
        .navbar-dark .navbar-nav .nav-link:hover { color: rgba(255,255,255,1); }
    </style>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-dark navbar-primary">
        <!-- Left navbar links -->
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
            <li class="nav-item d-none d-sm-inline-block">
                <a href="<?= BASE_PATH ?>/" class="nav-link">Início</a>
            </li>
        </ul>

        <!-- Right navbar links -->
        <ul class="navbar-nav ml-auto">
            <!-- Notifications Dropdown Menu -->
            <li class="nav-item dropdown">
                <a class="nav-link" data-toggle="dropdown" href="#">
                    <i class="far fa-bell"></i>
                    <span class="badge badge-warning navbar-badge" id="notification-count">0</span>
                </a>
                <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                    <span class="dropdown-header">Notificações</span>
                    <div class="dropdown-divider"></div>
                    <div id="notification-list">
                        <!-- Notificações serão carregadas aqui -->
                    </div>
                    <div class="dropdown-divider"></div>
                    <a href="<?= BASE_PATH ?>/notificacoes" class="dropdown-item dropdown-footer">Ver Todas</a>
                </div>
            </li>
            
            <!-- User Menu -->
            <li class="nav-item dropdown">
                <a class="nav-link" data-toggle="dropdown" href="#">
                    <i class="far fa-user"></i> <?= $_SESSION['user_name'] ?? 'Usuário' ?>
                </a>
                <div class="dropdown-menu dropdown-menu-right">
                    <a href="<?= BASE_PATH ?>/perfil" class="dropdown-item">
                        <i class="fas fa-user-cog mr-2"></i> Meu Perfil
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="<?= BASE_PATH ?>/logout" class="dropdown-item">
                        <i class="fas fa-sign-out-alt mr-2"></i> Sair
                    </a>
                </div>
            </li>
        </ul>
    </nav>

    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <!-- Brand Logo -->
        <a href="<?= base_path() ?>" class="brand-link">
            <img src="<?= img_url('logo.png') ?>" alt="Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
            <span class="brand-text font-weight-light">Kelles Duarte</span>
        </a>

        <!-- Sidebar -->
        <div class="sidebar">
            <!-- Sidebar user panel -->
            <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                <div class="image">
                    <img src="<?= img_url('user-default.png') ?>" class="img-circle elevation-2" alt="User Image">
                </div>
                <div class="info">
                    <a href="<?= BASE_PATH ?>/perfil" class="d-block"><?= $_SESSION['user_name'] ?? 'Usuário' ?></a>
                    <small class="text-muted"><?= $_SESSION['user_nivel_nome'] ?? 'Administrador' ?></small>
                </div>
            </div>

            <!-- Sidebar Menu -->
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                    
                    <li class="nav-item">
                        <a href="<?= BASE_PATH ?>/" class="nav-link <?= $_SERVER['REQUEST_URI'] == BASE_PATH . '/' ? 'active' : '' ?>">
                            <i class="nav-icon fas fa-home"></i>
                            <p>Início</p>
                        </a>
                    </li>

                    <?php if (in_array($_SESSION['user_nivel'] ?? 0, [NIVEL_ADMIN])): ?>
                    <li class="nav-header">ADMINISTRAÇÃO</li>
                    
                    <li class="nav-item">
                        <a href="<?= BASE_PATH ?>/usuarios" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/usuarios') !== false ? 'active' : '' ?>">
                            <i class="nav-icon fas fa-users"></i>
                            <p>Usuários</p>
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if (in_array($_SESSION['user_nivel'] ?? 0, [NIVEL_ADMIN, NIVEL_FINANCEIRO])): ?>
                    <li class="nav-header">IMOBILIÁRIO</li>
                    
                    <li class="nav-item">
                        <a href="<?= BASE_PATH ?>/empreendimentos" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/empreendimentos') !== false ? 'active' : '' ?>">
                            <i class="nav-icon fas fa-building"></i>
                            <p>Empreendimentos</p>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="<?= BASE_PATH ?>/imoveis" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/imoveis') !== false ? 'active' : '' ?>">
                            <i class="nav-icon fas fa-home"></i>
                            <p>Imóveis</p>
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if (in_array($_SESSION['user_nivel'] ?? 0, [NIVEL_ADMIN, NIVEL_FINANCEIRO])): ?>
                    <li class="nav-header">FINANCEIRO</li>
                    
                    <li class="nav-item">
                        <a href="<?= BASE_PATH ?>/faturas" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/faturas') !== false ? 'active' : '' ?>">
                            <i class="nav-icon fas fa-file-invoice-dollar"></i>
                            <p>Faturas</p>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="<?= BASE_PATH ?>/contas-pagar" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/contas-pagar') !== false ? 'active' : '' ?>">
                            <i class="nav-icon fas fa-money-check-alt"></i>
                            <p>Contas a Pagar</p>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="<?= BASE_PATH ?>/fornecedores" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/fornecedores') !== false ? 'active' : '' ?>">
                            <i class="nav-icon fas fa-truck"></i>
                            <p>Fornecedores</p>
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if (in_array($_SESSION['user_nivel'] ?? 0, [NIVEL_ADMIN, NIVEL_FINANCEIRO, NIVEL_ENCARREGADO])): ?>
                    <li class="nav-header">RECURSOS HUMANOS</li>
                    
                    <li class="nav-item">
                        <a href="<?= BASE_PATH ?>/funcionarios" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/funcionarios') !== false ? 'active' : '' ?>">
                            <i class="nav-icon fas fa-id-card"></i>
                            <p>Funcionários</p>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="<?= BASE_PATH ?>/epis" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/epis') !== false ? 'active' : '' ?>">
                            <i class="nav-icon fas fa-hard-hat"></i>
                            <p>EPIs</p>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="<?= BASE_PATH ?>/faltas" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/faltas') !== false ? 'active' : '' ?>">
                            <i class="nav-icon fas fa-calendar-times"></i>
                            <p>Controle de Faltas</p>
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if (in_array($_SESSION['user_nivel'] ?? 0, [NIVEL_ADMIN, NIVEL_ENCARREGADO])): ?>
                    <li class="nav-header">OBRAS</li>
                    
                    <li class="nav-item">
                        <a href="<?= BASE_PATH ?>/obras" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/obras') !== false ? 'active' : '' ?>">
                            <i class="nav-icon fas fa-hammer"></i>
                            <p>Gestão de Obras</p>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="<?= BASE_PATH ?>/ocorrencias" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/ocorrencias') !== false ? 'active' : '' ?>">
                            <i class="nav-icon fas fa-exclamation-triangle"></i>
                            <p>Ocorrências</p>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="<?= BASE_PATH ?>/compras" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/compras') !== false ? 'active' : '' ?>">
                            <i class="nav-icon fas fa-shopping-cart"></i>
                            <p>Compras e Suprimentos</p>
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if ($_SESSION['user_nivel'] == NIVEL_CLIENTE): ?>
                    <li class="nav-header">MINHA ÁREA</li>
                    
                    <li class="nav-item">
                        <a href="<?= BASE_PATH ?>/manutencoes" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/manutencoes') !== false ? 'active' : '' ?>">
                            <i class="nav-icon fas fa-tools"></i>
                            <p>Manutenções</p>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="<?= BASE_PATH ?>/minhas-faturas" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/minhas-faturas') !== false ? 'active' : '' ?>">
                            <i class="nav-icon fas fa-file-invoice"></i>
                            <p>Minhas Faturas</p>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="<?= BASE_PATH ?>/meus-documentos" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/meus-documentos') !== false ? 'active' : '' ?>">
                            <i class="nav-icon fas fa-folder-open"></i>
                            <p>Meus Documentos</p>
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if (in_array($_SESSION['user_nivel'] ?? 0, [NIVEL_ADMIN])): ?>
                    <li class="nav-header">SISTEMA</li>
                    
                    <li class="nav-item">
                        <a href="<?= BASE_PATH ?>/relatorios" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/relatorios') !== false ? 'active' : '' ?>">
                            <i class="nav-icon fas fa-chart-bar"></i>
                            <p>Relatórios</p>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="<?= BASE_PATH ?>/backup" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/backup') !== false ? 'active' : '' ?>">
                            <i class="nav-icon fas fa-database"></i>
                            <p>Backup</p>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="<?= BASE_URL ?>logs.php" class="nav-link <?= strpos($_SERVER['REQUEST_URI'], '/logs') !== false ? 'active' : '' ?>">
                            <i class="nav-icon fas fa-history"></i>
                            <p>Logs do Sistema</p>
                        </a>
                    </li>
                    <?php endif; ?>
                    
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Content Wrapper -->
    <div class="content-wrapper">
        <!-- Flash Messages -->
        <?php if (isset($flash) && $flash): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show m-3" role="alert">
            <?= $flash['message'] ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>
