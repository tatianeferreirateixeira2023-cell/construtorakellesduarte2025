    </div>
    <!-- /.content-wrapper -->

    <footer class="main-footer">
        <strong>Copyright &copy; <?= date('Y') ?> <a href="https://www.construtorakellesduarte.com.br">Construtora Kelles Duarte</a>.</strong>
        Todos os direitos reservados.
        <div class="float-right d-none d-sm-inline-block">
            <b>Versão</b> <?= APP_VERSION ?>
        </div>
    </footer>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Bootstrap 4 -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
<!-- DataTables -->
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap4.min.js"></script>
<!-- SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<!-- jQuery Mask Plugin -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<!-- Custom Scripts -->
<script src="<?= js_url('custom.js') ?>"></script>
<script>
// Define BASE_URL para uso em JavaScript
const BASE_URL = '<?= BASE_URL ?>';
const BASE_PATH = '<?= BASE_PATH ?>';

$(document).ready(function() {
    // Inicializa DataTables em português
    $('.datatable').DataTable({
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.13.6/i18n/pt-BR.json"
        },
        "pageLength": 25,
        "responsive": true
    });
    
    // Máscaras brasileiras
    $('.cpf-mask').mask('000.000.000-00');
    $('.cnpj-mask').mask('00.000.000/0000-00');
    $('.phone-mask').mask('(00) 00000-0000');
    $('.cep-mask').mask('00000-000');
    $('.money-mask').mask('#.##0,00', {reverse: true});
    $('.date-mask').mask('00/00/0000');
    
    // Confirmação de exclusão
    $('.btn-delete').on('click', function(e) {
        e.preventDefault();
        const url = $(this).attr('href');
        const item = $(this).data('item') || 'este item';
        
        Swal.fire({
            title: 'Tem certeza?',
            text: `Deseja realmente excluir ${item}?`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Sim, excluir!',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = url;
            }
        });
    });
    
    // Auto-hide alerts
    setTimeout(function() {
        $('.alert').fadeOut('slow');
    }, 5000);
    
    // Carrega notificações
    loadNotifications();
    
    // Atualiza notificações a cada 60 segundos
    setInterval(loadNotifications, 60000);
    
    // Tooltip
    $('[data-toggle="tooltip"]').tooltip();
    
    // Validação de formulários
    $('.needs-validation').on('submit', function(e) {
        if (this.checkValidity() === false) {
            e.preventDefault();
            e.stopPropagation();
        }
        $(this).addClass('was-validated');
    });
    
    // Preview de imagem
    $('.custom-file-input').on('change', function() {
        const fileName = $(this).val().split('\\').pop();
        $(this).siblings('.custom-file-label').addClass('selected').html(fileName);
        
        // Preview se for imagem
        if (this.files && this.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                $('#image-preview').attr('src', e.target.result).show();
            }
            reader.readAsDataURL(this.files[0]);
        }
    });
    
    // Função para formatar moeda
    $('.money-input').on('blur', function() {
        let value = $(this).val().replace(/\D/g, '');
        value = (value / 100).toFixed(2);
        value = value.replace('.', ',');
        value = 'R$ ' + value.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
        $(this).val(value);
    });
});

// Função para carregar notificações
function loadNotifications() {
    $.ajax({
        url: BASE_PATH + '/api/notifications',
        method: 'GET',
        success: function(data) {
            $('#notification-count').text(data.count || 0);
            
            let html = '';
            if (data.notifications && data.notifications.length > 0) {
                data.notifications.forEach(function(notif) {
                    html += `
                        <a href="${notif.link}" class="dropdown-item">
                            <i class="${notif.icon} mr-2"></i> ${notif.message}
                            <span class="float-right text-muted text-sm">${notif.time}</span>
                        </a>
                        <div class="dropdown-divider"></div>
                    `;
                });
            } else {
                html = '<p class="text-center text-muted p-3">Nenhuma notificação</p>';
            }
            
            $('#notification-list').html(html);
        }
    });
}

// Função para enviar formulário via AJAX
function submitFormAjax(formId, callback) {
    $(formId).on('submit', function(e) {
        e.preventDefault();
        
        const form = $(this);
        const url = form.attr('action');
        const method = form.attr('method') || 'POST';
        const formData = new FormData(this);
        
        $.ajax({
            url: url,
            method: method,
            data: formData,
            processData: false,
            contentType: false,
            beforeSend: function() {
                form.find('button[type="submit"]').prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Processando...');
            },
            success: function(response) {
                if (response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Sucesso!',
                        text: response.message || 'Operação realizada com sucesso!',
                        timer: 2000,
                        showConfirmButton: false
                    });
                    
                    if (callback) callback(response);
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Erro!',
                        text: response.message || 'Ocorreu um erro ao processar a solicitação.'
                    });
                }
            },
            error: function(xhr) {
                Swal.fire({
                    icon: 'error',
                    title: 'Erro!',
                    text: 'Ocorreu um erro ao processar a solicitação.'
                });
            },
            complete: function() {
                form.find('button[type="submit"]').prop('disabled', false).html(form.find('button[type="submit"]').data('original-text') || 'Salvar');
            }
        });
    });
}

// Função para calcular parcelas
function calcularParcelas() {
    const valor = parseFloat($('#valor_imovel').val().replace(/\D/g, '')) / 100;
    const taxa = parseFloat($('#taxa_juros').val()) / 100;
    const parcelas = parseInt($('#quantidade_parcelas').val());
    
    if (valor && taxa && parcelas) {
        const taxaMensal = taxa / 12;
        const valorParcela = valor * (taxaMensal * Math.pow(1 + taxaMensal, parcelas)) / (Math.pow(1 + taxaMensal, parcelas) - 1);
        
        $('#valor_parcela').val(valorParcela.toFixed(2).replace('.', ','));
        $('#total_financiamento').text('R$ ' + (valorParcela * parcelas).toFixed(2).replace('.', ','));
    }
}

// Função para gerar boleto
function gerarBoleto(faturaId) {
    window.open(`/faturas/boleto/${faturaId}`, '_blank');
}

// Função para gerar QR Code PIX
function gerarPixQRCode(faturaId) {
    $.ajax({
        url: `/api/pix/qrcode/${faturaId}`,
        method: 'GET',
        success: function(data) {
            Swal.fire({
                title: 'QR Code PIX',
                html: `
                    <div class="text-center">
                        <img src="${data.qrcode}" alt="QR Code PIX" class="img-fluid mb-3">
                        <p><strong>Valor:</strong> ${data.valor}</p>
                        <p><small>CNPJ: ${data.cnpj}</small></p>
                        <button class="btn btn-primary" onclick="navigator.clipboard.writeText('${data.codigo}')">
                            <i class="fas fa-copy"></i> Copiar Código
                        </button>
                    </div>
                `,
                showConfirmButton: false,
                width: 400
            });
        }
    });
}

// Função para verificar aniversários
function verificarAniversarios() {
    $.ajax({
        url: '/api/aniversarios/hoje',
        method: 'GET',
        success: function(data) {
            if (data.aniversarios && data.aniversarios.length > 0) {
                let html = '<ul>';
                data.aniversarios.forEach(function(pessoa) {
                    html += `<li>${pessoa.nome} - ${pessoa.idade} anos</li>`;
                });
                html += '</ul>';
                
                Swal.fire({
                    icon: 'info',
                    title: '🎂 Aniversários de Hoje!',
                    html: html,
                    timer: 10000,
                    timerProgressBar: true
                });
            }
        }
    });
}

// Verifica aniversários ao carregar a página
$(document).ready(function() {
    if (window.location.pathname === '/' || window.location.pathname === '/dashboard') {
        verificarAniversarios();
    }
});
</script>

</body>
</html>
