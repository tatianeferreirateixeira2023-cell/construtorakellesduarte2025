-- Banco de Dados: construtorakelle_sistema
-- Versão: 1.0.0
-- Charset: utf8mb4

CREATE DATABASE IF NOT EXISTS construtorakelle_sistema 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE construtorakelle_sistema;

-- Tabela de Níveis de Acesso
CREATE TABLE niveis_acesso (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(50) NOT NULL,
    descricao TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Inserir níveis padrão
INSERT INTO niveis_acesso (id, nome, descricao) VALUES
(1, 'Administrador', 'Acesso total ao sistema'),
(2, 'Cliente', 'Acesso restrito aos próprios dados'),
(3, 'Funcionário', 'Acesso intermediário'),
(4, 'Financeiro', 'Acesso ao módulo financeiro'),
(5, 'Encarregado de Obras', 'Acesso operacional');

-- Tabela de Usuários
CREATE TABLE usuarios (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nome_completo VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    cpf VARCHAR(14) UNIQUE,
    identidade VARCHAR(20),
    data_nascimento DATE,
    telefone VARCHAR(15),
    profissao VARCHAR(100),
    renda_familiar DECIMAL(10,2),
    nivel_acesso_id INT NOT NULL,
    
    -- Dados do cônjuge
    conjuge_nome VARCHAR(255),
    conjuge_cpf VARCHAR(14),
    conjuge_email VARCHAR(255),
    conjuge_identidade VARCHAR(20),
    conjuge_telefone VARCHAR(15),
    conjuge_profissao VARCHAR(100),
    conjuge_data_nascimento DATE,
    
    -- Controle
    ativo BOOLEAN DEFAULT TRUE,
    ultimo_acesso DATETIME,
    tentativas_login INT DEFAULT 0,
    bloqueado_ate DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (nivel_acesso_id) REFERENCES niveis_acesso(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Logs de Acesso
CREATE TABLE logs_acesso (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT NOT NULL,
    ip_address VARCHAR(45),
    user_agent TEXT,
    pagina VARCHAR(255),
    acao VARCHAR(100),
    descricao TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Permissões
CREATE TABLE permissoes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nivel_acesso_id INT NOT NULL,
    modulo VARCHAR(100) NOT NULL,
    visualizar BOOLEAN DEFAULT FALSE,
    criar BOOLEAN DEFAULT FALSE,
    editar BOOLEAN DEFAULT FALSE,
    deletar BOOLEAN DEFAULT FALSE,
    
    FOREIGN KEY (nivel_acesso_id) REFERENCES niveis_acesso(id),
    UNIQUE KEY unique_nivel_modulo (nivel_acesso_id, modulo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Empreendimentos
CREATE TABLE empreendimentos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    cidade VARCHAR(100) NOT NULL,
    nome VARCHAR(255) NOT NULL,
    endereco TEXT NOT NULL,
    cno VARCHAR(50) NOT NULL,
    engenheiro_nome VARCHAR(255) NOT NULL,
    engenheiro_art VARCHAR(50) NOT NULL,
    arquiteto_nome VARCHAR(255) NOT NULL,
    arquiteto_cau VARCHAR(50) NOT NULL,
    art_execucao VARCHAR(50) NOT NULL,
    encarregado_id INT,
    status ENUM('planejamento', 'em_andamento', 'concluido', 'suspenso') DEFAULT 'planejamento',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (encarregado_id) REFERENCES usuarios(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Imóveis
CREATE TABLE imoveis (
    id INT PRIMARY KEY AUTO_INCREMENT,
    empreendimento_id INT,
    cliente_id INT,
    valor DECIMAL(12,2) NOT NULL,
    status ENUM('disponivel', 'vendido', 'reservado') DEFAULT 'disponivel',
    metragem DECIMAL(10,2),
    quartos INT,
    suites INT,
    vagas_garagem INT,
    data_venda DATE,
    taxa_juros DECIMAL(5,2),
    quantidade_parcelas INT,
    valor_parcela DECIMAL(10,2),
    descricao TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (empreendimento_id) REFERENCES empreendimentos(id),
    FOREIGN KEY (cliente_id) REFERENCES usuarios(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Arquivos
CREATE TABLE arquivos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    tipo_entidade ENUM('imovel', 'empreendimento', 'usuario', 'funcionario', 'fatura', 'obra') NOT NULL,
    entidade_id INT NOT NULL,
    tipo_arquivo VARCHAR(50),
    nome_arquivo VARCHAR(255) NOT NULL,
    caminho VARCHAR(500) NOT NULL,
    tamanho INT,
    descricao TEXT,
    uploaded_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (uploaded_by) REFERENCES usuarios(id),
    INDEX idx_entidade (tipo_entidade, entidade_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Fornecedores
CREATE TABLE fornecedores (
    id INT PRIMARY KEY AUTO_INCREMENT,
    razao_social VARCHAR(255) NOT NULL,
    cnpj VARCHAR(18) UNIQUE NOT NULL,
    endereco TEXT,
    cep VARCHAR(9),
    telefone VARCHAR(15),
    email VARCHAR(255),
    responsavel_legal VARCHAR(255),
    area_atuacao VARCHAR(100),
    cidade VARCHAR(100),
    ativo BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Funcionários
CREATE TABLE funcionarios (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT UNIQUE,
    nome VARCHAR(255) NOT NULL,
    cpf VARCHAR(14) UNIQUE NOT NULL,
    identidade VARCHAR(20),
    ctps VARCHAR(20),
    pis VARCHAR(20),
    endereco TEXT,
    cep VARCHAR(9),
    telefone VARCHAR(15),
    email VARCHAR(255),
    data_admissao DATE NOT NULL,
    empreendimento_id INT,
    funcao VARCHAR(100),
    salario DECIMAL(10,2),
    ultimas_ferias DATE,
    vale_transporte BOOLEAN DEFAULT FALSE,
    status ENUM('ativo', 'inativo', 'ferias', 'afastado') DEFAULT 'ativo',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    FOREIGN KEY (empreendimento_id) REFERENCES empreendimentos(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de EPIs
CREATE TABLE epis (
    id INT PRIMARY KEY AUTO_INCREMENT,
    funcionario_id INT NOT NULL,
    data_entrega DATE NOT NULL,
    descricao TEXT NOT NULL,
    codigo VARCHAR(50),
    quantidade INT DEFAULT 1,
    data_devolucao DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (funcionario_id) REFERENCES funcionarios(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Faltas
CREATE TABLE faltas (
    id INT PRIMARY KEY AUTO_INCREMENT,
    funcionario_id INT NOT NULL,
    data DATE NOT NULL,
    horas_atraso TIME,
    motivo TEXT,
    justificada BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (funcionario_id) REFERENCES funcionarios(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Adiantamentos
CREATE TABLE adiantamentos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    funcionario_id INT NOT NULL,
    valor DECIMAL(10,2) NOT NULL,
    data_solicitacao DATE NOT NULL,
    tipo ENUM('quinzenal', 'emergencial') NOT NULL,
    motivo TEXT,
    parcelas INT DEFAULT 1,
    valor_parcela DECIMAL(10,2),
    status ENUM('pendente', 'aprovado', 'pago', 'cancelado') DEFAULT 'pendente',
    data_pagamento DATE,
    comprovante_path VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (funcionario_id) REFERENCES funcionarios(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Férias
CREATE TABLE ferias (
    id INT PRIMARY KEY AUTO_INCREMENT,
    funcionario_id INT NOT NULL,
    periodo_inicio DATE NOT NULL,
    periodo_fim DATE NOT NULL,
    valor_pago DECIMAL(10,2),
    data_pagamento DATE,
    comprovante_path VARCHAR(500),
    observacoes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (funcionario_id) REFERENCES funcionarios(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Faturas
CREATE TABLE faturas (
    id INT PRIMARY KEY AUTO_INCREMENT,
    imovel_id INT NOT NULL,
    cliente_id INT NOT NULL,
    numero_fatura VARCHAR(50) UNIQUE,
    valor DECIMAL(10,2) NOT NULL,
    data_vencimento DATE NOT NULL,
    data_pagamento DATE,
    status ENUM('em_aberto', 'pago', 'vencido', 'cancelado') DEFAULT 'em_aberto',
    forma_pagamento ENUM('pix', 'boleto', 'transferencia', 'dinheiro', 'cartao'),
    codigo_boleto VARCHAR(100),
    pix_codigo VARCHAR(255),
    observacoes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (imovel_id) REFERENCES imoveis(id),
    FOREIGN KEY (cliente_id) REFERENCES usuarios(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Lembretes de Faturas
CREATE TABLE lembretes_faturas (
    id INT PRIMARY KEY AUTO_INCREMENT,
    fatura_id INT NOT NULL,
    tipo ENUM('lancamento', 'pre_vencimento', 'vencimento', 'pos_vencimento') NOT NULL,
    enviado_whatsapp BOOLEAN DEFAULT FALSE,
    enviado_email BOOLEAN DEFAULT FALSE,
    data_envio DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (fatura_id) REFERENCES faturas(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Contas a Pagar
CREATE TABLE contas_pagar (
    id INT PRIMARY KEY AUTO_INCREMENT,
    fornecedor_id INT,
    empreendimento_id INT,
    descricao TEXT NOT NULL,
    valor DECIMAL(12,2) NOT NULL,
    data_vencimento DATE NOT NULL,
    data_pagamento DATE,
    status ENUM('pendente', 'pago', 'vencido', 'cancelado') DEFAULT 'pendente',
    numero_nota_fiscal VARCHAR(50),
    cidade VARCHAR(100),
    observacoes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (fornecedor_id) REFERENCES fornecedores(id),
    FOREIGN KEY (empreendimento_id) REFERENCES empreendimentos(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Ocorrências de Manutenção
CREATE TABLE ocorrencias_manutencao (
    id INT PRIMARY KEY AUTO_INCREMENT,
    empreendimento_id INT NOT NULL,
    encarregado_id INT NOT NULL,
    descricao TEXT NOT NULL,
    status ENUM('aberta', 'em_andamento', 'concluida', 'cancelada') DEFAULT 'aberta',
    prioridade ENUM('baixa', 'media', 'alta', 'urgente') DEFAULT 'media',
    data_abertura DATETIME NOT NULL,
    data_conclusao DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (empreendimento_id) REFERENCES empreendimentos(id),
    FOREIGN KEY (encarregado_id) REFERENCES usuarios(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Compras
CREATE TABLE compras (
    id INT PRIMARY KEY AUTO_INCREMENT,
    empreendimento_id INT NOT NULL,
    fornecedor_id INT,
    solicitante_id INT NOT NULL,
    descricao TEXT NOT NULL,
    status ENUM('solicitado', 'aprovado', 'comprado', 'entregue', 'cancelado') DEFAULT 'solicitado',
    prazo_entrega DATE,
    data_recebimento DATE,
    valor_total DECIMAL(12,2),
    observacoes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (empreendimento_id) REFERENCES empreendimentos(id),
    FOREIGN KEY (fornecedor_id) REFERENCES fornecedores(id),
    FOREIGN KEY (solicitante_id) REFERENCES usuarios(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Itens de Compra
CREATE TABLE itens_compra (
    id INT PRIMARY KEY AUTO_INCREMENT,
    compra_id INT NOT NULL,
    descricao VARCHAR(255) NOT NULL,
    quantidade DECIMAL(10,2) NOT NULL,
    unidade VARCHAR(20),
    valor_unitario DECIMAL(10,2),
    valor_total DECIMAL(12,2),
    
    FOREIGN KEY (compra_id) REFERENCES compras(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Orçamentos
CREATE TABLE orcamentos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    empreendimento_id INT NOT NULL,
    descricao VARCHAR(255) NOT NULL,
    valor_previsto DECIMAL(12,2) NOT NULL,
    valor_realizado DECIMAL(12,2) DEFAULT 0,
    categoria VARCHAR(100),
    status ENUM('planejado', 'em_execucao', 'concluido') DEFAULT 'planejado',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (empreendimento_id) REFERENCES empreendimentos(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Backups
CREATE TABLE backups (
    id INT PRIMARY KEY AUTO_INCREMENT,
    tipo ENUM('diario', 'semanal', 'mensal') NOT NULL,
    arquivo VARCHAR(255) NOT NULL,
    tamanho BIGINT,
    status ENUM('sucesso', 'erro') NOT NULL,
    mensagem TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Recuperação de Senha
CREATE TABLE IF NOT EXISTS password_resets (
    id INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(255) NOT NULL,
    token VARCHAR(255) NOT NULL,
    expires_at DATETIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_token (token),
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de Aniversários e Lembretes
CREATE TABLE lembretes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT NOT NULL,
    tipo ENUM('aniversario', 'ferias', 'documento', 'outro') NOT NULL,
    titulo VARCHAR(255) NOT NULL,
    descricao TEXT,
    data_lembrete DATE NOT NULL,
    enviado BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Índices para otimização
CREATE INDEX idx_faturas_status ON faturas(status);
CREATE INDEX idx_faturas_vencimento ON faturas(data_vencimento);
CREATE INDEX idx_contas_pagar_status ON contas_pagar(status);
CREATE INDEX idx_contas_pagar_vencimento ON contas_pagar(data_vencimento);
CREATE INDEX idx_imoveis_status ON imoveis(status);
CREATE INDEX idx_funcionarios_status ON funcionarios(status);
CREATE INDEX idx_usuarios_email ON usuarios(email);
CREATE INDEX idx_usuarios_cpf ON usuarios(cpf);

-- Criar usuário administrador padrão
INSERT INTO usuarios (nome_completo, email, senha, cpf, nivel_acesso_id) VALUES
('Administrador', 'admin@construtorakellesduarte.com.br', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '000.000.000-00', 1);
-- Senha padrão: password (deve ser alterada no primeiro acesso)
