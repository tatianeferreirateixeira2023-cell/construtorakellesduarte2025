-- Criar tabela de notificações se não existir
CREATE TABLE IF NOT EXISTS `notificacoes` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `usuario_id` int(11) NOT NULL,
    `titulo` varchar(255) NOT NULL,
    `mensagem` text NOT NULL,
    `tipo` enum('sistema','alerta','fatura','manutencao','obra') DEFAULT 'sistema',
    `link` varchar(255) DEFAULT NULL,
    `lida` tinyint(1) DEFAULT 0,
    `data_leitura` datetime DEFAULT NULL,
    `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_usuario_id` (`usuario_id`),
    KEY `idx_lida` (`lida`),
    KEY `idx_created_at` (`created_at`),
    KEY `idx_tipo` (`tipo`),
    CONSTRAINT `fk_notificacoes_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Inserir algumas notificações de exemplo
INSERT INTO `notificacoes` (`usuario_id`, `titulo`, `mensagem`, `tipo`, `lida`) 
SELECT 
    id,
    'Bem-vindo ao Sistema',
    'Seja bem-vindo ao novo sistema de gerenciamento da Construtora Kelles Duarte. Aqui você poderá acompanhar todas as suas informações.',
    'sistema',
    0
FROM usuarios 
WHERE NOT EXISTS (
    SELECT 1 FROM notificacoes WHERE usuario_id = usuarios.id AND titulo = 'Bem-vindo ao Sistema'
);

-- Criar índice para melhor performance
ALTER TABLE `notificacoes` ADD INDEX `idx_usuario_lida` (`usuario_id`, `lida`);
