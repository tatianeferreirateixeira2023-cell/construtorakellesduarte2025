-- Criar tabela de logs de acesso se não existir
CREATE TABLE IF NOT EXISTS `logs_acesso` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `usuario_id` int(11) DEFAULT NULL,
    `ip_address` varchar(45) DEFAULT NULL,
    `user_agent` text DEFAULT NULL,
    `pagina` varchar(255) DEFAULT NULL,
    `acao` varchar(100) DEFAULT NULL,
    `descricao` text DEFAULT NULL,
    `metodo` varchar(10) DEFAULT NULL,
    `dados` text DEFAULT NULL,
    `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_usuario_id` (`usuario_id`),
    KEY `idx_acao` (`acao`),
    KEY `idx_created_at` (`created_at`),
    KEY `idx_pagina` (`pagina`),
    CONSTRAINT `fk_logs_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Inserir alguns logs de exemplo
INSERT INTO `logs_acesso` (`usuario_id`, `ip_address`, `pagina`, `acao`, `descricao`) 
SELECT 
    id,
    '127.0.0.1',
    '/login',
    'login',
    CONCAT('Usuário ', nome_completo, ' fez login no sistema')
FROM usuarios 
WHERE NOT EXISTS (
    SELECT 1 FROM logs_acesso WHERE usuario_id = usuarios.id AND acao = 'login'
)
LIMIT 1;

-- Criar índice para melhor performance
ALTER TABLE `logs_acesso` ADD INDEX `idx_usuario_acao` (`usuario_id`, `acao`);
