<?php
abstract class Controller {
    protected $db;
    protected $user;
    protected $view;
    
    public function __construct() {
        $this->db = Database::getInstance();
        $this->loadUser();
        $this->view = new View();
    }
    
    // Carrega dados do usuário logado
    protected function loadUser() {
        if (isset($_SESSION['user_id'])) {
            $sql = "SELECT u.*, na.nome as nivel_nome 
                    FROM usuarios u 
                    JOIN niveis_acesso na ON u.nivel_acesso_id = na.id 
                    WHERE u.id = :id";
            $this->user = $this->db->fetchOne($sql, ['id' => $_SESSION['user_id']]);
        }
    }
    
    // Verifica se o usuário tem permissão para acessar o módulo
    protected function checkPermission($modulo, $acao = 'visualizar') {
        if (!$this->user) {
            $this->redirect('/login');
            return false;
        }
        
        // Admin tem acesso total
        if ($this->user['nivel_acesso_id'] == NIVEL_ADMIN) {
            return true;
        }
        
        $sql = "SELECT $acao FROM permissoes 
                WHERE nivel_acesso_id = :nivel_id 
                AND modulo = :modulo";
        
        $result = $this->db->fetchOne($sql, [
            'nivel_id' => $this->user['nivel_acesso_id'],
            'modulo' => $modulo
        ]);
        
        if (!$result || !$result[$acao]) {
            $this->setFlash('Você não tem permissão para acessar este recurso.', 'danger');
            $this->redirect('/');
            return false;
        }
        
        return true;
    }
    
    // Registra atividade no log
    protected function logActivity($acao, $descricao = '', $pagina = '') {
        if (!$this->user) return;
        
        $data = [
            'usuario_id' => $this->user['id'],
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'pagina' => $pagina ?: $_SERVER['REQUEST_URI'],
            'acao' => $acao,
            'descricao' => $descricao
        ];
        
        $this->db->insert('logs_acesso', $data);
    }
    
    // Define mensagem flash
    protected function setFlash($message, $type = 'info') {
        $_SESSION['flash'] = [
            'message' => $message,
            'type' => $type
        ];
    }
    
    // Obtém mensagem flash
    protected function getFlash() {
        if (isset($_SESSION['flash'])) {
            $flash = $_SESSION['flash'];
            unset($_SESSION['flash']);
            return $flash;
        }
        return null;
    }
    
    // Redireciona para outra página
    protected function redirect($url) {
        // Se a URL não começar com http, adiciona o BASE_PATH
        if (strpos($url, 'http') !== 0) {
            $url = BASE_PATH . $url;
        }
        header("Location: $url");
        exit;
    }
    
    // Valida dados de entrada
    protected function validate($data, $rules) {
        $errors = [];
        
        foreach ($rules as $field => $fieldRules) {
            $value = $data[$field] ?? null;
            
            foreach ($fieldRules as $rule) {
                if ($rule === 'required' && empty($value)) {
                    $errors[$field][] = "O campo é obrigatório.";
                }
                
                if ($rule === 'email' && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    $errors[$field][] = "E-mail inválido.";
                }
                
                if (strpos($rule, 'min:') === 0) {
                    $min = (int)substr($rule, 4);
                    if (strlen($value) < $min) {
                        $errors[$field][] = "Deve ter no mínimo $min caracteres.";
                    }
                }
                
                if (strpos($rule, 'max:') === 0) {
                    $max = (int)substr($rule, 4);
                    if (strlen($value) > $max) {
                        $errors[$field][] = "Deve ter no máximo $max caracteres.";
                    }
                }
                
                if ($rule === 'cpf' && !$this->validaCPF($value)) {
                    $errors[$field][] = "CPF inválido.";
                }
                
                if ($rule === 'cnpj' && !$this->validaCNPJ($value)) {
                    $errors[$field][] = "CNPJ inválido.";
                }
            }
        }
        
        return $errors;
    }
    
    // Valida CPF
    protected function validaCPF($cpf) {
        $cpf = preg_replace('/[^0-9]/', '', $cpf);
        
        if (strlen($cpf) != 11) return false;
        
        if (preg_match('/(\d)\1{10}/', $cpf)) return false;
        
        for ($t = 9; $t < 11; $t++) {
            for ($d = 0, $c = 0; $c < $t; $c++) {
                $d += $cpf[$c] * (($t + 1) - $c);
            }
            $d = ((10 * $d) % 11) % 10;
            if ($cpf[$c] != $d) return false;
        }
        
        return true;
    }
    
    // Valida CNPJ
    protected function validaCNPJ($cnpj) {
        $cnpj = preg_replace('/[^0-9]/', '', $cnpj);
        
        if (strlen($cnpj) != 14) return false;
        
        if (preg_match('/(\d)\1{13}/', $cnpj)) return false;
        
        $j = 5;
        $k = 6;
        $soma1 = 0;
        $soma2 = 0;
        
        for ($i = 0; $i < 13; $i++) {
            $j = ($j == 1) ? 9 : $j;
            $k = ($k == 1) ? 9 : $k;
            $soma2 += ($cnpj[$i] * $k);
            if ($i < 12) {
                $soma1 += ($cnpj[$i] * $j);
            }
            $k--;
            $j--;
        }
        
        $digito1 = ($soma1 % 11 < 2) ? 0 : 11 - $soma1 % 11;
        $digito2 = ($soma2 % 11 < 2) ? 0 : 11 - $soma2 % 11;
        
        return (($cnpj[12] == $digito1) && ($cnpj[13] == $digito2));
    }
    
    // Formata moeda brasileira
    protected function formatMoney($value) {
        return 'R$ ' . number_format($value, 2, ',', '.');
    }
    
    // Formata data brasileira
    protected function formatDate($date, $format = 'd/m/Y') {
        if (empty($date)) return '';
        return date($format, strtotime($date));
    }
    
    // Upload de arquivo
    protected function uploadFile($file, $directory, $allowedTypes = null) {
        if ($allowedTypes === null) {
            $allowedTypes = ALLOWED_EXTENSIONS;
        }
        
        $uploadPath = UPLOAD_PATH . $directory . '/';
        
        if (!file_exists($uploadPath)) {
            mkdir($uploadPath, 0777, true);
        }
        
        $fileName = uniqid() . '_' . basename($file['name']);
        $targetFile = $uploadPath . $fileName;
        $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
        
        // Verifica tipo de arquivo
        if (!in_array($fileType, $allowedTypes)) {
            return ['success' => false, 'message' => 'Tipo de arquivo não permitido.'];
        }
        
        // Verifica tamanho
        if ($file['size'] > MAX_FILE_SIZE) {
            return ['success' => false, 'message' => 'Arquivo muito grande.'];
        }
        
        // Move o arquivo
        if (move_uploaded_file($file['tmp_name'], $targetFile)) {
            return ['success' => true, 'filename' => $fileName, 'path' => $directory . '/' . $fileName];
        }
        
        return ['success' => false, 'message' => 'Erro ao fazer upload do arquivo.'];
    }
    
    // Envia e-mail
    protected function sendEmail($to, $subject, $body, $attachments = []) {
        // Implementar envio de e-mail com PHPMailer
        // Por enquanto, apenas registra no log
        $logFile = __DIR__ . '/../../logs/emails.log';
        $timestamp = date('Y-m-d H:i:s');
        $logMessage = "[$timestamp] Para: $to | Assunto: $subject" . PHP_EOL;
        
        if (!file_exists(dirname($logFile))) {
            mkdir(dirname($logFile), 0777, true);
        }
        
        file_put_contents($logFile, $logMessage, FILE_APPEND);
        
        return true;
    }
    
    // Envia mensagem WhatsApp
    protected function sendWhatsApp($number, $message) {
        // Implementar integração com API do WhatsApp
        // Por enquanto, apenas registra no log
        $logFile = __DIR__ . '/../../logs/whatsapp.log';
        $timestamp = date('Y-m-d H:i:s');
        $logMessage = "[$timestamp] Para: $number | Mensagem: $message" . PHP_EOL;
        
        if (!file_exists(dirname($logFile))) {
            mkdir(dirname($logFile), 0777, true);
        }
        
        file_put_contents($logFile, $logMessage, FILE_APPEND);
        
        return true;
    }
    
    // Responde com JSON
    protected function json($data, $statusCode = 200) {
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data);
        exit;
    }
}
