<?php
class View {
    private $data = [];
    
    public function set($key, $value) {
        $this->data[$key] = $value;
    }
    
    public function render($template, $data = []) {
        // Mescla dados
        $this->data = array_merge($this->data, $data);
        
        // Adiciona variáveis globais úteis
        $this->data['BASE_URL'] = BASE_URL;
        $this->data['BASE_PATH'] = BASE_PATH;
        
        // Extrai variáveis
        extract($this->data);
        
        // Carrega o template
        $templateFile = __DIR__ . '/../../views/' . $template . '.php';
        
        if (!file_exists($templateFile)) {
            throw new Exception("Template não encontrado: $template");
        }
        
        // Inicia buffer de saída
        ob_start();
        
        // Inclui header
        include __DIR__ . '/../../views/layouts/header.php';
        
        // Inclui o template
        include $templateFile;
        
        // Inclui footer
        include __DIR__ . '/../../views/layouts/footer.php';
        
        // Retorna conteúdo
        return ob_get_clean();
    }
    
    public function renderPartial($template, $data = []) {
        // Mescla dados
        $this->data = array_merge($this->data, $data);
        
        // Extrai variáveis
        extract($this->data);
        
        // Carrega o template
        $templateFile = __DIR__ . '/../../views/' . $template . '.php';
        
        if (!file_exists($templateFile)) {
            throw new Exception("Template não encontrado: $template");
        }
        
        // Inicia buffer de saída
        ob_start();
        
        // Inclui o template
        include $templateFile;
        
        // Retorna conteúdo
        return ob_get_clean();
    }
    
    // Helpers para a view
    public function escape($string) {
        return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
    }
    
    public function formatMoney($value) {
        return 'R$ ' . number_format($value, 2, ',', '.');
    }
    
    public function formatDate($date, $format = 'd/m/Y') {
        if (empty($date)) return '';
        return date($format, strtotime($date));
    }
    
    public function formatDateTime($datetime, $format = 'd/m/Y H:i') {
        if (empty($datetime)) return '';
        return date($format, strtotime($datetime));
    }
    
    public function formatCPF($cpf) {
        $cpf = preg_replace('/[^0-9]/', '', $cpf);
        return substr($cpf, 0, 3) . '.' . substr($cpf, 3, 3) . '.' . substr($cpf, 6, 3) . '-' . substr($cpf, 9, 2);
    }
    
    public function formatCNPJ($cnpj) {
        $cnpj = preg_replace('/[^0-9]/', '', $cnpj);
        return substr($cnpj, 0, 2) . '.' . substr($cnpj, 2, 3) . '.' . substr($cnpj, 5, 3) . '/' . substr($cnpj, 8, 4) . '-' . substr($cnpj, 12, 2);
    }
    
    public function formatPhone($phone) {
        $phone = preg_replace('/[^0-9]/', '', $phone);
        if (strlen($phone) == 11) {
            return '(' . substr($phone, 0, 2) . ') ' . substr($phone, 2, 5) . '-' . substr($phone, 7, 4);
        } else {
            return '(' . substr($phone, 0, 2) . ') ' . substr($phone, 2, 4) . '-' . substr($phone, 6, 4);
        }
    }
    
    public function truncate($string, $length = 100, $append = '...') {
        if (strlen($string) > $length) {
            return substr($string, 0, $length) . $append;
        }
        return $string;
    }
}
