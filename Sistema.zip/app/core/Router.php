<?php
class Router {
    private $routes = [];
    private $params = [];
    
    public function addRoute($path, $handler) {
        $this->routes[$path] = $handler;
    }
    
    public function dispatch($uri) {
        // Remove query string
        $uri = parse_url($uri, PHP_URL_PATH);
        
        // Garante que a URI comece com /
        if (empty($uri)) {
            $uri = '/';
        } elseif ($uri[0] !== '/') {
            $uri = '/' . $uri;
        }
        
        // Procura rota exata
        if (isset($this->routes[$uri])) {
            return $this->handleRoute($this->routes[$uri]);
        }
        
        // Procura rotas com parâmetros
        foreach ($this->routes as $route => $handler) {
            $pattern = $this->convertRouteToRegex($route);
            if (preg_match($pattern, $uri, $matches)) {
                array_shift($matches);
                $this->params = $matches;
                return $this->handleRoute($handler);
            }
        }
        
        // Rota não encontrada
        $this->notFound();
    }
    
    private function handleRoute($handler) {
        list($controller, $method) = explode('@', $handler);
        
        $controllerFile = __DIR__ . '/../controllers/' . $controller . '.php';
        
        if (!file_exists($controllerFile)) {
            $this->notFound();
        }
        
        require_once $controllerFile;
        
        if (!class_exists($controller)) {
            $this->notFound();
        }
        
        $controllerInstance = new $controller();
        
        if (!method_exists($controllerInstance, $method)) {
            $this->notFound();
        }
        
        // Chama o método do controller com os parâmetros
        call_user_func_array([$controllerInstance, $method], $this->params);
    }
    
    private function convertRouteToRegex($route) {
        // Converte :param para regex
        $pattern = preg_replace('/:[a-zA-Z0-9_]+/', '([a-zA-Z0-9_]+)', $route);
        return '#^' . $pattern . '$#';
    }
    
    private function notFound() {
        http_response_code(404);
        require_once __DIR__ . '/../../views/errors/404.php';
        exit;
    }
    
    public function get($path, $handler) {
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $this->addRoute($path, $handler);
        }
    }
    
    public function post($path, $handler) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->addRoute($path, $handler);
        }
    }
    
    public function put($path, $handler) {
        if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
            $this->addRoute($path, $handler);
        }
    }
    
    public function delete($path, $handler) {
        if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
            $this->addRoute($path, $handler);
        }
    }
}
