<?php
/**
 * Autoloader simples para carregar classes automaticamente
 */

// Carrega helpers
$helpers = [
    __DIR__ . '/helpers/url_helper.php'
];

foreach ($helpers as $helper) {
    if (file_exists($helper)) {
        require_once $helper;
    }
}

spl_autoload_register(function ($class) {
    // Diretórios onde procurar as classes
    $directories = [
        __DIR__ . '/core/',
        __DIR__ . '/controllers/',
        __DIR__ . '/services/',
        __DIR__ . '/models/'
    ];
    
    // Procura a classe em cada diretório
    foreach ($directories as $directory) {
        $file = $directory . $class . '.php';
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
    
    // Se não encontrar, tenta no vendor (se existir)
    $vendorFile = __DIR__ . '/../vendor/autoload.php';
    if (file_exists($vendorFile)) {
        require_once $vendorFile;
    }
});
