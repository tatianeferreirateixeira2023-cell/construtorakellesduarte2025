<?php

class Empreendimento {
    private $db;
    
    // Status possíveis
    const STATUS_PLANEJAMENTO = 'planejamento';
    const STATUS_EM_ANDAMENTO = 'em_andamento';
    const STATUS_CONCLUIDO = 'concluido';
    const STATUS_SUSPENSO = 'suspenso';
    
    // Tipos de empreendimento
    const TIPO_RESIDENCIAL = 'residencial';
    const TIPO_COMERCIAL = 'comercial';
    const TIPO_INDUSTRIAL = 'industrial';
    const TIPO_MISTO = 'misto';
    
    public function __construct($db) {
        $this->db = $db;
    }
    
    /**
     * Retorna todos os status disponíveis
     */
    public static function getStatusList() {
        return [
            self::STATUS_PLANEJAMENTO => 'Em Planejamento',
            self::STATUS_EM_ANDAMENTO => 'Em Andamento',
            self::STATUS_CONCLUIDO => 'Concluído',
            self::STATUS_SUSPENSO => 'Suspenso'
        ];
    }
    
    /**
     * Retorna os tipos de empreendimento disponíveis
     */
    public static function getTipos() {
        return [
            self::TIPO_RESIDENCIAL => 'Residencial',
            self::TIPO_COMERCIAL => 'Comercial',
            self::TIPO_INDUSTRIAL => 'Industrial',
            self::TIPO_MISTO => 'Misto'
        ];
    }
    
    /**
     * Busca um empreendimento pelo ID
     */
    public function find($id) {
        $sql = "SELECT e.*, 
                       u.nome_completo as encarregado_nome,
                       (SELECT COUNT(*) FROM imoveis WHERE empreendimento_id = e.id) as total_imoveis,
                       (SELECT COUNT(*) FROM imoveis WHERE empreendimento_id = e.id AND status = 'vendido') as imoveis_vendidos
                FROM empreendimentos e
                LEFT JOIN usuarios u ON e.encarregado_id = u.id
                WHERE e.id = :id";
                
        return $this->db->fetchOne($sql, ['id' => $id]);
    }
    
    /**
     * Lista todos os empreendimentos com paginação
     */
    public function paginate($page = 1, $perPage = 15, $filters = []) {
        $offset = ($page - 1) * $perPage;
        
        $where = '1=1';
        $params = [];
        
        // Filtros
        if (!empty($filters['nome'])) {
            $where .= " AND e.nome LIKE :nome";
            $params['nome'] = "%{$filters['nome']}%";
        }
        
        if (!empty($filters['cidade'])) {
            $where .= " AND e.cidade LIKE :cidade";
            $params['cidade'] = "%{$filters['cidade']}%";
        }
        
        if (!empty($filters['status'])) {
            $where .= " AND e.status = :status";
            $params['status'] = $filters['status'];
        }
        
        // Conta total de registros
        $total = $this->db->count('empreendimentos e', $where, $params);
        
        // Busca os registros
        $sql = "SELECT e.*, 
                       u.nome_completo as encarregado_nome,
                       (SELECT COUNT(*) FROM imoveis WHERE empreendimento_id = e.id) as total_imoveis,
                       (SELECT COUNT(*) FROM imoveis WHERE empreendimento_id = e.id AND status = 'vendido') as imoveis_vendidos
                FROM empreendimentos e
                LEFT JOIN usuarios u ON e.encarregado_id = u.id
                WHERE $where
                ORDER BY e.created_at DESC
                LIMIT $perPage OFFSET $offset";
                
        $empreendimentos = $this->db->fetchAll($sql, $params);
        
        return [
            'data' => $empreendimentos,
            'total' => $total,
            'per_page' => $perPage,
            'current_page' => $page,
            'last_page' => ceil($total / $perPage)
        ];
    }
    
    /**
     * Cria um novo empreendimento
     */
    public function create(array $data) {
        $data = $this->prepareData($data);
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['updated_at'] = date('Y-m-d H:i:s');
        
        return $this->db->insert('empreendimentos', $data);
    }
    
    /**
     * Atualiza um empreendimento existente
     */
    public function update($id, array $data) {
        $data = $this->prepareData($data);
        $data['updated_at'] = date('Y-m-d H:i:s');
        
        return $this->db->update('empreendimentos', $data, ['id' => $id]);
    }
    
    /**
     * Remove um empreendimento
     */
    public function delete($id) {
        // Verifica se existem imóveis vinculados
        $count = $this->db->count('imoveis', 'empreendimento_id = :id', ['id' => $id]);
        
        if ($count > 0) {
            throw new Exception('Não é possível excluir um empreendimento que possui imóveis vinculados.');
        }
        
        return $this->db->delete('empreendimentos', ['id' => $id]);
    }
    
    /**
     * Prepara os dados para inserção/atualização
     */
    private function prepareData(array $data) {
        $fields = [
            'nome', 'cidade', 'endereco', 'cno', 'engenheiro_nome', 'engenheiro_art',
            'arquiteto_nome', 'arquiteto_cau', 'art_execucao', 'encarregado_id', 'status',
            'tipo', 'area_total', 'area_privativa', 'area_comum', 'torres', 'unidades_por_andar',
            'total_unidades', 'data_inicio', 'previsao_termino', 'data_entrega', 'descricao'
        ];
        
        $prepared = [];
        
        foreach ($fields as $field) {
            if (isset($data[$field])) {
                $prepared[$field] = is_string($data[$field]) ? trim($data[$field]) : $data[$field];
                
                // Converte strings vazias para NULL
                if ($prepared[$field] === '') {
                    $prepared[$field] = null;
                }
            }
        }
        
        return $prepared;
    }
    
    /**
     * Busca documentos de um empreendimento
     */
    public function getDocumentos($empreendimentoId) {
        $sql = "SELECT * FROM empreendimento_documentos 
                WHERE empreendimento_id = :id 
                ORDER BY tipo, nome";
                
        return $this->db->fetchAll($sql, ['id' => $empreendimentoId]);
    }
    
    /**
     * Adiciona um documento ao empreendimento
     */
    public function adicionarDocumento($empreendimentoId, $dados) {
        $dados['empreendimento_id'] = $empreendimentoId;
        $dados['data_upload'] = date('Y-m-d H:i:s');
        
        return $this->db->insert('empreendimento_documentos', $dados);
    }
    
    /**
     * Remove um documento do empreendimento
     */
    public function removerDocumento($documentoId) {
        // Primeiro busca o documento para obter o caminho do arquivo
        $documento = $this->db->fetchOne("SELECT * FROM empreendimento_documentos WHERE id = :id", ['id' => $documentoId]);
        
        if ($documento) {
            // Remove o arquivo físico se existir
            $caminhoArquivo = __DIR__ . "/../../uploads/empreendimentos/{$documento['empreendimento_id']}/{$documento['arquivo']}";
            if (file_exists($caminhoArquivo)) {
                @unlink($caminhoArquivo);
            }
            
            // Remove o registro do banco
            return $this->db->delete('empreendimento_documentos', ['id' => $documentoId]);
        }
        
        return false;
    }
    
    /**
     * Busca estatísticas dos empreendimentos
     */
    public function getEstatisticas() {
        // Total de empreendimentos por status
        $status = $this->db->fetchAll(
            "SELECT status, COUNT(*) as total 
             FROM empreendimentos 
             GROUP BY status"
        );
        
        // Total de imóveis por empreendimento
        $imoveis = $this->db->fetchAll(
            "SELECT e.id, e.nome, COUNT(i.id) as total_imoveis
             FROM empreendimentos e
             LEFT JOIN imoveis i ON e.id = i.empreendimento_id
             GROUP BY e.id, e.nome
             ORDER BY e.nome"
        );
        
        // Total de imóveis vendidos por empreendimento
        $vendas = $this->db->fetchAll(
            "SELECT e.id, e.nome, COUNT(i.id) as vendidos
             FROM empreendimentos e
             LEFT JOIN imoveis i ON e.id = i.empreendimento_id AND i.status = 'vendido'
             GROUP BY e.id, e.nome
             ORDER BY e.nome"
        );
        
        return [
            'status' => $status,
            'imoveis' => $imoveis,
            'vendas' => $vendas
        ];
    }
}
