<?php
/**
 * Helper de Segurança
 * Fornece funções para gerenciar tokens CSRF e outras funcionalidades de segurança
 */

/**
 * Gera um token CSRF se não existir e o retorna
 * 
 * @return string Token CSRF
 */
function generateCsrfToken() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        $_SESSION['csrf_token_time'] = time();
    }
    
    return $_SESSION['csrf_token'];
}

/**
 * Valida um token CSRF
 * 
 * @param string $token Token a ser validado
 * @param int $timeout Tempo de expiração em segundos (padrão: 1 hora)
 * @return bool True se o token for válido, false caso contrário
 */
function validateCsrfToken($token, $timeout = 3600) {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    // Se não houver token na sessão, retorna falso
    if (empty($_SESSION['csrf_token'])) {
        return false;
    }
    
    // Verifica se o token expirou
    $tokenTime = $_SESSION['csrf_token_time'] ?? 0;
    if (time() - $tokenTime > $timeout) {
        clearCsrfToken();
        return false;
    }
    
    // Verifica se o token é válido
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Limpa o token CSRF da sessão
 */
function clearCsrfToken() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    unset($_SESSION['csrf_token']);
    unset($_SESSION['csrf_token_time']);
}

/**
 * Processa os dados do formulário, removendo campos vazios e aplicando trim
 * 
 * @param array $data Dados do formulário
 * @return array Dados processados
 */
function processFormData($data) {
    $processed = [];
    
    foreach ($data as $key => $value) {
        // Remove espaços em branco no início e no fim
        if (is_string($value)) {
            $value = trim($value);
        }
        
        // Converte string 'true'/'false' para booleanos
        if ($value === 'true') {
            $value = true;
        } elseif ($value === 'false') {
            $value = false;
        }
        
        // Converte string vazia para null, exceto para campos de senha
        if ($value === '' && strpos($key, 'password') === false) {
            $value = null;
        }
        
        $processed[$key] = $value;
    }
    
    return $processed;
}

/**
 * Retorna o HTML para um campo de token CSRF
 * 
 * @return string HTML do campo de token CSRF
 */
function csrfField() {
    $token = generateCsrfToken();
    return '<input type="hidden" name="csrf_token" value="' . $token . '">';
}

/**
 * Valida o token CSRF enviado via POST
 * 
 * @param string $formToken Token do formulário (opcional, pega do $_POST['csrf_token'] por padrão)
 * @return bool True se o token for válido, false caso contrário
 */
function validateCsrfForm($formToken = null) {
    if ($formToken === null) {
        $formToken = $_POST['csrf_token'] ?? '';
    }
    
    return validateCsrfToken($formToken);
}
