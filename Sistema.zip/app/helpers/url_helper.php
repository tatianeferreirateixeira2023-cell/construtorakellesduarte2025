<?php
/**
 * Helper de URLs para o sistema
 * Facilita o uso de URLs absolutas em todo o sistema
 */

/**
 * Retorna a URL base do sistema
 */
function base_url($path = '') {
    return BASE_URL . ltrim($path, '/');
}

/**
 * Retorna o caminho base do sistema (para links internos)
 */
function base_path($path = '') {
    if (empty($path) || $path === '/') {
        return BASE_PATH;
    }
    return BASE_PATH . '/' . ltrim($path, '/');
}

/**
 * Função simplificada para URLs (alias de base_path)
 */
function url($path = '') {
    return base_path($path);
}

/**
 * Retorna a URL completa para assets
 */
function asset_url($path) {
    return BASE_URL . 'assets/' . ltrim($path, '/');
}

/**
 * Retorna a URL para imagens
 */
function img_url($path) {
    return BASE_URL . 'assets/img/' . ltrim($path, '/');
}

/**
 * Retorna a URL para CSS
 */
function css_url($path) {
    return BASE_URL . 'assets/css/' . ltrim($path, '/');
}

/**
 * Retorna a URL para JavaScript
 */
function js_url($path) {
    return BASE_URL . 'assets/js/' . ltrim($path, '/');
}

/**
 * Retorna a URL para uploads
 */
function upload_url($path) {
    return BASE_URL . 'uploads/' . ltrim($path, '/');
}

/**
 * Redireciona para uma URL interna
 */
function redirect_to($path) {
    header('Location: ' . base_path($path));
    exit;
}

/**
 * Verifica se a URL atual corresponde ao path
 */
function is_current_page($path) {
    $current = $_SERVER['REQUEST_URI'];
    $check = BASE_PATH . '/' . ltrim($path, '/');
    return $current === $check;
}

/**
 * Retorna classe 'active' se for a página atual
 */
function active_class($path) {
    return is_current_page($path) ? 'active' : '';
}

/**
 * Gera URL para API
 */
function api_url($endpoint) {
    return BASE_URL . 'api/' . ltrim($endpoint, '/');
}

/**
 * Gera link HTML
 */
function link_to($path, $text, $attributes = []) {
    $url = base_path($path);
    $attrs = '';
    
    foreach ($attributes as $key => $value) {
        $attrs .= ' ' . $key . '="' . htmlspecialchars($value) . '"';
    }
    
    return '<a href="' . $url . '"' . $attrs . '>' . htmlspecialchars($text) . '</a>';
}

/**
 * Gera tag de imagem HTML
 */
function img_tag($path, $alt = '', $attributes = []) {
    $url = img_url($path);
    $attrs = '';
    
    foreach ($attributes as $key => $value) {
        $attrs .= ' ' . $key . '="' . htmlspecialchars($value) . '"';
    }
    
    return '<img src="' . $url . '" alt="' . htmlspecialchars($alt) . '"' . $attrs . '>';
}
