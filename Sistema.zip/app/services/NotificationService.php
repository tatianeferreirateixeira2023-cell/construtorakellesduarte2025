<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

class NotificationService {
    private $db;
    private $mailer;
    
    public function __construct() {
        $this->db = Database::getInstance();
        $this->setupMailer();
    }
    
    private function setupMailer() {
        require_once __DIR__ . '/../../vendor/autoload.php';
        
        $this->mailer = new PHPMailer(true);
        
        // Configurações do servidor
        $this->mailer->isSMTP();
        $this->mailer->Host = SMTP_HOST;
        $this->mailer->SMTPAuth = true;
        $this->mailer->Username = SMTP_USER;
        $this->mailer->Password = SMTP_PASS;
        $this->mailer->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $this->mailer->Port = SMTP_PORT;
        $this->mailer->CharSet = 'UTF-8';
        
        // Remetente padrão
        $this->mailer->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
    }
    
    // ENVIO DE E-MAIL
    public function sendEmail($to, $subject, $body, $attachments = [], $isHtml = false) {
        try {
            // Limpa destinatários anteriores
            $this->mailer->clearAddresses();
            $this->mailer->clearAttachments();
            
            // Adiciona destinatário
            if (is_array($to)) {
                foreach ($to as $email => $name) {
                    $this->mailer->addAddress($email, $name);
                }
            } else {
                $this->mailer->addAddress($to);
            }
            
            // Assunto e corpo
            $this->mailer->Subject = $subject;
            
            if ($isHtml) {
                $this->mailer->isHTML(true);
                $this->mailer->Body = $body;
                $this->mailer->AltBody = strip_tags($body);
            } else {
                $this->mailer->isHTML(false);
                $this->mailer->Body = $body;
            }
            
            // Anexos
            foreach ($attachments as $attachment) {
                if (file_exists($attachment)) {
                    $this->mailer->addAttachment($attachment);
                }
            }
            
            // Envia
            $result = $this->mailer->send();
            
            // Registra no log
            $this->logEmail($to, $subject, $result);
            
            return $result;
            
        } catch (Exception $e) {
            $this->logError("Erro ao enviar e-mail: {$this->mailer->ErrorInfo}");
            return false;
        }
    }
    
    // ENVIO DE WHATSAPP
    public function sendWhatsApp($number, $message, $mediaUrl = null) {
        // Remove caracteres não numéricos
        $number = preg_replace('/[^0-9]/', '', $number);
        
        // Adiciona código do país se não tiver
        if (strlen($number) == 11) {
            $number = '55' . $number;
        }
        
        // Prepara dados para API
        $data = [
            'phone' => $number,
            'message' => $message
        ];
        
        if ($mediaUrl) {
            $data['media_url'] = $mediaUrl;
        }
        
        // Envia via API (exemplo com API genérica)
        $result = $this->sendToWhatsAppAPI($data);
        
        // Registra no log
        $this->logWhatsApp($number, $message, $result);
        
        return $result;
    }
    
    private function sendToWhatsAppAPI($data) {
        if (empty(WHATSAPP_API_URL) || empty(WHATSAPP_TOKEN)) {
            $this->logError("API WhatsApp não configurada");
            return false;
        }
        
        $ch = curl_init();
        
        curl_setopt($ch, CURLOPT_URL, WHATSAPP_API_URL . '/send');
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . WHATSAPP_TOKEN
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return $httpCode == 200;
    }
    
    // NOTIFICAÇÕES DE FATURAS
    public function notificarVencimentoFatura($faturaId) {
        $sql = "SELECT f.*, u.nome_completo, u.email, u.telefone, i.id as imovel_ref
                FROM faturas f
                JOIN usuarios u ON f.cliente_id = u.id
                JOIN imoveis i ON f.imovel_id = i.id
                WHERE f.id = :id";
        
        $fatura = $this->db->fetchOne($sql, ['id' => $faturaId]);
        
        if (!$fatura) return false;
        
        $diasRestantes = (strtotime($fatura['data_vencimento']) - time()) / 86400;
        
        // E-mail
        $subject = "Lembrete de Vencimento - Fatura #{$fatura['numero_fatura']}";
        
        if ($diasRestantes == 1) {
            $body = "Olá {$fatura['nome_completo']},\n\n";
            $body .= "Sua fatura vence AMANHÃ!\n\n";
        } elseif ($diasRestantes == 0) {
            $body = "Olá {$fatura['nome_completo']},\n\n";
            $body .= "Sua fatura vence HOJE!\n\n";
        } else {
            $body = "Olá {$fatura['nome_completo']},\n\n";
            $body .= "Sua fatura está VENCIDA há " . abs($diasRestantes) . " dias!\n\n";
        }
        
        $body .= "Detalhes da Fatura:\n";
        $body .= "Número: #{$fatura['numero_fatura']}\n";
        $body .= "Valor: " . $this->formatMoney($fatura['valor']) . "\n";
        $body .= "Vencimento: " . $this->formatDate($fatura['data_vencimento']) . "\n\n";
        $body .= "Para pagamento via PIX, use o CNPJ: " . PIX_CNPJ . "\n";
        $body .= "Ou acesse o sistema para gerar o boleto.\n\n";
        $body .= "Construtora Kelles Duarte";
        
        $this->sendEmail($fatura['email'], $subject, $body);
        
        // WhatsApp
        $whatsappMsg = "🏠 *Construtora Kelles Duarte*\n\n";
        
        if ($diasRestantes == 1) {
            $whatsappMsg .= "⚠️ Sua fatura vence *AMANHÃ*!\n\n";
        } elseif ($diasRestantes == 0) {
            $whatsappMsg .= "⚠️ Sua fatura vence *HOJE*!\n\n";
        } else {
            $whatsappMsg .= "🚨 Sua fatura está *VENCIDA*!\n\n";
        }
        
        $whatsappMsg .= "📄 Fatura: #{$fatura['numero_fatura']}\n";
        $whatsappMsg .= "💰 Valor: " . $this->formatMoney($fatura['valor']) . "\n";
        $whatsappMsg .= "📅 Vencimento: " . $this->formatDate($fatura['data_vencimento']) . "\n\n";
        $whatsappMsg .= "Para pagar:\n";
        $whatsappMsg .= "• PIX CNPJ: " . PIX_CNPJ . "\n";
        $whatsappMsg .= "• Ou acesse o sistema para boleto";
        
        $this->sendWhatsApp($fatura['telefone'], $whatsappMsg);
        
        // Registra envio
        $this->db->insert('lembretes_faturas', [
            'fatura_id' => $faturaId,
            'tipo' => $diasRestantes > 0 ? 'pre_vencimento' : ($diasRestantes == 0 ? 'vencimento' : 'pos_vencimento'),
            'enviado_whatsapp' => 1,
            'enviado_email' => 1,
            'data_envio' => date('Y-m-d H:i:s')
        ]);
        
        return true;
    }
    
    // NOTIFICAÇÕES DE ANIVERSÁRIO
    public function notificarAniversarios() {
        $sql = "SELECT * FROM usuarios 
                WHERE DAY(data_nascimento) = DAY(CURDATE()) 
                AND MONTH(data_nascimento) = MONTH(CURDATE())";
        
        $aniversariantes = $this->db->fetchAll($sql);
        
        foreach ($aniversariantes as $pessoa) {
            $idade = date('Y') - date('Y', strtotime($pessoa['data_nascimento']));
            
            // E-mail
            $subject = "🎂 Feliz Aniversário!";
            $body = "Olá {$pessoa['nome_completo']},\n\n";
            $body .= "A Construtora Kelles Duarte deseja a você um FELIZ ANIVERSÁRIO!\n\n";
            $body .= "Que este novo ano de vida seja repleto de realizações, ";
            $body .= "saúde e muitas alegrias!\n\n";
            $body .= "Parabéns pelos seus $idade anos!\n\n";
            $body .= "Com carinho,\n";
            $body .= "Equipe Construtora Kelles Duarte";
            
            $this->sendEmail($pessoa['email'], $subject, $body);
            
            // WhatsApp
            $whatsappMsg = "🎉🎂 *FELIZ ANIVERSÁRIO!* 🎂🎉\n\n";
            $whatsappMsg .= "Olá *{$pessoa['nome_completo']}*!\n\n";
            $whatsappMsg .= "A Construtora Kelles Duarte deseja a você um dia muito especial!\n\n";
            $whatsappMsg .= "Parabéns pelos seus *$idade anos*! 🎊\n\n";
            $whatsappMsg .= "Que Deus abençoe sua vida com muita saúde, paz e prosperidade! 🙏\n\n";
            $whatsappMsg .= "_Equipe Construtora Kelles Duarte_ 🏠";
            
            $this->sendWhatsApp($pessoa['telefone'], $whatsappMsg);
            
            // Registra lembrete enviado
            $this->db->insert('lembretes', [
                'usuario_id' => $pessoa['id'],
                'tipo' => 'aniversario',
                'titulo' => 'Aniversário',
                'descricao' => "Parabéns enviado para {$pessoa['nome_completo']}",
                'data_lembrete' => date('Y-m-d'),
                'enviado' => 1
            ]);
        }
    }
    
    // NOTIFICAÇÃO DE NOVA FATURA GERADA
    public function notificarNovaFatura($faturaId) {
        $sql = "SELECT f.*, u.nome_completo, u.email, u.telefone
                FROM faturas f
                JOIN usuarios u ON f.cliente_id = u.id
                WHERE f.id = :id";
        
        $fatura = $this->db->fetchOne($sql, ['id' => $faturaId]);
        
        if (!$fatura) return false;
        
        // E-mail
        $subject = "Nova Fatura Disponível - #{$fatura['numero_fatura']}";
        $body = "Olá {$fatura['nome_completo']},\n\n";
        $body .= "Uma nova fatura foi gerada para você.\n\n";
        $body .= "Detalhes:\n";
        $body .= "Número: #{$fatura['numero_fatura']}\n";
        $body .= "Valor: " . $this->formatMoney($fatura['valor']) . "\n";
        $body .= "Vencimento: " . $this->formatDate($fatura['data_vencimento']) . "\n\n";
        $body .= "Acesse o sistema para visualizar e efetuar o pagamento.\n\n";
        $body .= "Construtora Kelles Duarte";
        
        $this->sendEmail($fatura['email'], $subject, $body);
        
        // WhatsApp
        $whatsappMsg = "📄 *Nova Fatura Disponível*\n\n";
        $whatsappMsg .= "Olá, {$fatura['nome_completo']}!\n\n";
        $whatsappMsg .= "Fatura: #{$fatura['numero_fatura']}\n";
        $whatsappMsg .= "Valor: " . $this->formatMoney($fatura['valor']) . "\n";
        $whatsappMsg .= "Vencimento: " . $this->formatDate($fatura['data_vencimento']) . "\n\n";
        $whatsappMsg .= "Acesse o sistema para mais detalhes.";
        
        $this->sendWhatsApp($fatura['telefone'], $whatsappMsg);
        
        return true;
    }
    
    // LOGS
    private function logEmail($to, $subject, $success) {
        $logFile = __DIR__ . '/../../logs/emails.log';
        $timestamp = date('Y-m-d H:i:s');
        $status = $success ? 'SUCCESS' : 'FAILED';
        $toStr = is_array($to) ? implode(', ', array_keys($to)) : $to;
        
        $logMessage = "[$timestamp] [$status] To: $toStr | Subject: $subject\n";
        
        if (!file_exists(dirname($logFile))) {
            mkdir(dirname($logFile), 0777, true);
        }
        
        file_put_contents($logFile, $logMessage, FILE_APPEND);
    }
    
    private function logWhatsApp($number, $message, $success) {
        $logFile = __DIR__ . '/../../logs/whatsapp.log';
        $timestamp = date('Y-m-d H:i:s');
        $status = $success ? 'SUCCESS' : 'FAILED';
        $messagePreview = substr($message, 0, 50) . '...';
        
        $logMessage = "[$timestamp] [$status] To: $number | Message: $messagePreview\n";
        
        if (!file_exists(dirname($logFile))) {
            mkdir(dirname($logFile), 0777, true);
        }
        
        file_put_contents($logFile, $logMessage, FILE_APPEND);
    }
    
    private function logError($message) {
        $logFile = __DIR__ . '/../../logs/notification_errors.log';
        $timestamp = date('Y-m-d H:i:s');
        
        $logMessage = "[$timestamp] ERROR: $message\n";
        
        if (!file_exists(dirname($logFile))) {
            mkdir(dirname($logFile), 0777, true);
        }
        
        file_put_contents($logFile, $logMessage, FILE_APPEND);
    }
    
    // Helpers
    private function formatMoney($value) {
        return 'R$ ' . number_format($value, 2, ',', '.');
    }
    
    private function formatDate($date) {
        return date('d/m/Y', strtotime($date));
    }
}
