<?php
require_once __DIR__ . '/../core/Controller.php';

class NotificacaoController extends Controller {
    
    public function index() {
        if (!$this->user) {
            $this->redirect('/login');
            return;
        }
        
        $page = $_GET['page'] ?? 1;
        $limit = 20;
        $offset = ($page - 1) * $limit;
        
        // Busca notificações do usuário
        $sql = "SELECT n.*, 
                CASE 
                    WHEN n.tipo = 'fatura' THEN 'fa-file-invoice-dollar'
                    WHEN n.tipo = 'manutencao' THEN 'fa-tools'
                    WHEN n.tipo = 'obra' THEN 'fa-hard-hat'
                    WHEN n.tipo = 'sistema' THEN 'fa-info-circle'
                    WHEN n.tipo = 'alerta' THEN 'fa-exclamation-triangle'
                    ELSE 'fa-bell'
                END as icone,
                CASE 
                    WHEN n.tipo = 'fatura' THEN 'text-success'
                    WHEN n.tipo = 'manutencao' THEN 'text-warning'
                    WHEN n.tipo = 'obra' THEN 'text-info'
                    WHEN n.tipo = 'alerta' THEN 'text-danger'
                    ELSE 'text-primary'
                END as cor
                FROM notificacoes n
                WHERE n.usuario_id = :usuario_id
                ORDER BY n.lida ASC, n.created_at DESC
                LIMIT $limit OFFSET $offset";
        
        $notificacoes = $this->db->fetchAll($sql, ['usuario_id' => $this->user['id']]);
        
        // Total para paginação
        $total = $this->db->count('notificacoes', 'usuario_id = :usuario_id', ['usuario_id' => $this->user['id']]);
        $totalPages = ceil($total / $limit);
        
        // Conta notificações não lidas
        $naoLidas = $this->db->count('notificacoes', 'usuario_id = :usuario_id AND lida = 0', ['usuario_id' => $this->user['id']]);
        
        $data = [
            'notificacoes' => $notificacoes,
            'naoLidas' => $naoLidas,
            'pagination' => [
                'current' => $page,
                'total' => $totalPages,
                'limit' => $limit,
                'total_records' => $total
            ],
            'flash' => $this->getFlash()
        ];
        
        echo $this->view->render('notificacoes/index', $data);
    }
    
    public function marcarLida() {
        if (!$this->user) {
            echo json_encode(['success' => false, 'message' => 'Não autorizado']);
            return;
        }
        
        $id = $_POST['id'] ?? null;
        
        if (!$id) {
            echo json_encode(['success' => false, 'message' => 'ID não fornecido']);
            return;
        }
        
        // Verifica se a notificação pertence ao usuário
        $notificacao = $this->db->fetchOne(
            "SELECT * FROM notificacoes WHERE id = :id AND usuario_id = :usuario_id",
            ['id' => $id, 'usuario_id' => $this->user['id']]
        );
        
        if (!$notificacao) {
            echo json_encode(['success' => false, 'message' => 'Notificação não encontrada']);
            return;
        }
        
        // Marca como lida
        $updated = $this->db->update('notificacoes', 
            ['lida' => 1, 'data_leitura' => date('Y-m-d H:i:s')],
            ['id' => $id]
        );
        
        if ($updated) {
            echo json_encode(['success' => true, 'message' => 'Notificação marcada como lida']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao atualizar notificação']);
        }
    }
    
    public function marcarTodasLidas() {
        if (!$this->user) {
            $this->setFlash('Acesso não autorizado.', 'danger');
            $this->redirect('/login');
            return;
        }
        
        $sql = "UPDATE notificacoes 
                SET lida = 1, data_leitura = NOW() 
                WHERE usuario_id = :usuario_id AND lida = 0";
        
        $this->db->execute($sql, ['usuario_id' => $this->user['id']]);
        
        $this->setFlash('Todas as notificações foram marcadas como lidas.', 'success');
        $this->redirect('/notificacoes');
    }
    
    public function excluir($id) {
        if (!$this->user) {
            $this->setFlash('Acesso não autorizado.', 'danger');
            $this->redirect('/login');
            return;
        }
        
        // Verifica se a notificação pertence ao usuário
        $notificacao = $this->db->fetchOne(
            "SELECT * FROM notificacoes WHERE id = :id AND usuario_id = :usuario_id",
            ['id' => $id, 'usuario_id' => $this->user['id']]
        );
        
        if (!$notificacao) {
            $this->setFlash('Notificação não encontrada.', 'danger');
            $this->redirect('/notificacoes');
            return;
        }
        
        // Exclui a notificação
        $deleted = $this->db->delete('notificacoes', ['id' => $id]);
        
        if ($deleted) {
            $this->setFlash('Notificação excluída com sucesso.', 'success');
        } else {
            $this->setFlash('Erro ao excluir notificação.', 'danger');
        }
        
        $this->redirect('/notificacoes');
    }
    
    public function limparAntigas() {
        if (!$this->user) {
            $this->setFlash('Acesso não autorizado.', 'danger');
            $this->redirect('/login');
            return;
        }
        
        // Remove notificações lidas com mais de 30 dias
        $sql = "DELETE FROM notificacoes 
                WHERE usuario_id = :usuario_id 
                AND lida = 1 
                AND data_leitura < DATE_SUB(NOW(), INTERVAL 30 DAY)";
        
        $deleted = $this->db->execute($sql, ['usuario_id' => $this->user['id']]);
        
        if ($deleted) {
            $this->setFlash('Notificações antigas foram removidas.', 'success');
        } else {
            $this->setFlash('Nenhuma notificação antiga para remover.', 'info');
        }
        
        $this->redirect('/notificacoes');
    }
    
    public function obterNaoLidas() {
        if (!$this->user) {
            echo json_encode(['success' => false, 'count' => 0]);
            return;
        }
        
        // Busca notificações não lidas recentes
        $sql = "SELECT id, titulo, mensagem, tipo, created_at 
                FROM notificacoes 
                WHERE usuario_id = :usuario_id AND lida = 0 
                ORDER BY created_at DESC 
                LIMIT 5";
        
        $notificacoes = $this->db->fetchAll($sql, ['usuario_id' => $this->user['id']]);
        
        // Conta total de não lidas
        $total = $this->db->count('notificacoes', 'usuario_id = :usuario_id AND lida = 0', ['usuario_id' => $this->user['id']]);
        
        echo json_encode([
            'success' => true,
            'count' => $total,
            'notificacoes' => $notificacoes
        ]);
    }
    
    public function criar() {
        // Apenas administradores podem criar notificações em massa
        if (!$this->user || $this->user['nivel_acesso_id'] != NIVEL_ADMIN) {
            $this->setFlash('Acesso negado.', 'danger');
            $this->redirect('/');
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $titulo = $_POST['titulo'] ?? '';
            $mensagem = $_POST['mensagem'] ?? '';
            $tipo = $_POST['tipo'] ?? 'sistema';
            $destinatarios = $_POST['destinatarios'] ?? 'todos';
            $nivel_acesso = $_POST['nivel_acesso'] ?? null;
            
            if (empty($titulo) || empty($mensagem)) {
                $this->setFlash('Título e mensagem são obrigatórios.', 'danger');
                $this->redirect('/notificacoes/criar');
                return;
            }
            
            // Determina os usuários que receberão a notificação
            $usuarios = [];
            if ($destinatarios == 'todos') {
                $usuarios = $this->db->fetchAll("SELECT id FROM usuarios WHERE status = 'ativo'");
            } elseif ($destinatarios == 'nivel' && $nivel_acesso) {
                $usuarios = $this->db->fetchAll(
                    "SELECT id FROM usuarios WHERE status = 'ativo' AND nivel_acesso_id = :nivel",
                    ['nivel' => $nivel_acesso]
                );
            }
            
            // Cria notificação para cada usuário
            $count = 0;
            foreach ($usuarios as $usuario) {
                $data = [
                    'usuario_id' => $usuario['id'],
                    'titulo' => $titulo,
                    'mensagem' => $mensagem,
                    'tipo' => $tipo,
                    'lida' => 0,
                    'created_at' => date('Y-m-d H:i:s')
                ];
                
                if ($this->db->insert('notificacoes', $data)) {
                    $count++;
                }
            }
            
            $this->setFlash("Notificação enviada para $count usuários.", 'success');
            $this->redirect('/notificacoes');
            return;
        }
        
        // Busca níveis de acesso para o formulário
        $niveis = $this->db->fetchAll("SELECT * FROM niveis_acesso ORDER BY nome");
        
        $data = [
            'niveis' => $niveis,
            'flash' => $this->getFlash()
        ];
        
        echo $this->view->render('notificacoes/criar', $data);
    }
}
