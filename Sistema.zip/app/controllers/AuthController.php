<?php
class AuthController extends Controller {
    
    public function login() {
        // Se já está logado, redireciona
        if (isset($_SESSION['user_id'])) {
            $this->redirect('/dashboard');
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->processLogin();
        } else {
            $this->showLoginForm();
        }
    }
    
    private function showLoginForm() {
        $flash = $this->getFlash();
        echo $this->view->renderPartial('auth/login', ['flash' => $flash]);
    }
    
    private function processLogin() {
        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
        $senha = $_POST['senha'] ?? '';
        
        // Validação
        $errors = $this->validate($_POST, [
            'email' => ['required', 'email'],
            'senha' => ['required']
        ]);
        
        if (!empty($errors)) {
            $this->setFlash('Por favor, preencha todos os campos corretamente.', 'danger');
            $this->showLoginForm();
            return;
        }
        
        // Busca usuário com o nome do nível
        $sql = "SELECT u.*, na.nome as nivel_nome 
                FROM usuarios u 
                LEFT JOIN niveis_acesso na ON u.nivel_acesso_id = na.id 
                WHERE u.email = :email AND u.ativo = 1";
        $user = $this->db->fetchOne($sql, ['email' => $email]);
        
        if (!$user) {
            $this->logActivity('login_failed', "Tentativa de login com e-mail inexistente: $email");
            $this->setFlash('E-mail ou senha incorretos.', 'danger');
            $this->showLoginForm();
            return;
        }
        
        // Verifica se está bloqueado
        if ($user['bloqueado_ate'] && strtotime($user['bloqueado_ate']) > time()) {
            $this->setFlash('Conta temporariamente bloqueada. Tente novamente mais tarde.', 'warning');
            $this->showLoginForm();
            return;
        }
        
        // Verifica senha
        if (!password_verify($senha, $user['senha'])) {
            // Incrementa tentativas
            $tentativas = $user['tentativas_login'] + 1;
            $bloqueado_ate = null;
            
            if ($tentativas >= MAX_LOGIN_ATTEMPTS) {
                $bloqueado_ate = date('Y-m-d H:i:s', time() + LOCKOUT_TIME);
                $this->setFlash('Muitas tentativas de login. Conta bloqueada temporariamente.', 'danger');
            }
            
            $this->db->update('usuarios', [
                'tentativas_login' => $tentativas,
                'bloqueado_ate' => $bloqueado_ate
            ], 'id = :id', ['id' => $user['id']]);
            
            $this->logActivity('login_failed', "Senha incorreta para: $email");
            
            if (!$bloqueado_ate) {
                $this->setFlash('E-mail ou senha incorretos.', 'danger');
            }
            
            $this->showLoginForm();
            return;
        }
        
        // Login bem-sucedido
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['nome_completo'];
        $_SESSION['user_nivel'] = $user['nivel_acesso_id'];
        $_SESSION['user_nivel_nome'] = $user['nivel_nome'] ?? 'Usuário';
        $_SESSION['login_time'] = time();
        
        // Reseta tentativas e atualiza último acesso
        $this->db->update('usuarios', [
            'tentativas_login' => 0,
            'bloqueado_ate' => null,
            'ultimo_acesso' => date('Y-m-d H:i:s')
        ], 'id = :id', ['id' => $user['id']]);
        
        $this->logActivity('login_success', "Login bem-sucedido");
        
        // Redireciona baseado no nível de acesso
        switch ($user['nivel_acesso_id']) {
            case NIVEL_ADMIN:
                $this->redirect('/');
                break;
            case NIVEL_CLIENTE:
                $this->redirect('/meus-imoveis');
                break;
            case NIVEL_FUNCIONARIO:
                $this->redirect('/meu-perfil');
                break;
            case NIVEL_FINANCEIRO:
                $this->redirect('/financeiro');
                break;
            case NIVEL_ENCARREGADO:
                $this->redirect('/obras');
                break;
            default:
                $this->redirect('/');
        }
    }
    
    public function logout() {
        if (isset($_SESSION['user_id'])) {
            $this->logActivity('logout', "Logout realizado");
        }
        
        // Limpa a sessão
        $_SESSION = array();
        
        // Destroi o cookie de sessão
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        
        // Destroi a sessão
        session_destroy();
        
        // Redireciona para login
        $this->redirect('/login');
    }
    
    public function forgotPassword() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
            
            if (!$email) {
                $this->setFlash('Por favor, informe um e-mail válido.', 'danger');
                echo $this->view->renderPartial('auth/forgot-password');
                return;
            }
            
            $user = $this->db->fetchOne("SELECT * FROM usuarios WHERE email = :email", ['email' => $email]);
            
            if ($user) {
                // Gera token de recuperação
                $token = bin2hex(random_bytes(32));
                $expiry = date('Y-m-d H:i:s', time() + 3600); // 1 hora
                
                // Salva token no banco (você precisará criar esta tabela)
                $this->db->insert('password_resets', [
                    'email' => $email,
                    'token' => $token,
                    'expires_at' => $expiry
                ]);
                
                // Envia e-mail
                $resetLink = BASE_URL . "reset-password?token=$token";
                $subject = "Recuperação de Senha - Construtora Kelles Duarte";
                $body = "Olá {$user['nome_completo']},\n\n";
                $body .= "Você solicitou a recuperação de senha.\n";
                $body .= "Clique no link abaixo para criar uma nova senha:\n\n";
                $body .= $resetLink . "\n\n";
                $body .= "Este link expira em 1 hora.\n\n";
                $body .= "Se você não solicitou esta recuperação, ignore este e-mail.";
                
                $this->sendEmail($email, $subject, $body);
            }
            
            // Sempre mostra mensagem de sucesso por segurança
            $this->setFlash('Se o e-mail existir em nosso sistema, você receberá instruções de recuperação.', 'success');
            $this->redirect('/login');
            
        } else {
            echo $this->view->renderPartial('auth/forgot-password');
        }
    }
    
    public function resetPassword() {
        $token = $_GET['token'] ?? '';
        
        if (!$token) {
            $this->setFlash('Token inválido.', 'danger');
            $this->redirect('/login');
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $senha = $_POST['senha'] ?? '';
            $confirma_senha = $_POST['confirma_senha'] ?? '';
            
            if (strlen($senha) < PASSWORD_MIN_LENGTH) {
                $this->setFlash('A senha deve ter no mínimo ' . PASSWORD_MIN_LENGTH . ' caracteres.', 'danger');
                echo $this->view->renderPartial('auth/reset-password', ['token' => $token]);
                return;
            }
            
            if ($senha !== $confirma_senha) {
                $this->setFlash('As senhas não coincidem.', 'danger');
                echo $this->view->renderPartial('auth/reset-password', ['token' => $token]);
                return;
            }
            
            // Verifica token
            $reset = $this->db->fetchOne(
                "SELECT * FROM password_resets WHERE token = :token AND expires_at > NOW()",
                ['token' => $token]
            );
            
            if (!$reset) {
                $this->setFlash('Token inválido ou expirado.', 'danger');
                $this->redirect('/login');
                return;
            }
            
            // Atualiza senha
            $hashedPassword = password_hash($senha, PASSWORD_DEFAULT);
            $this->db->update('usuarios', 
                ['senha' => $hashedPassword],
                'email = :email',
                ['email' => $reset['email']]
            );
            
            // Remove token usado
            $this->db->delete('password_resets', 'token = :token', ['token' => $token]);
            
            $this->setFlash('Senha alterada com sucesso!', 'success');
            $this->redirect('/login');
            
        } else {
            echo $this->view->renderPartial('auth/reset-password', ['token' => $token]);
        }
    }
}
