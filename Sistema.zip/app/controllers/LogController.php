<?php
require_once __DIR__ . '/../core/Controller.php';

class LogController extends Controller {
    
    public function index() {
        // Debug - remover depois
        // error_log("LogController::index() foi chamado");
        
        // Apenas administradores podem ver logs
        if (!isset($this->user['nivel_acesso_id']) || $this->user['nivel_acesso_id'] != NIVEL_ADMIN) {
            $this->setFlash('Acesso negado. Apenas administradores podem visualizar logs.', 'danger');
            $this->redirect('/');
            return;
        }
        
        $page = $_GET['page'] ?? 1;
        $limit = 50;
        $offset = ($page - 1) * $limit;
        
        // Filtros
        $where = "1=1";
        $params = [];
        
        if (isset($_GET['usuario']) && !empty($_GET['usuario'])) {
            $where .= " AND l.usuario_id = :usuario";
            $params['usuario'] = $_GET['usuario'];
        }
        
        if (isset($_GET['acao']) && !empty($_GET['acao'])) {
            $where .= " AND l.acao LIKE :acao";
            $params['acao'] = '%' . $_GET['acao'] . '%';
        }
        
        if (isset($_GET['data_inicio']) && !empty($_GET['data_inicio'])) {
            $where .= " AND DATE(l.created_at) >= :data_inicio";
            $params['data_inicio'] = $_GET['data_inicio'];
        }
        
        if (isset($_GET['data_fim']) && !empty($_GET['data_fim'])) {
            $where .= " AND DATE(l.created_at) <= :data_fim";
            $params['data_fim'] = $_GET['data_fim'];
        }
        
        // Busca logs
        try {
            $sql = "SELECT l.*, u.nome_completo as usuario_nome
                    FROM logs_acesso l
                    LEFT JOIN usuarios u ON l.usuario_id = u.id
                    WHERE $where
                    ORDER BY l.created_at DESC
                    LIMIT $limit OFFSET $offset";
            
            $logs = $this->db->fetchAll($sql, $params);
            
            // Total para paginação
            $total = $this->db->count('logs_acesso l', $where, $params);
            $totalPages = ceil($total / $limit);
            
            // Lista de usuários para filtro
            $usuarios = $this->db->fetchAll("SELECT id, nome_completo FROM usuarios ORDER BY nome_completo");
        } catch (Exception $e) {
            // Se a tabela não existir, cria arrays vazios
            $logs = [];
            $total = 0;
            $totalPages = 0;
            $usuarios = [];
        }
        
        $data = [
            'logs' => $logs,
            'usuarios' => $usuarios,
            'pagination' => [
                'current' => $page,
                'total' => $totalPages,
                'limit' => $limit,
                'total_records' => $total
            ],
            'filters' => $_GET,
            'flash' => $this->getFlash()
        ];
        
        echo $this->view->render('logs/index', $data);
    }
    
    public function limpar() {
        // Apenas administradores
        if ($this->user['nivel_acesso_id'] != NIVEL_ADMIN) {
            $this->setFlash('Acesso negado.', 'danger');
            $this->redirect('/');
            return;
        }
        
        $dias = $_POST['dias'] ?? 30;
        
        // Remove logs antigos
        $sql = "DELETE FROM logs_acesso WHERE created_at < DATE_SUB(NOW(), INTERVAL :dias DAY)";
        $deleted = $this->db->execute($sql, ['dias' => $dias]);
        
        if ($deleted) {
            $this->logActivity('logs_limpos', "Logs com mais de $dias dias foram removidos");
            $this->setFlash("Logs com mais de $dias dias foram removidos com sucesso!", 'success');
        } else {
            $this->setFlash('Erro ao limpar logs.', 'danger');
        }
        
        $this->redirect('/logs');
    }
    
    public function exportar() {
        // Apenas administradores
        if ($this->user['nivel_acesso_id'] != NIVEL_ADMIN) {
            $this->setFlash('Acesso negado.', 'danger');
            $this->redirect('/');
            return;
        }
        
        // Busca todos os logs do período selecionado
        $where = "1=1";
        $params = [];
        
        if (isset($_GET['data_inicio']) && !empty($_GET['data_inicio'])) {
            $where .= " AND DATE(l.created_at) >= :data_inicio";
            $params['data_inicio'] = $_GET['data_inicio'];
        }
        
        if (isset($_GET['data_fim']) && !empty($_GET['data_fim'])) {
            $where .= " AND DATE(l.created_at) <= :data_fim";
            $params['data_fim'] = $_GET['data_fim'];
        }
        
        $sql = "SELECT l.*, u.nome_completo as usuario_nome
                FROM logs_acesso l
                LEFT JOIN usuarios u ON l.usuario_id = u.id
                WHERE $where
                ORDER BY l.created_at DESC";
        
        $logs = $this->db->fetchAll($sql, $params);
        
        // Gera CSV
        $filename = 'logs_' . date('Y-m-d_H-i-s') . '.csv';
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        $output = fopen('php://output', 'w');
        
        // Cabeçalho do CSV
        fputcsv($output, ['Data/Hora', 'Usuário', 'IP', 'Página', 'Ação', 'Descrição']);
        
        // Dados
        foreach ($logs as $log) {
            fputcsv($output, [
                $log['created_at'],
                $log['usuario_nome'] ?? 'Sistema',
                $log['ip_address'],
                $log['pagina'],
                $log['acao'],
                $log['descricao']
            ]);
        }
        
        fclose($output);
        
        $this->logActivity('logs_exportados', "Logs exportados para CSV");
        exit;
    }
}
