<?php
require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../models/Empreendimento.php';

class EmpreendimentoController extends Controller {
    
    private $empreendimentoModel;
    
    public function __construct() {
        parent::__construct();
        $this->empreendimentoModel = new Empreendimento($this->db);
    }
    
    /**
     * Lista todos os empreendimentos
     */
    public function index() {
        if (!$this->checkPermission('empreendimentos', 'visualizar')) {
            $this->setFlash('Você não tem permissão para acessar esta página.', 'danger');
            $this->redirect('/');
            return;
        }
        
        // Filtros
        $filtros = [
            'nome' => $_GET['nome'] ?? '',
            'cidade' => $_GET['cidade'] ?? '',
            'status' => $_GET['status'] ?? ''
        ];
        
        // Paginação
        $pagina = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $porPagina = 15;
        
        // Busca os empreendimentos
        $resultado = $this->empreendimentoModel->paginate($pagina, $porPagina, $filtros);
        
        // Busca encarregados para o filtro
        $encarregados = $this->db->fetchAll(
            "SELECT id, nome_completo FROM usuarios WHERE nivel_acesso_id = :nivel ORDER BY nome_completo",
            ['nivel' => NIVEL_ENCARREGADO]
        );
        
        // Dados para a view
        $data = [
            'empreendimentos' => $resultado['data'],
            'pagination' => [
                'current' => $pagina,
                'total' => $resultado['last_page'],
                'per_page' => $porPagina,
                'total_records' => $resultado['total']
            ],
            'filters' => $filtros,
            'encarregados' => $encarregados,
            'status_list' => $this->empreendimentoModel::getStatusList(),
            'flash' => $this->getFlash()
        ];
        
        echo $this->view->render('empreendimentos/index', $data);
    }
    
    /**
     * Exibe o formulário de criação de empreendimento
     */
    public function criar() {
        if (!$this->checkPermission('empreendimentos', 'criar')) {
            $this->setFlash('Você não tem permissão para acessar esta página.', 'danger');
            $this->redirect('/');
            return;
        }
        
        // Busca encarregados para o formulário
        $encarregados = $this->db->fetchAll(
            "SELECT id, nome_completo FROM usuarios WHERE nivel_acesso_id = :nivel ORDER BY nome_completo",
            ['nivel' => NIVEL_ENCARREGADO]
        );
        
        // Dados para a view
        $data = [
            'encarregados' => $encarregados,
            'status_list' => $this->empreendimentoModel::getStatusList(),
            'tipos' => $this->empreendimentoModel::getTipos(),
            'csrf_token' => $this->generateCsrfToken(),
            'errors' => [],
            'old' => [],
            'flash' => $this->getFlash()
        ];
        
        echo $this->view->render('empreendimentos/novo', $data);
    }
    
    /**
     * Processa o formulário de criação de empreendimento
     */
    public function salvar() {
        if (!$this->checkPermission('empreendimentos', 'criar')) {
            $this->setFlash('Você não tem permissão para realizar esta ação.', 'danger');
            $this->json(['success' => false, 'message' => 'Sem permissão'], 403);
            return;
        }
        
        // Verifica se é uma requisição POST
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->json(['success' => false, 'message' => 'Método não permitido'], 405);
            return;
        }
        
        // Valida o token CSRF
        if (!$this->validateCsrfToken($_POST['csrf_token'] ?? '')) {
            $this->json(['success' => false, 'message' => 'Token de segurança inválido'], 403);
            return;
        }
        
        // Processa os dados do formulário
        $data = $this->processFormData($_POST);
        
        try {
            // Prepara os dados para inserção
            $empreendimentoData = [
                'nome' => $data['nome'] ?? null,
                'cidade' => $data['cidade'] ?? null,
                'endereco' => $data['endereco'] ?? null,
                'cno' => $data['cno'] ?? null,
                'engenheiro_nome' => $data['engenheiro_nome'] ?? null,
                'engenheiro_art' => $data['engenheiro_art'] ?? null,
                'arquiteto_nome' => $data['arquiteto_nome'] ?? null,
                'arquiteto_cau' => $data['arquiteto_cau'] ?? null,
                'art_execucao' => $data['art_execucao'] ?? null,
                'encarregado_id' => !empty($data['encarregado_id']) ? $data['encarregado_id'] : null,
                'status' => $data['status'] ?? 'planejamento',
                'tipo' => $data['tipo'] ?? 'residencial',
                'descricao' => $data['descricao'] ?? null,
                'area_total' => !empty($data['area_total']) ? (float)$data['area_total'] : null,
                'area_privativa' => !empty($data['area_privativa']) ? (float)$data['area_privativa'] : null,
                'area_comum' => !empty($data['area_comum']) ? (float)$data['area_comum'] : null,
                'torres' => !empty($data['torres']) ? (int)$data['torres'] : null,
                'unidades_por_andar' => !empty($data['unidades_por_andar']) ? (int)$data['unidades_por_andar'] : null,
                'total_unidades' => !empty($data['total_unidades']) ? (int)$data['total_unidades'] : null,
                'data_inicio' => !empty($data['data_inicio']) ? $data['data_inicio'] : null,
                'previsao_termino' => !empty($data['previsao_termino']) ? $data['previsao_termino'] : null,
                'data_entrega' => !empty($data['data_entrega']) ? $data['data_entrega'] : null,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ];
            
            // Inicia uma transação
            $this->db->beginTransaction();
            
            // Insere o empreendimento
            $empreendimentoId = $this->empreendimentoModel->create($empreendimentoData);
            
            if (!$empreendimentoId) {
                throw new Exception('Falha ao inserir o empreendimento no banco de dados.');
            }
            
            // Processa upload de arquivos, se houver
            if (isset($_FILES['arquivos']) && !empty($_FILES['arquivos']['name'][0])) {
                $this->processarUploads($empreendimentoId, $_FILES['arquivos']);
            }
            
            // Confirma a transação
            $this->db->commit();
            
            // Registra a atividade
            $this->logActivity('empreendimento_criado', "Novo empreendimento criado: {$data['nome']} (ID: $empreendimentoId)");
            
            // Retorna sucesso
            $this->json([
                'success' => true, 
                'message' => 'Empreendimento cadastrado com sucesso!',
                'redirect' => url("empreendimentos/editar/$empreendimentoId")
            ]);
            
        } catch (Exception $e) {
            // Desfaz a transação em caso de erro
            $this->db->rollBack();
            
            // Log do erro
            error_log('Erro ao salvar empreendimento: ' . $e->getMessage());
            
            // Retorna erro
            $this->json([
                'success' => false, 
                'message' => 'Erro ao salvar o empreendimento: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Exibe o formulário de edição de empreendimento
     */
    public function editar($id) {
        if (!$this->checkPermission('empreendimentos', 'editar')) {
            $this->setFlash('Você não tem permissão para acessar esta página.', 'danger');
            $this->redirect('/');
            return;
        }
        
        // Busca o empreendimento
        $empreendimento = $this->empreendimentoModel->find($id);
        
        if (!$empreendimento) {
            $this->setFlash('Empreendimento não encontrado.', 'danger');
            $this->redirect('/empreendimentos');
            return;
        }
        
        // Busca encarregados para o formulário
        $encarregados = $this->db->fetchAll(
            "SELECT id, nome_completo FROM usuarios WHERE nivel_acesso_id = :nivel ORDER BY nome_completo",
            ['nivel' => NIVEL_ENCARREGADO]
        );
        
        // Busca documentos do empreendimento
        $documentos = $this->empreendimentoModel->getDocumentos($id);
        
        // Dados para a view
        $data = [
            'empreendimento' => $empreendimento,
            'encarregados' => $encarregados,
            'documentos' => $documentos,
            'status_list' => $this->empreendimentoModel::getStatusList(),
            'tipos' => $this->empreendimentoModel::getTipos(),
            'csrf_token' => $this->generateCsrfToken(),
            'flash' => $this->getFlash(),
            'tab' => $_GET['tab'] ?? 'dados-gerais'
        ];
        
        echo $this->view->render('empreendimentos/editar', $data);
    }
    
    /**
     * Processa o formulário de atualização de empreendimento
     */
    public function atualizar($id) {
        if (!$this->checkPermission('empreendimentos', 'editar')) {
            $this->setFlash('Você não tem permissão para realizar esta ação.', 'danger');
            $this->json(['success' => false, 'message' => 'Sem permissão'], 403);
            return;
        }
        
        // Verifica se é uma requisição POST
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->json(['success' => false, 'message' => 'Método não permitido'], 405);
            return;
        }
        
        // Valida o token CSRF
        if (!$this->validateCsrfToken($_POST['csrf_token'] ?? '')) {
            $this->json(['success' => false, 'message' => 'Token de segurança inválido'], 403);
            return;
        }
        
        // Verifica se o empreendimento existe
        $empreendimento = $this->empreendimentoModel->find($id);
        if (!$empreendimento) {
            $this->json(['success' => false, 'message' => 'Empreendimento não encontrado'], 404);
            return;
        }
        
        // Processa os dados do formulário
        $data = $this->processFormData($_POST);
        
        // Define as regras de validação
        $rules = [
            'nome' => ['required', 'min:3', 'max:100'],
            'cidade' => ['required', 'min:3', 'max:100'],
            'endereco' => ['required', 'min:5', 'max:255'],
            'cno' => ['required', 'max:50'],
            'engenheiro_nome' => ['required', 'max:100'],
            'engenheiro_art' => ['required', 'max:50'],
            'arquiteto_nome' => ['required', 'max:100'],
            'arquiteto_cau' => ['required', 'max:50'],
            'art_execucao' => ['required', 'max:50']
        ];
        
        // Valida os dados
        $errors = $this->validateFormData($data, $rules);
        
        if (!empty($errors)) {
            $this->json([
                'success' => false, 
                'message' => 'Por favor, corrija os erros no formulário.',
                'errors' => $errors
            ], 422);
            return;
        }
        
        try {
            // Prepara os dados para atualização
            $empreendimentoData = [
                'nome' => $data['nome'],
                'cidade' => $data['cidade'],
                'endereco' => $data['endereco'],
                'cno' => $data['cno'],
                'engenheiro_nome' => $data['engenheiro_nome'],
                'engenheiro_art' => $data['engenheiro_art'],
                'arquiteto_nome' => $data['arquiteto_nome'],
                'arquiteto_cau' => $data['arquiteto_cau'],
                'art_execucao' => $data['art_execucao'],
                'encarregado_id' => !empty($data['encarregado_id']) ? $data['encarregado_id'] : null,
                'status' => $data['status'] ?? 'planejamento',
                'tipo' => $data['tipo'] ?? 'residencial',
                'descricao' => $data['descricao'] ?? null,
                'area_total' => !empty($data['area_total']) ? (float)$data['area_total'] : null,
                'area_privativa' => !empty($data['area_privativa']) ? (float)$data['area_privativa'] : null,
                'area_comum' => !empty($data['area_comum']) ? (float)$data['area_comum'] : null,
                'torres' => !empty($data['torres']) ? (int)$data['torres'] : null,
                'unidades_por_andar' => !empty($data['unidades_por_andar']) ? (int)$data['unidades_por_andar'] : null,
                'total_unidades' => !empty($data['total_unidades']) ? (int)$data['total_unidades'] : null,
                'data_inicio' => !empty($data['data_inicio']) ? $data['data_inicio'] : null,
                'previsao_termino' => !empty($data['previsao_termino']) ? $data['previsao_termino'] : null,
                'data_entrega' => !empty($data['data_entrega']) ? $data['data_entrega'] : null,
                'updated_at' => date('Y-m-d H:i:s')
            ];
            
            // Inicia uma transação
            $this->db->beginTransaction();
            
            // Atualiza o empreendimento
            $atualizado = $this->empreendimentoModel->update($id, $empreendimentoData);
            
            if (!$atualizado) {
                throw new Exception('Falha ao atualizar o empreendimento no banco de dados.');
            }
            
            // Processa upload de arquivos, se houver
            if (isset($_FILES['arquivos']) && !empty($_FILES['arquivos']['name'][0])) {
                $this->processarUploads($id, $_FILES['arquivos']);
            }
            
            // Confirma a transação
            $this->db->commit();
            
            // Registra a atividade
            $this->logActivity('empreendimento_atualizado', "Empreendimento atualizado: {$data['nome']} (ID: $id)");
            
            // Retorna sucesso
            $this->json([
                'success' => true, 
                'message' => 'Empreendimento atualizado com sucesso!',
                'redirect' => url("empreendimentos/editar/$id")
            ]);
            
        } catch (Exception $e) {
            // Desfaz a transação em caso de erro
            $this->db->rollBack();
            
            // Log do erro
            error_log('Erro ao atualizar empreendimento: ' . $e->getMessage());
            
            // Retorna erro
            $this->json([
                'success' => false, 
                'message' => 'Erro ao atualizar o empreendimento: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Remove um empreendimento
     */
    public function excluir($id) {
        if (!$this->checkPermission('empreendimentos', 'excluir')) {
            $this->setFlash('Você não tem permissão para realizar esta ação.', 'danger');
            $this->redirect('/');
            return;
        }
        
        try {
            // Remove o empreendimento
            $this->empreendimentoModel->delete($id);
            
            // Registra a atividade
            $this->logActivity('empreendimento_excluido', "Empreendimento excluído (ID: $id)");
            
            $this->setFlash('Empreendimento excluído com sucesso!', 'success');
            
        } catch (Exception $e) {
            // Log do erro
            error_log('Erro ao excluir empreendimento: ' . $e->getMessage());
            
            $this->setFlash('Erro ao excluir o empreendimento: ' . $e->getMessage(), 'danger');
        }
        
        $this->redirect('/empreendimentos');
    }
    
    /**
     * Exibe os detalhes de um empreendimento
     */
    public function visualizar($id) {
        if (!$this->checkPermission('empreendimentos', 'visualizar')) {
            $this->setFlash('Você não tem permissão para acessar esta página.', 'danger');
            $this->redirect('/');
            return;
        }
        
        // Busca o empreendimento
        $empreendimento = $this->empreendimentoModel->find($id);
        
        if (!$empreendimento) {
            $this->setFlash('Empreendimento não encontrado.', 'danger');
            $this->redirect('/empreendimentos');
            return;
        }
        
        // Busca documentos do empreendimento
        $documentos = $this->empreendimentoModel->getDocumentos($id);
        
        // Dados para a view
        $data = [
            'empreendimento' => $empreendimento,
            'documentos' => $documentos,
            'status_list' => $this->empreendimentoModel::getStatusList(),
            'tipos' => $this->empreendimentoModel::getTipos(),
            'flash' => $this->getFlash()
        ];
        
        echo $this->view->render('empreendimentos/visualizar', $data);
    }
    
    /**
     * Processa o upload de arquivos
     */
    private function processarUploads($empreendimentoId, $arquivos) {
        $diretorio = __DIR__ . "/../../uploads/empreendimentos/$empreendimentoId";
        
        // Cria o diretório se não existir
        if (!is_dir($diretorio)) {
            mkdir($diretorio, 0777, true);
        }
        
        // Configurações de upload
        $config = [
            'tipos_permitidos' => ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'jpg', 'jpeg', 'png', 'gif'],
            'tamanho_maximo' => 10 * 1024 * 1024, // 10MB
            'pasta_destino' => $diretorio
        ];
        
        // Processa cada arquivo
        $total = count($arquivos['name']);
        
        for ($i = 0; $i < $total; $i++) {
            if ($arquivos['error'][$i] === UPLOAD_ERR_OK) {
                $nomeOriginal = $arquivos['name'][$i];
                $tipo = $arquivos['type'][$i];
                $tamanho = $arquivos['size'][$i];
                $tmpName = $arquivos['tmp_name'][$i];
                
                // Verifica o tipo do arquivo
                $extensao = strtolower(pathinfo($nomeOriginal, PATHINFO_EXTENSION));
                
                if (!in_array($extensao, $config['tipos_permitidos'])) {
                    throw new Exception("Tipo de arquivo não permitido: $nomeOriginal");
                }
                
                // Verifica o tamanho do arquivo
                if ($tamanho > $config['tamanho_maximo']) {
                    throw new Exception("Arquivo muito grande: $nomeOriginal");
                }
                
                // Gera um nome único para o arquivo
                $nomeArquivo = uniqid() . '.' . $extensao;
                $caminhoCompleto = $config['pasta_destino'] . '/' . $nomeArquivo;
                
                // Move o arquivo para o diretório de uploads
                if (move_uploaded_file($tmpName, $caminhoCompleto)) {
                    // Salva as informações no banco de dados
                    $dadosDocumento = [
                        'empreendimento_id' => $empreendimentoId,
                        'nome' => pathinfo($nomeOriginal, PATHINFO_FILENAME),
                        'arquivo' => $nomeArquivo,
                        'tipo' => $this->getTipoDocumento($extensao),
                        'tamanho' => $tamanho,
                        'tipo_mime' => $tipo,
                        'data_upload' => date('Y-m-d H:i:s'),
                        'usuario_id' => $_SESSION['user_id'] ?? null
                    ];
                    
                    $this->db->insert('empreendimento_documentos', $dadosDocumento);
                } else {
                    throw new Exception("Falha ao fazer upload do arquivo: $nomeOriginal");
                }
            }
        }
    }
    
    /**
     * Remove um documento do empreendimento
     */
    public function removerDocumento($id) {
        if (!$this->checkPermission('empreendimentos', 'editar')) {
            $this->json(['success' => false, 'message' => 'Sem permissão'], 403);
            return;
        }
        
        try {
            // Remove o documento
            $this->empreendimentoModel->removerDocumento($id);
            
            // Registra a atividade
            $this->logActivity('documento_removido', "Documento removido (ID: $id)");
            
            $this->json([
                'success' => true, 
                'message' => 'Documento removido com sucesso!'
            ]);
            
        } catch (Exception $e) {
            // Log do erro
            error_log('Erro ao remover documento: ' . $e->getMessage());
            
            $this->json([
                'success' => false, 
                'message' => 'Erro ao remover o documento: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Retorna o tipo de documento com base na extensão
     */
    private function getTipoDocumento($extensao) {
        $tipos = [
            'pdf' => 'pdf',
            'doc' => 'word',
            'docx' => 'word',
            'xls' => 'excel',
            'xlsx' => 'excel',
            'jpg' => 'imagem',
            'jpeg' => 'imagem',
            'png' => 'imagem',
            'gif' => 'imagem'
        ];
        
        return $tipos[strtolower($extensao)] ?? 'outros';
    }
    
    /**
     * Gera um relatório do empreendimento em PDF
     */
    public function relatorio($id) {
        if (!$this->checkPermission('empreendimentos', 'relatorios')) {
            $this->setFlash('Você não tem permissão para acessar esta página.', 'danger');
            $this->redirect('/');
            return;
        }
        
        // Busca o empreendimento
        $empreendimento = $this->empreendimentoModel->find($id);
        
        if (!$empreendimento) {
            $this->setFlash('Empreendimento não encontrado.', 'danger');
            $this->redirect('/empreendimentos');
            return;
        }
        
        // Busca estatísticas
        $estatisticas = $this->empreendimentoModel->getEstatisticas($id);
        
        // Gera o HTML do relatório
        $html = $this->view->render('empreendimentos/relatorio', [
            'empreendimento' => $empreendimento,
            'estatisticas' => $estatisticas,
            'data_geracao' => date('d/m/Y H:i:s')
        ], true);
        
        // Gera o PDF (requer a biblioteca mPDF)
        try {
            $mpdf = new \Mpdf\Mpdf([
                'mode' => 'utf-8',
                'format' => 'A4',
                'default_font_size' => 10,
                'default_font' => 'helvetica',
                'margin_left' => 10,
                'margin_right' => 10,
                'margin_top' => 25,
                'margin_bottom' => 25,
                'margin_header' => 10,
                'margin_footer' => 10
            ]);
            
            $mpdf->SetTitle("Relatório - {$empreendimento['nome']}");
            $mpdf->SetAuthor('Sistema Construtora Kelle Duarte');
            $mpdf->SetCreator('Sistema Construtora Kelle Duarte');
            
            // Adiciona o cabeçalho
            $mpdf->SetHTMLHeader(''
                . '<div style="text-align: center; border-bottom: 1px solid #ddd; padding-bottom: 5px; margin-bottom: 20px;">'
                . '    <h2>Relatório do Empreendimento</h2>'
                . '    <p style="font-size: 12px; color: #666;">Gerado em ' . date('d/m/Y H:i:s') . '</p>'
                . '</div>'
            );
            
            // Adiciona o rodapé
            $mpdf->SetHTMLFooter(''
                . '<div style="text-align: center; border-top: 1px solid #ddd; padding-top: 5px; font-size: 9px; color: #666;">'
                . '    Página {PAGENO} de {nb} • Sistema Construtora Kelle Duarte • ' . date('d/m/Y H:i:s') . ''
                . '</div>'
            );
            
            $mpdf->WriteHTML($html);
            
            // Define o nome do arquivo
            $nomeArquivo = 'relatorio_empreendimento_' . $id . '_' . date('Ymd_His') . '.pdf';
            
            // Força o download do arquivo
            $mpdf->Output($nomeArquivo, 'D');
            
        } catch (Exception $e) {
            error_log('Erro ao gerar relatório PDF: ' . $e->getMessage());
            $this->setFlash('Erro ao gerar o relatório em PDF: ' . $e->getMessage(), 'danger');
            $this->redirect("/empreendimentos/visualizar/$id");
        }
    }
    
    /**
     * Retorna os empreendimentos em formato JSON para uso em selects
     */
    public function jsonList() {
        if (!$this->checkPermission('empreendimentos', 'visualizar')) {
            $this->json(['success' => false, 'message' => 'Sem permissão'], 403);
            return;
        }
        
        $termo = $_GET['q'] ?? '';
        
        $sql = "SELECT id, nome, cidade 
                FROM empreendimentos 
                WHERE nome LIKE :termo OR cidade LIKE :termo 
                ORDER BY nome 
                LIMIT 20";
                
        $resultados = $this->db->fetchAll($sql, ['termo' => "%$termo%"]);
        
        $dados = [];
        foreach ($resultados as $row) {
            $dados[] = [
                'id' => $row['id'],
                'text' => $row['nome'] . ' - ' . $row['cidade']
            ];
        }
        
        $this->json(['results' => $dados]);
    }
}
