<?php
require_once __DIR__ . '/../core/Controller.php';

class BackupController extends Controller {
    
    public function index() {
        // Apenas administradores podem acessar
        if ($this->user['nivel_acesso_id'] != NIVEL_ADMIN) {
            $this->setFlash('Acesso negado. Apenas administradores podem gerenciar backups.', 'danger');
            $this->redirect('/');
            return;
        }
        
        // Lista backups existentes
        $backupDir = __DIR__ . '/../../backups';
        $backups = [];
        
        if (is_dir($backupDir)) {
            $files = scandir($backupDir);
            foreach ($files as $file) {
                if (pathinfo($file, PATHINFO_EXTENSION) == 'sql') {
                    $backups[] = [
                        'nome' => $file,
                        'tamanho' => filesize($backupDir . '/' . $file),
                        'data' => filemtime($backupDir . '/' . $file)
                    ];
                }
            }
        }
        
        // Ordena por data (mais recente primeiro)
        usort($backups, function($a, $b) {
            return $b['data'] - $a['data'];
        });
        
        $data = [
            'backups' => $backups,
            'flash' => $this->getFlash()
        ];
        
        echo $this->view->render('backup/index', $data);
    }
    
    public function criar() {
        // Apenas administradores
        if ($this->user['nivel_acesso_id'] != NIVEL_ADMIN) {
            $this->setFlash('Acesso negado.', 'danger');
            $this->redirect('/');
            return;
        }
        
        try {
            $backupDir = __DIR__ . '/../../backups';
            
            // Cria diretório se não existir
            if (!is_dir($backupDir)) {
                mkdir($backupDir, 0755, true);
            }
            
            // Nome do arquivo de backup
            $filename = 'backup_' . date('Y-m-d_H-i-s') . '.sql';
            $filepath = $backupDir . '/' . $filename;
            
            // Configurações do banco
            $host = DB_HOST;
            $user = DB_USER;
            $pass = DB_PASS;
            $db = DB_NAME;
            
            // Comando mysqldump
            $command = "mysqldump --host=$host --user=$user --password=$pass $db > $filepath 2>&1";
            
            // Executa o backup
            exec($command, $output, $return);
            
            if ($return === 0 && file_exists($filepath) && filesize($filepath) > 0) {
                $this->logActivity('backup_criado', "Backup criado: $filename");
                $this->setFlash('Backup criado com sucesso!', 'success');
            } else {
                // Remove arquivo vazio se foi criado
                if (file_exists($filepath)) {
                    unlink($filepath);
                }
                $this->setFlash('Erro ao criar backup. Verifique as configurações do servidor.', 'danger');
            }
        } catch (Exception $e) {
            $this->setFlash('Erro ao criar backup: ' . $e->getMessage(), 'danger');
        }
        
        $this->redirect('/backup');
    }
    
    public function download($filename) {
        // Apenas administradores
        if ($this->user['nivel_acesso_id'] != NIVEL_ADMIN) {
            $this->setFlash('Acesso negado.', 'danger');
            $this->redirect('/');
            return;
        }
        
        $backupDir = __DIR__ . '/../../backups';
        $filepath = $backupDir . '/' . $filename;
        
        // Valida nome do arquivo
        if (!preg_match('/^backup_[\d\-_]+\.sql$/', $filename)) {
            $this->setFlash('Arquivo inválido.', 'danger');
            $this->redirect('/backup');
            return;
        }
        
        if (file_exists($filepath)) {
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Content-Length: ' . filesize($filepath));
            readfile($filepath);
            
            $this->logActivity('backup_download', "Download do backup: $filename");
            exit;
        } else {
            $this->setFlash('Arquivo de backup não encontrado.', 'danger');
            $this->redirect('/backup');
        }
    }
    
    public function deletar($filename) {
        // Apenas administradores
        if ($this->user['nivel_acesso_id'] != NIVEL_ADMIN) {
            $this->setFlash('Acesso negado.', 'danger');
            $this->redirect('/');
            return;
        }
        
        $backupDir = __DIR__ . '/../../backups';
        $filepath = $backupDir . '/' . $filename;
        
        // Valida nome do arquivo
        if (!preg_match('/^backup_[\d\-_]+\.sql$/', $filename)) {
            $this->setFlash('Arquivo inválido.', 'danger');
            $this->redirect('/backup');
            return;
        }
        
        if (file_exists($filepath)) {
            if (unlink($filepath)) {
                $this->logActivity('backup_deletado', "Backup deletado: $filename");
                $this->setFlash('Backup deletado com sucesso!', 'success');
            } else {
                $this->setFlash('Erro ao deletar backup.', 'danger');
            }
        } else {
            $this->setFlash('Arquivo de backup não encontrado.', 'danger');
        }
        
        $this->redirect('/backup');
    }
    
    public function restaurar($filename) {
        // Apenas administradores
        if ($this->user['nivel_acesso_id'] != NIVEL_ADMIN) {
            $this->setFlash('Acesso negado.', 'danger');
            $this->redirect('/');
            return;
        }
        
        $backupDir = __DIR__ . '/../../backups';
        $filepath = $backupDir . '/' . $filename;
        
        // Valida nome do arquivo
        if (!preg_match('/^backup_[\d\-_]+\.sql$/', $filename)) {
            $this->setFlash('Arquivo inválido.', 'danger');
            $this->redirect('/backup');
            return;
        }
        
        if (!file_exists($filepath)) {
            $this->setFlash('Arquivo de backup não encontrado.', 'danger');
            $this->redirect('/backup');
            return;
        }
        
        try {
            // Configurações do banco
            $host = DB_HOST;
            $user = DB_USER;
            $pass = DB_PASS;
            $db = DB_NAME;
            
            // Comando mysql para restaurar
            $command = "mysql --host=$host --user=$user --password=$pass $db < $filepath 2>&1";
            
            // Executa a restauração
            exec($command, $output, $return);
            
            if ($return === 0) {
                $this->logActivity('backup_restaurado', "Backup restaurado: $filename");
                $this->setFlash('Backup restaurado com sucesso! Por segurança, faça logout e entre novamente.', 'success');
                
                // Força logout após restauração
                session_destroy();
                $this->redirect('/login');
            } else {
                $this->setFlash('Erro ao restaurar backup. Verifique o arquivo e as configurações.', 'danger');
            }
        } catch (Exception $e) {
            $this->setFlash('Erro ao restaurar backup: ' . $e->getMessage(), 'danger');
        }
        
        $this->redirect('/backup');
    }
}
