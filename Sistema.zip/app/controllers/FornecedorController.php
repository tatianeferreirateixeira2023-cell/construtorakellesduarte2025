<?php
require_once __DIR__ . '/../core/Controller.php';

class FornecedorController extends Controller {
    
    public function index() {
        if (!$this->checkPermission('fornecedores', 'visualizar')) {
            return;
        }
        
        $page = $_GET['page'] ?? 1;
        $limit = 20;
        $offset = ($page - 1) * $limit;
        
        // Filtros
        $where = "1=1";
        $params = [];
        
        if (isset($_GET['search']) && !empty($_GET['search'])) {
            $search = '%' . $_GET['search'] . '%';
            $where .= " AND (f.razao_social LIKE :search OR f.cnpj LIKE :search OR f.cidade LIKE :search)";
            $params['search'] = $search;
        }
        
        if (isset($_GET['cidade']) && !empty($_GET['cidade'])) {
            $where .= " AND f.cidade = :cidade";
            $params['cidade'] = $_GET['cidade'];
        }
        
        if (isset($_GET['status']) && $_GET['status'] !== '') {
            $where .= " AND f.ativo = :status";
            $params['status'] = $_GET['status'];
        }
        
        // Busca fornecedores
        $sql = "SELECT f.*,
                (SELECT COUNT(*) FROM contas_pagar WHERE fornecedor_id = f.id) as total_contas,
                (SELECT COUNT(*) FROM compras WHERE fornecedor_id = f.id) as total_compras,
                (SELECT SUM(valor) FROM contas_pagar WHERE fornecedor_id = f.id AND status = 'pago') as total_pago
                FROM fornecedores f
                WHERE $where
                ORDER BY f.razao_social ASC
                LIMIT $limit OFFSET $offset";
        
        $fornecedores = $this->db->fetchAll($sql, $params);
        
        // Total para paginação
        $total = $this->db->count('fornecedores f', $where, $params);
        $totalPages = ceil($total / $limit);
        
        // Cidades únicas para filtro
        $cidades = $this->db->fetchAll("SELECT DISTINCT cidade FROM fornecedores WHERE cidade IS NOT NULL ORDER BY cidade");
        
        $data = [
            'fornecedores' => $fornecedores,
            'cidades' => $cidades,
            'pagination' => [
                'current' => $page,
                'total' => $totalPages,
                'limit' => $limit,
                'total_records' => $total
            ],
            'filters' => $_GET,
            'flash' => $this->getFlash()
        ];
        
        echo $this->view->render('fornecedores/index', $data);
    }
    
    public function criar() {
        if (!$this->checkPermission('fornecedores', 'criar')) {
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->store();
        } else {
            echo $this->view->render('fornecedores/form', [
                'fornecedor' => null,
                'flash' => $this->getFlash()
            ]);
        }
    }
    
    public function create() {
        // Alias para manter compatibilidade
        return $this->criar();
    }
    
    public function salvar() {
        // Processa o salvamento do formulário
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->store();
        } else {
            $this->redirect('/fornecedores/novo');
        }
    }
    
    private function store() {
        $data = $_POST;
        
        // Validação
        $errors = $this->validate($data, [
            'razao_social' => ['required'],
            'cnpj' => ['required', 'cnpj']
        ]);
        
        // Verifica CNPJ único
        $cnpjLimpo = preg_replace('/[^0-9]/', '', $data['cnpj']);
        if ($this->db->count('fornecedores', 'cnpj = :cnpj', ['cnpj' => $cnpjLimpo]) > 0) {
            $errors['cnpj'][] = 'CNPJ já cadastrado.';
        }
        
        if (!empty($errors)) {
            $this->setFlash('Corrija os erros no formulário.', 'danger');
            echo $this->view->render('fornecedores/form', [
                'errors' => $errors,
                'old' => $data,
                'fornecedor' => null
            ]);
            return;
        }
        
        // Prepara dados
        $fornecedorData = [
            'razao_social' => $data['razao_social'],
            'cnpj' => $cnpjLimpo,
            'endereco' => $data['endereco'] ?? null,
            'cep' => preg_replace('/[^0-9]/', '', $data['cep'] ?? ''),
            'telefone' => $data['telefone'] ?? null,
            'email' => $data['email'] ?? null,
            'responsavel_legal' => $data['responsavel_legal'] ?? null,
            'area_atuacao' => $data['area_atuacao'] ?? null,
            'cidade' => $data['cidade'] ?? null,
            'ativo' => 1
        ];
        
        if ($this->db->insert('fornecedores', $fornecedorData)) {
            $this->logActivity('fornecedor_criado', "Fornecedor criado: {$data['razao_social']}");
            $this->setFlash('Fornecedor cadastrado com sucesso!', 'success');
            $this->redirect('/fornecedores');
        } else {
            $this->setFlash('Erro ao cadastrar fornecedor.', 'danger');
            $this->redirect('/fornecedores/create');
        }
    }
    
    public function edit($id) {
        if (!$this->checkPermission('fornecedores', 'editar')) {
            return;
        }
        
        $fornecedor = $this->db->fetchOne("SELECT * FROM fornecedores WHERE id = :id", ['id' => $id]);
        
        if (!$fornecedor) {
            $this->setFlash('Fornecedor não encontrado.', 'danger');
            $this->redirect('/fornecedores');
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->update($id);
        } else {
            echo $this->view->render('fornecedores/form', [
                'fornecedor' => $fornecedor
            ]);
        }
    }
    
    public function atualizar($id) {
        // Processa a atualização do formulário
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->update($id);
        } else {
            $this->redirect("/fornecedores/editar/$id");
        }
    }
    
    private function update($id) {
        $data = $_POST;
        
        // Validação
        $errors = $this->validate($data, [
            'razao_social' => ['required']
        ]);
        
        if (!empty($errors)) {
            $this->setFlash('Corrija os erros no formulário.', 'danger');
            $this->redirect("/fornecedores/edit/$id");
            return;
        }
        
        // Prepara dados
        $fornecedorData = [
            'razao_social' => $data['razao_social'],
            'endereco' => $data['endereco'] ?? null,
            'cep' => preg_replace('/[^0-9]/', '', $data['cep'] ?? ''),
            'telefone' => $data['telefone'] ?? null,
            'email' => $data['email'] ?? null,
            'responsavel_legal' => $data['responsavel_legal'] ?? null,
            'area_atuacao' => $data['area_atuacao'] ?? null,
            'cidade' => $data['cidade'] ?? null,
            'ativo' => isset($data['ativo']) ? 1 : 0
        ];
        
        if ($this->db->update('fornecedores', $fornecedorData, 'id = :id', ['id' => $id])) {
            $this->logActivity('fornecedor_atualizado', "Fornecedor atualizado ID: $id");
            $this->setFlash('Fornecedor atualizado com sucesso!', 'success');
            $this->redirect('/fornecedores');
        } else {
            $this->setFlash('Erro ao atualizar fornecedor.', 'danger');
            $this->redirect("/fornecedores/edit/$id");
        }
    }
    
    public function view($id) {
        if (!$this->checkPermission('fornecedores', 'visualizar')) {
            return;
        }
        
        $fornecedor = $this->db->fetchOne("SELECT * FROM fornecedores WHERE id = :id", ['id' => $id]);
        
        if (!$fornecedor) {
            $this->setFlash('Fornecedor não encontrado.', 'danger');
            $this->redirect('/fornecedores');
            return;
        }
        
        // Últimas contas pagas
        $sql = "SELECT cp.*, e.nome as empreendimento_nome
                FROM contas_pagar cp
                LEFT JOIN empreendimentos e ON cp.empreendimento_id = e.id
                WHERE cp.fornecedor_id = :id
                ORDER BY cp.data_vencimento DESC
                LIMIT 20";
        
        $contas = $this->db->fetchAll($sql, ['id' => $id]);
        
        // Últimas compras
        $sql = "SELECT c.*, e.nome as empreendimento_nome
                FROM compras c
                JOIN empreendimentos e ON c.empreendimento_id = e.id
                WHERE c.fornecedor_id = :id
                ORDER BY c.created_at DESC
                LIMIT 20";
        
        $compras = $this->db->fetchAll($sql, ['id' => $id]);
        
        // Estatísticas
        $stats = [
            'total_pago' => $this->db->fetchOne(
                "SELECT SUM(valor) as total FROM contas_pagar WHERE fornecedor_id = :id AND status = 'pago'",
                ['id' => $id]
            )['total'] ?? 0,
            
            'total_pendente' => $this->db->fetchOne(
                "SELECT SUM(valor) as total FROM contas_pagar WHERE fornecedor_id = :id AND status IN ('pendente', 'vencido')",
                ['id' => $id]
            )['total'] ?? 0,
            
            'total_compras' => $this->db->count('compras', 'fornecedor_id = :id', ['id' => $id]),
            
            'compras_mes' => $this->db->count(
                'compras',
                "fornecedor_id = :id AND MONTH(created_at) = MONTH(CURDATE())",
                ['id' => $id]
            )
        ];
        
        echo $this->view->render('fornecedores/view', [
            'fornecedor' => $fornecedor,
            'contas' => $contas,
            'compras' => $compras,
            'stats' => $stats
        ]);
    }
    
    public function delete($id) {
        if (!$this->checkPermission('fornecedores', 'deletar')) {
            return;
        }
        
        // Verifica se há contas ou compras vinculadas
        $contas = $this->db->count('contas_pagar', 'fornecedor_id = :id', ['id' => $id]);
        $compras = $this->db->count('compras', 'fornecedor_id = :id', ['id' => $id]);
        
        if ($contas > 0 || $compras > 0) {
            $this->setFlash('Não é possível excluir este fornecedor pois existem registros vinculados.', 'danger');
            $this->redirect('/fornecedores');
            return;
        }
        
        if ($this->db->delete('fornecedores', 'id = :id', ['id' => $id])) {
            $this->logActivity('fornecedor_deletado', "Fornecedor deletado ID: $id");
            $this->setFlash('Fornecedor excluído com sucesso!', 'success');
        } else {
            $this->setFlash('Erro ao excluir fornecedor.', 'danger');
        }
        
        $this->redirect('/fornecedores');
    }
    
    public function ativar($id) {
        if (!$this->checkPermission('fornecedores', 'editar')) {
            return;
        }
        
        if ($this->db->update('fornecedores', ['ativo' => 1], 'id = :id', ['id' => $id])) {
            $this->logActivity('fornecedor_ativado', "Fornecedor ativado ID: $id");
            $this->setFlash('Fornecedor ativado com sucesso!', 'success');
        } else {
            $this->setFlash('Erro ao ativar fornecedor.', 'danger');
        }
        
        $this->redirect('/fornecedores');
    }
    
    public function desativar($id) {
        if (!$this->checkPermission('fornecedores', 'editar')) {
            return;
        }
        
        if ($this->db->update('fornecedores', ['ativo' => 0], 'id = :id', ['id' => $id])) {
            $this->logActivity('fornecedor_desativado', "Fornecedor desativado ID: $id");
            $this->setFlash('Fornecedor desativado com sucesso!', 'success');
        } else {
            $this->setFlash('Erro ao desativar fornecedor.', 'danger');
        }
        
        $this->redirect('/fornecedores');
    }
    
    public function relatorio() {
        if (!$this->checkPermission('fornecedores', 'visualizar')) {
            return;
        }
        
        $mes = $_GET['mes'] ?? date('Y-m');
        
        // Fornecedores com movimentação no mês
        $sql = "SELECT f.*, 
                (SELECT SUM(valor) FROM contas_pagar 
                 WHERE fornecedor_id = f.id 
                 AND DATE_FORMAT(data_pagamento, '%Y-%m') = :mes 
                 AND status = 'pago') as total_mes,
                (SELECT COUNT(*) FROM compras 
                 WHERE fornecedor_id = f.id 
                 AND DATE_FORMAT(created_at, '%Y-%m') = :mes2) as compras_mes
                FROM fornecedores f
                WHERE f.ativo = 1
                HAVING total_mes > 0 OR compras_mes > 0
                ORDER BY total_mes DESC";
        
        $fornecedores = $this->db->fetchAll($sql, ['mes' => $mes, 'mes2' => $mes]);
        
        // Total geral do mês
        $sql = "SELECT SUM(valor) as total 
                FROM contas_pagar 
                WHERE DATE_FORMAT(data_pagamento, '%Y-%m') = :mes 
                AND status = 'pago'";
        
        $totalMes = $this->db->fetchOne($sql, ['mes' => $mes])['total'] ?? 0;
        
        echo $this->view->render('fornecedores/relatorio', [
            'fornecedores' => $fornecedores,
            'mes' => $mes,
            'total_mes' => $totalMes
        ]);
    }
    
    // API para busca AJAX
    public function buscar() {
        if (!$this->checkPermission('fornecedores', 'visualizar')) {
            $this->json(['success' => false, 'message' => 'Sem permissão'], 403);
            return;
        }
        
        $query = $_GET['q'] ?? '';
        
        if (strlen($query) < 2) {
            $this->json(['results' => []]);
            return;
        }
        
        $sql = "SELECT id, razao_social, cnpj 
                FROM fornecedores 
                WHERE ativo = 1 
                AND (razao_social LIKE :query OR cnpj LIKE :query)
                LIMIT 10";
        
        $fornecedores = $this->db->fetchAll($sql, ['query' => "%$query%"]);
        
        $results = array_map(function($f) {
            return [
                'id' => $f['id'],
                'text' => $f['razao_social'] . ' - ' . $this->formatCNPJ($f['cnpj'])
            ];
        }, $fornecedores);
        
        $this->json(['results' => $results]);
    }
    
    private function formatCNPJ($cnpj) {
        $cnpj = preg_replace('/[^0-9]/', '', $cnpj);
        return substr($cnpj, 0, 2) . '.' . substr($cnpj, 2, 3) . '.' . 
               substr($cnpj, 5, 3) . '/' . substr($cnpj, 8, 4) . '-' . 
               substr($cnpj, 12, 2);
    }
}
