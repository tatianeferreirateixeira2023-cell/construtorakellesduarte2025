<?php
class FuncionarioController extends Controller {
    
    public function index() {
        if (!$this->checkPermission('funcionarios', 'visualizar')) {
            return;
        }
        
        $page = $_GET['page'] ?? 1;
        $limit = 20;
        $offset = ($page - 1) * $limit;
        
        // Filtros
        $where = "1=1";
        $params = [];
        
        if (isset($_GET['status']) && !empty($_GET['status'])) {
            $where .= " AND f.status = :status";
            $params['status'] = $_GET['status'];
        }
        
        if (isset($_GET['empreendimento']) && !empty($_GET['empreendimento'])) {
            $where .= " AND f.empreendimento_id = :empreendimento";
            $params['empreendimento'] = $_GET['empreendimento'];
        }
        
        if (isset($_GET['search']) && !empty($_GET['search'])) {
            $search = '%' . $_GET['search'] . '%';
            $where .= " AND (f.nome LIKE :search OR f.cpf LIKE :search OR f.funcao LIKE :search)";
            $params['search'] = $search;
        }
        
        // Busca funcionários
        $sql = "SELECT f.*, e.nome as empreendimento_nome,
                (SELECT COUNT(*) FROM epis WHERE funcionario_id = f.id AND data_devolucao IS NULL) as epis_ativos,
                (SELECT COUNT(*) FROM faltas WHERE funcionario_id = f.id AND MONTH(data) = MONTH(CURDATE())) as faltas_mes
                FROM funcionarios f 
                LEFT JOIN empreendimentos e ON f.empreendimento_id = e.id 
                WHERE $where 
                ORDER BY f.nome ASC 
                LIMIT $limit OFFSET $offset";
        
        $funcionarios = $this->db->fetchAll($sql, $params);
        
        // Total para paginação
        $total = $this->db->count('funcionarios f', $where, $params);
        $totalPages = ceil($total / $limit);
        
        // Empreendimentos para filtro
        $empreendimentos = $this->db->fetchAll("SELECT id, nome FROM empreendimentos ORDER BY nome");
        
        $data = [
            'funcionarios' => $funcionarios,
            'empreendimentos' => $empreendimentos,
            'pagination' => [
                'current' => $page,
                'total' => $totalPages,
                'limit' => $limit,
                'total_records' => $total
            ],
            'filters' => $_GET,
            'flash' => $this->getFlash()
        ];
        
        echo $this->view->render('funcionarios/index', $data);
    }
    
    public function epis() {
        if (!$this->checkPermission('epis', 'visualizar')) {
            return;
        }
        
        $page = $_GET['page'] ?? 1;
        $limit = 25;
        $offset = ($page - 1) * $limit;
        
        // Filtros
        $where = "1=1";
        $params = [];
        
        if (isset($_GET['funcionario']) && !empty($_GET['funcionario'])) {
            $where .= " AND e.funcionario_id = :funcionario";
            $params['funcionario'] = $_GET['funcionario'];
        }
        
        if (isset($_GET['status']) && !empty($_GET['status'])) {
            if ($_GET['status'] == 'entregue') {
                $where .= " AND e.data_devolucao IS NULL";
            } else if ($_GET['status'] == 'devolvido') {
                $where .= " AND e.data_devolucao IS NOT NULL";
            }
        }
        
        // Busca EPIs
        $sql = "SELECT e.*, f.nome as funcionario_nome, f.cpf as funcionario_cpf,
                te.nome as tipo_epi_nome
                FROM epis e 
                JOIN funcionarios f ON e.funcionario_id = f.id 
                LEFT JOIN tipos_epi te ON e.tipo_epi_id = te.id
                WHERE $where 
                ORDER BY e.data_entrega DESC 
                LIMIT $limit OFFSET $offset";
        
        $epis = $this->db->fetchAll($sql, $params);
        
        // Total para paginação
        $total = $this->db->count('epis e', $where, $params);
        $totalPages = ceil($total / $limit);
        
        // Funcionários para filtro
        $funcionarios = $this->db->fetchAll("SELECT id, nome FROM funcionarios WHERE status = 'ativo' ORDER BY nome");
        
        // Estatísticas
        $estatisticas = [
            'total_entregue' => $this->db->count('epis', 'data_devolucao IS NULL'),
            'total_devolvido' => $this->db->count('epis', 'data_devolucao IS NOT NULL'),
            'vencendo_mes' => $this->db->count('epis', 'data_devolucao IS NULL AND DATE_ADD(data_entrega, INTERVAL validade_meses MONTH) <= DATE_ADD(CURDATE(), INTERVAL 1 MONTH)'),
            'total_funcionarios' => $this->db->count('funcionarios', "status = 'ativo'")
        ];
        
        $data = [
            'epis' => $epis,
            'funcionarios' => $funcionarios,
            'estatisticas' => $estatisticas,
            'pagination' => [
                'current' => $page,
                'total' => $totalPages,
                'limit' => $limit,
                'total_records' => $total
            ],
            'filters' => $_GET,
            'flash' => $this->getFlash()
        ];
        
        echo $this->view->render('funcionarios/epis', $data);
    }
    
    public function faltas() {
        if (!$this->checkPermission('faltas', 'visualizar')) {
            return;
        }
        
        $page = $_GET['page'] ?? 1;
        $limit = 25;
        $offset = ($page - 1) * $limit;
        
        // Filtros
        $where = "1=1";
        $params = [];
        
        if (isset($_GET['funcionario']) && !empty($_GET['funcionario'])) {
            $where .= " AND fa.funcionario_id = :funcionario";
            $params['funcionario'] = $_GET['funcionario'];
        }
        
        if (isset($_GET['mes']) && !empty($_GET['mes'])) {
            $where .= " AND DATE_FORMAT(fa.data, '%Y-%m') = :mes";
            $params['mes'] = $_GET['mes'];
        }
        
        // Busca faltas
        $sql = "SELECT fa.*, f.nome as funcionario_nome, f.cpf as funcionario_cpf
                FROM faltas fa 
                JOIN funcionarios f ON fa.funcionario_id = f.id 
                WHERE $where 
                ORDER BY fa.data DESC 
                LIMIT $limit OFFSET $offset";
        
        $faltas = $this->db->fetchAll($sql, $params);
        
        // Total para paginação
        $total = $this->db->count('faltas fa', $where, $params);
        $totalPages = ceil($total / $limit);
        
        // Funcionários para filtro
        $funcionarios = $this->db->fetchAll("SELECT id, nome FROM funcionarios WHERE status = 'ativo' ORDER BY nome");
        
        // Estatísticas do mês atual
        $mesAtual = date('Y-m');
        $estatisticas = [
            'total_mes' => $this->db->count('faltas', "DATE_FORMAT(data, '%Y-%m') = '$mesAtual'"),
            'total_justificadas' => $this->db->count('faltas', "DATE_FORMAT(data, '%Y-%m') = '$mesAtual' AND justificada = 1"),
            'total_injustificadas' => $this->db->count('faltas', "DATE_FORMAT(data, '%Y-%m') = '$mesAtual' AND justificada = 0"),
            'funcionarios_faltosos' => $this->db->fetchOne("SELECT COUNT(DISTINCT funcionario_id) as total FROM faltas WHERE DATE_FORMAT(data, '%Y-%m') = '$mesAtual'")['total']
        ];
        
        $data = [
            'faltas' => $faltas,
            'funcionarios' => $funcionarios,
            'estatisticas' => $estatisticas,
            'pagination' => [
                'current' => $page,
                'total' => $totalPages,
                'limit' => $limit,
                'total_records' => $total
            ],
            'filters' => $_GET,
            'flash' => $this->getFlash()
        ];
        
        echo $this->view->render('funcionarios/faltas', $data);
    }
    
    public function criar() {
        if (!$this->checkPermission('funcionarios', 'criar')) {
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->store();
        } else {
            $empreendimentos = $this->db->fetchAll("SELECT id, nome FROM empreendimentos ORDER BY nome");
            echo $this->view->render('funcionarios/form', [
                'empreendimentos' => $empreendimentos,
                'funcionario' => null,
                'flash' => $this->getFlash()
            ]);
        }
    }
    
    public function create() {
        // Alias para manter compatibilidade
        return $this->criar();
    }
    
    public function salvar() {
        // Processa o salvamento do formulário
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->store();
        } else {
            $this->redirect('/funcionarios/novo');
        }
    }
    
    private function store() {
        $data = $_POST;
        
        // Validação
        $errors = $this->validate($data, [
            'nome' => ['required'],
            'cpf' => ['required', 'cpf'],
            'data_admissao' => ['required'],
            'funcao' => ['required']
        ]);
        
        // Verifica CPF único
        if ($this->db->count('funcionarios', 'cpf = :cpf', ['cpf' => preg_replace('/[^0-9]/', '', $data['cpf'])]) > 0) {
            $errors['cpf'][] = 'CPF já cadastrado.';
        }
        
        if (!empty($errors)) {
            $this->setFlash('Corrija os erros no formulário.', 'danger');
            $empreendimentos = $this->db->fetchAll("SELECT id, nome FROM empreendimentos ORDER BY nome");
            echo $this->view->render('funcionarios/form', [
                'empreendimentos' => $empreendimentos,
                'errors' => $errors,
                'old' => $data,
                'funcionario' => null
            ]);
            return;
        }
        
        // Prepara dados
        $funcionarioData = [
            'nome' => $data['nome'],
            'cpf' => preg_replace('/[^0-9]/', '', $data['cpf']),
            'identidade' => $data['identidade'] ?? null,
            'ctps' => $data['ctps'] ?? null,
            'pis' => $data['pis'] ?? null,
            'endereco' => $data['endereco'] ?? null,
            'cep' => preg_replace('/[^0-9]/', '', $data['cep'] ?? ''),
            'telefone' => $data['telefone'] ?? null,
            'email' => $data['email'] ?? null,
            'data_admissao' => $data['data_admissao'],
            'empreendimento_id' => $data['empreendimento_id'] ?? null,
            'funcao' => $data['funcao'],
            'salario' => str_replace(['R$', '.', ','], ['', '', '.'], $data['salario'] ?? 0),
            'vale_transporte' => isset($data['vale_transporte']) ? 1 : 0,
            'status' => 'ativo'
        ];
        
        // Cria usuário se solicitado
        if (isset($data['criar_usuario']) && $data['criar_usuario']) {
            $userData = [
                'nome_completo' => $data['nome'],
                'email' => $data['email'],
                'senha' => password_hash($data['cpf'], PASSWORD_DEFAULT), // Senha inicial = CPF
                'cpf' => $funcionarioData['cpf'],
                'telefone' => $data['telefone'],
                'nivel_acesso_id' => NIVEL_FUNCIONARIO,
                'ativo' => 1
            ];
            
            $userId = $this->db->insert('usuarios', $userData);
            $funcionarioData['usuario_id'] = $userId;
        }
        
        if ($this->db->insert('funcionarios', $funcionarioData)) {
            $this->logActivity('funcionario_criado', "Funcionário criado: {$data['nome']}");
            $this->setFlash('Funcionário cadastrado com sucesso!', 'success');
            $this->redirect('/funcionarios');
        } else {
            $this->setFlash('Erro ao cadastrar funcionário.', 'danger');
            $this->redirect('/funcionarios/create');
        }
    }
    
    public function edit($id) {
        if (!$this->checkPermission('funcionarios', 'editar')) {
            return;
        }
        
        $funcionario = $this->db->fetchOne("SELECT * FROM funcionarios WHERE id = :id", ['id' => $id]);
        
        if (!$funcionario) {
            $this->setFlash('Funcionário não encontrado.', 'danger');
            $this->redirect('/funcionarios');
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->update($id);
        } else {
            $empreendimentos = $this->db->fetchAll("SELECT id, nome FROM empreendimentos ORDER BY nome");
            echo $this->view->render('funcionarios/form', [
                'funcionario' => $funcionario,
                'empreendimentos' => $empreendimentos
            ]);
        }
    }
    
    public function atualizar($id) {
        // Processa a atualização do formulário
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->update($id);
        } else {
            $this->redirect("/funcionarios/editar/$id");
        }
    }
    
    private function update($id) {
        $data = $_POST;
        
        // Validação
        $errors = $this->validate($data, [
            'nome' => ['required'],
            'funcao' => ['required']
        ]);
        
        if (!empty($errors)) {
            $this->setFlash('Corrija os erros no formulário.', 'danger');
            $this->redirect("/funcionarios/edit/$id");
            return;
        }
        
        // Prepara dados
        $funcionarioData = [
            'nome' => $data['nome'],
            'identidade' => $data['identidade'] ?? null,
            'ctps' => $data['ctps'] ?? null,
            'pis' => $data['pis'] ?? null,
            'endereco' => $data['endereco'] ?? null,
            'cep' => preg_replace('/[^0-9]/', '', $data['cep'] ?? ''),
            'telefone' => $data['telefone'] ?? null,
            'email' => $data['email'] ?? null,
            'empreendimento_id' => $data['empreendimento_id'] ?? null,
            'funcao' => $data['funcao'],
            'salario' => str_replace(['R$', '.', ','], ['', '', '.'], $data['salario'] ?? 0),
            'vale_transporte' => isset($data['vale_transporte']) ? 1 : 0,
            'status' => $data['status']
        ];
        
        if ($this->db->update('funcionarios', $funcionarioData, 'id = :id', ['id' => $id])) {
            $this->logActivity('funcionario_atualizado', "Funcionário atualizado ID: $id");
            $this->setFlash('Funcionário atualizado com sucesso!', 'success');
            $this->redirect('/funcionarios');
        } else {
            $this->setFlash('Erro ao atualizar funcionário.', 'danger');
            $this->redirect("/funcionarios/edit/$id");
        }
    }
    
    public function view($id) {
        if (!$this->checkPermission('funcionarios', 'visualizar')) {
            return;
        }
        
        $sql = "SELECT f.*, e.nome as empreendimento_nome
                FROM funcionarios f 
                LEFT JOIN empreendimentos e ON f.empreendimento_id = e.id 
                WHERE f.id = :id";
        
        $funcionario = $this->db->fetchOne($sql, ['id' => $id]);
        
        if (!$funcionario) {
            $this->setFlash('Funcionário não encontrado.', 'danger');
            $this->redirect('/funcionarios');
            return;
        }
        
        // EPIs do funcionário
        $epis = $this->db->fetchAll(
            "SELECT * FROM epis WHERE funcionario_id = :id ORDER BY data_entrega DESC",
            ['id' => $id]
        );
        
        // Faltas do funcionário
        $faltas = $this->db->fetchAll(
            "SELECT * FROM faltas WHERE funcionario_id = :id ORDER BY data DESC LIMIT 20",
            ['id' => $id]
        );
        
        // Adiantamentos
        $adiantamentos = $this->db->fetchAll(
            "SELECT * FROM adiantamentos WHERE funcionario_id = :id ORDER BY data_solicitacao DESC LIMIT 10",
            ['id' => $id]
        );
        
        // Férias
        $ferias = $this->db->fetchAll(
            "SELECT * FROM ferias WHERE funcionario_id = :id ORDER BY periodo_inicio DESC",
            ['id' => $id]
        );
        
        echo $this->view->render('funcionarios/view', [
            'funcionario' => $funcionario,
            'epis' => $epis,
            'faltas' => $faltas,
            'adiantamentos' => $adiantamentos,
            'ferias' => $ferias
        ]);
    }
    
    // Gestão de EPIs
    public function novaEntregaEpi() {
        if (!$this->checkPermission('epis', 'criar')) {
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = $_POST;
            
            $epiData = [
                'funcionario_id' => $data['funcionario_id'],
                'data_entrega' => $data['data_entrega'] ?? date('Y-m-d'),
                'descricao' => $data['descricao'],
                'codigo' => $data['codigo'] ?? null,
                'quantidade' => $data['quantidade'] ?? 1
            ];
            
            if ($this->db->insert('epis_entregues', $epiData)) {
                $this->logActivity('epi_entregue', "EPI entregue para funcionário ID: {$data['funcionario_id']}");
                $this->setFlash('EPI registrado com sucesso!', 'success');
            } else {
                $this->setFlash('Erro ao registrar EPI.', 'danger');
            }
            
            $this->redirect('/epis');
        } else {
            $funcionarios = $this->db->fetchAll("SELECT id, nome FROM funcionarios WHERE status = 'ativo' ORDER BY nome");
            $tipos_epi = $this->db->fetchAll("SELECT * FROM tipos_epi ORDER BY nome");
            
            echo $this->view->render('funcionarios/nova_entrega_epi', [
                'funcionarios' => $funcionarios,
                'tipos_epi' => $tipos_epi,
                'flash' => $this->getFlash()
            ]);
        }
    }
    
    public function entregarEpi() {
        // Alias para compatibilidade
        return $this->novaEntregaEpi();
    }
    
    public function devolverEpi($id) {
        if (!$this->checkPermission('epis', 'editar')) {
            return;
        }
        
        $data = [
            'data_devolucao' => date('Y-m-d')
        ];
        
        if ($this->db->update('epis', $data, 'id = :id', ['id' => $id])) {
            $this->logActivity('epi_devolvido', "EPI devolvido ID: $id");
            $this->setFlash('Devolução registrada com sucesso!', 'success');
        } else {
            $this->setFlash('Erro ao registrar devolução.', 'danger');
        }
        
        $this->redirect('/funcionarios/epis');
    }
    
    // Gestão de Faltas
    public function registrarFalta() {
        if (!$this->checkPermission('faltas', 'criar')) {
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = $_POST;
            
            $faltaData = [
                'funcionario_id' => $data['funcionario_id'],
                'data' => $data['data'],
                'tipo' => $data['tipo'] ?? 'falta',
                'horas_atraso' => $data['horas_atraso'] ?? null,
                'motivo' => $data['motivo'] ?? null,
                'justificada' => isset($data['justificada']) ? 1 : 0
            ];
            
            if ($this->db->insert('faltas', $faltaData)) {
                $this->logActivity('falta_registrada', "Falta registrada para funcionário ID: {$data['funcionario_id']}");
                $this->setFlash('Falta registrada com sucesso!', 'success');
            } else {
                $this->setFlash('Erro ao registrar falta.', 'danger');
            }
            
            $this->redirect('/funcionarios/faltas');
        } else {
            $funcionarios = $this->db->fetchAll("SELECT id, nome FROM funcionarios WHERE status = 'ativo' ORDER BY nome");
            echo $this->view->render('funcionarios/registrar_falta', [
                'funcionarios' => $funcionarios
            ]);
        }
    }
    
    public function excluirFalta($id) {
        if (!$this->checkPermission('faltas', 'deletar')) {
            return;
        }
        
        // Verifica se a falta existe
        $falta = $this->db->fetchOne("SELECT * FROM faltas WHERE id = :id", ['id' => $id]);
        
        if (!$falta) {
            $this->setFlash('Falta não encontrada.', 'danger');
            $this->redirect('/faltas');
            return;
        }
        
        // Exclui a falta
        if ($this->db->delete('faltas', 'id = :id', ['id' => $id])) {
            $this->logActivity('falta_excluida', "Falta excluída ID: $id");
            $this->setFlash('Falta excluída com sucesso!', 'success');
        } else {
            $this->setFlash('Erro ao excluir falta.', 'danger');
        }
        
        $this->redirect('/faltas');
    }
    
    // Gestão de Adiantamentos
    public function adiantamentos() {
        if (!$this->checkPermission('funcionarios', 'visualizar')) {
            return;
        }
        
        $sql = "SELECT a.*, f.nome as funcionario_nome
                FROM adiantamentos a
                JOIN funcionarios f ON a.funcionario_id = f.id
                WHERE a.status IN ('pendente', 'aprovado')
                ORDER BY a.data_solicitacao DESC";
        
        $adiantamentos = $this->db->fetchAll($sql);
        
        echo $this->view->render('funcionarios/adiantamentos', [
            'adiantamentos' => $adiantamentos,
            'flash' => $this->getFlash()
        ]);
    }
    
    public function solicitarAdiantamento() {
        if (!$this->checkPermission('funcionarios', 'criar')) {
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = $_POST;
            
            $valor = str_replace(['R$', '.', ','], ['', '', '.'], $data['valor']);
            $parcelas = $data['parcelas'] ?? 1;
            
            $adiantamentoData = [
                'funcionario_id' => $data['funcionario_id'],
                'valor' => $valor,
                'data_solicitacao' => date('Y-m-d'),
                'tipo' => $data['tipo'],
                'motivo' => $data['motivo'] ?? null,
                'parcelas' => $parcelas,
                'valor_parcela' => $valor / $parcelas,
                'status' => 'pendente'
            ];
            
            if ($this->db->insert('adiantamentos', $adiantamentoData)) {
                $this->logActivity('adiantamento_solicitado', "Adiantamento solicitado: R$ $valor");
                $this->setFlash('Adiantamento solicitado com sucesso!', 'success');
            } else {
                $this->setFlash('Erro ao solicitar adiantamento.', 'danger');
            }
            
            $this->redirect('/funcionarios/adiantamentos');
        } else {
            $funcionarios = $this->db->fetchAll("SELECT id, nome FROM funcionarios WHERE status = 'ativo' ORDER BY nome");
            echo $this->view->render('funcionarios/solicitar_adiantamento', [
                'funcionarios' => $funcionarios
            ]);
        }
    }
    
    public function aprovarAdiantamento($id) {
        if (!$this->checkPermission('funcionarios', 'editar')) {
            return;
        }
        
        $this->db->update('adiantamentos', ['status' => 'aprovado'], 'id = :id', ['id' => $id]);
        $this->logActivity('adiantamento_aprovado', "Adiantamento aprovado ID: $id");
        $this->setFlash('Adiantamento aprovado!', 'success');
        $this->redirect('/funcionarios/adiantamentos');
    }
    
    public function pagarAdiantamento($id) {
        if (!$this->checkPermission('funcionarios', 'editar')) {
            return;
        }
        
        $data = [
            'status' => 'pago',
            'data_pagamento' => date('Y-m-d')
        ];
        
        if ($this->db->update('adiantamentos', $data, 'id = :id', ['id' => $id])) {
            $this->logActivity('adiantamento_pago', "Adiantamento pago ID: $id");
            $this->setFlash('Pagamento registrado!', 'success');
        } else {
            $this->setFlash('Erro ao registrar pagamento.', 'danger');
        }
        
        $this->redirect('/funcionarios/adiantamentos');
    }
    
    // Gestão de Férias
    public function ferias() {
        if (!$this->checkPermission('funcionarios', 'visualizar')) {
            return;
        }
        
        $ano = $_GET['ano'] ?? date('Y');
        
        $sql = "SELECT f.*, func.nome as funcionario_nome, func.data_admissao
                FROM ferias f
                JOIN funcionarios func ON f.funcionario_id = func.id
                WHERE YEAR(f.periodo_inicio) = :ano
                ORDER BY f.periodo_inicio";
        
        $ferias = $this->db->fetchAll($sql, ['ano' => $ano]);
        
        // Funcionários com direito a férias
        $sql = "SELECT * FROM funcionarios 
                WHERE status = 'ativo' 
                AND DATEDIFF(CURDATE(), data_admissao) >= 365
                AND (ultimas_ferias IS NULL OR DATEDIFF(CURDATE(), ultimas_ferias) >= 365)";
        
        $funcionarios_direito = $this->db->fetchAll($sql);
        
        echo $this->view->render('funcionarios/ferias', [
            'ferias' => $ferias,
            'ano' => $ano,
            'funcionarios_direito' => $funcionarios_direito,
            'flash' => $this->getFlash()
        ]);
    }
    
    public function registrarFerias() {
        if (!$this->checkPermission('funcionarios', 'criar')) {
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = $_POST;
            
            $feriasData = [
                'funcionario_id' => $data['funcionario_id'],
                'periodo_inicio' => $data['periodo_inicio'],
                'periodo_fim' => $data['periodo_fim'],
                'valor_pago' => str_replace(['R$', '.', ','], ['', '', '.'], $data['valor_pago'] ?? 0),
                'observacoes' => $data['observacoes'] ?? null
            ];
            
            if ($this->db->insert('ferias', $feriasData)) {
                // Atualiza última férias do funcionário
                $this->db->update('funcionarios', 
                    ['ultimas_ferias' => $data['periodo_inicio']], 
                    'id = :id', 
                    ['id' => $data['funcionario_id']]
                );
                
                $this->logActivity('ferias_registradas', "Férias registradas para funcionário ID: {$data['funcionario_id']}");
                $this->setFlash('Férias registradas com sucesso!', 'success');
            } else {
                $this->setFlash('Erro ao registrar férias.', 'danger');
            }
            
            $this->redirect('/funcionarios/ferias');
        } else {
            $funcionarios = $this->db->fetchAll(
                "SELECT * FROM funcionarios 
                WHERE status = 'ativo' 
                AND DATEDIFF(CURDATE(), data_admissao) >= 365
                ORDER BY nome"
            );
            
            echo $this->view->render('funcionarios/registrar_ferias', [
                'funcionarios' => $funcionarios
            ]);
        }
    }
}
