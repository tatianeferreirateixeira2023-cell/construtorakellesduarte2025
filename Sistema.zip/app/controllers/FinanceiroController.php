<?php
class FinanceiroController extends Controller {
    
    public function index() {
        if (!$this->checkPermission('financeiro', 'visualizar')) {
            return;
        }
        
        // Estatísticas do mês atual
        $mesAtual = date('Y-m');
        
        // Receitas
        $sql = "SELECT SUM(valor) as total, COUNT(*) as quantidade 
                FROM faturas 
                WHERE DATE_FORMAT(data_pagamento, '%Y-%m') = :mes 
                AND status = 'pago'";
        $receitas = $this->db->fetchOne($sql, ['mes' => $mesAtual]);
        
        // Despesas
        $sql = "SELECT SUM(valor) as total, COUNT(*) as quantidade 
                FROM contas_pagar 
                WHERE DATE_FORMAT(data_pagamento, '%Y-%m') = :mes 
                AND status = 'pago'";
        $despesas = $this->db->fetchOne($sql, ['mes' => $mesAtual]);
        
        // A receber
        $sql = "SELECT SUM(valor) as total, COUNT(*) as quantidade 
                FROM faturas 
                WHERE status IN ('em_aberto', 'vencido')";
        $aReceber = $this->db->fetchOne($sql);
        
        // A pagar
        $sql = "SELECT SUM(valor) as total, COUNT(*) as quantidade 
                FROM contas_pagar 
                WHERE status IN ('pendente', 'vencido')";
        $aPagar = $this->db->fetchOne($sql);
        
        // Faturas vencendo hoje
        $sql = "SELECT f.*, u.nome_completo as cliente_nome 
                FROM faturas f 
                JOIN usuarios u ON f.cliente_id = u.id 
                WHERE f.data_vencimento = CURDATE() 
                AND f.status = 'em_aberto'
                LIMIT 10";
        $vencendoHoje = $this->db->fetchAll($sql);
        
        $data = [
            'receitas_mes' => $receitas['total'] ?? 0,
            'qtd_receitas' => $receitas['quantidade'] ?? 0,
            'despesas_mes' => $despesas['total'] ?? 0,
            'qtd_despesas' => $despesas['quantidade'] ?? 0,
            'total_receber' => $aReceber['total'] ?? 0,
            'qtd_receber' => $aReceber['quantidade'] ?? 0,
            'total_pagar' => $aPagar['total'] ?? 0,
            'qtd_pagar' => $aPagar['quantidade'] ?? 0,
            'saldo_mes' => ($receitas['total'] ?? 0) - ($despesas['total'] ?? 0),
            'vencendo_hoje' => $vencendoHoje,
            'flash' => $this->getFlash()
        ];
        
        echo $this->view->render('financeiro/index', $data);
    }
    
    public function faturas() {
        if (!$this->checkPermission('faturas', 'visualizar')) {
            return;
        }
        
        $page = $_GET['page'] ?? 1;
        $limit = 25;
        $offset = ($page - 1) * $limit;
        
        // Filtros
        $where = "1=1";
        $params = [];
        
        if (isset($_GET['status']) && !empty($_GET['status'])) {
            $where .= " AND f.status = :status";
            $params['status'] = $_GET['status'];
        }
        
        if (isset($_GET['cliente']) && !empty($_GET['cliente'])) {
            $where .= " AND f.cliente_id = :cliente";
            $params['cliente'] = $_GET['cliente'];
        }
        
        // Atualiza status de faturas vencidas
        $this->atualizarFaturasVencidas();
        
        // Busca faturas
        $sql = "SELECT f.*, u.nome_completo as cliente_nome, u.cpf, u.telefone
                FROM faturas f 
                JOIN usuarios u ON f.cliente_id = u.id 
                WHERE $where 
                ORDER BY f.data_vencimento DESC 
                LIMIT $limit OFFSET $offset";
        
        $faturas = $this->db->fetchAll($sql, $params);
        
        // Total para paginação
        $total = $this->db->count('faturas f', $where, $params);
        $totalPages = ceil($total / $limit);
        
        // Clientes para o filtro
        $clientes = $this->db->fetchAll("SELECT id, nome_completo FROM usuarios WHERE nivel_acesso_id = " . NIVEL_CLIENTE . " ORDER BY nome_completo");
        
        $data = [
            'faturas' => $faturas,
            'clientes' => $clientes,
            'pagination' => [
                'current' => $page,
                'total' => $totalPages,
                'limit' => $limit,
                'total_records' => $total
            ],
            'filters' => $_GET,
            'flash' => $this->getFlash()
        ];
        
        echo $this->view->render('financeiro/faturas', $data);
    }
    
    public function contasPagar() {
        if (!$this->checkPermission('contas_pagar', 'visualizar')) {
            return;
        }
        
        $page = $_GET['page'] ?? 1;
        $limit = 25;
        $offset = ($page - 1) * $limit;
        
        // Filtros
        $where = "1=1";
        $params = [];
        
        if (isset($_GET['status']) && !empty($_GET['status'])) {
            $where .= " AND cp.status = :status";
            $params['status'] = $_GET['status'];
        }
        
        if (isset($_GET['fornecedor']) && !empty($_GET['fornecedor'])) {
            $where .= " AND cp.fornecedor_id = :fornecedor";
            $params['fornecedor'] = $_GET['fornecedor'];
        }
        
        if (isset($_GET['categoria']) && !empty($_GET['categoria'])) {
            $where .= " AND cp.categoria = :categoria";
            $params['categoria'] = $_GET['categoria'];
        }
        
        // Busca contas a pagar
        $sql = "SELECT cp.*, f.nome as fornecedor_nome 
                FROM contas_pagar cp 
                LEFT JOIN fornecedores f ON cp.fornecedor_id = f.id 
                WHERE $where 
                ORDER BY cp.data_vencimento DESC 
                LIMIT $limit OFFSET $offset";
        
        $contas = $this->db->fetchAll($sql, $params);
        
        // Total para paginação
        $total = $this->db->count('contas_pagar cp', $where, $params);
        $totalPages = ceil($total / $limit);
        
        // Estatísticas
        $estatisticas = [
            'total_pago' => $this->db->fetchOne("SELECT SUM(valor) as total FROM contas_pagar WHERE status = 'pago'")['total'] ?? 0,
            'total_pendente' => $this->db->fetchOne("SELECT SUM(valor) as total FROM contas_pagar WHERE status = 'pendente'")['total'] ?? 0,
            'total_vencido' => $this->db->fetchOne("SELECT SUM(valor) as total FROM contas_pagar WHERE status = 'vencido' AND data_vencimento < CURDATE()")['total'] ?? 0,
            'total_contas' => $this->db->count('contas_pagar')
        ];
        
        // Fornecedores para filtro
        $fornecedores = $this->db->fetchAll("SELECT id, nome FROM fornecedores ORDER BY nome");
        
        $data = [
            'contas' => $contas,
            'fornecedores' => $fornecedores,
            'estatisticas' => $estatisticas,
            'pagination' => [
                'current' => $page,
                'total' => $totalPages,
                'limit' => $limit,
                'total_records' => $total
            ],
            'filters' => $_GET,
            'flash' => $this->getFlash()
        ];
        
        echo $this->view->render('financeiro/contas-pagar', $data);
    }
    
    public function registrarPagamento($id) {
        if (!$this->checkPermission('faturas', 'editar')) {
            return;
        }
        
        $fatura = $this->db->fetchOne("SELECT * FROM faturas WHERE id = :id", ['id' => $id]);
        
        if (!$fatura) {
            $this->setFlash('Fatura não encontrada.', 'danger');
            $this->redirect('/financeiro/faturas');
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = $_POST;
            
            // Atualiza fatura
            $updateData = [
                'status' => 'pago',
                'data_pagamento' => $data['data_pagamento'] ?? date('Y-m-d'),
                'forma_pagamento' => $data['forma_pagamento'],
                'observacoes' => $data['observacoes'] ?? null
            ];
            
            if ($this->db->update('faturas', $updateData, 'id = :id', ['id' => $id])) {
                $this->logActivity('pagamento_registrado', "Pagamento registrado para fatura #$id");
                $this->setFlash('Pagamento registrado com sucesso!', 'success');
                $this->redirect('/financeiro/faturas');
            } else {
                $this->setFlash('Erro ao registrar pagamento.', 'danger');
                $this->redirect("/financeiro/faturas/pagar/$id");
            }
        } else {
            echo $this->view->render('financeiro/registrar_pagamento', ['fatura' => $fatura]);
        }
    }
    
    public function criarFatura() {
        if (!$this->checkPermission('faturas', 'criar')) {
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = $_POST;
            
            // Validação básica
            if (empty($data['imovel_id']) || empty($data['valor']) || empty($data['data_vencimento'])) {
                $this->setFlash('Preencha todos os campos obrigatórios.', 'danger');
                $this->redirect('/faturas/nova');
                return;
            }
            
            // Busca informações do imóvel e cliente
            $imovel = $this->db->fetchOne(
                "SELECT i.*, u.id as cliente_id FROM imoveis i 
                 LEFT JOIN usuarios u ON i.usuario_id = u.id 
                 WHERE i.id = :id",
                ['id' => $data['imovel_id']]
            );
            
            if (!$imovel) {
                $this->setFlash('Imóvel não encontrado.', 'danger');
                $this->redirect('/faturas/nova');
                return;
            }
            
            $faturaData = [
                'imovel_id' => $data['imovel_id'],
                'cliente_id' => $imovel['cliente_id'],
                'descricao' => $data['descricao'] ?? 'Fatura de cobrança',
                'valor' => str_replace(['R$', '.', ','], ['', '', '.'], $data['valor']),
                'data_vencimento' => $data['data_vencimento'],
                'status' => 'pendente',
                'tipo' => $data['tipo'] ?? 'mensalidade',
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            if ($this->db->insert('faturas', $faturaData)) {
                $this->logActivity('fatura_criada', "Fatura criada para imóvel ID: {$data['imovel_id']}");
                $this->setFlash('Fatura criada com sucesso!', 'success');
                $this->redirect('/faturas');
            } else {
                $this->setFlash('Erro ao criar fatura.', 'danger');
                $this->redirect('/faturas/nova');
            }
        } else {
            $imoveis = $this->db->fetchAll(
                "SELECT i.id, i.codigo, i.endereco, e.nome as empreendimento, u.nome_completo as cliente
                 FROM imoveis i
                 LEFT JOIN empreendimentos e ON i.empreendimento_id = e.id
                 LEFT JOIN usuarios u ON i.usuario_id = u.id
                 ORDER BY i.codigo"
            );
            
            echo $this->view->render('financeiro/criar_fatura', [
                'imoveis' => $imoveis,
                'flash' => $this->getFlash()
            ]);
        }
    }
    
    public function gerarBoleto($id) {
        if (!$this->checkPermission('faturas', 'visualizar')) {
            return;
        }
        
        $sql = "SELECT f.*, u.nome_completo, u.cpf, u.email
                FROM faturas f 
                JOIN usuarios u ON f.cliente_id = u.id 
                WHERE f.id = :id";
        
        $fatura = $this->db->fetchOne($sql, ['id' => $id]);
        
        if (!$fatura) {
            $this->setFlash('Fatura não encontrada.', 'danger');
            $this->redirect('/financeiro/faturas');
            return;
        }
        
        // Gera código do boleto se não existir
        if (empty($fatura['codigo_boleto'])) {
            $codigoBoleto = $this->gerarCodigoBoleto($fatura);
            $this->db->update('faturas', ['codigo_boleto' => $codigoBoleto], 'id = :id', ['id' => $id]);
            $fatura['codigo_boleto'] = $codigoBoleto;
        }
        
        // Renderiza view do boleto
        echo $this->view->renderPartial('financeiro/boleto', ['fatura' => $fatura]);
    }
    
    public function gerarPixQRCode($id) {
        if (!$this->checkPermission('faturas', 'visualizar')) {
            $this->json(['success' => false, 'message' => 'Sem permissão'], 403);
            return;
        }
        
        $fatura = $this->db->fetchOne("SELECT * FROM faturas WHERE id = :id", ['id' => $id]);
        
        if (!$fatura) {
            $this->json(['success' => false, 'message' => 'Fatura não encontrada'], 404);
            return;
        }
        
        // Gera código PIX
        $pixCode = $this->gerarCodigoPix($fatura);
        
        $this->json([
            'success' => true,
            'codigo' => $pixCode,
            'valor' => $this->formatMoney($fatura['valor']),
            'cnpj' => PIX_CNPJ
        ]);
    }
    
    public function criarContaPagar() {
        if (!$this->checkPermission('contas_pagar', 'criar')) {
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = $_POST;
            
            // Prepara dados
            $contaData = [
                'fornecedor_id' => $data['fornecedor_id'] ?? null,
                'empreendimento_id' => $data['empreendimento_id'] ?? null,
                'descricao' => $data['descricao'],
                'valor' => str_replace(['R$', '.', ','], ['', '', '.'], $data['valor']),
                'data_vencimento' => $data['data_vencimento'],
                'status' => 'pendente',
                'numero_nota_fiscal' => $data['numero_nota_fiscal'] ?? null,
                'cidade' => $data['cidade'] ?? null,
                'observacoes' => $data['observacoes'] ?? null
            ];
            
            if ($this->db->insert('contas_pagar', $contaData)) {
                $this->logActivity('conta_pagar_criada', "Conta a pagar criada: {$data['descricao']}");
                $this->setFlash('Conta a pagar criada com sucesso!', 'success');
                $this->redirect('/financeiro/contas-pagar');
            } else {
                $this->setFlash('Erro ao criar conta a pagar.', 'danger');
                $this->redirect('/financeiro/contas-pagar/criar');
            }
        } else {
            $fornecedores = $this->db->fetchAll("SELECT id, razao_social FROM fornecedores WHERE ativo = 1 ORDER BY razao_social");
            $empreendimentos = $this->db->fetchAll("SELECT id, nome FROM empreendimentos ORDER BY nome");
            
            echo $this->view->render('financeiro/criar_conta_pagar', [
                'fornecedores' => $fornecedores,
                'empreendimentos' => $empreendimentos
            ]);
        }
    }
    
    public function pagarConta($id) {
        if (!$this->checkPermission('contas_pagar', 'editar')) {
            return;
        }
        
        $conta = $this->db->fetchOne("SELECT * FROM contas_pagar WHERE id = :id", ['id' => $id]);
        
        if (!$conta) {
            $this->setFlash('Conta não encontrada.', 'danger');
            $this->redirect('/financeiro/contas-pagar');
            return;
        }
        
        $updateData = [
            'status' => 'pago',
            'data_pagamento' => date('Y-m-d')
        ];
        
        if ($this->db->update('contas_pagar', $updateData, 'id = :id', ['id' => $id])) {
            $this->logActivity('conta_paga', "Conta paga ID: $id");
            $this->setFlash('Pagamento registrado com sucesso!', 'success');
        } else {
            $this->setFlash('Erro ao registrar pagamento.', 'danger');
        }
        
        $this->redirect('/financeiro/contas-pagar');
    }
    
    // Métodos auxiliares
    private function atualizarFaturasVencidas() {
        $sql = "UPDATE faturas 
                SET status = 'vencido' 
                WHERE status = 'em_aberto' 
                AND data_vencimento < CURDATE()";
        $this->db->execute($sql);
    }
    
    private function gerarCodigoBoleto($fatura) {
        // Simulação de geração de código de boleto
        $codigo = date('Ymd') . str_pad($fatura['id'], 10, '0', STR_PAD_LEFT);
        return $codigo;
    }
    
    private function gerarCodigoPix($fatura) {
        // Simulação de geração de código PIX
        $valor = number_format($fatura['valor'], 2, '', '');
        $txid = 'KD' . date('YmdHis') . $fatura['id'];
        
        // Formato simplificado do PIX
        $pix = "00020126360014BR.GOV.BCB.PIX0114" . str_replace(['.', '/', '-'], '', PIX_CNPJ);
        $pix .= "5204000053039865402" . $valor;
        $pix .= "5802BR5925CONSTRUTORA KELLES DUARTE6007ITABIRA";
        $pix .= "62070503" . $txid;
        
        return $pix;
    }
}
