<?php
class UsuarioController extends Controller {
    
    public function index() {
        if (!$this->checkPermission('usuarios', 'visualizar')) {
            return;
        }
        
        $page = $_GET['page'] ?? 1;
        $limit = 20;
        $offset = ($page - 1) * $limit;
        
        // Filtros
        $where = "1=1";
        $params = [];
        
        if (isset($_GET['search']) && !empty($_GET['search'])) {
            $search = '%' . $_GET['search'] . '%';
            $where .= " AND (u.nome_completo LIKE :search OR u.email LIKE :search OR u.cpf LIKE :search)";
            $params['search'] = $search;
        }
        
        if (isset($_GET['nivel']) && !empty($_GET['nivel'])) {
            $where .= " AND u.nivel_acesso_id = :nivel";
            $params['nivel'] = $_GET['nivel'];
        }
        
        if (isset($_GET['status']) && $_GET['status'] !== '') {
            $where .= " AND u.ativo = :status";
            $params['status'] = $_GET['status'];
        }
        
        // Busca usuários
        $sql = "SELECT u.*, na.nome as nivel_nome 
                FROM usuarios u 
                JOIN niveis_acesso na ON u.nivel_acesso_id = na.id 
                WHERE $where 
                ORDER BY u.nome_completo ASC 
                LIMIT $limit OFFSET $offset";
        
        $usuarios = $this->db->fetchAll($sql, $params);
        
        // Total para paginação
        $total = $this->db->count('usuarios u', $where, $params);
        $totalPages = ceil($total / $limit);
        
        // Níveis de acesso para o filtro
        $niveis = $this->db->fetchAll("SELECT * FROM niveis_acesso ORDER BY nome");
        
        $data = [
            'usuarios' => $usuarios,
            'niveis' => $niveis,
            'pagination' => [
                'current' => $page,
                'total' => $totalPages,
                'limit' => $limit,
                'total_records' => $total
            ],
            'filters' => $_GET,
            'flash' => $this->getFlash()
        ];
        
        echo $this->view->render('usuarios/index', $data);
    }
    
    public function criar() {
        if (!$this->checkPermission('usuarios', 'criar')) {
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->store();
        } else {
            $niveis = $this->db->fetchAll("SELECT * FROM niveis_acesso ORDER BY nome");
            echo $this->view->render('usuarios/form', [
                'niveis' => $niveis,
                'usuario' => null,
                'flash' => $this->getFlash()
            ]);
        }
    }
    
    public function create() {
        // Alias para manter compatibilidade
        return $this->criar();
    }
    
    public function salvar() {
        // Processa o salvamento do formulário
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->store();
        } else {
            $this->redirect('/usuarios/novo');
        }
    }
    
    private function store() {
        $data = $_POST;
        
        // Validação
        $errors = $this->validate($data, [
            'nome_completo' => ['required', 'min:3', 'max:255'],
            'email' => ['required', 'email'],
            'senha' => ['required', 'min:' . PASSWORD_MIN_LENGTH],
            'cpf' => ['required', 'cpf'],
            'nivel_acesso_id' => ['required']
        ]);
        
        // Verifica se e-mail já existe
        if ($this->db->count('usuarios', 'email = :email', ['email' => $data['email']]) > 0) {
            $errors['email'][] = 'Este e-mail já está cadastrado.';
        }
        
        // Verifica se CPF já existe
        if ($this->db->count('usuarios', 'cpf = :cpf', ['cpf' => $data['cpf']]) > 0) {
            $errors['cpf'][] = 'Este CPF já está cadastrado.';
        }
        
        if (!empty($errors)) {
            $this->setFlash('Corrija os erros no formulário.', 'danger');
            $niveis = $this->db->fetchAll("SELECT * FROM niveis_acesso ORDER BY nome");
            echo $this->view->render('usuarios/form', [
                'niveis' => $niveis,
                'errors' => $errors,
                'old' => $data,
                'usuario' => null
            ]);
            return;
        }
        
        // Prepara dados para inserção
        $userData = [
            'nome_completo' => $data['nome_completo'],
            'email' => $data['email'],
            'senha' => password_hash($data['senha'], PASSWORD_DEFAULT),
            'cpf' => preg_replace('/[^0-9]/', '', $data['cpf']),
            'identidade' => $data['identidade'] ?? null,
            'data_nascimento' => $data['data_nascimento'] ?? null,
            'telefone' => $data['telefone'] ?? null,
            'profissao' => $data['profissao'] ?? null,
            'renda_familiar' => $data['renda_familiar'] ?? null,
            'nivel_acesso_id' => $data['nivel_acesso_id'],
            'conjuge_nome' => $data['conjuge_nome'] ?? null,
            'conjuge_cpf' => isset($data['conjuge_cpf']) ? preg_replace('/[^0-9]/', '', $data['conjuge_cpf']) : null,
            'conjuge_email' => $data['conjuge_email'] ?? null,
            'conjuge_identidade' => $data['conjuge_identidade'] ?? null,
            'conjuge_telefone' => $data['conjuge_telefone'] ?? null,
            'conjuge_profissao' => $data['conjuge_profissao'] ?? null,
            'conjuge_data_nascimento' => $data['conjuge_data_nascimento'] ?? null,
            'ativo' => 1
        ];
        
        // Insere usuário
        $userId = $this->db->insert('usuarios', $userData);
        
        if ($userId) {
            // Se for funcionário, cria registro na tabela funcionarios
            if ($data['nivel_acesso_id'] == NIVEL_FUNCIONARIO) {
                $this->createFuncionario($userId, $data);
            }
            
            $this->logActivity('usuario_criado', "Usuário criado: {$data['nome_completo']} (ID: $userId)");
            $this->setFlash('Usuário criado com sucesso!', 'success');
            $this->redirect('/usuarios');
        } else {
            $this->setFlash('Erro ao criar usuário.', 'danger');
            $this->redirect('/usuarios/create');
        }
    }
    
    public function editar($id) {
        if (!$this->checkPermission('usuarios', 'editar')) {
            return;
        }
        
        $usuario = $this->db->fetchOne("SELECT * FROM usuarios WHERE id = :id", ['id' => $id]);
        
        if (!$usuario) {
            $this->setFlash('Usuário não encontrado.', 'danger');
            $this->redirect('/usuarios');
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->update($id);
        } else {
            $niveis = $this->db->fetchAll("SELECT * FROM niveis_acesso ORDER BY nome");
            echo $this->view->render('usuarios/form', [
                'usuario' => $usuario,
                'niveis' => $niveis,
                'flash' => $this->getFlash()
            ]);
        }
    }
    
    public function edit($id) {
        // Alias para manter compatibilidade
        return $this->editar($id);
    }
    
    public function atualizar($id) {
        // Processa a atualização do formulário
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->update($id);
        } else {
            $this->redirect("/usuarios/editar/$id");
        }
    }
    
    private function update($id) {
        $data = $_POST;
        
        // Validação
        $errors = $this->validate($data, [
            'nome_completo' => ['required', 'min:3', 'max:255'],
            'email' => ['required', 'email'],
            'cpf' => ['required', 'cpf'],
            'nivel_acesso_id' => ['required']
        ]);
        
        // Verifica se e-mail já existe (exceto para o próprio usuário)
        $emailCheck = $this->db->fetchOne(
            "SELECT id FROM usuarios WHERE email = :email AND id != :id",
            ['email' => $data['email'], 'id' => $id]
        );
        if ($emailCheck) {
            $errors['email'][] = 'Este e-mail já está cadastrado.';
        }
        
        // Verifica se CPF já existe (exceto para o próprio usuário)
        $cpfCheck = $this->db->fetchOne(
            "SELECT id FROM usuarios WHERE cpf = :cpf AND id != :id",
            ['cpf' => preg_replace('/[^0-9]/', '', $data['cpf']), 'id' => $id]
        );
        if ($cpfCheck) {
            $errors['cpf'][] = 'Este CPF já está cadastrado.';
        }
        
        if (!empty($errors)) {
            $this->setFlash('Corrija os erros no formulário.', 'danger');
            $niveis = $this->db->fetchAll("SELECT * FROM niveis_acesso ORDER BY nome");
            $usuario = $this->db->fetchOne("SELECT * FROM usuarios WHERE id = :id", ['id' => $id]);
            echo $this->view->render('usuarios/form', [
                'usuario' => $usuario,
                'niveis' => $niveis,
                'errors' => $errors,
                'old' => $data
            ]);
            return;
        }
        
        // Prepara dados para atualização
        $userData = [
            'nome_completo' => $data['nome_completo'],
            'email' => $data['email'],
            'cpf' => preg_replace('/[^0-9]/', '', $data['cpf']),
            'identidade' => $data['identidade'] ?? null,
            'data_nascimento' => $data['data_nascimento'] ?? null,
            'telefone' => $data['telefone'] ?? null,
            'profissao' => $data['profissao'] ?? null,
            'renda_familiar' => $data['renda_familiar'] ?? null,
            'nivel_acesso_id' => $data['nivel_acesso_id'],
            'conjuge_nome' => $data['conjuge_nome'] ?? null,
            'conjuge_cpf' => isset($data['conjuge_cpf']) ? preg_replace('/[^0-9]/', '', $data['conjuge_cpf']) : null,
            'conjuge_email' => $data['conjuge_email'] ?? null,
            'conjuge_identidade' => $data['conjuge_identidade'] ?? null,
            'conjuge_telefone' => $data['conjuge_telefone'] ?? null,
            'conjuge_profissao' => $data['conjuge_profissao'] ?? null,
            'conjuge_data_nascimento' => $data['conjuge_data_nascimento'] ?? null
        ];
        
        // Se uma nova senha foi fornecida
        if (!empty($data['senha'])) {
            if (strlen($data['senha']) < PASSWORD_MIN_LENGTH) {
                $this->setFlash('A senha deve ter no mínimo ' . PASSWORD_MIN_LENGTH . ' caracteres.', 'danger');
                $this->redirect("/usuarios/edit/$id");
                return;
            }
            $userData['senha'] = password_hash($data['senha'], PASSWORD_DEFAULT);
        }
        
        // Atualiza usuário
        if ($this->db->update('usuarios', $userData, 'id = :id', ['id' => $id])) {
            $this->logActivity('usuario_atualizado', "Usuário atualizado: {$data['nome_completo']} (ID: $id)");
            $this->setFlash('Usuário atualizado com sucesso!', 'success');
            $this->redirect('/usuarios');
        } else {
            $this->setFlash('Erro ao atualizar usuário.', 'danger');
            $this->redirect("/usuarios/edit/$id");
        }
    }
    
    public function delete($id) {
        if (!$this->checkPermission('usuarios', 'deletar')) {
            return;
        }
        
        // Não permite deletar o próprio usuário
        if ($id == $this->user['id']) {
            $this->setFlash('Você não pode deletar seu próprio usuário.', 'danger');
            $this->redirect('/usuarios');
            return;
        }
        
        // Não permite deletar o admin principal (ID 1)
        if ($id == 1) {
            $this->setFlash('O administrador principal não pode ser deletado.', 'danger');
            $this->redirect('/usuarios');
            return;
        }
        
        $usuario = $this->db->fetchOne("SELECT nome_completo FROM usuarios WHERE id = :id", ['id' => $id]);
        
        if (!$usuario) {
            $this->setFlash('Usuário não encontrado.', 'danger');
            $this->redirect('/usuarios');
            return;
        }
        
        // Em vez de deletar, desativa o usuário
        if ($this->db->update('usuarios', ['ativo' => 0], 'id = :id', ['id' => $id])) {
            $this->logActivity('usuario_desativado', "Usuário desativado: {$usuario['nome_completo']} (ID: $id)");
            $this->setFlash('Usuário desativado com sucesso!', 'success');
        } else {
            $this->setFlash('Erro ao desativar usuário.', 'danger');
        }
        
        $this->redirect('/usuarios');
    }
    
    public function activate($id) {
        if (!$this->checkPermission('usuarios', 'editar')) {
            return;
        }
        
        $usuario = $this->db->fetchOne("SELECT nome_completo FROM usuarios WHERE id = :id", ['id' => $id]);
        
        if (!$usuario) {
            $this->setFlash('Usuário não encontrado.', 'danger');
            $this->redirect('/usuarios');
            return;
        }
        
        if ($this->db->update('usuarios', ['ativo' => 1], 'id = :id', ['id' => $id])) {
            $this->logActivity('usuario_ativado', "Usuário ativado: {$usuario['nome_completo']} (ID: $id)");
            $this->setFlash('Usuário ativado com sucesso!', 'success');
        } else {
            $this->setFlash('Erro ao ativar usuário.', 'danger');
        }
        
        $this->redirect('/usuarios');
    }
    
    public function profile() {
        $usuario = $this->db->fetchOne("SELECT * FROM usuarios WHERE id = :id", ['id' => $this->user['id']]);
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->updateProfile();
        } else {
            echo $this->view->render('usuarios/profile', [
                'usuario' => $usuario,
                'flash' => $this->getFlash()
            ]);
        }
    }
    
    private function updateProfile() {
        $data = $_POST;
        $id = $this->user['id'];
        
        // Validação básica
        $errors = $this->validate($data, [
            'nome_completo' => ['required', 'min:3', 'max:255'],
            'email' => ['required', 'email'],
            'cpf' => ['required']
        ]);
        
        if (!empty($errors)) {
            $this->setFlash('Corrija os erros no formulário.', 'danger');
            $usuario = $this->db->fetchOne("SELECT * FROM usuarios WHERE id = :id", ['id' => $id]);
            echo $this->view->render('usuarios/profile', [
                'usuario' => $usuario,
                'errors' => $errors,
                'old' => $data,
                'flash' => $this->getFlash()
            ]);
            return;
        }
        
        // Prepara dados para atualização
        $userData = [
            'nome_completo' => $data['nome_completo'],
            'email' => $data['email'],
            'cpf' => preg_replace('/[^0-9]/', '', $data['cpf']),
            'telefone' => $data['telefone'] ?? null,
            'data_nascimento' => !empty($data['data_nascimento']) ? $data['data_nascimento'] : null,
            'cep' => $data['cep'] ?? null,
            'endereco' => $data['endereco'] ?? null,
            'numero' => $data['numero'] ?? null,
            'complemento' => $data['complemento'] ?? null,
            'bairro' => $data['bairro'] ?? null,
            'cidade' => $data['cidade'] ?? null
        ];
        
        // Remove campos nulos se estiverem vazios
        foreach ($userData as $key => $value) {
            if ($value === '') {
                $userData[$key] = null;
            }
        }
        
        // Atualiza perfil
        try {
            if ($this->db->update('usuarios', $userData, 'id = :id', ['id' => $id])) {
                $this->logActivity('perfil_atualizado', "Perfil atualizado");
                $this->setFlash('Perfil atualizado com sucesso!', 'success');
                
                // Atualiza sessão
                $_SESSION['user_name'] = $data['nome_completo'];
            } else {
                $this->setFlash('Erro ao atualizar perfil.', 'danger');
            }
        } catch (Exception $e) {
            $this->setFlash('Erro ao atualizar perfil: ' . $e->getMessage(), 'danger');
        }
        
        $this->redirect('/perfil');
    }
    
    public function alterarSenha() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/perfil');
            return;
        }
        
        $data = $_POST;
        $id = $this->user['id'];
        
        // Validação
        if (empty($data['senha_atual']) || empty($data['nova_senha']) || empty($data['confirmar_senha'])) {
            $this->setFlash('Preencha todos os campos de senha.', 'danger');
            $this->redirect('/perfil');
            return;
        }
        
        // Verifica senha atual
        $user = $this->db->fetchOne("SELECT senha FROM usuarios WHERE id = :id", ['id' => $id]);
        
        if (!password_verify($data['senha_atual'], $user['senha'])) {
            $this->setFlash('Senha atual incorreta.', 'danger');
            $this->redirect('/perfil');
            return;
        }
        
        // Valida nova senha
        if (strlen($data['nova_senha']) < 6) {
            $this->setFlash('A nova senha deve ter no mínimo 6 caracteres.', 'danger');
            $this->redirect('/perfil');
            return;
        }
        
        if ($data['nova_senha'] !== $data['confirmar_senha']) {
            $this->setFlash('As senhas não coincidem.', 'danger');
            $this->redirect('/perfil');
            return;
        }
        
        // Atualiza senha
        $updateData = [
            'senha' => password_hash($data['nova_senha'], PASSWORD_DEFAULT)
        ];
        
        if ($this->db->update('usuarios', $updateData, 'id = :id', ['id' => $id])) {
            $this->logActivity('senha_alterada', "Senha alterada pelo usuário");
            $this->setFlash('Senha alterada com sucesso!', 'success');
        } else {
            $this->setFlash('Erro ao alterar senha.', 'danger');
        }
        
        $this->redirect('/perfil');
    }
    
    private function createFuncionario($userId, $data) {
        // Cria registro básico de funcionário
        $funcionarioData = [
            'usuario_id' => $userId,
            'nome' => $data['nome_completo'],
            'cpf' => preg_replace('/[^0-9]/', '', $data['cpf']),
            'identidade' => $data['identidade'] ?? null,
            'telefone' => $data['telefone'] ?? null,
            'email' => $data['email'],
            'data_admissao' => date('Y-m-d'),
            'status' => 'ativo'
        ];
        
        $this->db->insert('funcionarios', $funcionarioData);
    }
}
