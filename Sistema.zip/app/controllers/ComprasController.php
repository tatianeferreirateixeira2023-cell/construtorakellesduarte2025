<?php
require_once __DIR__ . '/../core/Controller.php';

class ComprasController extends Controller {
    
    public function index() {
        // Redireciona para o módulo de obras/compras
        $this->redirect('/obras/compras');
    }
}
