<?php
require_once __DIR__ . '/../core/Controller.php';

class EmpreendimentoController extends Controller {
    
    public function index() {
        if (!$this->checkPermission('empreendimentos', 'visualizar')) {
            return;
        }
        
        $page = $_GET['page'] ?? 1;
        $limit = 20;
        $offset = ($page - 1) * $limit;
        
        // Filtros
        $where = "1=1";
        $params = [];
        
        if (isset($_GET['cidade']) && !empty($_GET['cidade'])) {
            $where .= " AND e.cidade LIKE :cidade";
            $params['cidade'] = '%' . $_GET['cidade'] . '%';
        }
        
        if (isset($_GET['status']) && !empty($_GET['status'])) {
            $where .= " AND e.status = :status";
            $params['status'] = $_GET['status'];
        }
        
        // Busca empreendimentos
        $sql = "SELECT e.*, u.nome_completo as encarregado_nome,
                (SELECT COUNT(*) FROM imoveis WHERE empreendimento_id = e.id) as total_imoveis,
                (SELECT COUNT(*) FROM imoveis WHERE empreendimento_id = e.id AND status = 'vendido') as imoveis_vendidos
                FROM empreendimentos e 
                LEFT JOIN usuarios u ON e.encarregado_id = u.id 
                WHERE $where 
                ORDER BY e.created_at DESC 
                LIMIT $limit OFFSET $offset";
        
        $empreendimentos = $this->db->fetchAll($sql, $params);
        
        // Total para paginação
        $total = $this->db->count('empreendimentos e', $where, $params);
        $totalPages = ceil($total / $limit);
        
        $data = [
            'empreendimentos' => $empreendimentos,
            'pagination' => [
                'current' => $page,
                'total' => $totalPages,
                'limit' => $limit,
                'total_records' => $total
            ],
            'filters' => $_GET,
            'flash' => $this->getFlash()
        ];
        
        echo $this->view->render('empreendimentos/index', $data);
    }
    
    public function criar() {
        if (!$this->checkPermission('empreendimentos', 'criar')) {
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->store();
        } else {
            // Busca encarregados
            $encarregados = $this->db->fetchAll(
                "SELECT id, nome_completo FROM usuarios WHERE nivel_acesso_id = :nivel ORDER BY nome_completo",
                ['nivel' => NIVEL_ENCARREGADO]
            );
            
            echo $this->view->render('empreendimentos/form', [
                'encarregados' => $encarregados,
                'empreendimento' => null,
                'flash' => $this->getFlash()
            ]);
        }
    }
    
    public function create() {
        // Alias para manter compatibilidade
        return $this->criar();
    }
    
    public function salvar() {
        // Processa o salvamento do formulário
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->store();
        } else {
            $this->redirect('/empreendimentos/novo');
        }
    }
    
    private function store() {
        $data = $_POST;
        
        // Prepara dados para inserção
        $empreendimentoData = [
            'cidade' => $data['cidade'] ?? null,
            'nome' => $data['nome'] ?? null,
            'endereco' => $data['endereco'] ?? null,
            'cno' => $data['cno'] ?? null,
            'engenheiro_nome' => $data['engenheiro_nome'] ?? null,
            'engenheiro_art' => $data['engenheiro_art'] ?? null,
            'arquiteto_nome' => $data['arquiteto_nome'] ?? null,
            'arquiteto_cau' => $data['arquiteto_cau'] ?? null,
            'art_execucao' => $data['art_execucao'] ?? null,
            'encarregado_id' => $data['encarregado_id'] ?? null,
            'status' => $data['status'] ?? 'planejamento'
        ];
        
        // Insere empreendimento
        $empreendimentoId = $this->db->insert('empreendimentos', $empreendimentoData);
        
        if ($empreendimentoId) {
            // Upload de arquivos
            if (isset($_FILES['arquivos']) && !empty($_FILES['arquivos']['name'][0])) {
                $this->uploadEmpreendimentoFiles($empreendimentoId, $_FILES['arquivos']);
            }
            
            $this->logActivity('empreendimento_criado', "Empreendimento criado: {$data['nome']} (ID: $empreendimentoId)");
            $this->setFlash('Empreendimento cadastrado com sucesso!', 'success');
            $this->redirect('/empreendimentos');
        } else {
            $this->setFlash('Erro ao cadastrar empreendimento.', 'danger');
            $this->redirect('/empreendimentos/create');
        }
    }
    
    public function edit($id) {
        if (!$this->checkPermission('empreendimentos', 'editar')) {
            return;
        }
        
        $empreendimento = $this->db->fetchOne("SELECT * FROM empreendimentos WHERE id = :id", ['id' => $id]);
        
        if (!$empreendimento) {
            $this->setFlash('Empreendimento não encontrado.', 'danger');
            $this->redirect('/empreendimentos');
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->update($id);
        } else {
            $encarregados = $this->db->fetchAll(
                "SELECT id, nome_completo FROM usuarios WHERE nivel_acesso_id = :nivel ORDER BY nome_completo",
                ['nivel' => NIVEL_ENCARREGADO]
            );
            
            $arquivos = $this->db->fetchAll(
                "SELECT * FROM arquivos WHERE tipo_entidade = 'empreendimento' AND entidade_id = :id",
                ['id' => $id]
            );
            
            echo $this->view->render('empreendimentos/form', [
                'empreendimento' => $empreendimento,
                'encarregados' => $encarregados,
                'arquivos' => $arquivos
            ]);
        }
    }
    
    public function atualizar($id) {
        // Processa a atualização do formulário
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->update($id);
        } else {
            $this->redirect("/empreendimentos/editar/$id");
        }
    }
    
    private function update($id) {
        $data = $_POST;
        
        // Validação
        $errors = $this->validate($data, [
            'cidade' => ['required'],
            'nome' => ['required'],
            'endereco' => ['required'],
            'cno' => ['required'],
            'engenheiro_nome' => ['required'],
            'engenheiro_art' => ['required'],
            'arquiteto_nome' => ['required'],
            'arquiteto_cau' => ['required'],
            'art_execucao' => ['required']
        ]);
        
        if (!empty($errors)) {
            $this->setFlash('Corrija os erros no formulário.', 'danger');
            $this->redirect("/empreendimentos/edit/$id");
            return;
        }
        
        // Prepara dados para atualização
        $empreendimentoData = [
            'cidade' => $data['cidade'],
            'nome' => $data['nome'],
            'endereco' => $data['endereco'],
            'cno' => $data['cno'],
            'engenheiro_nome' => $data['engenheiro_nome'],
            'engenheiro_art' => $data['engenheiro_art'],
            'arquiteto_nome' => $data['arquiteto_nome'],
            'arquiteto_cau' => $data['arquiteto_cau'],
            'art_execucao' => $data['art_execucao'],
            'encarregado_id' => $data['encarregado_id'] ?? null,
            'status' => $data['status']
        ];
        
        // Atualiza empreendimento
        if ($this->db->update('empreendimentos', $empreendimentoData, 'id = :id', ['id' => $id])) {
            // Upload de novos arquivos
            if (isset($_FILES['arquivos']) && !empty($_FILES['arquivos']['name'][0])) {
                $this->uploadEmpreendimentoFiles($id, $_FILES['arquivos']);
            }
            
            $this->logActivity('empreendimento_atualizado', "Empreendimento atualizado: {$data['nome']} (ID: $id)");
            $this->setFlash('Empreendimento atualizado com sucesso!', 'success');
            $this->redirect('/empreendimentos');
        } else {
            $this->setFlash('Erro ao atualizar empreendimento.', 'danger');
            $this->redirect("/empreendimentos/edit/$id");
        }
    }
    
    public function view($id) {
        if (!$this->checkPermission('empreendimentos', 'visualizar')) {
            return;
        }
        
        $sql = "SELECT e.*, u.nome_completo as encarregado_nome, u.email as encarregado_email, u.telefone as encarregado_telefone
                FROM empreendimentos e 
                LEFT JOIN usuarios u ON e.encarregado_id = u.id 
                WHERE e.id = :id";
        
        $empreendimento = $this->db->fetchOne($sql, ['id' => $id]);
        
        if (!$empreendimento) {
            $this->setFlash('Empreendimento não encontrado.', 'danger');
            $this->redirect('/empreendimentos');
            return;
        }
        
        // Busca arquivos
        $arquivos = $this->db->fetchAll(
            "SELECT * FROM arquivos WHERE tipo_entidade = 'empreendimento' AND entidade_id = :id",
            ['id' => $id]
        );
        
        // Busca imóveis do empreendimento
        $imoveis = $this->db->fetchAll(
            "SELECT i.*, u.nome_completo as cliente_nome 
             FROM imoveis i 
             LEFT JOIN usuarios u ON i.cliente_id = u.id 
             WHERE i.empreendimento_id = :id 
             ORDER BY i.created_at DESC",
            ['id' => $id]
        );
        
        // Estatísticas
        $stats = [
            'total_imoveis' => count($imoveis),
            'imoveis_vendidos' => count(array_filter($imoveis, function($i) { return $i['status'] == 'vendido'; })),
            'imoveis_disponiveis' => count(array_filter($imoveis, function($i) { return $i['status'] == 'disponivel'; })),
            'valor_total' => array_sum(array_column($imoveis, 'valor'))
        ];
        
        echo $this->view->render('empreendimentos/view', [
            'empreendimento' => $empreendimento,
            'arquivos' => $arquivos,
            'imoveis' => $imoveis,
            'stats' => $stats
        ]);
    }
    
    public function delete($id) {
        if (!$this->checkPermission('empreendimentos', 'deletar')) {
            return;
        }
        
        // Verifica se há imóveis vinculados
        $imoveis = $this->db->count('imoveis', 'empreendimento_id = :id', ['id' => $id]);
        
        if ($imoveis > 0) {
            $this->setFlash('Não é possível excluir este empreendimento pois existem imóveis vinculados.', 'danger');
            $this->redirect('/empreendimentos');
            return;
        }
        
        // Deleta arquivos
        $this->db->delete('arquivos', "tipo_entidade = 'empreendimento' AND entidade_id = :id", ['id' => $id]);
        
        // Deleta empreendimento
        if ($this->db->delete('empreendimentos', 'id = :id', ['id' => $id])) {
            $this->logActivity('empreendimento_deletado', "Empreendimento deletado ID: $id");
            $this->setFlash('Empreendimento excluído com sucesso!', 'success');
        } else {
            $this->setFlash('Erro ao excluir empreendimento.', 'danger');
        }
        
        $this->redirect('/empreendimentos');
    }
    
    private function uploadEmpreendimentoFiles($empreendimentoId, $files) {
        $uploadedFiles = [];
        
        for ($i = 0; $i < count($files['name']); $i++) {
            if ($files['error'][$i] === UPLOAD_ERR_OK) {
                $file = [
                    'name' => $files['name'][$i],
                    'type' => $files['type'][$i],
                    'tmp_name' => $files['tmp_name'][$i],
                    'error' => $files['error'][$i],
                    'size' => $files['size'][$i]
                ];
                
                $result = $this->uploadFile($file, 'empreendimentos/' . $empreendimentoId);
                
                if ($result['success']) {
                    // Salva no banco
                    $this->db->insert('arquivos', [
                        'tipo_entidade' => 'empreendimento',
                        'entidade_id' => $empreendimentoId,
                        'tipo_arquivo' => $this->getFileType($file['name']),
                        'nome_arquivo' => $file['name'],
                        'caminho' => $result['path'],
                        'tamanho' => $file['size'],
                        'descricao' => $_POST['descricao_arquivo'][$i] ?? null,
                        'uploaded_by' => $this->user['id']
                    ]);
                    
                    $uploadedFiles[] = $result['filename'];
                }
            }
        }
        
        return $uploadedFiles;
    }
    
    private function getFileType($filename) {
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'bmp'])) {
            return 'imagem';
        } elseif (in_array($ext, ['pdf'])) {
            return 'pdf';
        } elseif (in_array($ext, ['doc', 'docx'])) {
            return 'documento';
        } elseif (in_array($ext, ['dwg', 'dxf'])) {
            return 'planta';
        } else {
            return 'outro';
        }
    }
    
    public function deleteFile($id) {
        if (!$this->checkPermission('empreendimentos', 'editar')) {
            $this->json(['success' => false, 'message' => 'Sem permissão'], 403);
            return;
        }
        
        $arquivo = $this->db->fetchOne("SELECT * FROM arquivos WHERE id = :id", ['id' => $id]);
        
        if (!$arquivo) {
            $this->json(['success' => false, 'message' => 'Arquivo não encontrado'], 404);
            return;
        }
        
        // Deleta arquivo físico
        $filePath = UPLOAD_PATH . $arquivo['caminho'];
        if (file_exists($filePath)) {
            unlink($filePath);
        }
        
        // Deleta do banco
        if ($this->db->delete('arquivos', 'id = :id', ['id' => $id])) {
            $this->json(['success' => true, 'message' => 'Arquivo excluído com sucesso']);
        } else {
            $this->json(['success' => false, 'message' => 'Erro ao excluir arquivo'], 500);
        }
    }
    
    public function relatorio($id) {
        if (!$this->checkPermission('empreendimentos', 'visualizar')) {
            return;
        }
        
        $empreendimento = $this->db->fetchOne("SELECT * FROM empreendimentos WHERE id = :id", ['id' => $id]);
        
        if (!$empreendimento) {
            $this->setFlash('Empreendimento não encontrado.', 'danger');
            $this->redirect('/empreendimentos');
            return;
        }
        
        // Busca todos os dados relacionados
        $imoveis = $this->db->fetchAll(
            "SELECT * FROM imoveis WHERE empreendimento_id = :id",
            ['id' => $id]
        );
        
        $ocorrencias = $this->db->fetchAll(
            "SELECT * FROM ocorrencias_manutencao WHERE empreendimento_id = :id ORDER BY data_abertura DESC",
            ['id' => $id]
        );
        
        $compras = $this->db->fetchAll(
            "SELECT c.*, f.razao_social as fornecedor_nome 
             FROM compras c 
             LEFT JOIN fornecedores f ON c.fornecedor_id = f.id 
             WHERE c.empreendimento_id = :id 
             ORDER BY c.created_at DESC",
            ['id' => $id]
        );
        
        $funcionarios = $this->db->fetchAll(
            "SELECT * FROM funcionarios WHERE empreendimento_id = :id AND status = 'ativo'",
            ['id' => $id]
        );
        
        // Gera relatório em PDF
        require_once __DIR__ . '/../../vendor/autoload.php';
        
        $mpdf = new \Mpdf\Mpdf(['tempDir' => __DIR__ . '/../../temp']);
        
        $html = $this->view->renderPartial('empreendimentos/relatorio', [
            'empreendimento' => $empreendimento,
            'imoveis' => $imoveis,
            'ocorrencias' => $ocorrencias,
            'compras' => $compras,
            'funcionarios' => $funcionarios
        ]);
        
        $mpdf->WriteHTML($html);
        $mpdf->Output("relatorio_empreendimento_{$id}.pdf", 'I');
    }
}
