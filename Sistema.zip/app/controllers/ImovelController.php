<?php
require_once __DIR__ . '/../core/Controller.php';

class ImovelController extends Controller {
    
    public function index() {
        if (!$this->checkPermission('imoveis', 'visualizar')) {
            return;
        }
        
        $page = $_GET['page'] ?? 1;
        $limit = 20;
        $offset = ($page - 1) * $limit;
        
        // Filtros
        $where = "1=1";
        $params = [];
        
        // Se for cliente, mostra apenas seus imóveis
        if ($this->user['nivel_acesso_id'] == NIVEL_CLIENTE) {
            $where .= " AND i.cliente_id = :cliente_id";
            $params['cliente_id'] = $this->user['id'];
        }
        
        if (isset($_GET['status']) && !empty($_GET['status'])) {
            $where .= " AND i.status = :status";
            $params['status'] = $_GET['status'];
        }
        
        if (isset($_GET['empreendimento']) && !empty($_GET['empreendimento'])) {
            $where .= " AND i.empreendimento_id = :empreendimento";
            $params['empreendimento'] = $_GET['empreendimento'];
        }
        
        if (isset($_GET['valor_min']) && !empty($_GET['valor_min'])) {
            $where .= " AND i.valor >= :valor_min";
            $params['valor_min'] = str_replace(['R$', '.', ','], ['', '', '.'], $_GET['valor_min']);
        }
        
        if (isset($_GET['valor_max']) && !empty($_GET['valor_max'])) {
            $where .= " AND i.valor <= :valor_max";
            $params['valor_max'] = str_replace(['R$', '.', ','], ['', '', '.'], $_GET['valor_max']);
        }
        
        // Busca imóveis
        $sql = "SELECT i.*, e.nome as empreendimento_nome, e.cidade, 
                u.nome_completo as cliente_nome
                FROM imoveis i 
                LEFT JOIN empreendimentos e ON i.empreendimento_id = e.id 
                LEFT JOIN usuarios u ON i.cliente_id = u.id 
                WHERE $where 
                ORDER BY i.created_at DESC 
                LIMIT $limit OFFSET $offset";
        
        $imoveis = $this->db->fetchAll($sql, $params);
        
        // Total para paginação
        $total = $this->db->count('imoveis i', $where, $params);
        $totalPages = ceil($total / $limit);
        
        // Empreendimentos para o filtro
        $empreendimentos = $this->db->fetchAll("SELECT id, nome, cidade FROM empreendimentos ORDER BY nome");
        
        $data = [
            'imoveis' => $imoveis,
            'empreendimentos' => $empreendimentos,
            'pagination' => [
                'current' => $page,
                'total' => $totalPages,
                'limit' => $limit,
                'total_records' => $total
            ],
            'filters' => $_GET,
            'flash' => $this->getFlash()
        ];
        
        echo $this->view->render('imoveis/index', $data);
    }
    
    public function criar() {
        if (!$this->checkPermission('imoveis', 'criar')) {
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->store();
        } else {
            $empreendimentos = $this->db->fetchAll("SELECT id, nome, cidade FROM empreendimentos ORDER BY nome");
            $clientes = $this->db->fetchAll("SELECT id, nome_completo FROM usuarios WHERE nivel_acesso_id = " . NIVEL_CLIENTE . " ORDER BY nome_completo");
            
            echo $this->view->render('imoveis/form', [
                'empreendimentos' => $empreendimentos,
                'clientes' => $clientes,
                'imovel' => null,
                'flash' => $this->getFlash()
            ]);
        }
    }
    
    public function salvar() {
        // Processa o salvamento do formulário
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->store();
        } else {
            $this->redirect('/imoveis/novo');
        }
    }
    
    public function create() {
        // Alias para manter compatibilidade
        return $this->criar();
    }
    
    private function store() {
        $data = $_POST;
        
        // Validação
        $errors = $this->validate($data, [
            'empreendimento_id' => ['required'],
            'valor' => ['required'],
            'metragem' => ['required'],
            'quartos' => ['required'],
            'status' => ['required']
        ]);
        
        if (!empty($errors)) {
            $this->setFlash('Corrija os erros no formulário.', 'danger');
            $empreendimentos = $this->db->fetchAll("SELECT id, nome, cidade FROM empreendimentos ORDER BY nome");
            $clientes = $this->db->fetchAll("SELECT id, nome_completo FROM usuarios WHERE nivel_acesso_id = " . NIVEL_CLIENTE . " ORDER BY nome_completo");
            
            echo $this->view->render('imoveis/form', [
                'empreendimentos' => $empreendimentos,
                'clientes' => $clientes,
                'errors' => $errors,
                'old' => $data,
                'imovel' => null
            ]);
            return;
        }
        
        // Prepara dados para inserção
        $imovelData = [
            'empreendimento_id' => $data['empreendimento_id'],
            'cliente_id' => $data['cliente_id'] ?? null,
            'valor' => str_replace(['R$', '.', ','], ['', '', '.'], $data['valor']),
            'status' => $data['status'],
            'metragem' => str_replace(',', '.', $data['metragem']),
            'quartos' => $data['quartos'],
            'suites' => $data['suites'] ?? 0,
            'vagas_garagem' => $data['vagas_garagem'] ?? 0,
            'descricao' => $data['descricao'] ?? null
        ];
        
        // Se vendido, adiciona informações de venda
        if ($data['status'] === 'vendido' && !empty($data['cliente_id'])) {
            $imovelData['data_venda'] = $data['data_venda'] ?? date('Y-m-d');
            $imovelData['taxa_juros'] = str_replace(',', '.', $data['taxa_juros'] ?? 0);
            $imovelData['quantidade_parcelas'] = $data['quantidade_parcelas'] ?? 0;
            $imovelData['valor_parcela'] = str_replace(['R$', '.', ','], ['', '', '.'], $data['valor_parcela'] ?? 0);
        }
        
        // Insere imóvel
        $imovelId = $this->db->insert('imoveis', $imovelData);
        
        if ($imovelId) {
            // Upload de arquivos
            if (isset($_FILES['arquivos']) && !empty($_FILES['arquivos']['name'][0])) {
                $this->uploadImovelFiles($imovelId, $_FILES['arquivos']);
            }
            
            // Se vendido, gera faturas
            if ($data['status'] === 'vendido' && !empty($data['cliente_id']) && $imovelData['quantidade_parcelas'] > 0) {
                $this->gerarFaturas($imovelId, $data['cliente_id'], $imovelData);
            }
            
            $this->logActivity('imovel_criado', "Imóvel criado ID: $imovelId");
            $this->setFlash('Imóvel cadastrado com sucesso!', 'success');
            $this->redirect('/imoveis');
        } else {
            $this->setFlash('Erro ao cadastrar imóvel.', 'danger');
            $this->redirect('/imoveis/create');
        }
    }
    
    public function edit($id) {
        if (!$this->checkPermission('imoveis', 'editar')) {
            return;
        }
        
        $imovel = $this->db->fetchOne("SELECT * FROM imoveis WHERE id = :id", ['id' => $id]);
        
        if (!$imovel) {
            $this->setFlash('Imóvel não encontrado.', 'danger');
            $this->redirect('/imoveis');
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->update($id);
        } else {
            $empreendimentos = $this->db->fetchAll("SELECT id, nome, cidade FROM empreendimentos ORDER BY nome");
            $clientes = $this->db->fetchAll("SELECT id, nome_completo FROM usuarios WHERE nivel_acesso_id = " . NIVEL_CLIENTE . " ORDER BY nome_completo");
            $arquivos = $this->db->fetchAll("SELECT * FROM arquivos WHERE tipo_entidade = 'imovel' AND entidade_id = :id", ['id' => $id]);
            
            echo $this->view->render('imoveis/form', [
                'imovel' => $imovel,
                'empreendimentos' => $empreendimentos,
                'clientes' => $clientes,
                'arquivos' => $arquivos
            ]);
        }
    }
    
    public function atualizar($id) {
        // Processa a atualização do formulário
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->update($id);
        } else {
            $this->redirect("/imoveis/editar/$id");
        }
    }
    
    private function update($id) {
        $data = $_POST;
        
        // Validação
        $errors = $this->validate($data, [
            'empreendimento_id' => ['required'],
            'valor' => ['required'],
            'metragem' => ['required'],
            'quartos' => ['required'],
            'status' => ['required']
        ]);
        
        if (!empty($errors)) {
            $this->setFlash('Corrija os erros no formulário.', 'danger');
            $this->redirect("/imoveis/edit/$id");
            return;
        }
        
        // Prepara dados para atualização
        $imovelData = [
            'empreendimento_id' => $data['empreendimento_id'],
            'cliente_id' => $data['cliente_id'] ?? null,
            'valor' => str_replace(['R$', '.', ','], ['', '', '.'], $data['valor']),
            'status' => $data['status'],
            'metragem' => str_replace(',', '.', $data['metragem']),
            'quartos' => $data['quartos'],
            'suites' => $data['suites'] ?? 0,
            'vagas_garagem' => $data['vagas_garagem'] ?? 0,
            'descricao' => $data['descricao'] ?? null
        ];
        
        // Se vendido, adiciona informações de venda
        if ($data['status'] === 'vendido' && !empty($data['cliente_id'])) {
            $imovelData['data_venda'] = $data['data_venda'] ?? date('Y-m-d');
            $imovelData['taxa_juros'] = str_replace(',', '.', $data['taxa_juros'] ?? 0);
            $imovelData['quantidade_parcelas'] = $data['quantidade_parcelas'] ?? 0;
            $imovelData['valor_parcela'] = str_replace(['R$', '.', ','], ['', '', '.'], $data['valor_parcela'] ?? 0);
        }
        
        // Atualiza imóvel
        if ($this->db->update('imoveis', $imovelData, 'id = :id', ['id' => $id])) {
            // Upload de novos arquivos
            if (isset($_FILES['arquivos']) && !empty($_FILES['arquivos']['name'][0])) {
                $this->uploadImovelFiles($id, $_FILES['arquivos']);
            }
            
            $this->logActivity('imovel_atualizado', "Imóvel atualizado ID: $id");
            $this->setFlash('Imóvel atualizado com sucesso!', 'success');
            $this->redirect('/imoveis');
        } else {
            $this->setFlash('Erro ao atualizar imóvel.', 'danger');
            $this->redirect("/imoveis/edit/$id");
        }
    }
    
    public function view($id) {
        if (!$this->checkPermission('imoveis', 'visualizar')) {
            return;
        }
        
        // Se for cliente, verifica se o imóvel é dele
        if ($this->user['nivel_acesso_id'] == NIVEL_CLIENTE) {
            $check = $this->db->fetchOne("SELECT id FROM imoveis WHERE id = :id AND cliente_id = :cliente_id", 
                ['id' => $id, 'cliente_id' => $this->user['id']]);
            
            if (!$check) {
                $this->setFlash('Você não tem permissão para visualizar este imóvel.', 'danger');
                $this->redirect('/imoveis');
                return;
            }
        }
        
        $sql = "SELECT i.*, e.nome as empreendimento_nome, e.cidade, e.endereco,
                u.nome_completo as cliente_nome, u.email as cliente_email, u.telefone as cliente_telefone
                FROM imoveis i 
                LEFT JOIN empreendimentos e ON i.empreendimento_id = e.id 
                LEFT JOIN usuarios u ON i.cliente_id = u.id 
                WHERE i.id = :id";
        
        $imovel = $this->db->fetchOne($sql, ['id' => $id]);
        
        if (!$imovel) {
            $this->setFlash('Imóvel não encontrado.', 'danger');
            $this->redirect('/imoveis');
            return;
        }
        
        // Busca arquivos
        $arquivos = $this->db->fetchAll("SELECT * FROM arquivos WHERE tipo_entidade = 'imovel' AND entidade_id = :id", ['id' => $id]);
        
        // Busca faturas se houver cliente
        $faturas = [];
        if ($imovel['cliente_id']) {
            $faturas = $this->db->fetchAll(
                "SELECT * FROM faturas WHERE imovel_id = :imovel_id ORDER BY data_vencimento", 
                ['imovel_id' => $id]
            );
        }
        
        echo $this->view->render('imoveis/view', [
            'imovel' => $imovel,
            'arquivos' => $arquivos,
            'faturas' => $faturas
        ]);
    }
    
    public function delete($id) {
        if (!$this->checkPermission('imoveis', 'deletar')) {
            return;
        }
        
        // Verifica se há faturas vinculadas
        $faturas = $this->db->count('faturas', 'imovel_id = :id', ['id' => $id]);
        
        if ($faturas > 0) {
            $this->setFlash('Não é possível excluir este imóvel pois existem faturas vinculadas.', 'danger');
            $this->redirect('/imoveis');
            return;
        }
        
        // Deleta arquivos
        $this->db->delete('arquivos', "tipo_entidade = 'imovel' AND entidade_id = :id", ['id' => $id]);
        
        // Deleta imóvel
        if ($this->db->delete('imoveis', 'id = :id', ['id' => $id])) {
            $this->logActivity('imovel_deletado', "Imóvel deletado ID: $id");
            $this->setFlash('Imóvel excluído com sucesso!', 'success');
        } else {
            $this->setFlash('Erro ao excluir imóvel.', 'danger');
        }
        
        $this->redirect('/imoveis');
    }
    
    private function uploadImovelFiles($imovelId, $files) {
        $uploadedFiles = [];
        
        for ($i = 0; $i < count($files['name']); $i++) {
            if ($files['error'][$i] === UPLOAD_ERR_OK) {
                $file = [
                    'name' => $files['name'][$i],
                    'type' => $files['type'][$i],
                    'tmp_name' => $files['tmp_name'][$i],
                    'error' => $files['error'][$i],
                    'size' => $files['size'][$i]
                ];
                
                $result = $this->uploadFile($file, 'imoveis/' . $imovelId);
                
                if ($result['success']) {
                    // Salva no banco
                    $this->db->insert('arquivos', [
                        'tipo_entidade' => 'imovel',
                        'entidade_id' => $imovelId,
                        'tipo_arquivo' => $this->getFileType($file['name']),
                        'nome_arquivo' => $file['name'],
                        'caminho' => $result['path'],
                        'tamanho' => $file['size'],
                        'descricao' => $_POST['descricao_arquivo'][$i] ?? null,
                        'uploaded_by' => $this->user['id']
                    ]);
                    
                    $uploadedFiles[] = $result['filename'];
                }
            }
        }
        
        return $uploadedFiles;
    }
    
    private function getFileType($filename) {
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'bmp'])) {
            return 'imagem';
        } elseif (in_array($ext, ['pdf'])) {
            return 'pdf';
        } elseif (in_array($ext, ['doc', 'docx'])) {
            return 'documento';
        } elseif (in_array($ext, ['xls', 'xlsx'])) {
            return 'planilha';
        } else {
            return 'outro';
        }
    }
    
    private function gerarFaturas($imovelId, $clienteId, $imovelData) {
        $valorParcela = $imovelData['valor_parcela'];
        $quantidadeParcelas = $imovelData['quantidade_parcelas'];
        $dataBase = new DateTime($imovelData['data_venda'] ?? date('Y-m-d'));
        
        for ($i = 1; $i <= $quantidadeParcelas; $i++) {
            $dataVencimento = clone $dataBase;
            $dataVencimento->modify("+$i month");
            
            $numeroFatura = sprintf('%s-%04d-%03d', 
                date('Y'), 
                $imovelId, 
                $i
            );
            
            $this->db->insert('faturas', [
                'imovel_id' => $imovelId,
                'cliente_id' => $clienteId,
                'numero_fatura' => $numeroFatura,
                'valor' => $valorParcela,
                'data_vencimento' => $dataVencimento->format('Y-m-d'),
                'status' => 'em_aberto'
            ]);
        }
    }
    
    public function deleteFile($id) {
        if (!$this->checkPermission('imoveis', 'editar')) {
            $this->json(['success' => false, 'message' => 'Sem permissão'], 403);
            return;
        }
        
        $arquivo = $this->db->fetchOne("SELECT * FROM arquivos WHERE id = :id", ['id' => $id]);
        
        if (!$arquivo) {
            $this->json(['success' => false, 'message' => 'Arquivo não encontrado'], 404);
            return;
        }
        
        // Deleta arquivo físico
        $filePath = UPLOAD_PATH . $arquivo['caminho'];
        if (file_exists($filePath)) {
            unlink($filePath);
        }
        
        // Deleta do banco
        if ($this->db->delete('arquivos', 'id = :id', ['id' => $id])) {
            $this->json(['success' => true, 'message' => 'Arquivo excluído com sucesso']);
        } else {
            $this->json(['success' => false, 'message' => 'Erro ao excluir arquivo'], 500);
        }
    }
}
