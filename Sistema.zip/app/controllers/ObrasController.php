<?php
require_once __DIR__ . '/../core/Controller.php';

class ObrasController extends Controller {
    
    public function index() {
        if (!$this->checkPermission('obras', 'visualizar')) {
            return;
        }
        
        // Dashboard de obras
        $data = [];
        
        // Estatísticas gerais
        $data['total_empreendimentos'] = $this->db->count('empreendimentos', "status = 'em_andamento'");
        $data['total_ocorrencias'] = $this->db->count('ocorrencias_manutencao', "status IN ('aberta', 'em_andamento')");
        $data['total_compras'] = $this->db->count('compras', "status IN ('solicitado', 'aprovado')");
        
        // Ocorrências recentes
        $sql = "SELECT o.*, e.nome as empreendimento_nome, u.nome_completo as encarregado_nome
                FROM ocorrencias_manutencao o
                JOIN empreendimentos e ON o.empreendimento_id = e.id
                JOIN usuarios u ON o.encarregado_id = u.id
                WHERE o.status IN ('aberta', 'em_andamento')
                ORDER BY o.prioridade DESC, o.data_abertura DESC
                LIMIT 10";
        $data['ocorrencias_recentes'] = $this->db->fetchAll($sql);
        
        // Compras pendentes
        $sql = "SELECT c.*, e.nome as empreendimento_nome, f.razao_social as fornecedor_nome
                FROM compras c
                JOIN empreendimentos e ON c.empreendimento_id = e.id
                LEFT JOIN fornecedores f ON c.fornecedor_id = f.id
                WHERE c.status IN ('solicitado', 'aprovado')
                ORDER BY c.created_at DESC
                LIMIT 10";
        $data['compras_pendentes'] = $this->db->fetchAll($sql);
        
        $data['flash'] = $this->getFlash();
        
        echo $this->view->render('obras/index', $data);
    }
    
    // GESTÃO DE OCORRÊNCIAS
    public function ocorrencias() {
        if (!$this->checkPermission('ocorrencias', 'visualizar')) {
            return;
        }
        
        $page = $_GET['page'] ?? 1;
        $limit = 20;
        $offset = ($page - 1) * $limit;
        
        // Filtros
        $where = "1=1";
        $params = [];
        
        // Se for encarregado, mostra apenas suas ocorrências
        if ($this->user['nivel_acesso_id'] == NIVEL_ENCARREGADO) {
            $where .= " AND o.encarregado_id = :encarregado_id";
            $params['encarregado_id'] = $this->user['id'];
        }
        
        if (isset($_GET['status']) && !empty($_GET['status'])) {
            $where .= " AND o.status = :status";
            $params['status'] = $_GET['status'];
        }
        
        if (isset($_GET['prioridade']) && !empty($_GET['prioridade'])) {
            $where .= " AND o.prioridade = :prioridade";
            $params['prioridade'] = $_GET['prioridade'];
        }
        
        if (isset($_GET['empreendimento']) && !empty($_GET['empreendimento'])) {
            $where .= " AND o.empreendimento_id = :empreendimento";
            $params['empreendimento'] = $_GET['empreendimento'];
        }
        
        // Busca ocorrências
        $sql = "SELECT o.*, e.nome as empreendimento_nome, e.cidade, u.nome_completo as encarregado_nome,
                CASE 
                    WHEN o.status IN ('aberta', 'em_andamento') THEN DATEDIFF(CURDATE(), o.data_abertura)
                    ELSE DATEDIFF(o.data_conclusao, o.data_abertura)
                END as dias_duracao
                FROM ocorrencias_manutencao o
                JOIN empreendimentos e ON o.empreendimento_id = e.id
                JOIN usuarios u ON o.encarregado_id = u.id
                WHERE $where
                ORDER BY 
                    FIELD(o.status, 'aberta', 'em_andamento', 'concluida', 'cancelada'),
                    FIELD(o.prioridade, 'urgente', 'alta', 'media', 'baixa'),
                    o.data_abertura DESC
                LIMIT $limit OFFSET $offset";
        
        $ocorrencias = $this->db->fetchAll($sql, $params);
        
        // Total para paginação
        $total = $this->db->count('ocorrencias_manutencao o', $where, $params);
        $totalPages = ceil($total / $limit);
        
        // Dados para filtros
        $empreendimentos = $this->db->fetchAll("SELECT id, nome FROM empreendimentos ORDER BY nome");
        
        $data = [
            'ocorrencias' => $ocorrencias,
            'empreendimentos' => $empreendimentos,
            'pagination' => [
                'current' => $page,
                'total' => $totalPages,
                'limit' => $limit,
                'total_records' => $total
            ],
            'filters' => $_GET,
            'flash' => $this->getFlash()
        ];
        
        echo $this->view->render('obras/ocorrencias', $data);
    }
    
    public function criarOcorrencia() {
        if (!$this->checkPermission('ocorrencias', 'criar')) {
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = $_POST;
            
            // Validação
            $errors = $this->validate($data, [
                'empreendimento_id' => ['required'],
                'descricao' => ['required'],
                'prioridade' => ['required']
            ]);
            
            if (!empty($errors)) {
                $this->setFlash('Corrija os erros no formulário.', 'danger');
                $empreendimentos = $this->db->fetchAll("SELECT id, nome FROM empreendimentos ORDER BY nome");
                $encarregados = $this->db->fetchAll(
                    "SELECT id, nome_completo FROM usuarios WHERE nivel_acesso_id = :nivel ORDER BY nome_completo",
                    ['nivel' => NIVEL_ENCARREGADO]
                );
                
                echo $this->view->render('obras/criar_ocorrencia', [
                    'empreendimentos' => $empreendimentos,
                    'encarregados' => $encarregados,
                    'errors' => $errors,
                    'old' => $data
                ]);
                return;
            }
            
            // Prepara dados
            $ocorrenciaData = [
                'empreendimento_id' => $data['empreendimento_id'],
                'encarregado_id' => $data['encarregado_id'] ?? $this->user['id'],
                'descricao' => $data['descricao'],
                'status' => 'aberta',
                'prioridade' => $data['prioridade'],
                'data_abertura' => date('Y-m-d H:i:s')
            ];
            
            $ocorrenciaId = $this->db->insert('ocorrencias_manutencao', $ocorrenciaData);
            
            if ($ocorrenciaId) {
                // Upload de arquivos/fotos
                if (isset($_FILES['arquivos']) && !empty($_FILES['arquivos']['name'][0])) {
                    $this->uploadOcorrenciaFiles($ocorrenciaId, $_FILES['arquivos']);
                }
                
                // Notifica o encarregado
                $this->notificarEncarregado($ocorrenciaData['encarregado_id'], $ocorrenciaId);
                
                $this->logActivity('ocorrencia_criada', "Ocorrência criada ID: $ocorrenciaId");
                $this->setFlash('Ocorrência registrada com sucesso!', 'success');
                $this->redirect('/obras/ocorrencias');
            } else {
                $this->setFlash('Erro ao registrar ocorrência.', 'danger');
                $this->redirect('/obras/ocorrencias/criar');
            }
        } else {
            $empreendimentos = $this->db->fetchAll("SELECT id, nome FROM empreendimentos ORDER BY nome");
            $encarregados = $this->db->fetchAll(
                "SELECT id, nome_completo FROM usuarios WHERE nivel_acesso_id = :nivel ORDER BY nome_completo",
                ['nivel' => NIVEL_ENCARREGADO]
            );
            
            echo $this->view->render('obras/criar_ocorrencia', [
                'empreendimentos' => $empreendimentos,
                'encarregados' => $encarregados
            ]);
        }
    }
    
    public function editarOcorrencia($id) {
        if (!$this->checkPermission('ocorrencias', 'editar')) {
            return;
        }
        
        $ocorrencia = $this->db->fetchOne("SELECT * FROM ocorrencias_manutencao WHERE id = :id", ['id' => $id]);
        
        if (!$ocorrencia) {
            $this->setFlash('Ocorrência não encontrada.', 'danger');
            $this->redirect('/obras/ocorrencias');
            return;
        }
        
        // Verifica se o usuário pode editar (admin ou encarregado responsável)
        if ($this->user['nivel_acesso_id'] != NIVEL_ADMIN && $ocorrencia['encarregado_id'] != $this->user['id']) {
            $this->setFlash('Você não tem permissão para editar esta ocorrência.', 'danger');
            $this->redirect('/obras/ocorrencias');
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = $_POST;
            
            $updateData = [
                'descricao' => $data['descricao'],
                'status' => $data['status'],
                'prioridade' => $data['prioridade']
            ];
            
            // Se concluída, adiciona data de conclusão
            if ($data['status'] == 'concluida') {
                $updateData['data_conclusao'] = date('Y-m-d H:i:s');
            }
            
            if ($this->db->update('ocorrencias_manutencao', $updateData, 'id = :id', ['id' => $id])) {
                // Upload de novos arquivos
                if (isset($_FILES['arquivos']) && !empty($_FILES['arquivos']['name'][0])) {
                    $this->uploadOcorrenciaFiles($id, $_FILES['arquivos']);
                }
                
                $this->logActivity('ocorrencia_atualizada', "Ocorrência atualizada ID: $id");
                $this->setFlash('Ocorrência atualizada com sucesso!', 'success');
                $this->redirect('/obras/ocorrencias');
            } else {
                $this->setFlash('Erro ao atualizar ocorrência.', 'danger');
                $this->redirect("/obras/ocorrencias/editar/$id");
            }
        } else {
            $arquivos = $this->db->fetchAll(
                "SELECT * FROM arquivos WHERE tipo_entidade = 'obra' AND entidade_id = :id",
                ['id' => $id]
            );
            
            echo $this->view->render('obras/editar_ocorrencia', [
                'ocorrencia' => $ocorrencia,
                'arquivos' => $arquivos
            ]);
        }
    }
    
    public function verOcorrencia($id) {
        if (!$this->checkPermission('ocorrencias', 'visualizar')) {
            return;
        }
        
        $sql = "SELECT o.*, e.nome as empreendimento_nome, e.cidade, e.endereco,
                u.nome_completo as encarregado_nome, u.telefone as encarregado_telefone
                FROM ocorrencias_manutencao o
                JOIN empreendimentos e ON o.empreendimento_id = e.id
                JOIN usuarios u ON o.encarregado_id = u.id
                WHERE o.id = :id";
        
        $ocorrencia = $this->db->fetchOne($sql, ['id' => $id]);
        
        if (!$ocorrencia) {
            $this->setFlash('Ocorrência não encontrada.', 'danger');
            $this->redirect('/obras/ocorrencias');
            return;
        }
        
        // Arquivos anexados
        $arquivos = $this->db->fetchAll(
            "SELECT * FROM arquivos WHERE tipo_entidade = 'obra' AND entidade_id = :id",
            ['id' => $id]
        );
        
        echo $this->view->render('obras/ver_ocorrencia', [
            'ocorrencia' => $ocorrencia,
            'arquivos' => $arquivos
        ]);
    }
    
    // GESTÃO DE COMPRAS
    public function compras() {
        if (!$this->checkPermission('compras', 'visualizar')) {
            return;
        }
        
        $page = $_GET['page'] ?? 1;
        $limit = 20;
        $offset = ($page - 1) * $limit;
        
        // Filtros
        $where = "1=1";
        $params = [];
        
        // Se for encarregado, mostra apenas suas solicitações
        if ($this->user['nivel_acesso_id'] == NIVEL_ENCARREGADO) {
            $where .= " AND c.solicitante_id = :solicitante_id";
            $params['solicitante_id'] = $this->user['id'];
        }
        
        if (isset($_GET['status']) && !empty($_GET['status'])) {
            $where .= " AND c.status = :status";
            $params['status'] = $_GET['status'];
        }
        
        if (isset($_GET['empreendimento']) && !empty($_GET['empreendimento'])) {
            $where .= " AND c.empreendimento_id = :empreendimento";
            $params['empreendimento'] = $_GET['empreendimento'];
        }
        
        // Busca compras
        $sql = "SELECT c.*, e.nome as empreendimento_nome, f.razao_social as fornecedor_nome,
                u.nome_completo as solicitante_nome
                FROM compras c
                JOIN empreendimentos e ON c.empreendimento_id = e.id
                LEFT JOIN fornecedores f ON c.fornecedor_id = f.id
                JOIN usuarios u ON c.solicitante_id = u.id
                WHERE $where
                ORDER BY 
                    FIELD(c.status, 'solicitado', 'aprovado', 'comprado', 'entregue', 'cancelado'),
                    c.created_at DESC
                LIMIT $limit OFFSET $offset";
        
        $compras = $this->db->fetchAll($sql, $params);
        
        // Total para paginação
        $total = $this->db->count('compras c', $where, $params);
        $totalPages = ceil($total / $limit);
        
        // Dados para filtros
        $empreendimentos = $this->db->fetchAll("SELECT id, nome FROM empreendimentos ORDER BY nome");
        
        $data = [
            'compras' => $compras,
            'empreendimentos' => $empreendimentos,
            'pagination' => [
                'current' => $page,
                'total' => $totalPages,
                'limit' => $limit,
                'total_records' => $total
            ],
            'filters' => $_GET,
            'flash' => $this->getFlash()
        ];
        
        echo $this->view->render('obras/compras', $data);
    }
    
    public function solicitarCompra() {
        if (!$this->checkPermission('compras', 'criar')) {
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = $_POST;
            
            // Validação
            $errors = $this->validate($data, [
                'empreendimento_id' => ['required'],
                'descricao' => ['required']
            ]);
            
            if (!empty($errors)) {
                $this->setFlash('Corrija os erros no formulário.', 'danger');
                $this->redirect('/obras/compras/solicitar');
                return;
            }
            
            // Prepara dados da compra
            $compraData = [
                'empreendimento_id' => $data['empreendimento_id'],
                'fornecedor_id' => $data['fornecedor_id'] ?? null,
                'solicitante_id' => $this->user['id'],
                'descricao' => $data['descricao'],
                'status' => 'solicitado',
                'prazo_entrega' => $data['prazo_entrega'] ?? null,
                'valor_total' => str_replace(['R$', '.', ','], ['', '', '.'], $data['valor_total'] ?? 0),
                'observacoes' => $data['observacoes'] ?? null
            ];
            
            $compraId = $this->db->insert('compras', $compraData);
            
            if ($compraId) {
                // Adiciona itens da compra
                if (isset($data['item_descricao'])) {
                    for ($i = 0; $i < count($data['item_descricao']); $i++) {
                        if (!empty($data['item_descricao'][$i])) {
                            $itemData = [
                                'compra_id' => $compraId,
                                'descricao' => $data['item_descricao'][$i],
                                'quantidade' => str_replace(',', '.', $data['item_quantidade'][$i] ?? 1),
                                'unidade' => $data['item_unidade'][$i] ?? 'UN',
                                'valor_unitario' => str_replace(['R$', '.', ','], ['', '', '.'], $data['item_valor'][$i] ?? 0),
                                'valor_total' => str_replace(['R$', '.', ','], ['', '', '.'], $data['item_total'][$i] ?? 0)
                            ];
                            
                            $this->db->insert('itens_compra', $itemData);
                        }
                    }
                }
                
                // Notifica responsável financeiro
                $this->notificarFinanceiro($compraId);
                
                $this->logActivity('compra_solicitada', "Compra solicitada ID: $compraId");
                $this->setFlash('Solicitação de compra enviada com sucesso!', 'success');
                $this->redirect('/obras/compras');
            } else {
                $this->setFlash('Erro ao solicitar compra.', 'danger');
                $this->redirect('/obras/compras/solicitar');
            }
        } else {
            $empreendimentos = $this->db->fetchAll("SELECT id, nome FROM empreendimentos ORDER BY nome");
            $fornecedores = $this->db->fetchAll("SELECT id, razao_social FROM fornecedores WHERE ativo = 1 ORDER BY razao_social");
            
            echo $this->view->render('obras/solicitar_compra', [
                'empreendimentos' => $empreendimentos,
                'fornecedores' => $fornecedores
            ]);
        }
    }
    
    public function aprovarCompra($id) {
        if (!$this->checkPermission('compras', 'editar')) {
            return;
        }
        
        // Apenas admin e financeiro podem aprovar
        if (!in_array($this->user['nivel_acesso_id'], [NIVEL_ADMIN, NIVEL_FINANCEIRO])) {
            $this->setFlash('Você não tem permissão para aprovar compras.', 'danger');
            $this->redirect('/obras/compras');
            return;
        }
        
        $compra = $this->db->fetchOne("SELECT * FROM compras WHERE id = :id", ['id' => $id]);
        
        if (!$compra) {
            $this->setFlash('Compra não encontrada.', 'danger');
            $this->redirect('/obras/compras');
            return;
        }
        
        if ($compra['status'] != 'solicitado') {
            $this->setFlash('Esta compra já foi processada.', 'warning');
            $this->redirect('/obras/compras');
            return;
        }
        
        if ($this->db->update('compras', ['status' => 'aprovado'], 'id = :id', ['id' => $id])) {
            // Notifica solicitante
            $this->notificarSolicitante($compra['solicitante_id'], $id, 'aprovada');
            
            $this->logActivity('compra_aprovada', "Compra aprovada ID: $id");
            $this->setFlash('Compra aprovada com sucesso!', 'success');
        } else {
            $this->setFlash('Erro ao aprovar compra.', 'danger');
        }
        
        $this->redirect('/obras/compras');
    }
    
    public function rejeitarCompra($id) {
        if (!$this->checkPermission('compras', 'editar')) {
            return;
        }
        
        // Apenas admin e financeiro podem rejeitar
        if (!in_array($this->user['nivel_acesso_id'], [NIVEL_ADMIN, NIVEL_FINANCEIRO])) {
            $this->setFlash('Você não tem permissão para rejeitar compras.', 'danger');
            $this->redirect('/obras/compras');
            return;
        }
        
        $compra = $this->db->fetchOne("SELECT * FROM compras WHERE id = :id", ['id' => $id]);
        
        if (!$compra) {
            $this->setFlash('Compra não encontrada.', 'danger');
            $this->redirect('/obras/compras');
            return;
        }
        
        if ($this->db->update('compras', ['status' => 'cancelado'], 'id = :id', ['id' => $id])) {
            // Notifica solicitante
            $this->notificarSolicitante($compra['solicitante_id'], $id, 'rejeitada');
            
            $this->logActivity('compra_rejeitada', "Compra rejeitada ID: $id");
            $this->setFlash('Compra rejeitada.', 'warning');
        } else {
            $this->setFlash('Erro ao rejeitar compra.', 'danger');
        }
        
        $this->redirect('/obras/compras');
    }
    
    public function marcarComprado($id) {
        if (!$this->checkPermission('compras', 'editar')) {
            return;
        }
        
        if ($this->db->update('compras', ['status' => 'comprado'], 'id = :id', ['id' => $id])) {
            $this->logActivity('compra_realizada', "Compra realizada ID: $id");
            $this->setFlash('Status atualizado: Comprado!', 'success');
        } else {
            $this->setFlash('Erro ao atualizar status.', 'danger');
        }
        
        $this->redirect('/obras/compras');
    }
    
    public function marcarEntregue($id) {
        if (!$this->checkPermission('compras', 'editar')) {
            return;
        }
        
        $updateData = [
            'status' => 'entregue',
            'data_recebimento' => date('Y-m-d')
        ];
        
        if ($this->db->update('compras', $updateData, 'id = :id', ['id' => $id])) {
            $this->logActivity('compra_entregue', "Compra entregue ID: $id");
            $this->setFlash('Material recebido com sucesso!', 'success');
        } else {
            $this->setFlash('Erro ao confirmar recebimento.', 'danger');
        }
        
        $this->redirect('/obras/compras');
    }
    
    public function verCompra($id) {
        if (!$this->checkPermission('compras', 'visualizar')) {
            return;
        }
        
        $sql = "SELECT c.*, e.nome as empreendimento_nome, f.razao_social as fornecedor_nome,
                u.nome_completo as solicitante_nome
                FROM compras c
                JOIN empreendimentos e ON c.empreendimento_id = e.id
                LEFT JOIN fornecedores f ON c.fornecedor_id = f.id
                JOIN usuarios u ON c.solicitante_id = u.id
                WHERE c.id = :id";
        
        $compra = $this->db->fetchOne($sql, ['id' => $id]);
        
        if (!$compra) {
            $this->setFlash('Compra não encontrada.', 'danger');
            $this->redirect('/obras/compras');
            return;
        }
        
        // Itens da compra
        $itens = $this->db->fetchAll("SELECT * FROM itens_compra WHERE compra_id = :id", ['id' => $id]);
        
        echo $this->view->render('obras/ver_compra', [
            'compra' => $compra,
            'itens' => $itens
        ]);
    }
    
    // Métodos auxiliares
    private function uploadOcorrenciaFiles($ocorrenciaId, $files) {
        for ($i = 0; $i < count($files['name']); $i++) {
            if ($files['error'][$i] === UPLOAD_ERR_OK) {
                $file = [
                    'name' => $files['name'][$i],
                    'type' => $files['type'][$i],
                    'tmp_name' => $files['tmp_name'][$i],
                    'error' => $files['error'][$i],
                    'size' => $files['size'][$i]
                ];
                
                $result = $this->uploadFile($file, 'ocorrencias/' . $ocorrenciaId);
                
                if ($result['success']) {
                    $this->db->insert('arquivos', [
                        'tipo_entidade' => 'obra',
                        'entidade_id' => $ocorrenciaId,
                        'tipo_arquivo' => 'imagem',
                        'nome_arquivo' => $file['name'],
                        'caminho' => $result['path'],
                        'tamanho' => $file['size'],
                        'uploaded_by' => $this->user['id']
                    ]);
                }
            }
        }
    }
    
    private function notificarEncarregado($encarregadoId, $ocorrenciaId) {
        // Busca dados do encarregado
        $encarregado = $this->db->fetchOne("SELECT * FROM usuarios WHERE id = :id", ['id' => $encarregadoId]);
        
        if ($encarregado) {
            $subject = "Nova Ocorrência de Manutenção #$ocorrenciaId";
            $message = "Uma nova ocorrência foi registrada e atribuída a você.\n";
            $message .= "Acesse o sistema para mais detalhes.";
            
            $this->sendEmail($encarregado['email'], $subject, $message);
            $this->sendWhatsApp($encarregado['telefone'], $message);
        }
    }
    
    private function notificarFinanceiro($compraId) {
        // Busca usuários do financeiro
        $sql = "SELECT * FROM usuarios WHERE nivel_acesso_id = :nivel AND ativo = 1";
        $financeiros = $this->db->fetchAll($sql, ['nivel' => NIVEL_FINANCEIRO]);
        
        foreach ($financeiros as $financeiro) {
            $subject = "Nova Solicitação de Compra #$compraId";
            $message = "Uma nova solicitação de compra aguarda aprovação.\n";
            $message .= "Acesse o sistema para revisar e aprovar.";
            
            $this->sendEmail($financeiro['email'], $subject, $message);
        }
    }
    
    private function notificarSolicitante($solicitanteId, $compraId, $status) {
        $solicitante = $this->db->fetchOne("SELECT * FROM usuarios WHERE id = :id", ['id' => $solicitanteId]);
        
        if ($solicitante) {
            $subject = "Compra #$compraId - Status: " . ucfirst($status);
            $message = "Sua solicitação de compra #$compraId foi $status.\n";
            $message .= "Acesse o sistema para mais detalhes.";
            
            $this->sendEmail($solicitante['email'], $subject, $message);
            $this->sendWhatsApp($solicitante['telefone'], $message);
        }
    }
}
