<?php
class DashboardController extends Controller {
    
    public function index() {
        // Verifica permissão
        if (!$this->checkPermission('dashboard', 'visualizar')) {
            return;
        }
        
        $data = [];
        
        // Estatísticas baseadas no nível de acesso
        switch ($this->user['nivel_acesso_id']) {
            case NIVEL_ADMIN:
                $data = $this->getAdminDashboard();
                break;
            case NIVEL_CLIENTE:
                $data = $this->getClienteDashboard();
                break;
            case NIVEL_FUNCIONARIO:
                $data = $this->getFuncionarioDashboard();
                break;
            case NIVEL_FINANCEIRO:
                $data = $this->getFinanceiroDashboard();
                break;
            case NIVEL_ENCARREGADO:
                $data = $this->getEncarregadoDashboard();
                break;
        }
        
        // Adiciona informações do usuário
        $data['user'] = $this->user;
        $data['flash'] = $this->getFlash();
        
        // Verifica aniversários do dia
        $data['aniversarios'] = $this->getAniversariosHoje();
        
        // Lembretes pendentes
        $data['lembretes'] = $this->getLembretesPendentes();
        
        echo $this->view->render('dashboard/index', $data);
    }
    
    private function getAdminDashboard() {
        $data = [];
        
        // Total de imóveis
        $data['total_imoveis'] = $this->db->count('imoveis');
        $data['imoveis_disponiveis'] = $this->db->count('imoveis', "status = 'disponivel'");
        $data['imoveis_vendidos'] = $this->db->count('imoveis', "status = 'vendido'");
        
        // Total de clientes
        $data['total_clientes'] = $this->db->count('usuarios', 'nivel_acesso_id = ' . NIVEL_CLIENTE);
        
        // Total de funcionários
        $data['total_funcionarios'] = $this->db->count('funcionarios', "status = 'ativo'");
        
        // Empreendimentos
        $data['total_empreendimentos'] = $this->db->count('empreendimentos');
        $data['empreendimentos_andamento'] = $this->db->count('empreendimentos', "status = 'em_andamento'");
        
        // Financeiro - Resumo do mês
        $mesAtual = date('Y-m');
        
        // Receitas do mês
        $sql = "SELECT SUM(valor) as total FROM faturas 
                WHERE DATE_FORMAT(data_pagamento, '%Y-%m') = :mes 
                AND status = 'pago'";
        $receita = $this->db->fetchOne($sql, ['mes' => $mesAtual]);
        $data['receita_mes'] = $receita['total'] ?? 0;
        
        // Despesas do mês
        $sql = "SELECT SUM(valor) as total FROM contas_pagar 
                WHERE DATE_FORMAT(data_pagamento, '%Y-%m') = :mes 
                AND status = 'pago'";
        $despesa = $this->db->fetchOne($sql, ['mes' => $mesAtual]);
        $data['despesa_mes'] = $despesa['total'] ?? 0;
        
        // Faturas vencidas
        $data['faturas_vencidas'] = $this->db->count('faturas', 
            "status = 'vencido' OR (status = 'em_aberto' AND data_vencimento < CURDATE())");
        
        // Contas a pagar vencidas
        $data['contas_vencidas'] = $this->db->count('contas_pagar', 
            "status = 'vencido' OR (status = 'pendente' AND data_vencimento < CURDATE())");
        
        // Últimas atividades
        $sql = "SELECT l.*, u.nome_completo 
                FROM logs_acesso l 
                JOIN usuarios u ON l.usuario_id = u.id 
                ORDER BY l.created_at DESC 
                LIMIT 10";
        $data['ultimas_atividades'] = $this->db->fetchAll($sql);
        
        // Gráfico de vendas dos últimos 6 meses
        $data['grafico_vendas'] = $this->getGraficoVendas(6);
        
        return $data;
    }
    
    private function getClienteDashboard() {
        $data = [];
        
        // Imóveis do cliente
        $sql = "SELECT * FROM imoveis WHERE cliente_id = :cliente_id";
        $data['meus_imoveis'] = $this->db->fetchAll($sql, ['cliente_id' => $this->user['id']]);
        
        // Faturas pendentes
        $sql = "SELECT * FROM faturas 
                WHERE cliente_id = :cliente_id 
                AND status IN ('em_aberto', 'vencido')
                ORDER BY data_vencimento ASC";
        $data['faturas_pendentes'] = $this->db->fetchAll($sql, ['cliente_id' => $this->user['id']]);
        
        // Próximas parcelas
        $sql = "SELECT * FROM faturas 
                WHERE cliente_id = :cliente_id 
                AND status = 'em_aberto'
                AND data_vencimento >= CURDATE()
                ORDER BY data_vencimento ASC
                LIMIT 5";
        $data['proximas_parcelas'] = $this->db->fetchAll($sql, ['cliente_id' => $this->user['id']]);
        
        // Total pago
        $sql = "SELECT SUM(valor) as total FROM faturas 
                WHERE cliente_id = :cliente_id AND status = 'pago'";
        $result = $this->db->fetchOne($sql, ['cliente_id' => $this->user['id']]);
        $data['total_pago'] = $result['total'] ?? 0;
        
        // Total a pagar
        $sql = "SELECT SUM(valor) as total FROM faturas 
                WHERE cliente_id = :cliente_id AND status IN ('em_aberto', 'vencido')";
        $result = $this->db->fetchOne($sql, ['cliente_id' => $this->user['id']]);
        $data['total_a_pagar'] = $result['total'] ?? 0;
        
        return $data;
    }
    
    private function getFuncionarioDashboard() {
        $data = [];
        
        // Dados do funcionário
        $sql = "SELECT * FROM funcionarios WHERE usuario_id = :usuario_id";
        $data['funcionario'] = $this->db->fetchOne($sql, ['usuario_id' => $this->user['id']]);
        
        if ($data['funcionario']) {
            // EPIs
            $sql = "SELECT * FROM epis 
                    WHERE funcionario_id = :funcionario_id 
                    AND data_devolucao IS NULL
                    ORDER BY data_entrega DESC";
            $data['meus_epis'] = $this->db->fetchAll($sql, ['funcionario_id' => $data['funcionario']['id']]);
            
            // Faltas do mês
            $sql = "SELECT COUNT(*) as total FROM faltas 
                    WHERE funcionario_id = :funcionario_id 
                    AND MONTH(data) = MONTH(CURDATE())
                    AND YEAR(data) = YEAR(CURDATE())";
            $result = $this->db->fetchOne($sql, ['funcionario_id' => $data['funcionario']['id']]);
            $data['faltas_mes'] = $result['total'];
            
            // Adiantamentos pendentes
            $sql = "SELECT * FROM adiantamentos 
                    WHERE funcionario_id = :funcionario_id 
                    AND status IN ('pendente', 'aprovado')
                    ORDER BY data_solicitacao DESC";
            $data['adiantamentos_pendentes'] = $this->db->fetchAll($sql, 
                ['funcionario_id' => $data['funcionario']['id']]);
            
            // Próximas férias
            if ($data['funcionario']['ultimas_ferias']) {
                $proximasFerias = date('Y-m-d', strtotime($data['funcionario']['ultimas_ferias'] . ' +1 year'));
                $data['proximas_ferias'] = $proximasFerias;
                $data['dias_para_ferias'] = (strtotime($proximasFerias) - time()) / 86400;
            }
        }
        
        return $data;
    }
    
    private function getFinanceiroDashboard() {
        $data = [];
        
        // Resumo financeiro do mês
        $mesAtual = date('Y-m');
        
        // Receitas
        $sql = "SELECT SUM(valor) as total, COUNT(*) as quantidade 
                FROM faturas 
                WHERE DATE_FORMAT(data_pagamento, '%Y-%m') = :mes 
                AND status = 'pago'";
        $receitas = $this->db->fetchOne($sql, ['mes' => $mesAtual]);
        $data['receitas_mes'] = $receitas['total'] ?? 0;
        $data['qtd_receitas'] = $receitas['quantidade'] ?? 0;
        
        // Despesas
        $sql = "SELECT SUM(valor) as total, COUNT(*) as quantidade 
                FROM contas_pagar 
                WHERE DATE_FORMAT(data_pagamento, '%Y-%m') = :mes 
                AND status = 'pago'";
        $despesas = $this->db->fetchOne($sql, ['mes' => $mesAtual]);
        $data['despesas_mes'] = $despesas['total'] ?? 0;
        $data['qtd_despesas'] = $despesas['quantidade'] ?? 0;
        
        // Saldo
        $data['saldo_mes'] = $data['receitas_mes'] - $data['despesas_mes'];
        
        // Contas a receber
        $sql = "SELECT SUM(valor) as total, COUNT(*) as quantidade 
                FROM faturas 
                WHERE status IN ('em_aberto', 'vencido')";
        $receber = $this->db->fetchOne($sql);
        $data['total_receber'] = $receber['total'] ?? 0;
        $data['qtd_receber'] = $receber['quantidade'] ?? 0;
        
        // Contas a pagar
        $sql = "SELECT SUM(valor) as total, COUNT(*) as quantidade 
                FROM contas_pagar 
                WHERE status IN ('pendente', 'vencido')";
        $pagar = $this->db->fetchOne($sql);
        $data['total_pagar'] = $pagar['total'] ?? 0;
        $data['qtd_pagar'] = $pagar['quantidade'] ?? 0;
        
        // Faturas vencendo hoje
        $sql = "SELECT * FROM faturas 
                WHERE data_vencimento = CURDATE() 
                AND status = 'em_aberto'
                ORDER BY valor DESC";
        $data['vencendo_hoje'] = $this->db->fetchAll($sql);
        
        // Contas vencidas
        $sql = "SELECT * FROM faturas 
                WHERE (status = 'vencido' OR (status = 'em_aberto' AND data_vencimento < CURDATE()))
                ORDER BY data_vencimento ASC
                LIMIT 10";
        $data['faturas_vencidas'] = $this->db->fetchAll($sql);
        
        // Fluxo de caixa dos próximos 30 dias
        $data['fluxo_caixa'] = $this->getFluxoCaixa(30);
        
        return $data;
    }
    
    private function getEncarregadoDashboard() {
        $data = [];
        
        // Empreendimentos sob responsabilidade
        $sql = "SELECT * FROM empreendimentos 
                WHERE encarregado_id = :encarregado_id 
                AND status = 'em_andamento'";
        $data['meus_empreendimentos'] = $this->db->fetchAll($sql, 
            ['encarregado_id' => $this->user['id']]);
        
        // Ocorrências abertas
        $sql = "SELECT o.*, e.nome as empreendimento_nome 
                FROM ocorrencias_manutencao o
                JOIN empreendimentos e ON o.empreendimento_id = e.id
                WHERE o.encarregado_id = :encarregado_id 
                AND o.status IN ('aberta', 'em_andamento')
                ORDER BY o.prioridade DESC, o.data_abertura ASC";
        $data['ocorrencias_abertas'] = $this->db->fetchAll($sql, 
            ['encarregado_id' => $this->user['id']]);
        
        // Compras pendentes
        $sql = "SELECT c.*, e.nome as empreendimento_nome 
                FROM compras c
                JOIN empreendimentos e ON c.empreendimento_id = e.id
                WHERE c.solicitante_id = :solicitante_id 
                AND c.status IN ('solicitado', 'aprovado')
                ORDER BY c.created_at DESC";
        $data['compras_pendentes'] = $this->db->fetchAll($sql, 
            ['solicitante_id' => $this->user['id']]);
        
        // Funcionários das obras
        $empreendimentoIds = array_column($data['meus_empreendimentos'], 'id');
        if (!empty($empreendimentoIds)) {
            $placeholders = implode(',', array_fill(0, count($empreendimentoIds), '?'));
            $sql = "SELECT f.*, e.nome as empreendimento_nome 
                    FROM funcionarios f
                    JOIN empreendimentos e ON f.empreendimento_id = e.id
                    WHERE f.empreendimento_id IN ($placeholders) 
                    AND f.status = 'ativo'";
            $data['funcionarios'] = $this->db->fetchAll($sql, $empreendimentoIds);
        }
        
        return $data;
    }
    
    private function getAniversariosHoje() {
        $sql = "SELECT nome_completo, email, telefone 
                FROM usuarios 
                WHERE DAY(data_nascimento) = DAY(CURDATE()) 
                AND MONTH(data_nascimento) = MONTH(CURDATE())";
        return $this->db->fetchAll($sql);
    }
    
    private function getLembretesPendentes() {
        $sql = "SELECT * FROM lembretes 
                WHERE usuario_id = :usuario_id 
                AND data_lembrete <= CURDATE() 
                AND enviado = 0
                ORDER BY data_lembrete ASC";
        return $this->db->fetchAll($sql, ['usuario_id' => $this->user['id']]);
    }
    
    private function getGraficoVendas($meses) {
        $dados = [];
        
        for ($i = $meses - 1; $i >= 0; $i--) {
            $mes = date('Y-m', strtotime("-$i months"));
            // Substituindo strftime() por DateTime para compatibilidade com PHP 8.1+
            $dateTime = new DateTime("-$i months");
            $mesNome = $this->getMonthNamePtBr($dateTime->format('n')) . '/' . $dateTime->format('Y');
            
            $sql = "SELECT COUNT(*) as vendas, SUM(valor) as total 
                    FROM imoveis 
                    WHERE DATE_FORMAT(data_venda, '%Y-%m') = :mes 
                    AND status = 'vendido'";
            
            $result = $this->db->fetchOne($sql, ['mes' => $mes]);
            
            $dados[] = [
                'mes' => $mesNome,
                'vendas' => $result['vendas'] ?? 0,
                'total' => $result['total'] ?? 0
            ];
        }
        
        return $dados;
    }
    
    private function getFluxoCaixa($dias) {
        $fluxo = [];
        
        for ($i = 0; $i < $dias; $i++) {
            $data = date('Y-m-d', strtotime("+$i days"));
            
            // Receitas previstas
            $sql = "SELECT SUM(valor) as total FROM faturas 
                    WHERE data_vencimento = :data 
                    AND status = 'em_aberto'";
            $receita = $this->db->fetchOne($sql, ['data' => $data]);
            
            // Despesas previstas
            $sql = "SELECT SUM(valor) as total FROM contas_pagar 
                    WHERE data_vencimento = :data 
                    AND status = 'pendente'";
            $despesa = $this->db->fetchOne($sql, ['data' => $data]);
            
            if (($receita['total'] ?? 0) > 0 || ($despesa['total'] ?? 0) > 0) {
                $fluxo[] = [
                    'data' => $data,
                    'receita' => $receita['total'] ?? 0,
                    'despesa' => $despesa['total'] ?? 0,
                    'saldo' => ($receita['total'] ?? 0) - ($despesa['total'] ?? 0)
                ];
            }
        }
        
        return $fluxo;
    }
    
    /**
     * Retorna o nome abreviado do mês em português
     * @param int $monthNumber Número do mês (1-12)
     * @return string Nome abreviado do mês
     */
    private function getMonthNamePtBr($monthNumber) {
        $meses = [
            1 => 'Jan',
            2 => 'Fev',
            3 => 'Mar',
            4 => 'Abr',
            5 => 'Mai',
            6 => 'Jun',
            7 => 'Jul',
            8 => 'Ago',
            9 => 'Set',
            10 => 'Out',
            11 => 'Nov',
            12 => 'Dez'
        ];
        
        return $meses[(int)$monthNumber] ?? '';
    }
}
