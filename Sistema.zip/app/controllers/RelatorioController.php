<?php
require_once __DIR__ . '/../core/Controller.php';

class RelatorioController extends Controller {
    
    public function index() {
        if (!$this->checkPermission('relatorios', 'visualizar')) {
            return;
        }
        
        $data = [
            'flash' => $this->getFlash()
        ];
        
        echo $this->view->render('relatorios/index', $data);
    }
    
    public function financeiro() {
        if (!$this->checkPermission('relatorios', 'visualizar')) {
            return;
        }
        
        // Relatório financeiro
        $periodo = $_GET['periodo'] ?? 'mes_atual';
        $data_inicio = null;
        $data_fim = null;
        
        switch($periodo) {
            case 'mes_atual':
                $data_inicio = date('Y-m-01');
                $data_fim = date('Y-m-t');
                break;
            case 'mes_anterior':
                $data_inicio = date('Y-m-01', strtotime('-1 month'));
                $data_fim = date('Y-m-t', strtotime('-1 month'));
                break;
            case 'ano_atual':
                $data_inicio = date('Y-01-01');
                $data_fim = date('Y-12-31');
                break;
            case 'personalizado':
                $data_inicio = $_GET['data_inicio'] ?? date('Y-m-01');
                $data_fim = $_GET['data_fim'] ?? date('Y-m-t');
                break;
        }
        
        // Busca dados financeiros
        $sql_receitas = "SELECT SUM(valor_pago) as total FROM faturas 
                        WHERE status = 'pago' 
                        AND data_pagamento BETWEEN :inicio AND :fim";
        $receitas = $this->db->fetchOne($sql_receitas, ['inicio' => $data_inicio, 'fim' => $data_fim]);
        
        $sql_despesas = "SELECT SUM(valor) as total FROM contas_pagar 
                        WHERE status = 'pago' 
                        AND data_pagamento BETWEEN :inicio AND :fim";
        $despesas = $this->db->fetchOne($sql_despesas, ['inicio' => $data_inicio, 'fim' => $data_fim]);
        
        $data = [
            'periodo' => $periodo,
            'data_inicio' => $data_inicio,
            'data_fim' => $data_fim,
            'receitas' => $receitas['total'] ?? 0,
            'despesas' => $despesas['total'] ?? 0,
            'lucro' => ($receitas['total'] ?? 0) - ($despesas['total'] ?? 0)
        ];
        
        echo $this->view->render('relatorios/financeiro', $data);
    }
    
    public function obras() {
        if (!$this->checkPermission('relatorios', 'visualizar')) {
            return;
        }
        
        // Estatísticas de obras
        $sql = "SELECT 
                    COUNT(DISTINCT e.id) as total_empreendimentos,
                    COUNT(DISTINCT o.id) as total_ocorrencias,
                    COUNT(DISTINCT c.id) as total_compras,
                    SUM(c.valor_total) as valor_total_compras
                FROM empreendimentos e
                LEFT JOIN ocorrencias_manutencao o ON e.id = o.empreendimento_id
                LEFT JOIN compras c ON e.id = c.empreendimento_id";
        
        $estatisticas = $this->db->fetchOne($sql);
        
        // Ocorrências por status
        $sql_ocorrencias = "SELECT status, COUNT(*) as total 
                           FROM ocorrencias_manutencao 
                           GROUP BY status";
        $ocorrencias_status = $this->db->fetchAll($sql_ocorrencias);
        
        // Compras por status
        $sql_compras = "SELECT status, COUNT(*) as total, SUM(valor_total) as valor 
                       FROM compras 
                       GROUP BY status";
        $compras_status = $this->db->fetchAll($sql_compras);
        
        $data = [
            'estatisticas' => $estatisticas,
            'ocorrencias_status' => $ocorrencias_status,
            'compras_status' => $compras_status
        ];
        
        echo $this->view->render('relatorios/obras', $data);
    }
    
    public function imoveis() {
        if (!$this->checkPermission('relatorios', 'visualizar')) {
            return;
        }
        
        // Estatísticas de imóveis
        $sql = "SELECT 
                    COUNT(*) as total_imoveis,
                    COUNT(CASE WHEN status = 'disponivel' THEN 1 END) as disponiveis,
                    COUNT(CASE WHEN status = 'alugado' THEN 1 END) as alugados,
                    COUNT(CASE WHEN status = 'vendido' THEN 1 END) as vendidos,
                    COUNT(CASE WHEN status = 'manutencao' THEN 1 END) as manutencao
                FROM imoveis";
        
        $estatisticas = $this->db->fetchOne($sql);
        
        // Imóveis por tipo
        $sql_tipos = "SELECT tipo, COUNT(*) as total FROM imoveis GROUP BY tipo";
        $imoveis_tipo = $this->db->fetchAll($sql_tipos);
        
        // Valor total dos imóveis
        $sql_valores = "SELECT 
                        SUM(valor_venda) as valor_total_venda,
                        SUM(valor_aluguel) as valor_total_aluguel,
                        AVG(valor_venda) as valor_medio_venda,
                        AVG(valor_aluguel) as valor_medio_aluguel
                       FROM imoveis";
        $valores = $this->db->fetchOne($sql_valores);
        
        $data = [
            'estatisticas' => $estatisticas,
            'imoveis_tipo' => $imoveis_tipo,
            'valores' => $valores
        ];
        
        echo $this->view->render('relatorios/imoveis', $data);
    }
    
    public function personalizado() {
        if (!$this->checkPermission('relatorios', 'visualizar')) {
            return;
        }
        
        // Relatório personalizado com filtros avançados
        $filtros = [
            'tipo_relatorio' => $_GET['tipo'] ?? 'geral',
            'data_inicio' => $_GET['data_inicio'] ?? date('Y-m-01'),
            'data_fim' => $_GET['data_fim'] ?? date('Y-m-t'),
            'modulo' => $_GET['modulo'] ?? 'todos'
        ];
        
        $dados = [];
        
        // Buscar dados baseado no tipo de relatório
        switch($filtros['tipo_relatorio']) {
            case 'financeiro_detalhado':
                $dados = $this->getRelatorioFinanceiroDetalhado($filtros);
                break;
            case 'obras_detalhado':
                $dados = $this->getRelatorioObrasDetalhado($filtros);
                break;
            case 'imoveis_detalhado':
                $dados = $this->getRelatorioImoveisDetalhado($filtros);
                break;
            default:
                $dados = $this->getRelatorioGeral($filtros);
        }
        
        $data = [
            'filtros' => $filtros,
            'dados' => $dados,
            'flash' => $this->getFlash()
        ];
        
        echo $this->view->render('relatorios/personalizado', $data);
    }
    
    public function fornecedores() {
        if (!$this->checkPermission('relatorios', 'visualizar')) {
            return;
        }
        
        // Período do relatório
        $data_inicio = $_GET['data_inicio'] ?? date('Y-m-01');
        $data_fim = $_GET['data_fim'] ?? date('Y-m-t');
        
        // Estatísticas de fornecedores
        $sql = "SELECT 
                    COUNT(DISTINCT f.id) as total_fornecedores,
                    COUNT(DISTINCT f.id) as fornecedores_ativos,
                    COUNT(DISTINCT c.id) as total_compras,
                    SUM(c.valor_total) as valor_total_compras
                FROM fornecedores f
                LEFT JOIN compras c ON f.id = c.fornecedor_id
                WHERE c.created_at BETWEEN :inicio AND :fim OR c.id IS NULL";
        
        $estatisticas = $this->db->fetchOne($sql, ['inicio' => $data_inicio, 'fim' => $data_fim]);
        
        // Top fornecedores por volume de compras
        $sql_top = "SELECT 
                        f.id,
                        f.nome,
                        f.cnpj,
                        COUNT(c.id) as total_compras,
                        SUM(c.valor_total) as valor_total,
                        AVG(c.valor_total) as valor_medio
                    FROM fornecedores f
                    LEFT JOIN compras c ON f.id = c.fornecedor_id
                    WHERE c.created_at BETWEEN :inicio AND :fim
                    GROUP BY f.id
                    ORDER BY valor_total DESC
                    LIMIT 10";
        
        $top_fornecedores = $this->db->fetchAll($sql_top, ['inicio' => $data_inicio, 'fim' => $data_fim]);
        
        // Compras por categoria
        $sql_categorias = "SELECT 
                            f.categoria,
                            COUNT(DISTINCT f.id) as total_fornecedores,
                            COUNT(c.id) as total_compras,
                            SUM(c.valor_total) as valor_total
                          FROM fornecedores f
                          LEFT JOIN compras c ON f.id = c.fornecedor_id
                          WHERE c.created_at BETWEEN :inicio AND :fim OR c.id IS NULL
                          GROUP BY f.categoria";
        
        $categorias = $this->db->fetchAll($sql_categorias, ['inicio' => $data_inicio, 'fim' => $data_fim]);
        
        $data = [
            'data_inicio' => $data_inicio,
            'data_fim' => $data_fim,
            'estatisticas' => $estatisticas,
            'top_fornecedores' => $top_fornecedores,
            'categorias' => $categorias,
            'flash' => $this->getFlash()
        ];
        
        echo $this->view->render('relatorios/fornecedores', $data);
    }
    
    public function funcionarios() {
        if (!$this->checkPermission('relatorios', 'visualizar')) {
            return;
        }
        
        // Período do relatório
        $mes = $_GET['mes'] ?? date('m');
        $ano = $_GET['ano'] ?? date('Y');
        $data_inicio = "$ano-$mes-01";
        $data_fim = date('Y-m-t', strtotime($data_inicio));
        
        // Estatísticas gerais
        $sql = "SELECT 
                    COUNT(*) as total_funcionarios,
                    COUNT(CASE WHEN status = 'ativo' THEN 1 END) as ativos,
                    COUNT(CASE WHEN status = 'inativo' THEN 1 END) as inativos,
                    AVG(salario) as salario_medio,
                    SUM(salario) as folha_pagamento
                FROM funcionarios";
        
        $estatisticas = $this->db->fetchOne($sql);
        
        // Funcionários por cargo
        $sql_cargos = "SELECT cargo, COUNT(*) as total, AVG(salario) as salario_medio 
                      FROM funcionarios 
                      WHERE status = 'ativo'
                      GROUP BY cargo 
                      ORDER BY total DESC";
        $funcionarios_cargo = $this->db->fetchAll($sql_cargos);
        
        // Faltas no período
        $sql_faltas = "SELECT 
                        f.id,
                        f.nome,
                        COUNT(fa.id) as total_faltas,
                        SUM(CASE WHEN fa.justificada = 1 THEN 1 ELSE 0 END) as faltas_justificadas,
                        SUM(CASE WHEN fa.justificada = 0 THEN 1 ELSE 0 END) as faltas_injustificadas
                      FROM funcionarios f
                      LEFT JOIN faltas fa ON f.id = fa.funcionario_id 
                        AND fa.data BETWEEN :inicio AND :fim
                      WHERE f.status = 'ativo'
                      GROUP BY f.id
                      HAVING total_faltas > 0
                      ORDER BY total_faltas DESC";
        
        $faltas = $this->db->fetchAll($sql_faltas, ['inicio' => $data_inicio, 'fim' => $data_fim]);
        
        // EPIs entregues no período
        $sql_epis = "SELECT 
                        COUNT(*) as total_entregas,
                        COUNT(DISTINCT funcionario_id) as funcionarios_atendidos,
                        SUM(CASE WHEN devolvido = 0 THEN 1 ELSE 0 END) as epis_em_uso
                    FROM epis_entregues
                    WHERE data_entrega BETWEEN :inicio AND :fim";
        
        $epis = $this->db->fetchOne($sql_epis, ['inicio' => $data_inicio, 'fim' => $data_fim]);
        
        // Funcionários por empreendimento
        $sql_empreendimentos = "SELECT 
                                    e.nome as empreendimento,
                                    COUNT(DISTINCT f.id) as total_funcionarios
                                FROM funcionarios f
                                INNER JOIN empreendimentos e ON f.empreendimento_id = e.id
                                WHERE f.status = 'ativo'
                                GROUP BY e.id
                                ORDER BY total_funcionarios DESC";
        
        $funcionarios_empreendimento = $this->db->fetchAll($sql_empreendimentos);
        
        $data = [
            'mes' => $mes,
            'ano' => $ano,
            'data_inicio' => $data_inicio,
            'data_fim' => $data_fim,
            'estatisticas' => $estatisticas,
            'funcionarios_cargo' => $funcionarios_cargo,
            'faltas' => $faltas,
            'epis' => $epis,
            'funcionarios_empreendimento' => $funcionarios_empreendimento,
            'flash' => $this->getFlash()
        ];
        
        echo $this->view->render('relatorios/funcionarios', $data);
    }
    
    private function getRelatorioFinanceiroDetalhado($filtros) {
        $sql = "SELECT 
                    'Receitas' as tipo,
                    f.descricao,
                    f.valor_pago as valor,
                    f.data_pagamento as data
                FROM faturas f
                WHERE f.status = 'pago' 
                    AND f.data_pagamento BETWEEN :inicio AND :fim
                UNION ALL
                SELECT 
                    'Despesas' as tipo,
                    c.descricao,
                    c.valor,
                    c.data_pagamento as data
                FROM contas_pagar c
                WHERE c.status = 'pago'
                    AND c.data_pagamento BETWEEN :inicio AND :fim
                ORDER BY data DESC";
        
        return $this->db->fetchAll($sql, [
            'inicio' => $filtros['data_inicio'],
            'fim' => $filtros['data_fim']
        ]);
    }
    
    private function getRelatorioObrasDetalhado($filtros) {
        $sql = "SELECT 
                    e.nome as empreendimento,
                    COUNT(DISTINCT o.id) as total_ocorrencias,
                    COUNT(DISTINCT c.id) as total_compras,
                    SUM(c.valor_total) as valor_compras
                FROM empreendimentos e
                LEFT JOIN ocorrencias_manutencao o ON e.id = o.empreendimento_id
                    AND o.created_at BETWEEN :inicio AND :fim
                LEFT JOIN compras c ON e.id = c.empreendimento_id
                    AND c.created_at BETWEEN :inicio AND :fim
                GROUP BY e.id
                ORDER BY e.nome";
        
        return $this->db->fetchAll($sql, [
            'inicio' => $filtros['data_inicio'],
            'fim' => $filtros['data_fim']
        ]);
    }
    
    private function getRelatorioImoveisDetalhado($filtros) {
        $sql = "SELECT 
                    i.*,
                    COUNT(m.id) as total_manutencoes,
                    SUM(m.valor) as valor_manutencoes
                FROM imoveis i
                LEFT JOIN manutencoes m ON i.id = m.imovel_id
                    AND m.data BETWEEN :inicio AND :fim
                GROUP BY i.id
                ORDER BY i.codigo";
        
        return $this->db->fetchAll($sql, [
            'inicio' => $filtros['data_inicio'],
            'fim' => $filtros['data_fim']
        ]);
    }
    
    private function getRelatorioGeral($filtros) {
        // Relatório geral com resumo de todos os módulos
        return [
            'financeiro' => $this->getResumoFinanceiro($filtros),
            'obras' => $this->getResumoObras($filtros),
            'imoveis' => $this->getResumoImoveis($filtros),
            'funcionarios' => $this->getResumoFuncionarios($filtros)
        ];
    }
    
    private function getResumoFinanceiro($filtros) {
        $sql = "SELECT 
                    (SELECT SUM(valor_pago) FROM faturas WHERE status = 'pago' AND data_pagamento BETWEEN :inicio AND :fim) as receitas,
                    (SELECT SUM(valor) FROM contas_pagar WHERE status = 'pago' AND data_pagamento BETWEEN :inicio2 AND :fim2) as despesas";
        
        return $this->db->fetchOne($sql, [
            'inicio' => $filtros['data_inicio'],
            'fim' => $filtros['data_fim'],
            'inicio2' => $filtros['data_inicio'],
            'fim2' => $filtros['data_fim']
        ]);
    }
    
    private function getResumoObras($filtros) {
        $sql = "SELECT 
                    COUNT(DISTINCT empreendimento_id) as empreendimentos_ativos,
                    COUNT(*) as total_ocorrencias
                FROM ocorrencias_manutencao
                WHERE created_at BETWEEN :inicio AND :fim";
        
        return $this->db->fetchOne($sql, [
            'inicio' => $filtros['data_inicio'],
            'fim' => $filtros['data_fim']
        ]);
    }
    
    private function getResumoImoveis($filtros) {
        return $this->db->fetchOne("SELECT COUNT(*) as total, 
                                            COUNT(CASE WHEN status = 'disponivel' THEN 1 END) as disponiveis,
                                            COUNT(CASE WHEN status = 'alugado' THEN 1 END) as alugados
                                     FROM imoveis");
    }
    
    private function getResumoFuncionarios($filtros) {
        return $this->db->fetchOne("SELECT COUNT(*) as total,
                                            COUNT(CASE WHEN status = 'ativo' THEN 1 END) as ativos,
                                            SUM(salario) as folha_pagamento
                                     FROM funcionarios");
    }
    
    public function exportar() {
        if (!$this->checkPermission('relatorios', 'exportar')) {
            return;
        }
        
        $tipo = $_GET['tipo'] ?? 'pdf';
        $relatorio = $_GET['relatorio'] ?? 'geral';
        
        // Implementar exportação para PDF/Excel
        $this->setFlash('Funcionalidade de exportação em desenvolvimento.', 'info');
        $this->redirect('/relatorios');
    }
}
