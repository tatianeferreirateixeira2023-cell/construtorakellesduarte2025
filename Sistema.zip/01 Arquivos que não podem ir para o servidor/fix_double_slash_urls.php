<?php
/**
 * Script para corrigir URLs com dupla barra no sistema
 * Problema: BASE_URL já termina com / então não deve ter / no início dos links
 */

$viewsPath = __DIR__ . '/views';
$totalFixed = 0;

// Função para processar arquivos recursivamente
function processDirectory($dir, &$totalFixed) {
    $files = scandir($dir);
    
    foreach ($files as $file) {
        if ($file === '.' || $file === '..') continue;
        
        $path = $dir . '/' . $file;
        
        if (is_dir($path)) {
            processDirectory($path, $totalFixed);
        } elseif (pathinfo($path, PATHINFO_EXTENSION) === 'php') {
            processFile($path, $totalFixed);
        }
    }
}

// Função para processar cada arquivo
function processFile($filePath, &$totalFixed) {
    $content = file_get_contents($filePath);
    $originalContent = $content;
    $patterns = [
        // Corrige BASE_URL com barra dupla
        '/\<\?=\s*BASE_URL\s*\?>\s*\//' => '<?= BASE_URL ?>',
        '/\<\?=\s*BASE_PATH\s*\?>\s*\//' => '<?= BASE_PATH ?>/',
        
        // Corrige href com BASE_URL
        '/href="<\?=\s*BASE_URL\s*\?>\//' => 'href="<?= BASE_URL ?>',
        '/href=\'<\?=\s*BASE_URL\s*\?>\//' => 'href=\'<?= BASE_URL ?>',
        
        // Corrige action com BASE_URL
        '/action="<\?=\s*BASE_URL\s*\?>\//' => 'action="<?= BASE_URL ?>',
        '/action=\'<\?=\s*BASE_URL\s*\?>\//' => 'action=\'<?= BASE_URL ?>',
        
        // Corrige src com BASE_URL
        '/src="<\?=\s*BASE_URL\s*\?>\//' => 'src="<?= BASE_URL ?>',
        '/src=\'<\?=\s*BASE_URL\s*\?>\//' => 'src=\'<?= BASE_URL ?>',
    ];
    
    foreach ($patterns as $pattern => $replacement) {
        $content = preg_replace($pattern, $replacement, $content);
    }
    
    // Se houve mudanças, salva o arquivo
    if ($content !== $originalContent) {
        file_put_contents($filePath, $content);
        $totalFixed++;
        echo "✓ Corrigido: " . str_replace(__DIR__ . '/', '', $filePath) . "\n";
    }
}

echo "=== Correção de URLs com Dupla Barra ===\n\n";
echo "Processando arquivos em: $viewsPath\n\n";

// Processa todos os arquivos
processDirectory($viewsPath, $totalFixed);

echo "\n=== Resumo ===\n";
echo "Total de arquivos corrigidos: $totalFixed\n";

// Também vamos verificar e listar possíveis problemas em controllers
echo "\n=== Verificando Controllers ===\n";

$controllersPath = __DIR__ . '/app/controllers';
$controllerIssues = [];

function checkControllers($dir, &$issues) {
    $files = scandir($dir);
    
    foreach ($files as $file) {
        if ($file === '.' || $file === '..') continue;
        
        $path = $dir . '/' . $file;
        
        if (is_file($path) && pathinfo($path, PATHINFO_EXTENSION) === 'php') {
            $content = file_get_contents($path);
            
            // Procura por redirects problemáticos
            if (preg_match_all('/\$this->redirect\([\'"]\/([^\'"]*)[\'"]\)/', $content, $matches)) {
                foreach ($matches[1] as $match) {
                    if (!empty($match)) {
                        $issues[] = [
                            'file' => str_replace(__DIR__ . '/', '', $path),
                            'redirect' => '/' . $match
                        ];
                    }
                }
            }
        }
    }
}

checkControllers($controllersPath, $controllerIssues);

if (!empty($controllerIssues)) {
    echo "\nPossíveis redirects que precisam de revisão:\n";
    foreach ($controllerIssues as $issue) {
        echo "- {$issue['file']}: redirect('{$issue['redirect']}')\n";
    }
    echo "\nNota: Verifique se estes redirects devem usar BASE_PATH ou caminho absoluto.\n";
} else {
    echo "Nenhum problema encontrado nos controllers.\n";
}

echo "\n✅ Processo concluído!\n";
echo "Recomendação: Teste o sistema para garantir que todos os links estão funcionando corretamente.\n";
?>
