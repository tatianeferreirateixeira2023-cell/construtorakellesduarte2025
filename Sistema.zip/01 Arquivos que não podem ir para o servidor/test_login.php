<?php
/**
 * Teste direto de login
 */

session_start();
require_once 'config/config.php';
require_once 'app/autoload.php';

echo "<h1>Teste de Login Direto</h1>";
echo "<hr>";

// Dados de teste
$email = 'admin@construtorakellesduarte.com.br';
$senha = 'Admin@2024';

echo "<h2>1. Verificando usuário no banco...</h2>";

try {
    $db = Database::getInstance();
    
    // Busca o usuário
    $sql = "SELECT * FROM usuarios WHERE email = :email";
    $stmt = $db->prepare($sql);
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user) {
        echo "✅ Usuário encontrado!<br>";
        echo "- ID: " . $user['id'] . "<br>";
        echo "- Nome: " . $user['nome_completo'] . "<br>";
        echo "- Email: " . $user['email'] . "<br>";
        echo "- Nível: " . $user['nivel_acesso_id'] . "<br>";
        echo "- Ativo: " . ($user['ativo'] ? 'Sim' : 'Não') . "<br>";
        echo "- Hash da senha (primeiros 30 chars): " . substr($user['senha'], 0, 30) . "...<br>";
        
        echo "<h2>2. Testando senha...</h2>";
        
        // Testa a senha
        $senhaCorreta = password_verify($senha, $user['senha']);
        
        if ($senhaCorreta) {
            echo "✅ SENHA CORRETA!<br><br>";
            
            echo "<h2>3. Simulando login...</h2>";
            
            // Simula o login
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['nome_completo'];
            $_SESSION['user_nivel'] = $user['nivel_acesso_id'];
            $_SESSION['login_time'] = time();
            
            echo "✅ Sessão criada com sucesso!<br>";
            echo "Session ID: " . session_id() . "<br>";
            echo "Dados da sessão:<br>";
            echo "<pre>";
            print_r($_SESSION);
            echo "</pre>";
            
            echo "<div style='background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
            echo "<h3>✅ LOGIN SIMULADO COM SUCESSO!</h3>";
            echo "Agora você pode tentar acessar o sistema:<br><br>";
            echo "<a href='" . BASE_PATH . "/' style='padding: 10px 20px; background: #28a745; color: white; text-decoration: none; border-radius: 5px;'>Acessar Sistema</a>";
            echo "</div>";
            
        } else {
            echo "❌ SENHA INCORRETA!<br><br>";
            
            echo "<h3>Vamos criar um novo hash para a senha:</h3>";
            $novoHash = password_hash('Admin@2024', PASSWORD_DEFAULT);
            echo "Novo hash gerado: " . substr($novoHash, 0, 30) . "...<br>";
            
            echo "<h3>Atualizando no banco...</h3>";
            $sql = "UPDATE usuarios SET senha = :senha WHERE id = :id";
            $stmt = $db->prepare($sql);
            $stmt->execute(['senha' => $novoHash, 'id' => $user['id']]);
            
            echo "✅ Senha atualizada! Testando novamente...<br>";
            
            // Testa novamente
            if (password_verify('Admin@2024', $novoHash)) {
                echo "✅ Nova senha funcionando!<br>";
                echo "<br><a href='" . $_SERVER['PHP_SELF'] . "' style='padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 5px;'>Recarregar e testar login</a>";
            }
        }
        
    } else {
        echo "❌ Usuário não encontrado!<br>";
        
        echo "<h2>Criando usuário admin...</h2>";
        
        $senhaHash = password_hash('Admin@2024', PASSWORD_DEFAULT);
        
        $sql = "INSERT INTO usuarios (nome_completo, email, senha, cpf, nivel_acesso_id, ativo) 
                VALUES (:nome, :email, :senha, :cpf, :nivel, :ativo)";
        
        $stmt = $db->prepare($sql);
        $result = $stmt->execute([
            'nome' => 'Administrador',
            'email' => 'admin@construtorakellesduarte.com.br',
            'senha' => $senhaHash,
            'cpf' => '00000000000',
            'nivel' => 1,
            'ativo' => 1
        ]);
        
        if ($result) {
            echo "✅ Usuário admin criado!<br>";
            echo "<br><a href='" . $_SERVER['PHP_SELF'] . "' style='padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 5px;'>Recarregar e testar login</a>";
        } else {
            echo "❌ Erro ao criar usuário<br>";
        }
    }
    
} catch (Exception $e) {
    echo "❌ Erro: " . $e->getMessage() . "<br>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}

echo "<hr>";
echo "<h2>Links úteis:</h2>";
echo "<a href='" . BASE_PATH . "/debug.php'>Debug do Sistema</a><br>";
echo "<a href='" . BASE_PATH . "/test_session.php'>Teste de Sessão</a><br>";
echo "<a href='" . BASE_PATH . "/login'>Página de Login</a><br>";
echo "<a href='" . BASE_PATH . "/'>Tentar acessar o sistema</a><br>";

// Mostra status da sessão atual
echo "<hr>";
echo "<h2>Status da Sessão Atual:</h2>";
if (isset($_SESSION['user_id'])) {
    echo "✅ Logado como: " . $_SESSION['user_name'] . " (ID: " . $_SESSION['user_id'] . ")<br>";
} else {
    echo "❌ Não logado<br>";
}
