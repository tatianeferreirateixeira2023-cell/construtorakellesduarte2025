<?php
/**
 * Teste Rápido de URLs
 */

require_once 'config/config.php';
require_once 'app/autoload.php';

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teste de URLs - Sistema</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background: #f5f5f5;
        }
        h1 {
            color: #E85D2C;
            border-bottom: 3px solid #E85D2C;
            padding-bottom: 10px;
        }
        .card {
            background: white;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .success {
            color: green;
            font-weight: bold;
        }
        .error {
            color: red;
            font-weight: bold;
        }
        .url-test {
            display: flex;
            justify-content: space-between;
            padding: 10px;
            border-bottom: 1px solid #eee;
        }
        .url-test:hover {
            background: #f9f9f9;
        }
        a {
            color: #E85D2C;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        code {
            background: #f4f4f4;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: monospace;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: #E85D2C;
            color: white;
            border-radius: 5px;
            margin: 5px;
        }
        .btn:hover {
            background: #D64520;
            color: white;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <h1>🔧 Teste de URLs do Sistema</h1>
    
    <div class="card">
        <h2>📋 Configurações</h2>
        <p><strong>BASE_URL:</strong> <code><?= BASE_URL ?></code></p>
        <p><strong>BASE_PATH:</strong> <code><?= BASE_PATH ?></code></p>
        <p><strong>URL Completa:</strong> <code>https://construtorakellesduarte.com.br/sistema/</code></p>
    </div>
    
    <div class="card">
        <h2>🔗 Links do Sistema</h2>
        <?php
        $links = [
            'Início' => '',
            'Login' => 'login',
            'Usuários' => 'usuarios',
            'Imóveis' => 'imoveis',
            'Empreendimentos' => 'empreendimentos',
            'Financeiro' => 'financeiro',
            'Obras' => 'obras',
            'Fornecedores' => 'fornecedores',
            'Funcionários' => 'funcionarios',
            'Compras' => 'compras',
            'Perfil' => 'perfil',
            'Logout' => 'logout'
        ];
        
        foreach ($links as $nome => $path):
            $url = url($path);
            $full_url = 'https://construtorakellesduarte.com.br' . $url;
        ?>
        <div class="url-test">
            <span><strong><?= $nome ?>:</strong></span>
            <span><code><?= $url ?></code></span>
            <span><a href="<?= $url ?>" target="_blank">Testar →</a></span>
        </div>
        <?php endforeach; ?>
    </div>
    
    <div class="card">
        <h2>🎨 Assets</h2>
        <?php
        $assets = [
            'CSS Custom' => css_url('custom.css'),
            'JS Custom' => js_url('custom.js'),
            'Logo' => img_url('logo.png'),
            'User Default' => img_url('user-default.png')
        ];
        
        foreach ($assets as $nome => $url):
        ?>
        <div class="url-test">
            <span><strong><?= $nome ?>:</strong></span>
            <span><code><?= $url ?></code></span>
            <span>
                <?php if (strpos($url, '.css') || strpos($url, '.js')): ?>
                    <a href="<?= $url ?>" target="_blank">Ver →</a>
                <?php else: ?>
                    <img src="<?= $url ?>" alt="<?= $nome ?>" style="height: 30px;">
                <?php endif; ?>
            </span>
        </div>
        <?php endforeach; ?>
    </div>
    
    <div class="card">
        <h2>✅ Status</h2>
        <?php
        // Verifica se os helpers estão funcionando
        $checks = [
            'Função url()' => function_exists('url'),
            'Função base_path()' => function_exists('base_path'),
            'Função base_url()' => function_exists('base_url'),
            'Função img_url()' => function_exists('img_url'),
            'Função css_url()' => function_exists('css_url'),
            'Função js_url()' => function_exists('js_url'),
            'Constante BASE_URL' => defined('BASE_URL'),
            'Constante BASE_PATH' => defined('BASE_PATH'),
        ];
        
        foreach ($checks as $nome => $status):
        ?>
        <div class="url-test">
            <span><strong><?= $nome ?>:</strong></span>
            <span class="<?= $status ? 'success' : 'error' ?>">
                <?= $status ? '✅ OK' : '❌ ERRO' ?>
            </span>
        </div>
        <?php endforeach; ?>
    </div>
    
    <div class="card">
        <h2>🚀 Ações</h2>
        <a href="<?= url() ?>" class="btn">Ir para o Sistema</a>
        <a href="<?= url('login') ?>" class="btn">Fazer Login</a>
        <a href="auto_fix_urls.php" class="btn" style="background: #28a745;">Corrigir URLs Automaticamente</a>
    </div>
    
    <div class="card" style="background: #fff3cd; border-left: 4px solid #ffc107;">
        <h3>⚠️ Importante</h3>
        <p>Se algum link não estiver funcionando:</p>
        <ol>
            <li>Execute o script <a href="auto_fix_urls.php">auto_fix_urls.php</a> para corrigir automaticamente</li>
            <li>Verifique se o arquivo .htaccess está configurado corretamente</li>
            <li>Certifique-se de que o mod_rewrite está habilitado no Apache</li>
            <li>Confirme que os arquivos foram enviados para o diretório /sistema/ no servidor</li>
        </ol>
    </div>
</body>
</html>
