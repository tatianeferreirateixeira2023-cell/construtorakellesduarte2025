<?php
/**
 * Script de Instalação - Sistema Construtora Kelles Duarte
 * Execute este script apenas uma vez para configurar o sistema
 */

// Verifica se está sendo executado via CLI ou Web
$isCLI = php_sapi_name() === 'cli';

if (!$isCLI) {
    echo "<pre>";
}

echo "=====================================\n";
echo "  INSTALAÇÃO DO SISTEMA - CONSTRUTORA KELLES DUARTE\n";
echo "=====================================\n\n";

// Função para exibir mensagens
function showMessage($message, $type = 'info') {
    $symbols = [
        'info' => '[i]',
        'success' => '[✓]',
        'error' => '[✗]',
        'warning' => '[!]'
    ];
    
    echo $symbols[$type] . " " . $message . "\n";
}

// Função para verificar requisitos
function checkRequirements() {
    $requirements = [];
    
    // PHP Version
    $requirements['PHP 8.2+'] = version_compare(PHP_VERSION, '8.2.0', '>=');
    
    // Extensões necessárias
    $extensions = ['pdo', 'pdo_mysql', 'mbstring', 'openssl', 'curl', 'gd', 'zip', 'json'];
    foreach ($extensions as $ext) {
        $requirements["Extensão $ext"] = extension_loaded($ext);
    }
    
    // Diretórios com permissão de escrita
    $directories = ['uploads', 'backups', 'logs', 'temp'];
    foreach ($directories as $dir) {
        $path = __DIR__ . '/' . $dir;
        if (!file_exists($path)) {
            @mkdir($path, 0777, true);
        }
        $requirements["Diretório $dir"] = is_writable($path);
    }
    
    return $requirements;
}

// Função para criar arquivo .env
function createEnvFile() {
    $envExample = __DIR__ . '/.env.example';
    $envFile = __DIR__ . '/.env';
    
    if (!file_exists($envFile)) {
        $envContent = <<<ENV
# Configurações do Banco de Dados
DB_HOST=localhost
DB_NAME=construtorakelle_sistema
DB_USER=construtorakelle_sistema
DB_PASS=cpsess2205955420

# Configurações de E-mail
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=
SMTP_PASS=

# Configurações do Banco Inter
BANCO_INTER_API_KEY=
BANCO_INTER_CLIENT_ID=

# Configurações do WhatsApp
WHATSAPP_API_URL=
WHATSAPP_TOKEN=

# Configurações Gerais
APP_ENV=production
APP_DEBUG=false
APP_URL=http://www.construtorakellesduarte.com.br/sistema
ENV;
        
        file_put_contents($envFile, $envContent);
        return true;
    }
    return false;
}

// Função para testar conexão com banco
function testDatabaseConnection() {
    require_once __DIR__ . '/config/config.php';
    
    try {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $pdo = new PDO($dsn, DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return true;
    } catch (PDOException $e) {
        return false;
    }
}

// Função para criar tabelas
function createDatabaseTables() {
    require_once __DIR__ . '/config/config.php';
    
    $sqlFile = __DIR__ . '/database/schema.sql';
    
    if (!file_exists($sqlFile)) {
        return false;
    }
    
    try {
        $dsn = "mysql:host=" . DB_HOST . ";charset=" . DB_CHARSET;
        $pdo = new PDO($dsn, DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // Cria o banco se não existir
        $pdo->exec("CREATE DATABASE IF NOT EXISTS " . DB_NAME . " CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->exec("USE " . DB_NAME);
        
        // Lê e executa o arquivo SQL
        $sql = file_get_contents($sqlFile);
        
        // Remove comentários e divide em comandos
        $sql = preg_replace('/--.*$/m', '', $sql);
        $commands = array_filter(array_map('trim', explode(';', $sql)));
        
        foreach ($commands as $command) {
            if (!empty($command)) {
                $pdo->exec($command);
            }
        }
        
        return true;
    } catch (PDOException $e) {
        showMessage("Erro SQL: " . $e->getMessage(), 'error');
        return false;
    }
}

// Função para criar usuário administrador
function createAdminUser() {
    require_once __DIR__ . '/config/config.php';
    require_once __DIR__ . '/app/core/Database.php';
    
    $db = Database::getInstance();
    
    // Verifica se já existe um admin
    $count = $db->count('usuarios', 'nivel_acesso_id = 1');
    
    if ($count == 0) {
        // Cria o admin padrão
        $adminData = [
            'nome_completo' => 'Administrador',
            'email' => 'admin@construtorakellesduarte.com.br',
            'senha' => password_hash('Admin@2024', PASSWORD_DEFAULT),
            'cpf' => '00000000000',
            'nivel_acesso_id' => 1,
            'ativo' => 1
        ];
        
        return $db->insert('usuarios', $adminData);
    }
    
    return true;
}

// Função para configurar permissões
function setupPermissions() {
    require_once __DIR__ . '/config/config.php';
    require_once __DIR__ . '/app/core/Database.php';
    
    $db = Database::getInstance();
    
    $modulos = [
        'dashboard', 'usuarios', 'imoveis', 'empreendimentos', 
        'faturas', 'contas_pagar', 'fornecedores', 'funcionarios',
        'epis', 'faltas', 'ocorrencias', 'compras', 'relatorios',
        'backup', 'logs', 'financeiro', 'obras'
    ];
    
    $niveis = [
        1 => ['visualizar' => true, 'criar' => true, 'editar' => true, 'deletar' => true], // Admin
        2 => ['visualizar' => true, 'criar' => false, 'editar' => false, 'deletar' => false], // Cliente
        3 => ['visualizar' => true, 'criar' => false, 'editar' => true, 'deletar' => false], // Funcionário
        4 => ['visualizar' => true, 'criar' => true, 'editar' => true, 'deletar' => false], // Financeiro
        5 => ['visualizar' => true, 'criar' => true, 'editar' => true, 'deletar' => false], // Encarregado
    ];
    
    foreach ($niveis as $nivel_id => $perms) {
        foreach ($modulos as $modulo) {
            // Verifica se já existe
            $exists = $db->count('permissoes', 'nivel_acesso_id = :nivel AND modulo = :modulo', 
                ['nivel' => $nivel_id, 'modulo' => $modulo]);
            
            if ($exists == 0) {
                $data = [
                    'nivel_acesso_id' => $nivel_id,
                    'modulo' => $modulo,
                    'visualizar' => $perms['visualizar'] ? 1 : 0,
                    'criar' => $perms['criar'] ? 1 : 0,
                    'editar' => $perms['editar'] ? 1 : 0,
                    'deletar' => $perms['deletar'] ? 1 : 0
                ];
                
                $db->insert('permissoes', $data);
            }
        }
    }
    
    return true;
}

// EXECUÇÃO DA INSTALAÇÃO
echo "Iniciando instalação...\n\n";

// 1. Verificar requisitos
echo "ETAPA 1: Verificando requisitos do sistema\n";
echo "----------------------------------------\n";
$requirements = checkRequirements();
$allOk = true;

foreach ($requirements as $req => $status) {
    if ($status) {
        showMessage("$req: OK", 'success');
    } else {
        showMessage("$req: FALHOU", 'error');
        $allOk = false;
    }
}

if (!$allOk) {
    echo "\n";
    showMessage("Alguns requisitos não foram atendidos. Corrija-os antes de continuar.", 'error');
    exit(1);
}

echo "\n";

// 2. Criar arquivo .env
echo "ETAPA 2: Configurando ambiente\n";
echo "----------------------------------------\n";
if (createEnvFile()) {
    showMessage("Arquivo .env criado com sucesso", 'success');
    showMessage("IMPORTANTE: Edite o arquivo .env com suas configurações", 'warning');
} else {
    showMessage("Arquivo .env já existe", 'info');
}

echo "\n";

// 3. Testar conexão com banco
echo "ETAPA 3: Testando conexão com banco de dados\n";
echo "----------------------------------------\n";
if (testDatabaseConnection()) {
    showMessage("Conexão com banco de dados OK", 'success');
} else {
    showMessage("Falha na conexão com banco de dados", 'error');
    showMessage("Verifique as configurações em config/config.php", 'warning');
    exit(1);
}

echo "\n";

// 4. Criar tabelas
echo "ETAPA 4: Criando estrutura do banco de dados\n";
echo "----------------------------------------\n";
if (createDatabaseTables()) {
    showMessage("Tabelas criadas com sucesso", 'success');
} else {
    showMessage("Erro ao criar tabelas", 'error');
    exit(1);
}

echo "\n";

// 5. Criar usuário admin
echo "ETAPA 5: Criando usuário administrador\n";
echo "----------------------------------------\n";
if (createAdminUser()) {
    showMessage("Usuário administrador criado", 'success');
    showMessage("E-mail: admin@construtorakellesduarte.com.br", 'info');
    showMessage("Senha: Admin@2024", 'info');
    showMessage("IMPORTANTE: Altere a senha no primeiro acesso!", 'warning');
} else {
    showMessage("Erro ao criar usuário administrador", 'error');
}

echo "\n";

// 6. Configurar permissões
echo "ETAPA 6: Configurando permissões\n";
echo "----------------------------------------\n";
if (setupPermissions()) {
    showMessage("Permissões configuradas com sucesso", 'success');
} else {
    showMessage("Erro ao configurar permissões", 'error');
}

echo "\n";

// 7. Instruções finais
echo "=====================================\n";
echo "  INSTALAÇÃO CONCLUÍDA!\n";
echo "=====================================\n\n";

echo "PRÓXIMOS PASSOS:\n";
echo "----------------\n";
echo "1. Configure o arquivo config/config.php com suas credenciais\n";
echo "2. Configure o cron para tarefas agendadas (veja scripts/cron_jobs.sh)\n";
echo "3. Configure o servidor web (Apache/Nginx)\n";
echo "4. Teste o sistema acessando: http://seu-dominio/sistema\n";
echo "5. Faça login com as credenciais fornecidas\n";
echo "6. ALTERE A SENHA DO ADMINISTRADOR!\n";

echo "\n";
showMessage("Por segurança, remova este arquivo após a instalação!", 'warning');
echo "\n";

if (!$isCLI) {
    echo "</pre>";
}

// Criar arquivo de flag indicando que a instalação foi concluída
file_put_contents(__DIR__ . '/.installed', date('Y-m-d H:i:s'));
