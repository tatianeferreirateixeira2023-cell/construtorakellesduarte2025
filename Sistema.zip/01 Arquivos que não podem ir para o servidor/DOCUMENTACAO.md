# 📚 Documentação Completa - Sistema de Gerenciamento Construtora Kelles Duarte

## 📋 Índice
1. [Visão Geral](#visão-geral)
2. [Arquitetura do Sistema](#arquitetura-do-sistema)
3. [Módulos Implementados](#módulos-implementados)
4. [Estrutura de Arquivos](#estrutura-de-arquivos)
5. [Banco de Dados](#banco-de-dados)
6. [Configuração e Instalação](#configuração-e-instalação)
7. [Segurança](#segurança)
8. [APIs e Integrações](#apis-e-integrações)
9. [Manutenção](#manutenção)
10. [Próximos Passos](#próximos-passos)

## 🎯 Visão Geral

Sistema completo de gerenciamento empresarial desenvolvido especificamente para a Construtora Kelles Duarte, com foco em:
- Gestão imobiliária e de empreendimentos
- Controle financeiro completo
- Gerenciamento de recursos humanos
- Controle de obras e manutenção
- Sistema de backup automático

### Tecnologias Utilizadas
- **Backend**: PHP 8.2
- **Banco de Dados**: MySQL 5.7+
- **Frontend**: AdminLTE 3.2 + Bootstrap 4
- **JavaScript**: jQuery, Chart.js, DataTables
- **Bibliotecas PHP**: PHPMailer, mPDF, Bacon QR Code

## 🏗️ Arquitetura do Sistema

### Padrão MVC
```
/sistema
├── /app
│   ├── /controllers    # Lógica de negócio
│   ├── /core           # Classes base do sistema
│   └── /models         # Modelos de dados
├── /views
│   ├── /layouts        # Templates base
│   └── /[módulos]      # Views específicas
├── /config             # Configurações
├── /database           # Scripts SQL
└── /public             # Arquivos públicos
```

### Classes Principais

#### Database.php
- Singleton para conexão com banco
- Prepared statements automáticos
- Métodos CRUD simplificados
- Log de erros

#### Controller.php
- Classe base para todos os controllers
- Validação de dados
- Controle de permissões
- Helpers para formatação

#### Router.php
- Roteamento de URLs
- Suporte a parâmetros dinâmicos
- Tratamento de erros 404

## 📦 Módulos Implementados

### ✅ Módulos Completos

#### 1. **Autenticação e Segurança**
- Login com proteção contra força bruta
- Recuperação de senha por e-mail
- Controle de sessão
- Logs de acesso detalhados
- 5 níveis de acesso distintos

#### 2. **Gerenciamento de Usuários**
- CRUD completo de usuários
- Dados pessoais e do cônjuge
- Perfis diferenciados por nível
- Histórico de atividades

#### 3. **Gestão Imobiliária**
- Cadastro completo de imóveis
- Controle de vendas e financiamentos
- Geração automática de faturas
- Upload de documentos e plantas
- Cálculo de parcelas

#### 4. **Gestão de Empreendimentos**
- Cadastro com CNO e documentação técnica
- Controle de responsáveis técnicos
- Upload de plantas e projetos
- Relatórios por empreendimento

#### 5. **Sistema Financeiro**
- **Faturas**:
  - Geração automática mensal
  - Boletos bancários
  - PIX com QR Code
  - Controle de vencimentos
  
- **Contas a Pagar**:
  - Cadastro de despesas
  - Controle por fornecedor
  - Relatórios financeiros

#### 6. **Sistema de Backup**
- Backup automático diário (BD)
- Backup semanal (BD + Arquivos)
- Backup mensal (Sistema completo)
- Limpeza automática de backups antigos

### 🚧 Módulos Pendentes

#### 7. **Recursos Humanos**
- Cadastro de funcionários
- Controle de EPIs
- Gestão de faltas e férias
- Adiantamentos salariais

#### 8. **Gestão de Obras**
- Ocorrências de manutenção
- Controle por encarregado
- Sistema de compras

#### 9. **Notificações**
- Integração WhatsApp
- Envio de e-mails automáticos
- Lembretes de vencimento

## 🗄️ Banco de Dados

### Tabelas Principais
```sql
- usuarios (22 campos)
- niveis_acesso (4 campos)
- permissoes (7 campos)
- logs_acesso (7 campos)
- empreendimentos (14 campos)
- imoveis (15 campos)
- faturas (13 campos)
- contas_pagar (11 campos)
- fornecedores (10 campos)
- funcionarios (18 campos)
- arquivos (9 campos)
- backups (6 campos)
```

### Índices Otimizados
- Índices em campos de busca frequente
- Chaves estrangeiras com CASCADE
- Campos de data para relatórios

## ⚙️ Configuração e Instalação

### Requisitos
- PHP 8.2+
- MySQL 5.7+
- Apache com mod_rewrite
- Composer

### Instalação Passo a Passo

1. **Clone o projeto**
```bash
cd /var/www/
git clone [repositório] sistema
```

2. **Configure o banco de dados**
```bash
mysql -u root -p
CREATE DATABASE construtorakelle_sistema;
mysql -u root -p construtorakelle_sistema < database/schema.sql
```

3. **Configure o sistema**
```php
// Edite config/config.php
define('DB_PASS', 'sua_senha');
define('SMTP_USER', 'seu_email@gmail.com');
define('SMTP_PASS', 'sua_senha_app');
```

4. **Instale dependências**
```bash
composer install
```

5. **Configure permissões**
```bash
chmod 755 uploads/
chmod 755 backups/
chmod 755 logs/
```

6. **Configure o cron para backup**
```bash
# Adicione ao crontab
0 2 * * * php /var/www/sistema/scripts/backup.php
```

## 🔒 Segurança

### Implementações de Segurança
- ✅ Senhas com hash bcrypt
- ✅ Prepared Statements (SQL Injection)
- ✅ Proteção XSS
- ✅ Proteção CSRF (a implementar)
- ✅ Limite de tentativas de login
- ✅ Timeout de sessão
- ✅ Logs de todas as ações
- ✅ Validação server-side

### Headers de Segurança (.htaccess)
```apache
Header set X-Content-Type-Options "nosniff"
Header set X-Frame-Options "SAMEORIGIN"
Header set X-XSS-Protection "1; mode=block"
```

## 🔌 APIs e Integrações

### Integrações Planejadas
1. **Banco Inter** - Geração de boletos
2. **WhatsApp Business** - Notificações
3. **SMTP Gmail** - Envio de e-mails
4. **ViaCEP** - Consulta de endereços

### Endpoints da API Interna
```
GET  /api/notifications     - Notificações do usuário
GET  /api/pix/qrcode/{id}  - Gera QR Code PIX
GET  /api/aniversarios/hoje - Aniversários do dia
POST /api/backup/manual     - Executa backup manual
```

## 🛠️ Manutenção

### Scripts de Manutenção
```bash
# Backup manual
php scripts/backup.php

# Limpeza de logs (criar)
php scripts/clean_logs.php

# Atualização de faturas vencidas
php scripts/update_faturas.php
```

### Monitoramento
- Verificar logs diariamente: `/logs/`
- Monitorar espaço em disco (backups)
- Verificar integridade do banco
- Testar restauração de backup mensalmente

## 📈 Próximos Passos

### Alta Prioridade
1. **Completar módulo de RH**
   - Controller de Funcionários
   - Gestão de EPIs
   - Controle de faltas

2. **Implementar notificações**
   - Integração WhatsApp API
   - Templates de e-mail
   - Sistema de filas

3. **Módulo de Obras**
   - Ocorrências de manutenção
   - Sistema de compras
   - Controle de materiais

### Média Prioridade
4. **Melhorias no Financeiro**
   - Integração bancária real
   - Conciliação automática
   - DRE automático

5. **Dashboard Analytics**
   - Gráficos avançados
   - KPIs personalizados
   - Exportação de relatórios

### Baixa Prioridade
6. **App Mobile**
   - PWA para clientes
   - App nativo para gestores

7. **Integrações Adicionais**
   - Contabilidade
   - Google Calendar
   - Assinatura digital

## 📞 Suporte e Contato

**Desenvolvedor**: [Seu Nome]
**E-mail**: suporte@construtorakellesduarte.com.br
**Documentação Online**: /docs/

## 📄 Licença

Sistema proprietário da Construtora Kelles Duarte.
Todos os direitos reservados.

---

**Última atualização**: <?= date('d/m/Y H:i') ?>
**Versão**: 1.0.0
