<?php
/**
 * Script para corrigir automaticamente URLs hardcoded
 */

echo "<h1>Correção Automática de URLs</h1>";
echo "<hr>";

// Lista de arquivos para verificar e corrigir
$files_to_fix = [
    'views/layouts/header.php',
    'views/layouts/footer.php',
    'views/auth/login.php',
    'views/auth/forgot-password.php',
    'views/auth/reset-password.php',
    'views/dashboard/index.php',
    'views/usuarios/index.php',
    'views/usuarios/form.php',
];

// Padrões para substituir
$replacements = [
    // Links href hardcoded
    'href="/"' => 'href="<?= BASE_PATH ?>/"',
    'href="/login"' => 'href="<?= BASE_PATH ?>/login"',
    'href="/logout"' => 'href="<?= BASE_PATH ?>/logout"',
    'href="/usuarios"' => 'href="<?= BASE_PATH ?>/usuarios"',
    'href="/imoveis"' => 'href="<?= BASE_PATH ?>/imoveis"',
    'href="/empreendimentos"' => 'href="<?= BASE_PATH ?>/empreendimentos"',
    'href="/financeiro"' => 'href="<?= BASE_PATH ?>/financeiro"',
    'href="/obras"' => 'href="<?= BASE_PATH ?>/obras"',
    'href="/fornecedores"' => 'href="<?= BASE_PATH ?>/fornecedores"',
    'href="/funcionarios"' => 'href="<?= BASE_PATH ?>/funcionarios"',
    'href="/compras"' => 'href="<?= BASE_PATH ?>/compras"',
    'href="/perfil"' => 'href="<?= BASE_PATH ?>/perfil"',
    'href="/notificacoes"' => 'href="<?= BASE_PATH ?>/notificacoes"',
    'href="/relatorios"' => 'href="<?= BASE_PATH ?>/relatorios"',
    'href="/backup"' => 'href="<?= BASE_PATH ?>/backup"',
    'href="/logs"' => 'href="<?= BASE_PATH ?>/logs"',
    'href="/faturas"' => 'href="<?= BASE_PATH ?>/faturas"',
    'href="/contas-pagar"' => 'href="<?= BASE_PATH ?>/contas-pagar"',
    'href="/epis"' => 'href="<?= BASE_PATH ?>/epis"',
    'href="/faltas"' => 'href="<?= BASE_PATH ?>/faltas"',
    'href="/ocorrencias"' => 'href="<?= BASE_PATH ?>/ocorrencias"',
    'href="/manutencoes"' => 'href="<?= BASE_PATH ?>/manutencoes"',
    'href="/minhas-faturas"' => 'href="<?= BASE_PATH ?>/minhas-faturas"',
    'href="/meus-documentos"' => 'href="<?= BASE_PATH ?>/meus-documentos"',
    'href="/esqueci-senha"' => 'href="<?= BASE_PATH ?>/esqueci-senha"',
    
    // Imagens src hardcoded
    'src="/assets/img/' => 'src="<?= BASE_URL ?>assets/img/',
    
    // Actions de formulários
    'action="/login"' => 'action="<?= BASE_PATH ?>/login"',
    'action="/esqueci-senha"' => 'action="<?= BASE_PATH ?>/esqueci-senha"',
    'action="/reset-senha"' => 'action="<?= BASE_PATH ?>/reset-senha"',
    
    // URLs em JavaScript
    "url: '/api/" => "url: BASE_PATH + '/api/",
    "location.href = '/" => "location.href = BASE_PATH + '/",
    "window.location = '/" => "window.location = BASE_PATH + '/",
];

$total_fixed = 0;

foreach ($files_to_fix as $file) {
    if (file_exists($file)) {
        echo "<h3>Processando: $file</h3>";
        
        $content = file_get_contents($file);
        $original_content = $content;
        $fixes = 0;
        
        foreach ($replacements as $search => $replace) {
            // Evita substituir se já foi corrigido
            if (strpos($content, $replace) === false && strpos($content, $search) !== false) {
                $count = 0;
                $content = str_replace($search, $replace, $content, $count);
                if ($count > 0) {
                    echo "- Substituído: <code>$search</code> → <code>" . htmlspecialchars($replace) . "</code> ($count ocorrências)<br>";
                    $fixes += $count;
                }
            }
        }
        
        if ($fixes > 0) {
            // Salva o arquivo corrigido
            file_put_contents($file, $content);
            echo "<strong style='color: green;'>✅ $fixes correções aplicadas!</strong><br>";
            $total_fixed += $fixes;
        } else {
            echo "<em style='color: gray;'>Nenhuma correção necessária.</em><br>";
        }
        
        echo "<br>";
    } else {
        echo "<h3 style='color: red;'>❌ Arquivo não encontrado: $file</h3><br>";
    }
}

echo "<hr>";
echo "<h2>Resumo</h2>";
echo "<p><strong>Total de correções aplicadas: $total_fixed</strong></p>";

if ($total_fixed > 0) {
    echo "<div style='background: #d4edda; color: #155724; padding: 15px; border-radius: 5px;'>";
    echo "<strong>✅ SUCESSO!</strong><br>";
    echo "As URLs foram corrigidas automaticamente. O sistema agora deve funcionar corretamente com o prefixo /sistema/";
    echo "</div>";
} else {
    echo "<div style='background: #cce5ff; color: #004085; padding: 15px; border-radius: 5px;'>";
    echo "<strong>ℹ️ INFORMAÇÃO</strong><br>";
    echo "Todas as URLs já estão corretas ou os arquivos não foram encontrados.";
    echo "</div>";
}

echo "<br>";
echo "<h3>Próximos Passos:</h3>";
echo "<ol>";
echo "<li>Teste o sistema acessando: <a href='https://construtorakellesduarte.com.br/sistema/' target='_blank'>https://construtorakellesduarte.com.br/sistema/</a></li>";
echo "<li>Verifique se todos os links estão funcionando</li>";
echo "<li>Se houver algum link quebrado, informe para correção manual</li>";
echo "</ol>";

echo "<hr>";
echo "<p>";
echo "<a href='fix_all_urls.php'>Ver Status das URLs</a> | ";
echo "<a href='https://construtorakellesduarte.com.br/sistema/'>Ir para o Sistema</a>";
echo "</p>";
