<?php
require_once 'config/config.php';
require_once 'app/core/Database.php';

try {
    $db = Database::getInstance();
    
    echo "Criando tabela de logs de acesso...\n";
    
    // SQL para criar a tabela
    $sql = "CREATE TABLE IF NOT EXISTS `logs_acesso` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `usuario_id` int(11) DEFAULT NULL,
        `ip_address` varchar(45) DEFAULT NULL,
        `user_agent` text DEFAULT NULL,
        `pagina` varchar(255) DEFAULT NULL,
        `acao` varchar(100) DEFAULT NULL,
        `descricao` text DEFAULT NULL,
        `metodo` varchar(10) DEFAULT NULL,
        `dados` text DEFAULT NULL,
        `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `idx_usuario_id` (`usuario_id`),
        KEY `idx_acao` (`acao`),
        KEY `idx_created_at` (`created_at`),
        KEY `idx_pagina` (`pagina`),
        KEY `idx_usuario_acao` (`usuario_id`, `acao`),
        CONSTRAINT `fk_logs_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    $db->execute($sql);
    echo "Tabela de logs criada com sucesso!\n";
    
    // Inserir log inicial
    echo "Inserindo logs iniciais...\n";
    
    // Log de instalação
    $data = [
        'usuario_id' => null,
        'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
        'pagina' => '/install',
        'acao' => 'instalacao',
        'descricao' => 'Sistema de logs instalado com sucesso',
        'created_at' => date('Y-m-d H:i:s')
    ];
    
    $db->insert('logs_acesso', $data);
    
    // Busca usuários para criar logs de exemplo
    $usuarios = $db->fetchAll("SELECT id, nome_completo FROM usuarios LIMIT 5");
    
    foreach ($usuarios as $usuario) {
        // Verifica se já existe log para este usuário
        $existe = $db->fetchOne(
            "SELECT id FROM logs_acesso WHERE usuario_id = :usuario_id LIMIT 1",
            ['usuario_id' => $usuario['id']]
        );
        
        if (!$existe) {
            $data = [
                'usuario_id' => $usuario['id'],
                'ip_address' => '127.0.0.1',
                'pagina' => '/dashboard',
                'acao' => 'acesso',
                'descricao' => "Usuário {$usuario['nome_completo']} acessou o dashboard",
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            $db->insert('logs_acesso', $data);
        }
    }
    
    // Conta total de logs
    $total = $db->count('logs_acesso');
    
    echo "\n✅ Instalação do sistema de logs concluída com sucesso!\n";
    echo "Total de logs no sistema: $total\n";
    echo "Acesse /sistema/logs para visualizar os logs (apenas administradores).\n";
    
} catch (Exception $e) {
    echo "❌ Erro ao instalar sistema de logs: " . $e->getMessage() . "\n";
    exit(1);
}
?>
