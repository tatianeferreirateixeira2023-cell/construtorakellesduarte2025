<?php
/**
 * Script para verificar e corrigir todas as URLs do sistema
 */

require_once 'config/config.php';

echo "<h1>Verificação de URLs do Sistema</h1>";
echo "<hr>";

echo "<h2>1. Configurações Atuais</h2>";
echo "BASE_URL: " . BASE_URL . "<br>";
echo "BASE_PATH: " . BASE_PATH . "<br>";
echo "<br>";

echo "<h2>2. Teste de URLs</h2>";

// URLs que devem funcionar
$urls_teste = [
    'Página Inicial' => BASE_PATH . '/',
    'Login' => BASE_PATH . '/login',
    'Usuários' => BASE_PATH . '/usuarios',
    'Imóveis' => BASE_PATH . '/imoveis',
    'Empreendimentos' => BASE_PATH . '/empreendimentos',
    'Financeiro' => BASE_PATH . '/financeiro',
    'Obras' => BASE_PATH . '/obras',
    'Fornecedores' => BASE_PATH . '/fornecedores',
    'Funcionários' => BASE_PATH . '/funcionarios',
    'Compras' => BASE_PATH . '/compras',
];

echo "<table border='1' cellpadding='10' style='border-collapse: collapse;'>";
echo "<tr><th>Página</th><th>URL Gerada</th><th>URL Completa</th></tr>";

foreach ($urls_teste as $nome => $url) {
    $url_completa = 'https://construtorakellesduarte.com.br' . $url;
    echo "<tr>";
    echo "<td>$nome</td>";
    echo "<td><code>$url</code></td>";
    echo "<td><a href='$url' target='_blank'>$url_completa</a></td>";
    echo "</tr>";
}

echo "</table>";
echo "<br>";

echo "<h2>3. Teste de Assets</h2>";

$assets_teste = [
    'CSS Customizado' => BASE_URL . 'assets/css/custom.css',
    'JS Customizado' => BASE_URL . 'assets/js/custom.js',
    'Logo' => BASE_URL . 'assets/img/logo.png',
    'User Default' => BASE_URL . 'assets/img/user-default.png',
];

echo "<table border='1' cellpadding='10' style='border-collapse: collapse;'>";
echo "<tr><th>Asset</th><th>URL</th><th>Status</th></tr>";

foreach ($assets_teste as $nome => $url) {
    $file_path = str_replace(BASE_URL, '', $url);
    $exists = file_exists($file_path);
    
    echo "<tr>";
    echo "<td>$nome</td>";
    echo "<td><code>$url</code></td>";
    echo "<td>" . ($exists ? '✅ Existe' : '❌ Não encontrado') . "</td>";
    echo "</tr>";
}

echo "</table>";
echo "<br>";

echo "<h2>4. Funções Helper Disponíveis</h2>";

if (file_exists('app/helpers/url_helper.php')) {
    require_once 'app/autoload.php';
    
    echo "✅ Helpers carregados com sucesso!<br><br>";
    
    echo "<strong>Exemplos de uso:</strong><br>";
    echo "<code>base_path('usuarios')</code> = " . base_path('usuarios') . "<br>";
    echo "<code>url('usuarios')</code> = " . url('usuarios') . "<br>";
    echo "<code>base_url('assets/css/custom.css')</code> = " . base_url('assets/css/custom.css') . "<br>";
    echo "<code>img_url('logo.png')</code> = " . img_url('logo.png') . "<br>";
    echo "<code>css_url('custom.css')</code> = " . css_url('custom.css') . "<br>";
    echo "<code>js_url('custom.js')</code> = " . js_url('custom.js') . "<br>";
} else {
    echo "❌ Helpers não encontrados!<br>";
}

echo "<br>";

echo "<h2>5. Recomendações</h2>";
echo "<ul>";
echo "<li>Use sempre <code>base_path()</code> ou <code>url()</code> para links internos</li>";
echo "<li>Use <code>img_url()</code> para imagens</li>";
echo "<li>Use <code>css_url()</code> para CSS</li>";
echo "<li>Use <code>js_url()</code> para JavaScript</li>";
echo "<li>Nunca use URLs hardcoded como '/usuarios' - sempre use helpers</li>";
echo "</ul>";

echo "<hr>";
echo "<h2>6. Código para Copiar/Colar</h2>";
echo "<pre style='background: #f4f4f4; padding: 10px; border-radius: 5px;'>";
echo htmlspecialchars('<!-- Em PHP/HTML -->
<a href="<?= url(\'usuarios\') ?>">Usuários</a>
<img src="<?= img_url(\'logo.png\') ?>">
<link rel="stylesheet" href="<?= css_url(\'custom.css\') ?>">
<script src="<?= js_url(\'custom.js\') ?>"></script>

// Em JavaScript
const url = BASE_PATH + \'/api/usuarios\';
window.location.href = BASE_PATH + \'/login\';');
echo "</pre>";

echo "<hr>";
echo "<p><a href='" . BASE_PATH . "/'>Voltar ao Sistema</a></p>";
