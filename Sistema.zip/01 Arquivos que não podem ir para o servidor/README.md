# Sistema de Gerenciamento - Construtora Kelles Duarte

Sistema completo de gerenciamento empresarial desenvolvido para a Construtora Kelles Duarte, com módulos integrados para controle de imóveis, empreendimentos, financeiro, recursos humanos e obras.

## 🏗️ Características Principais

- **Controle de Acesso Multi-nível**: 5 níveis de acesso (Administrador, Cliente, Funcionário, Financeiro, Encarregado)
- **Gestão Imobiliária Completa**: Cadastro e controle de imóveis, vendas e documentação
- **Gestão de Empreendimentos**: Controle de obras com CNO, ARTs e documentação técnica
- **Sistema Financeiro Integrado**: Faturas, boletos, PIX, contas a pagar e receber
- **Recursos Humanos**: Controle de funcionários, EPIs, faltas, férias e adiantamentos
- **Gestão de Obras**: Ocorrências de manutenção e controle de encarregados
- **Sistema de Compras**: Requisições, aprovações e controle de fornecedores
- **Backup Automático**: Sistema de backup diário, semanal e mensal
- **Notificações**: Lembretes automáticos via WhatsApp e E-mail

## 📋 Requisitos do Sistema

- PHP 8.2 ou superior
- MySQL 5.7 ou superior
- Apache com mod_rewrite habilitado
- Composer para gerenciamento de dependências
- Extensões PHP necessárias:
  - PDO e PDO_MySQL
  - mbstring
  - openssl
  - curl
  - gd ou imagick
  - zip

## 🚀 Instalação

### 1. Clone ou baixe o projeto

```bash
# Se usando Git
git clone https://github.com/construtorakelles/sistema.git

# Ou baixe e extraia o arquivo ZIP
```

### 2. Instale as dependências

```bash
cd sistema
composer install
```

### 3. Configure o banco de dados

1. Crie o banco de dados MySQL:
```sql
CREATE DATABASE construtorakelle_sistema CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'construtorakelle_sistema'@'localhost' IDENTIFIED BY 'sua_senha_aqui';
GRANT ALL PRIVILEGES ON construtorakelle_sistema.* TO 'construtorakelle_sistema'@'localhost';
FLUSH PRIVILEGES;
```

2. Importe o schema do banco:
```bash
mysql -u construtorakelle_sistema -p construtorakelle_sistema < database/schema.sql
```

### 4. Configure o sistema

1. Edite o arquivo `config/config.php` com suas configurações:

```php
// Configurações do Banco de Dados
define('DB_HOST', 'localhost');
define('DB_NAME', 'construtorakelle_sistema');
define('DB_USER', 'construtorakelle_sistema');
define('DB_PASS', 'sua_senha_aqui');

// Configurações de E-mail
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_USER', 'seu_email@gmail.com');
define('SMTP_PASS', 'sua_senha_app');

// Configurações do Banco Inter (para boletos)
define('BANCO_INTER_API_KEY', 'sua_api_key');
define('BANCO_INTER_CLIENT_ID', 'seu_client_id');

// Configurações do WhatsApp
define('WHATSAPP_API_URL', 'url_da_api');
define('WHATSAPP_TOKEN', 'seu_token');
```

### 5. Configure as permissões de diretórios

```bash
chmod 755 uploads/
chmod 755 backups/
chmod 755 logs/
```

### 6. Configure o Apache

Certifique-se de que o mod_rewrite está habilitado:

```bash
sudo a2enmod rewrite
sudo service apache2 restart
```

Configure o VirtualHost (opcional):

```apache
<VirtualHost *:80>
    ServerName www.construtorakellesduarte.com.br
    DocumentRoot /var/www/sistema
    
    <Directory /var/www/sistema>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    
    ErrorLog ${APACHE_LOG_DIR}/construtora_error.log
    CustomLog ${APACHE_LOG_DIR}/construtora_access.log combined
</VirtualHost>
```

## 🔐 Primeiro Acesso

- **URL**: http://www.construtorakellesduarte.com.br/sistema/
- **E-mail**: admin@construtorakellesduarte.com.br
- **Senha**: password

⚠️ **IMPORTANTE**: Altere a senha padrão no primeiro acesso!

## 📱 Módulos do Sistema

### 1. Controle de Usuários
- Cadastro completo com dados pessoais e do cônjuge
- Gerenciamento de permissões por nível
- Histórico de acessos e atividades

### 2. Gestão Imobiliária
- Cadastro de imóveis com todas as características
- Controle de vendas e financiamentos
- Gestão de documentos e plantas

### 3. Gestão de Empreendimentos
- Cadastro com CNO e documentação técnica
- Controle de engenheiros e arquitetos
- Acompanhamento de obras

### 4. Sistema Financeiro
- Geração automática de faturas
- Integração com Banco Inter para boletos
- PIX com QR Code
- Relatórios financeiros completos

### 5. Recursos Humanos
- Cadastro completo de funcionários
- Controle de EPIs
- Gestão de faltas e férias
- Sistema de adiantamentos salariais

### 6. Gestão de Obras
- Registro de ocorrências de manutenção
- Controle por encarregado
- Acompanhamento de status

### 7. Sistema de Compras
- Requisições de compra
- Aprovações por nível
- Controle de fornecedores
- Acompanhamento de entregas

## 🔧 Manutenção

### Backup Manual

```bash
php scripts/backup.php
```

### Limpeza de Logs

```bash
php scripts/clean_logs.php
```

### Atualização de Tabelas de Preços

```bash
php scripts/update_prices.php
```

## 📊 Relatórios Disponíveis

- Relatório de Vendas
- Fluxo de Caixa
- Contas a Pagar/Receber
- Relatório de Obras
- Relatório de Funcionários
- Análise de Inadimplência
- Relatório de Comissões

## 🛡️ Segurança

O sistema implementa várias camadas de segurança:

- Senhas criptografadas com bcrypt
- Proteção contra SQL Injection (Prepared Statements)
- Proteção contra XSS
- Proteção contra CSRF
- Limite de tentativas de login
- Logs detalhados de atividades
- Backup automático de dados

## 📞 Suporte

Para suporte técnico, entre em contato:

- **E-mail**: suporte@construtorakellesduarte.com.br
- **Telefone**: (31) XXXX-XXXX
- **WhatsApp**: (31) 9XXXX-XXXX

## 📄 Licença

Este sistema é propriedade exclusiva da Construtora Kelles Duarte. Todos os direitos reservados.

---

**Construtora Kelles Duarte**  
Itabira/MG - Brasil  
CNPJ: 11.030.523/0001-05  
www.construtorakellesduarte.com.br
