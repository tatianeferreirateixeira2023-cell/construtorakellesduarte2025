<?php
session_start();
require_once 'config/config.php';
require_once 'app/core/Database.php';

echo "=== Teste do Sistema de Logs ===\n\n";

try {
    $db = Database::getInstance();
    
    // Verifica se a tabela existe
    echo "1. Verificando se a tabela logs_acesso existe...\n";
    $sql = "SHOW TABLES LIKE 'logs_acesso'";
    $result = $db->fetchOne($sql);
    
    if ($result) {
        echo "✅ Tabela logs_acesso existe!\n\n";
        
        // Conta registros
        $count = $db->count('logs_acesso');
        echo "2. Total de registros na tabela: $count\n\n";
        
        // Busca últimos logs
        echo "3. Últimos 5 logs:\n";
        echo str_repeat("-", 80) . "\n";
        
        $logs = $db->fetchAll("SELECT l.*, u.nome_completo 
                               FROM logs_acesso l 
                               LEFT JOIN usuarios u ON l.usuario_id = u.id 
                               ORDER BY l.created_at DESC 
                               LIMIT 5");
        
        foreach ($logs as $log) {
            echo "ID: {$log['id']}\n";
            echo "Usuário: " . ($log['nome_completo'] ?? 'Sistema') . "\n";
            echo "Ação: {$log['acao']}\n";
            echo "Página: {$log['pagina']}\n";
            echo "Descrição: {$log['descricao']}\n";
            echo "Data: {$log['created_at']}\n";
            echo str_repeat("-", 40) . "\n";
        }
        
        // Testa inserção
        echo "\n4. Testando inserção de novo log...\n";
        $testData = [
            'usuario_id' => $_SESSION['user_id'] ?? null,
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
            'pagina' => '/test_logs',
            'acao' => 'teste',
            'descricao' => 'Teste do sistema de logs executado',
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        $inserted = $db->insert('logs_acesso', $testData);
        if ($inserted) {
            echo "✅ Log de teste inserido com sucesso! ID: $inserted\n";
        } else {
            echo "❌ Erro ao inserir log de teste\n";
        }
        
    } else {
        echo "❌ Tabela logs_acesso NÃO existe!\n";
        echo "Execute o script install_logs.php para criar a tabela.\n";
    }
    
    echo "\n5. Testando acesso à página de logs...\n";
    echo "URL: " . BASE_URL . "logs\n";
    
    // Verifica se o usuário é admin
    if (isset($_SESSION['user_id'])) {
        $user = $db->fetchOne("SELECT nivel_acesso_id FROM usuarios WHERE id = :id", 
                             ['id' => $_SESSION['user_id']]);
        if ($user && $user['nivel_acesso_id'] == NIVEL_ADMIN) {
            echo "✅ Você é administrador e pode acessar os logs\n";
        } else {
            echo "⚠️ Você não é administrador. Apenas admins podem ver logs.\n";
        }
    } else {
        echo "⚠️ Você não está logado. Faça login como admin para ver os logs.\n";
    }
    
} catch (Exception $e) {
    echo "❌ Erro: " . $e->getMessage() . "\n";
    echo "\nStack trace:\n" . $e->getTraceAsString() . "\n";
}

echo "\n=== Fim do Teste ===\n";
?>
