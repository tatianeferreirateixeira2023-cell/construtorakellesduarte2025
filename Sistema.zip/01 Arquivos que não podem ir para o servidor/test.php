<?php
/**
 * Arquivo de teste para verificar configuração
 */

// Mostra informações do ambiente
echo "<h1>Teste do Sistema - Construtora Kelles Duarte</h1>";
echo "<hr>";

// Verifica PHP
echo "<h2>1. Versão do PHP</h2>";
echo "Versão atual: " . PHP_VERSION . "<br>";
echo "Versão requerida: 8.2+<br>";
echo "Status: " . (version_compare(PHP_VERSION, '8.2.0', '>=') ? '✅ OK' : '❌ ERRO') . "<br>";

// Verifica extensões
echo "<h2>2. Extensões PHP</h2>";
$extensions = ['pdo', 'pdo_mysql', 'mbstring', 'openssl', 'curl', 'gd', 'zip', 'json'];
foreach ($extensions as $ext) {
    echo "$ext: " . (extension_loaded($ext) ? '✅ OK' : '❌ FALTANDO') . "<br>";
}

// Verifica arquivos importantes
echo "<h2>3. Arquivos do Sistema</h2>";
$files = [
    'config/config.php',
    'app/core/Database.php',
    'app/core/Controller.php',
    'app/core/Router.php',
    'index.php',
    '.htaccess'
];
foreach ($files as $file) {
    echo "$file: " . (file_exists($file) ? '✅ Existe' : '❌ Não encontrado') . "<br>";
}

// Verifica diretórios com permissão
echo "<h2>4. Diretórios com Permissão</h2>";
$dirs = ['uploads', 'backups', 'logs'];
foreach ($dirs as $dir) {
    if (!file_exists($dir)) {
        mkdir($dir, 0777, true);
    }
    echo "$dir: " . (is_writable($dir) ? '✅ Gravável' : '❌ Sem permissão') . "<br>";
}

// Testa conexão com banco
echo "<h2>5. Conexão com Banco de Dados</h2>";
if (file_exists('config/config.php')) {
    require_once 'config/config.php';
    
    try {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $pdo = new PDO($dsn, DB_USER, DB_PASS);
        echo "Conexão: ✅ OK<br>";
        
        // Verifica tabelas
        $stmt = $pdo->query("SHOW TABLES");
        $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
        echo "Tabelas encontradas: " . count($tables) . "<br>";
        
    } catch (PDOException $e) {
        echo "Conexão: ❌ ERRO<br>";
        echo "Mensagem: " . $e->getMessage() . "<br>";
    }
} else {
    echo "❌ Arquivo config.php não encontrado<br>";
}

// Informações do servidor
echo "<h2>6. Informações do Servidor</h2>";
echo "Sistema Operacional: " . PHP_OS . "<br>";
echo "Servidor Web: " . $_SERVER['SERVER_SOFTWARE'] . "<br>";
echo "Document Root: " . $_SERVER['DOCUMENT_ROOT'] . "<br>";
echo "Script Path: " . __DIR__ . "<br>";
echo "Request URI: " . $_SERVER['REQUEST_URI'] . "<br>";
echo "Base URL configurada: " . (defined('BASE_URL') ? BASE_URL : 'Não definida') . "<br>";
echo "Base Path configurado: " . (defined('BASE_PATH') ? BASE_PATH : 'Não definido') . "<br>";

// Links de teste
echo "<h2>7. Links de Teste</h2>";
echo "<a href='" . (defined('BASE_PATH') ? BASE_PATH : '/sistema') . "/'>Ir para Home</a><br>";
echo "<a href='" . (defined('BASE_PATH') ? BASE_PATH : '/sistema') . "/login'>Ir para Login</a><br>";

echo "<hr>";
echo "<p><strong>Se todos os itens estiverem ✅ OK, o sistema está pronto para uso!</strong></p>";
