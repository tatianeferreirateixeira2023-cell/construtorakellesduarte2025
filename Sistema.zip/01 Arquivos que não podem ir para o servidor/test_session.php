<?php
/**
 * Teste de Sessão PHP
 */

session_start();

echo "<h1>Teste de Sessão PHP</h1>";
echo "<hr>";

echo "<h2>1. Informações da Sessão</h2>";
echo "Session ID: " . session_id() . "<br>";
echo "Session Name: " . session_name() . "<br>";
echo "Session Save Path: " . session_save_path() . "<br>";
echo "Session Status: ";

$status = session_status();
switch($status) {
    case PHP_SESSION_DISABLED:
        echo "❌ DESABILITADA<br>";
        break;
    case PHP_SESSION_NONE:
        echo "⚠️ Nenhuma sessão ativa<br>";
        break;
    case PHP_SESSION_ACTIVE:
        echo "✅ ATIVA<br>";
        break;
}

echo "<h2>2. Teste de Escrita/Leitura</h2>";

// Tenta escrever na sessão
$_SESSION['teste'] = 'Valor de teste - ' . date('Y-m-d H:i:s');
$_SESSION['contador'] = ($_SESSION['contador'] ?? 0) + 1;

echo "Valor escrito: " . $_SESSION['teste'] . "<br>";
echo "Contador: " . $_SESSION['contador'] . "<br>";

echo "<h2>3. Conteúdo Completo da Sessão</h2>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

echo "<h2>4. Configurações PHP</h2>";
echo "session.save_handler: " . ini_get('session.save_handler') . "<br>";
echo "session.save_path: " . ini_get('session.save_path') . "<br>";
echo "session.gc_maxlifetime: " . ini_get('session.gc_maxlifetime') . " segundos<br>";
echo "session.cookie_lifetime: " . ini_get('session.cookie_lifetime') . " segundos<br>";
echo "session.cookie_path: " . ini_get('session.cookie_path') . "<br>";
echo "session.cookie_domain: " . ini_get('session.cookie_domain') . "<br>";
echo "session.cookie_secure: " . (ini_get('session.cookie_secure') ? 'Sim' : 'Não') . "<br>";
echo "session.cookie_httponly: " . (ini_get('session.cookie_httponly') ? 'Sim' : 'Não') . "<br>";

echo "<h2>5. Teste de Persistência</h2>";
if ($_SESSION['contador'] > 1) {
    echo "✅ A sessão está persistindo! (Você acessou esta página " . $_SESSION['contador'] . " vezes)<br>";
} else {
    echo "⚠️ Primeira visita ou sessão não está persistindo<br>";
    echo "Recarregue a página para testar a persistência<br>";
}

echo "<h2>6. Cookies</h2>";
echo "Cookies enviados pelo navegador:<br>";
echo "<pre>";
print_r($_COOKIE);
echo "</pre>";

echo "<hr>";
echo "<h2>Ações:</h2>";
echo "<a href='" . $_SERVER['PHP_SELF'] . "'>Recarregar página</a> (o contador deve aumentar)<br>";
echo "<a href='fix_password.php'>Corrigir senha do admin</a><br>";
echo "<a href='debug.php'>Voltar ao Debug</a><br>";

// Teste de escrita em arquivo (para verificar permissões)
echo "<h2>7. Teste de Permissões de Escrita</h2>";
$testFile = __DIR__ . '/test_write.txt';
$testContent = "Teste de escrita - " . date('Y-m-d H:i:s');

if (@file_put_contents($testFile, $testContent)) {
    echo "✅ Permissão de escrita OK<br>";
    @unlink($testFile); // Remove o arquivo de teste
} else {
    echo "❌ Sem permissão de escrita no diretório<br>";
}

// Verifica se o diretório de sessões tem permissão
$sessionPath = session_save_path();
if (empty($sessionPath)) {
    $sessionPath = sys_get_temp_dir();
}
echo "Diretório de sessões: " . $sessionPath . "<br>";
if (is_writable($sessionPath)) {
    echo "✅ Diretório de sessões tem permissão de escrita<br>";
} else {
    echo "❌ Diretório de sessões SEM permissão de escrita<br>";
}
