<?php
/**
 * Script para adicionar a tabela password_resets
 */

require_once 'config/config.php';
require_once 'app/autoload.php';

echo "<h1>Adicionando Tabela de Recuperação de Senha</h1>";
echo "<hr>";

try {
    $db = Database::getInstance();
    
    // Verifica se a tabela já existe
    $sql = "SHOW TABLES LIKE 'password_resets'";
    $stmt = $db->query($sql);
    $exists = $stmt->fetch();
    
    if ($exists) {
        echo "✅ A tabela password_resets já existe!<br>";
    } else {
        echo "⚠️ Tabela password_resets não encontrada. Criando...<br>";
        
        // Cria a tabela
        $sql = "CREATE TABLE password_resets (
            id INT PRIMARY KEY AUTO_INCREMENT,
            email VARCHAR(255) NOT NULL,
            token VARCHAR(255) NOT NULL,
            expires_at DATETIME NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_token (token),
            INDEX idx_email (email)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
        
        $db->query($sql);
        
        echo "✅ Tabela password_resets criada com sucesso!<br>";
    }
    
    // Verifica se foi criada corretamente
    $sql = "DESCRIBE password_resets";
    $stmt = $db->query($sql);
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($columns) > 0) {
        echo "<br><strong>Estrutura da tabela:</strong><br>";
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>Campo</th><th>Tipo</th><th>Nulo</th><th>Chave</th></tr>";
        foreach ($columns as $col) {
            echo "<tr>";
            echo "<td>{$col['Field']}</td>";
            echo "<td>{$col['Type']}</td>";
            echo "<td>{$col['Null']}</td>";
            echo "<td>{$col['Key']}</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        echo "<br><div style='background: #d4edda; color: #155724; padding: 10px; border-radius: 5px;'>";
        echo "<strong>✅ SUCESSO!</strong><br>";
        echo "A tabela de recuperação de senha está pronta para uso!";
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "❌ Erro: " . $e->getMessage() . "<br>";
}

echo "<hr>";
echo "<h2>Links:</h2>";
echo "1. <a href='" . BASE_PATH . "/login'>Ir para Login</a><br>";
echo "2. <a href='" . BASE_PATH . "/esqueci-senha'>Testar Recuperação de Senha</a><br>";
echo "3. <a href='" . BASE_PATH . "/debug.php'>Voltar ao Debug</a><br>";
