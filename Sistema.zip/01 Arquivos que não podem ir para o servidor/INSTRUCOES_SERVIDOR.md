
# Instruções para Corrigir Erro 403 no Sistema

## Problema
A página `/sistema/logs` está retornando erro 403 Forbidden.

## SOLUÇÃO RÁPIDA (Execute primeiro)

### Opção 1: Acesso Direto
Acesse através do arquivo direto:
```
https://construtorakellesduarte.com.br/sistema/logs.php
```

### Opção 2: Substituir .htaccess
```bash
cd /home/construtorakelle/public_html/sistema/
mv .htaccess .htaccess_backup
cp .htaccess_permissive .htaccess
```

### Opção 3: Execute o script de correção
```bash
php fix_logs_403.php
```

## Soluções

### 1. Executar Script de Instalação
Execute o seguinte comando no servidor para criar a tabela de logs:
```bash
php install_logs.php
```

### 2. Verificar Permissões de Arquivos
Certifique-se de que os seguintes diretórios tenham permissão 755:
```bash
chmod -R 755 app/
chmod -R 755 views/
chmod -R 755 config/
```

### 3. Verificar Arquivo .htaccess
O arquivo `.htaccess` foi simplificado. Se ainda houver problemas:

1. Faça backup do .htaccess atual
2. Use a versão simplificada fornecida
3. Se necessário, remova temporariamente o .htaccess para teste

### 4. Testar Acesso
Use os seguintes arquivos para teste:

1. `/sistema/logs_test.php` - Teste básico de acesso
2. `/sistema/test_logs.php` - Teste completo do sistema de logs

### 5. Verificar no Servidor

#### Via SSH:
```bash
# Verificar se a tabela existe
mysql -u construtorakelle_sistema -p construtorakelle_sistema -e "SHOW TABLES LIKE 'logs_acesso';"

# Verificar permissões
ls -la app/controllers/LogController.php
ls -la views/logs/index.php
```

### 6. Limpar Cache do Navegador
Após as correções:
1. Limpe o cache do navegador (Ctrl+F5)
2. Teste em modo anônimo/privado
3. Teste em outro navegador

### 7. Verificar Logs de Erro do Apache
```bash
tail -f /var/log/apache2/error.log
# ou
tail -f /home/construtorakelle/logs/error_log
```

## Arquivos Modificados
- `.htaccess` - Simplificado para evitar bloqueios
- `views/logs/index.php` - Corrigido cabeçalho e URLs
- Removidos `.htaccess` de `app/` e `views/`

## Arquivos Criados
- `install_logs.php` - Script para criar tabela
- `test_logs.php` - Script de teste completo
- `logs_test.php` - Teste básico de acesso
- `database/create_logs_table.sql` - SQL para criar tabela

## Importante
- Apenas administradores (nivel_acesso_id = 1) podem acessar logs
- A tabela `logs_acesso` precisa existir no banco de dados
- Não adicione .htaccess nos diretórios app/ e views/

## Contato para Suporte
Se o problema persistir após seguir estas instruções, verifique:
1. Versão do PHP (mínimo 7.4)
2. Módulo mod_rewrite do Apache está ativo
3. AllowOverride está configurado como All no Apache
