<?php
/**
 * Script para corrigir a senha do administrador
 */

require_once 'config/config.php';
require_once 'app/autoload.php';

echo "<h1>Correção de Senha do Administrador</h1>";
echo "<hr>";

try {
    $db = Database::getInstance();
    
    // Nova senha
    $novaSenha = 'Admin@2024';
    $senhaHash = password_hash($novaSenha, PASSWORD_DEFAULT);
    
    echo "Hash gerado: " . substr($senhaHash, 0, 30) . "...<br>";
    
    echo "<h2>1. Atualizando senha do administrador...</h2>";
    
    // Atualiza a senha do admin
    $sql = "UPDATE usuarios SET senha = :senha WHERE email = 'admin@construtorakellesduarte.com.br'";
    $stmt = $db->prepare($sql);
    $stmt->execute(['senha' => $senhaHash]);
    
    if ($stmt->rowCount() > 0) {
        echo "✅ Senha atualizada com sucesso!<br>";
    } else {
        echo "⚠️ Nenhum usuário foi atualizado. Vamos criar um novo admin...<br><br>";
        
        // Se não encontrou, cria um novo admin
        $sql = "INSERT INTO usuarios (nome_completo, email, senha, cpf, nivel_acesso_id, ativo) 
                VALUES (:nome, :email, :senha, :cpf, :nivel, :ativo)
                ON DUPLICATE KEY UPDATE senha = :senha2";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([
            'nome' => 'Administrador',
            'email' => 'admin@construtorakellesduarte.com.br',
            'senha' => $senhaHash,
            'senha2' => $senhaHash,
            'cpf' => '00000000000',
            'nivel' => 1,
            'ativo' => 1
        ]);
        
        echo "✅ Usuário admin criado/atualizado!<br>";
    }
    
    // Verifica se funcionou
    echo "<h2>2. Verificando...</h2>";
    
    $sql = "SELECT * FROM usuarios WHERE email = 'admin@construtorakellesduarte.com.br'";
    $stmt = $db->query($sql);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($admin) {
        echo "Usuário encontrado:<br>";
        echo "- ID: " . $admin['id'] . "<br>";
        echo "- Nome: " . $admin['nome_completo'] . "<br>";
        echo "- Email: " . $admin['email'] . "<br>";
        echo "- Nível: " . $admin['nivel_acesso_id'] . "<br>";
        echo "- Ativo: " . ($admin['ativo'] ? 'Sim' : 'Não') . "<br>";
        
        // Testa a nova senha
        $senhaOk = password_verify('Admin@2024', $admin['senha']);
        echo "- Senha 'Admin@2024': " . ($senhaOk ? '✅ FUNCIONANDO!' : '❌ Erro') . "<br>";
        
        if ($senhaOk) {
            echo "<br><div style='background: #d4edda; color: #155724; padding: 10px; border-radius: 5px;'>";
            echo "<strong>✅ SUCESSO!</strong><br>";
            echo "A senha foi corrigida. Você já pode fazer login com:<br>";
            echo "Email: admin@construtorakellesduarte.com.br<br>";
            echo "Senha: Admin@2024";
            echo "</div>";
        }
    } else {
        echo "❌ Erro: Usuário admin não encontrado<br>";
    }
    
    // Verifica se existem os níveis de acesso
    echo "<h2>3. Verificando níveis de acesso...</h2>";
    $sql = "SELECT * FROM niveis_acesso ORDER BY id";
    $stmt = $db->query($sql);
    $niveis = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($niveis) == 0) {
        echo "⚠️ Nenhum nível de acesso encontrado. Criando...<br>";
        
        $niveisData = [
            [1, 'Administrador', 'Acesso total ao sistema'],
            [2, 'Cliente', 'Acesso restrito aos próprios dados'],
            [3, 'Funcionário', 'Acesso intermediário'],
            [4, 'Financeiro', 'Acesso ao módulo financeiro'],
            [5, 'Encarregado de Obras', 'Acesso operacional']
        ];
        
        foreach ($niveisData as $nivel) {
            $sql = "INSERT IGNORE INTO niveis_acesso (id, nome, descricao) VALUES (?, ?, ?)";
            $stmt = $db->prepare($sql);
            $stmt->execute($nivel);
        }
        
        echo "✅ Níveis de acesso criados!<br>";
    } else {
        echo "✅ Níveis de acesso OK (" . count($niveis) . " níveis encontrados)<br>";
        foreach ($niveis as $nivel) {
            echo "- Nível " . $nivel['id'] . ": " . $nivel['nome'] . "<br>";
        }
    }
    
} catch (Exception $e) {
    echo "❌ Erro: " . $e->getMessage() . "<br>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}

echo "<hr>";
echo "<h2>Próximos passos:</h2>";
echo "1. <a href='" . BASE_PATH . "/login'>Fazer login</a><br>";
echo "2. <a href='" . BASE_PATH . "/debug.php'>Voltar ao Debug</a><br>";
echo "3. <a href='" . BASE_PATH . "/'>Acessar o sistema</a><br>";
