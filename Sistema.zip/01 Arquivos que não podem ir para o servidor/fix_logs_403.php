<?php
/**
 * Script para corrigir erro 403 na página de logs
 * Execute este arquivo no servidor para aplicar as correções
 */

echo "=== Correção do Erro 403 em /sistema/logs ===\n\n";

// 1. Criar arquivo .htaccess específico para permitir acesso
echo "1. Criando arquivo de permissão...\n";

$htaccess_content = '# Permite acesso aos arquivos PHP do sistema
<Files "*.php">
    Order Allow,Deny
    Allow from all
</Files>

# Permite que o sistema funcione corretamente
Options -Indexes +FollowSymLinks
AllowOverride All

# Garante que o mod_rewrite funcione
<IfModule mod_rewrite.c>
    RewriteEngine On
</IfModule>';

// Cria .htaccess temporário na raiz
file_put_contents('.htaccess_temp', $htaccess_content);
echo "✅ Arquivo .htaccess_temp criado\n\n";

// 2. Verifica estrutura de diretórios
echo "2. Verificando estrutura de diretórios...\n";

$dirs_to_check = [
    'app',
    'app/controllers',
    'app/core',
    'views',
    'views/logs',
    'views/layouts'
];

foreach ($dirs_to_check as $dir) {
    if (is_dir($dir)) {
        echo "✅ $dir existe\n";
        
        // Remove .htaccess se existir nesses diretórios
        $htaccess_file = $dir . '/.htaccess';
        if (file_exists($htaccess_file)) {
            unlink($htaccess_file);
            echo "   → Removido .htaccess de $dir\n";
        }
    } else {
        echo "❌ $dir NÃO existe - criando...\n";
        mkdir($dir, 0755, true);
    }
}

echo "\n3. Verificando arquivos essenciais...\n";

$files_to_check = [
    'index.php' => 'Arquivo principal',
    'app/controllers/LogController.php' => 'Controlador de Logs',
    'views/logs/index.php' => 'View de Logs',
    'app/core/Controller.php' => 'Controller Base',
    'app/core/Database.php' => 'Database',
    'app/core/Router.php' => 'Router'
];

foreach ($files_to_check as $file => $desc) {
    if (file_exists($file)) {
        echo "✅ $desc existe\n";
    } else {
        echo "❌ $desc NÃO encontrado em $file\n";
    }
}

// 4. Cria link simbólico alternativo
echo "\n4. Criando acesso alternativo...\n";

$alternate_access = '<?php
// Acesso alternativo para logs
$_SERVER["REQUEST_URI"] = "/logs";
require_once "index.php";
';

file_put_contents('logs_access.php', $alternate_access);
echo "✅ Arquivo logs_access.php criado\n";

// 5. Ajusta permissões
echo "\n5. Ajustando permissões...\n";

$dirs_to_chmod = ['app', 'views', 'config', 'database'];
foreach ($dirs_to_chmod as $dir) {
    if (is_dir($dir)) {
        chmod($dir, 0755);
        echo "✅ Permissão 755 aplicada em $dir\n";
    }
}

// 6. Testa conexão com banco
echo "\n6. Testando conexão com banco de dados...\n";

require_once 'config/config.php';
require_once 'app/core/Database.php';

try {
    $db = Database::getInstance();
    
    // Verifica se tabela logs_acesso existe
    $result = $db->fetchOne("SHOW TABLES LIKE 'logs_acesso'");
    if ($result) {
        echo "✅ Tabela logs_acesso existe\n";
        
        $count = $db->count('logs_acesso');
        echo "✅ Total de logs: $count\n";
    } else {
        echo "❌ Tabela logs_acesso NÃO existe\n";
        echo "   Execute: php install_logs.php\n";
    }
} catch (Exception $e) {
    echo "❌ Erro de conexão: " . $e->getMessage() . "\n";
}

echo "\n=== Instruções Finais ===\n";
echo "1. Renomeie .htaccess para .htaccess_old:\n";
echo "   mv .htaccess .htaccess_old\n\n";

echo "2. Renomeie .htaccess_temp para .htaccess:\n";
echo "   mv .htaccess_temp .htaccess\n\n";

echo "3. Teste os seguintes URLs:\n";
echo "   - " . BASE_URL . "logs.php (acesso direto)\n";
echo "   - " . BASE_URL . "logs_access.php (acesso alternativo)\n";
echo "   - " . BASE_URL . "logs (rota normal)\n\n";

echo "4. Se ainda houver erro 403, execute no servidor:\n";
echo "   sudo a2enmod rewrite\n";
echo "   sudo service apache2 restart\n\n";

echo "5. Verifique o arquivo de configuração do Apache:\n";
echo "   - AllowOverride deve estar como 'All'\n";
echo "   - O módulo mod_rewrite deve estar ativo\n\n";

echo "✅ Script concluído!\n";
?>
