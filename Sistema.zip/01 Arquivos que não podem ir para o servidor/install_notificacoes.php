<?php
require_once 'config/config.php';
require_once 'app/core/Database.php';

try {
    $db = Database::getInstance();
    
    echo "Criando tabela de notificações...\n";
    
    // SQL para criar a tabela
    $sql = "CREATE TABLE IF NOT EXISTS `notificacoes` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `usuario_id` int(11) NOT NULL,
        `titulo` varchar(255) NOT NULL,
        `mensagem` text NOT NULL,
        `tipo` enum('sistema','alerta','fatura','manutencao','obra') DEFAULT 'sistema',
        `link` varchar(255) DEFAULT NULL,
        `lida` tinyint(1) DEFAULT 0,
        `data_leitura` datetime DEFAULT NULL,
        `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
        `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `idx_usuario_id` (`usuario_id`),
        KEY `idx_lida` (`lida`),
        KEY `idx_created_at` (`created_at`),
        KEY `idx_tipo` (`tipo`),
        KEY `idx_usuario_lida` (`usuario_id`, `lida`),
        CONSTRAINT `fk_notificacoes_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    $db->execute($sql);
    echo "Tabela de notificações criada com sucesso!\n";
    
    // Inserir notificação de boas-vindas para todos os usuários
    echo "Inserindo notificações de boas-vindas...\n";
    
    $usuarios = $db->fetchAll("SELECT id FROM usuarios WHERE status = 'ativo'");
    $count = 0;
    
    foreach ($usuarios as $usuario) {
        // Verifica se já existe notificação de boas-vindas
        $existe = $db->fetchOne(
            "SELECT id FROM notificacoes WHERE usuario_id = :usuario_id AND titulo = 'Bem-vindo ao Sistema'",
            ['usuario_id' => $usuario['id']]
        );
        
        if (!$existe) {
            $data = [
                'usuario_id' => $usuario['id'],
                'titulo' => 'Bem-vindo ao Sistema',
                'mensagem' => 'Seja bem-vindo ao sistema de gerenciamento da Construtora Kelles Duarte. Aqui você poderá acompanhar todas as suas informações, faturas, manutenções e muito mais.',
                'tipo' => 'sistema',
                'lida' => 0,
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            if ($db->insert('notificacoes', $data)) {
                $count++;
            }
        }
    }
    
    echo "Foram criadas $count notificações de boas-vindas.\n";
    
    // Criar notificações para faturas vencidas
    echo "Verificando faturas vencidas...\n";
    
    $faturasVencidas = $db->fetchAll(
        "SELECT f.*, i.usuario_id, u.nome_completo 
         FROM faturas f
         JOIN imoveis i ON f.imovel_id = i.id
         JOIN usuarios u ON i.usuario_id = u.id
         WHERE f.status = 'pendente' 
         AND f.data_vencimento < CURDATE()
         AND NOT EXISTS (
             SELECT 1 FROM notificacoes n 
             WHERE n.usuario_id = i.usuario_id 
             AND n.tipo = 'fatura'
             AND n.link = CONCAT('/faturas/ver/', f.id)
         )"
    );
    
    $countFaturas = 0;
    foreach ($faturasVencidas as $fatura) {
        $data = [
            'usuario_id' => $fatura['usuario_id'],
            'titulo' => 'Fatura Vencida',
            'mensagem' => "Você possui uma fatura vencida no valor de R$ " . number_format($fatura['valor'], 2, ',', '.') . 
                         " com vencimento em " . date('d/m/Y', strtotime($fatura['data_vencimento'])) . ".",
            'tipo' => 'fatura',
            'link' => '/faturas/ver/' . $fatura['id'],
            'lida' => 0,
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        if ($db->insert('notificacoes', $data)) {
            $countFaturas++;
        }
    }
    
    echo "Foram criadas $countFaturas notificações de faturas vencidas.\n";
    
    echo "\n✅ Instalação do módulo de notificações concluída com sucesso!\n";
    echo "Acesse /sistema/notificacoes para visualizar as notificações.\n";
    
} catch (Exception $e) {
    echo "❌ Erro ao instalar módulo de notificações: " . $e->getMessage() . "\n";
    exit(1);
}
