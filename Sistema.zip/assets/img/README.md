# Diretório de Imagens

Este diretório contém as imagens do sistema.

## Estrutura:

- `logo.png` - Logo da empresa (recomendado: 200x200px)
- `favicon.ico` - Ícone do site (32x32px)
- `user-default.png` - Avatar padrão do usuário (128x128px)
- `logo-white.png` - Logo branca para fundos escuros
- `no-image.png` - Imagem padrão quando não há imagem

## Subdiretórios:

- `/icons/` - Ícones do sistema
- `/backgrounds/` - Imagens de fundo
- `/uploads/` - Imagens enviadas pelos usuários (movido para /uploads/)

## Formatos recomendados:

- PNG para logos e ícones (transparência)
- JPG para fotos
- SVG para ícones vetoriais
- WEBP para melhor performance (com fallback)

## Tamanhos recomendados:

- Logo principal: 200x200px
- Logo navbar: 150x40px
- Avatar usuário: 128x128px
- Thumbnails: 300x300px
- Imagens de imóveis: 800x600px
- Banners: 1920x400px
