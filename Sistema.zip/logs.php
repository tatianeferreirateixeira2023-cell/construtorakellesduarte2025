<?php
// Arquivo de redirecionamento direto para logs
session_start();
require_once 'config/config.php';
require_once 'app/autoload.php';

// Verifica se usuário está logado
if (!isset($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . 'login');
    exit;
}

// Verifica se é admin
require_once 'app/core/Database.php';
$db = Database::getInstance();
$user = $db->fetchOne("SELECT nivel_acesso_id FROM usuarios WHERE id = :id", ['id' => $_SESSION['user_id']]);

if (!$user || $user['nivel_acesso_id'] != NIVEL_ADMIN) {
    $_SESSION['flash'] = [
        'type' => 'danger',
        'message' => 'Acesso negado. Apenas administradores podem visualizar logs.'
    ];
    header('Location: ' . BASE_URL);
    exit;
}

// Carrega o controlador de logs diretamente
require_once 'app/controllers/LogController.php';
$controller = new LogController();

// Verifica qual ação executar baseado na URL
$action = $_GET['action'] ?? 'index';

// Se for POST e action=limpar, chama o método limpar
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'limpar') {
    $controller->limpar();
} else {
    switch($action) {
        case 'exportar':
            $controller->exportar();
            break;
        default:
            $controller->index();
            break;
    }
}
?>
