<?php
// Arquivo de teste simples para verificar acesso
echo "<!DOCTYPE html>";
echo "<html>";
echo "<head><title>Teste de Logs</title></head>";
echo "<body>";
echo "<h1>Teste de Acesso - Logs</h1>";
echo "<p>Se você está vendo esta página, o acesso básico está funcionando.</p>";

// Informações do servidor
echo "<h2>Informações do Servidor:</h2>";
echo "<ul>";
echo "<li>PHP Version: " . phpversion() . "</li>";
echo "<li>Server Software: " . $_SERVER['SERVER_SOFTWARE'] . "</li>";
echo "<li>Document Root: " . $_SERVER['DOCUMENT_ROOT'] . "</li>";
echo "<li>Script Name: " . $_SERVER['SCRIPT_NAME'] . "</li>";
echo "<li>Request URI: " . $_SERVER['REQUEST_URI'] . "</li>";
echo "</ul>";

// Verifica arquivos
echo "<h2>Verificação de Arquivos:</h2>";
echo "<ul>";

$files_to_check = [
    'index.php' => 'Arquivo principal',
    'config/config.php' => 'Configuração',
    'app/controllers/LogController.php' => 'Controlador de Logs',
    'views/logs/index.php' => 'View de Logs',
    '.htaccess' => 'Arquivo .htaccess'
];

foreach ($files_to_check as $file => $desc) {
    if (file_exists($file)) {
        echo "<li>✅ $desc ($file) - EXISTE</li>";
    } else {
        echo "<li>❌ $desc ($file) - NÃO ENCONTRADO</li>";
    }
}
echo "</ul>";

// Verifica permissões
echo "<h2>Permissões de Diretórios:</h2>";
echo "<ul>";

$dirs_to_check = ['app', 'views', 'views/logs', 'app/controllers'];

foreach ($dirs_to_check as $dir) {
    if (is_dir($dir)) {
        $perms = substr(sprintf('%o', fileperms($dir)), -4);
        echo "<li>$dir - Permissões: $perms";
        if (is_readable($dir)) {
            echo " (Leitura: ✅)";
        } else {
            echo " (Leitura: ❌)";
        }
        echo "</li>";
    } else {
        echo "<li>$dir - NÃO É UM DIRETÓRIO</li>";
    }
}
echo "</ul>";

echo "<h2>Links para Teste:</h2>";
echo "<ul>";
echo '<li><a href="/sistema/">Home</a></li>';
echo '<li><a href="/sistema/logs">Logs (via rota)</a></li>';
echo '<li><a href="/sistema/test_logs.php">Test Logs (arquivo direto)</a></li>';
echo '</ul>';

echo "</body>";
echo "</html>";
?>
